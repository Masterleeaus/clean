<?php

return ['name' => 'FSMRepairTemplate'];
