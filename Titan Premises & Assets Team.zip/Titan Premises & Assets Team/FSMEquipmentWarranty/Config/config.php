<?php

return ['name' => 'FSMEquipmentWarranty'];
