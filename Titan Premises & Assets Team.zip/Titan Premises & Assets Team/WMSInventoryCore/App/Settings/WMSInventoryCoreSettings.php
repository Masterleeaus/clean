<?php

namespace Modules\WMSInventoryCore\App\Settings;

use App\Services\Settings\BaseModuleSettings;

class WMSInventoryCoreSettings extends BaseModuleSettings
{
    protected string $module = 'WMSInventoryCore';

    /**
     * Get module display name
     */
    public function getModuleName(): string
    {
        return __('Inventory Management Settings');
    }

    /**
     * Get module description
     */
    public function getModuleDescription(): string
    {
        return __('Configure inventory transfers, adjustments, and stock control settings');
    }

    /**
     * Get module icon
     */
    public function getModuleIcon(): string
    {
        return 'bx bx-package';
    }

    /**
     * Define module settings
     *
     * These settings are actively used by WMSInventoryCoreSettingsService:
     * - transfer_prefix: Used for generating transfer codes
     * - allow_negative_stock: Checked in AdjustmentController.approve() and TransferController.ship()
     * - require_approval_for_adjustments: Controls approval workflow UI in AdjustmentController
     * - require_reason_for_adjustments: Dynamic validation in AdjustmentController.store()
     * - require_approval_for_transfers: Controls approval workflow UI in TransferController
     */
    protected function define(): array
    {
        return [
            'transfers' => [
                'transfer_prefix' => [
                    'type' => 'text',
                    'label' => __('Transfer Code Prefix'),
                    'help' => __('Prefix for transfer codes (e.g., TRN-, TR-, etc.)'),
                    'default' => 'TRN-',
                    'validation' => 'nullable|string|max:10',
                ],
                'require_approval_for_transfers' => [
                    'type' => 'toggle',
                    'label' => __('Require Approval for Transfers'),
                    'help' => __('All inventory transfers must be approved before shipping'),
                    'default' => false,
                    'validation' => 'boolean',
                ],
            ],

            'adjustments' => [
                'require_approval_for_adjustments' => [
                    'type' => 'toggle',
                    'label' => __('Require Approval for Adjustments'),
                    'help' => __('All inventory adjustments must be approved'),
                    'default' => true,
                    'validation' => 'boolean',
                ],
                'require_reason_for_adjustments' => [
                    'type' => 'toggle',
                    'label' => __('Require Reason for Adjustments'),
                    'help' => __('Make reason mandatory for inventory adjustments'),
                    'default' => true,
                    'validation' => 'boolean',
                ],
            ],

            'stock_control' => [
                'allow_negative_stock' => [
                    'type' => 'toggle',
                    'label' => __('Allow Negative Stock'),
                    'help' => __('Allow stock levels to go below zero during adjustments and transfers'),
                    'default' => false,
                    'validation' => 'boolean',
                ],
            ],
        ];
    }

    /**
     * Get settings sections for the view
     */
    public function getSections(): array
    {
        return [
            [
                'id' => 'transfers',
                'title' => __('Transfer Settings'),
                'icon' => 'bx bx-transfer',
                'description' => __('Configure transfer-related settings'),
                'fields' => [
                    [
                        'name' => 'transfer_prefix',
                        'label' => __('Transfer Code Prefix'),
                        'type' => 'text',
                        'default' => 'TRN-',
                        'required' => false,
                        'help' => __('Prefix for transfer codes (e.g., TRN-, TR-, etc.)'),
                    ],
                    [
                        'name' => 'require_approval_for_transfers',
                        'label' => __('Require Approval for Transfers'),
                        'type' => 'switch',
                        'default' => false,
                        'help' => __('All inventory transfers must be approved before shipping'),
                    ],
                ],
            ],
            [
                'id' => 'adjustments',
                'title' => __('Adjustment Settings'),
                'icon' => 'bx bx-edit-alt',
                'description' => __('Configure adjustment-related settings'),
                'fields' => [
                    [
                        'name' => 'require_approval_for_adjustments',
                        'label' => __('Require Approval for Adjustments'),
                        'type' => 'switch',
                        'default' => true,
                        'help' => __('All inventory adjustments must be approved'),
                    ],
                    [
                        'name' => 'require_reason_for_adjustments',
                        'label' => __('Require Reason for Adjustments'),
                        'type' => 'switch',
                        'default' => true,
                        'help' => __('Make reason mandatory for inventory adjustments'),
                    ],
                ],
            ],
            [
                'id' => 'stock_control',
                'title' => __('Stock Control Settings'),
                'icon' => 'bx bx-package',
                'description' => __('Configure stock control settings'),
                'fields' => [
                    [
                        'name' => 'allow_negative_stock',
                        'label' => __('Allow Negative Stock'),
                        'type' => 'switch',
                        'default' => false,
                        'help' => __('Allow stock levels to go below zero during adjustments and transfers'),
                    ],
                ],
            ],
        ];
    }

    /**
     * Get validation rules
     */
    public function getValidationRules(): array
    {
        return [
            'transfer_prefix' => 'nullable|string|max:10',
            'require_approval_for_transfers' => 'boolean',
            'require_approval_for_adjustments' => 'boolean',
            'require_reason_for_adjustments' => 'boolean',
            'allow_negative_stock' => 'boolean',
        ];
    }

    /**
     * Get default values
     */
    public function getDefaults(): array
    {
        return [
            'transfer_prefix' => 'TRN-',
            'require_approval_for_transfers' => false,
            'require_approval_for_adjustments' => true,
            'require_reason_for_adjustments' => true,
            'allow_negative_stock' => false,
        ];
    }
}
