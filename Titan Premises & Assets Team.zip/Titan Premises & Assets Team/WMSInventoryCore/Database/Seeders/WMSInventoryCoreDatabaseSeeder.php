<?php

namespace Modules\WMSInventoryCore\Database\Seeders;

use Illuminate\Database\Seeder;

class WMSInventoryCoreDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Essential seeders - always run
        $this->call([
            WMSInventoryCorePermissionSeeder::class,
            WMSInventoryCoreSettingsSeeder::class,
            AdjustmentTypesSeeder::class,
        ]);

        // Only run demo seeders in local/demo/testing environment
        if (app()->environment(['local', 'demo', 'testing'])) {
            $this->call([
                SampleDataSeeder::class,
            ]);
        }
    }
}
