<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('inventories', function (Blueprint $table) {
            $table->id();
            $table->foreignId('warehouse_id')->constrained('warehouses')->onDelete('cascade');
            $table->foreignId('core_product_id')->constrained('core_products')->onDelete('cascade');
            $table->integer('stock_level');
            $table->foreignId('unit_id')->constrained('units')->onDelete('cascade');
            $table->softDeletes();
            $table->timestamps();

            $table->unique(['warehouse_id', 'core_product_id'], 'warehouse_product_unique');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('inventory');
    }
};
