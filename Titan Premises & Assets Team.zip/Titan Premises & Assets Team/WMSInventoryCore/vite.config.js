import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import { readdirSync, statSync } from 'fs';
import { join,relative,dirname } from 'path';
import { fileURLToPath } from 'url';

export default defineConfig({
    build: {
        outDir: '../../public/build-wmsinventorycore',
        emptyOutDir: true,
        manifest: true,
    },
    plugins: [
        laravel({
            publicDirectory: '../../public',
            buildDirectory: 'build-wmsinventorycore',
            input: [
                __dirname + '/resources/assets/sass/app.scss',
                __dirname + '/resources/assets/js/app.js',
                // Dashboard
                __dirname + '/resources/assets/js/wms-inventory-dashboard.js',
                // Products
                __dirname + '/resources/assets/js/wms-inventory-products.js',
                __dirname + '/resources/assets/js/wms-inventory-product-form.js',
                __dirname + '/resources/assets/js/wms-inventory-product-show.js',
                // Warehouses
                __dirname + '/resources/assets/js/wms-inventory-warehouses.js',
                __dirname + '/resources/assets/js/wms-inventory-warehouse-form.js',
                __dirname + '/resources/assets/js/wms-inventory-warehouse-details.js',
                // Categories & Units
                __dirname + '/resources/assets/js/wms-inventory-categories.js',
                __dirname + '/resources/assets/js/wms-inventory-units.js',
                // Adjustments
                __dirname + '/resources/assets/js/wms-inventory-adjustment-types.js',
                __dirname + '/resources/assets/js/wms-inventory-adjustments.js',
                __dirname + '/resources/assets/js/wms-inventory-adjustment-form.js',
                __dirname + '/resources/assets/js/wms-inventory-adjustment-show.js',
                // Transfers
                __dirname + '/resources/assets/js/wms-inventory-transfers.js',
                __dirname + '/resources/assets/js/wms-inventory-transfer-form.js',
                __dirname + '/resources/assets/js/wms-inventory-transfer-show.js',
                // Purchases
                __dirname + '/resources/assets/js/wms-inventory-purchases.js',
                __dirname + '/resources/assets/js/wms-inventory-purchase-form.js',
                __dirname + '/resources/assets/js/wms-inventory-purchase-show.js',
                __dirname + '/resources/assets/js/wms-inventory-purchase-edit.js',
                __dirname + '/resources/assets/js/wms-inventory-purchase-receive.js',
                // Sales
                __dirname + '/resources/assets/js/wms-inventory-sales.js',
                __dirname + '/resources/assets/js/wms-inventory-sale-form.js',
                __dirname + '/resources/assets/js/wms-inventory-sale-show.js',
                __dirname + '/resources/assets/js/wms-inventory-sale-fulfill.js',
                // Vendors
                __dirname + '/resources/assets/js/wms-inventory-vendors.js',
                __dirname + '/resources/assets/js/wms-inventory-vendor-form.js',
                // Reports
                __dirname + '/resources/assets/js/wms-inventory-reports.js'
            ],
            refresh: true,
        }),
    ],
});
