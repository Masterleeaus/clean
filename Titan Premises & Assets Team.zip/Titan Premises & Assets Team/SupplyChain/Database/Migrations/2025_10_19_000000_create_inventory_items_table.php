<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        if (!Schema::hasTable('inventory_items')) {
        Schema::create('inventory_items', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('sku')->nullable()->unique();
            $table->string('unit')->nullable();
            $table->softDeletes();
            $table->timestamps();
        });
        }
    }
    public function down(): void {
        Schema::dropIfExists('inventory_items');
    }
};
