<?php

return [
    'name' => 'FSMEquipment',
];
