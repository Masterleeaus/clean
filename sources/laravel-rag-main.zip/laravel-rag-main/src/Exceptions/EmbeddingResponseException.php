<?php

declare(strict_types=1);

namespace Moneo\LaravelRag\Exceptions;

class EmbeddingResponseException extends EmbeddingException
{
}
