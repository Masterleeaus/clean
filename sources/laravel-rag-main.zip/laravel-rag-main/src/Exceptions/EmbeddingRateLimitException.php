<?php

declare(strict_types=1);

namespace Moneo\LaravelRag\Exceptions;

class EmbeddingRateLimitException extends EmbeddingException
{
}
