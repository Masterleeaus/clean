<?php

namespace App\Models;

use Database\Factories\CustomerLoyaltyAccountFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable([
    'business_id',
    'customer_id',
    'loyalty_program_id',
    'current_stamps',
    'total_stamps_earned',
    'total_rewards_redeemed',
])]
class CustomerLoyaltyAccount extends Model
{
    /** @use HasFactory<CustomerLoyaltyAccountFactory> */
    use HasFactory;

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function loyaltyProgram(): BelongsTo
    {
        return $this->belongsTo(LoyaltyProgram::class);
    }

    public function isRewardEligible(): bool
    {
        $program = $this->loyaltyProgram;

        return $program !== null && $this->current_stamps >= $program->stamps_required;
    }

    public function scopeForBusiness(Builder $query, Business|int $business): Builder
    {
        return $query->where('business_id', $business instanceof Business ? $business->id : $business);
    }

    protected function casts(): array
    {
        return [
            'current_stamps' => 'integer',
            'total_stamps_earned' => 'integer',
            'total_rewards_redeemed' => 'integer',
        ];
    }
}
