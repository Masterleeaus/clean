<?php

namespace App\Models;

use Database\Factories\BusinessFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable([
    'owner_user_id',
    'name',
    'slug',
    'owner_name',
    'owner_whatsapp',
    'business_type',
    'public_qr_token',
])]
class Business extends Model
{
    /** @use HasFactory<BusinessFactory> */
    use HasFactory;

    public function owner(): BelongsTo
    {
        return $this->belongsTo(User::class, 'owner_user_id');
    }

    public function loyaltyPrograms(): HasMany
    {
        return $this->hasMany(LoyaltyProgram::class);
    }

    public function branches(): HasMany
    {
        return $this->hasMany(Branch::class);
    }

    public function productServices(): HasMany
    {
        return $this->hasMany(ProductService::class);
    }

    public function customers(): HasMany
    {
        return $this->hasMany(Customer::class);
    }

    public function loyaltyAccounts(): HasMany
    {
        return $this->hasMany(CustomerLoyaltyAccount::class);
    }

    public function checkIns(): HasMany
    {
        return $this->hasMany(CustomerCheckIn::class);
    }

    public function stampTransactions(): HasMany
    {
        return $this->hasMany(StampTransaction::class);
    }

    public function rewardRedemptions(): HasMany
    {
        return $this->hasMany(RewardRedemption::class);
    }

    public function feedback(): HasMany
    {
        return $this->hasMany(CustomerFeedback::class);
    }

    public function scopeOwnedBy(Builder $query, User|int $owner): Builder
    {
        return $query->where('owner_user_id', $owner instanceof User ? $owner->id : $owner);
    }

    public function scopeAccessibleTo(Builder $query, User $user): Builder
    {
        if ($user->isSystemManager() || $user->isSystemAdmin()) {
            return $query;
        }

        $scopedBusinessIds = $user->scopedBusinessIds();
        $scopedBranchIds = $user->scopedBranchIds();

        if (! $user->isOwner() && (! $user->isBranchManager() || ($scopedBusinessIds === [] && $scopedBranchIds === []))) {
            return $query->whereRaw('1 = 0');
        }

        return $query->where(function (Builder $query) use ($user, $scopedBusinessIds, $scopedBranchIds): void {
            if ($user->isOwner()) {
                $query->where('owner_user_id', $user->id);
            }

            if ($user->isOwner() && $scopedBusinessIds !== []) {
                $query->orWhereIn('id', $scopedBusinessIds);
            }

            if ($user->isBranchManager() && $scopedBusinessIds !== []) {
                $query->orWhereIn('id', $scopedBusinessIds);
            }

            if ($user->isBranchManager() && $scopedBranchIds !== []) {
                $query->orWhereHas('branches', fn (Builder $branchQuery) => $branchQuery->whereIn('id', $scopedBranchIds));
            }
        });
    }
}
