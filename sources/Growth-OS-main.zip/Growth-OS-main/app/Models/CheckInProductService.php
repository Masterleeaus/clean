<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable([
    'business_id',
    'branch_id',
    'customer_id',
    'customer_check_in_id',
    'product_service_id',
    'captured_by_user_id',
    'quantity',
    'price_at_capture',
    'total_amount',
    'capture_type',
    'capture_source',
    'capture_reference',
    'notes',
])]
class CheckInProductService extends Model
{
    use HasFactory;

    public function checkIn(): BelongsTo
    {
        return $this->belongsTo(CustomerCheckIn::class, 'customer_check_in_id');
    }

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function productService(): BelongsTo
    {
        return $this->belongsTo(ProductService::class);
    }

    public function capturedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'captured_by_user_id');
    }

    protected function casts(): array
    {
        return [
            'quantity' => 'integer',
            'price_at_capture' => 'decimal:2',
            'total_amount' => 'decimal:2',
        ];
    }
}
