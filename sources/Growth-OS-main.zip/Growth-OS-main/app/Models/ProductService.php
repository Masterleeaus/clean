<?php

namespace App\Models;

use Database\Factories\ProductServiceFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable([
    'business_id',
    'branch_id',
    'name',
    'category',
    'type',
    'price',
    'is_active',
    'review_status',
    'review_flags',
    'review_note',
    'archived_at',
])]
class ProductService extends Model
{
    /** @use HasFactory<ProductServiceFactory> */
    use HasFactory;

    public const DEFAULT_CATEGORIES = [
        'Makanan',
        'Minuman',
        'Set Kombo',
        'Add-on',
    ];

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function captures(): HasMany
    {
        return $this->hasMany(CheckInProductService::class);
    }

    public function reviewAlerts(): HasMany
    {
        return $this->hasMany(ProductServiceReviewAlert::class);
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    public function scopeVisibleForBranch(Builder $query, Branch $branch): Builder
    {
        return $query
            ->where('business_id', $branch->business_id)
            ->where(function (Builder $query) use ($branch): void {
                $query->whereNull('branch_id')
                    ->orWhere('branch_id', $branch->id);
            });
    }

    /**
     * @param  iterable<int, string|null>  $existingCategories
     */
    public static function normalizeCategory(?string $category, iterable $existingCategories = []): string
    {
        $category = trim(preg_replace('/\s+/', ' ', (string) $category) ?? '');

        if ($category === '') {
            return 'Uncategorized';
        }

        $knownCategories = collect(self::DEFAULT_CATEGORIES)
            ->merge($existingCategories)
            ->filter()
            ->map(fn (string $known): string => trim($known))
            ->unique(fn (string $known): string => mb_strtolower($known))
            ->values();

        $matched = $knownCategories->first(
            fn (string $known): bool => mb_strtolower($known) === mb_strtolower($category)
        );

        return $matched ?: $category;
    }

    /**
     * @return array<int, string>
     */
    public static function categoryOptionsFor(Business $business): array
    {
        $existing = $business->productServices()
            ->whereNotNull('category')
            ->pluck('category')
            ->all();

        return collect(self::DEFAULT_CATEGORIES)
            ->merge($existing)
            ->map(fn (?string $category): string => self::normalizeCategory($category))
            ->filter()
            ->unique(fn (string $category): string => mb_strtolower($category))
            ->sortBy(fn (string $category): string => str_pad((string) self::categorySortIndex($category), 2, '0', STR_PAD_LEFT).'|'.mb_strtolower($category))
            ->values()
            ->all();
    }

    public static function categorySortIndex(?string $category): int
    {
        $category = self::normalizeCategory($category);
        $index = collect(self::DEFAULT_CATEGORIES)
            ->search(fn (string $default): bool => mb_strtolower($default) === mb_strtolower($category));

        return $index === false ? 99 : (int) $index;
    }

    protected function casts(): array
    {
        return [
            'price' => 'decimal:2',
            'is_active' => 'boolean',
            'review_flags' => 'array',
            'archived_at' => 'datetime',
        ];
    }
}
