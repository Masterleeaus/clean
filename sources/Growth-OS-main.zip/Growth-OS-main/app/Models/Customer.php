<?php

namespace App\Models;

use Database\Factories\CustomerFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable([
    'business_id',
    'user_id',
    'name',
    'whatsapp_number',
    'birthday',
    'consent_promo',
])]
class Customer extends Model
{
    /** @use HasFactory<CustomerFactory> */
    use HasFactory;

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function loyaltyAccounts(): HasMany
    {
        return $this->hasMany(CustomerLoyaltyAccount::class);
    }

    public function checkIns(): HasMany
    {
        return $this->hasMany(CustomerCheckIn::class);
    }

    public function stampTransactions(): HasMany
    {
        return $this->hasMany(StampTransaction::class);
    }

    public function rewardRedemptions(): HasMany
    {
        return $this->hasMany(RewardRedemption::class);
    }

    public function feedback(): HasMany
    {
        return $this->hasMany(CustomerFeedback::class);
    }

    public function scopeForBusiness(Builder $query, Business|int $business): Builder
    {
        return $query->where('business_id', $business instanceof Business ? $business->id : $business);
    }

    public function scopePromoConsented(Builder $query): Builder
    {
        return $query->where('consent_promo', true);
    }

    protected function casts(): array
    {
        return [
            'birthday' => 'date',
            'consent_promo' => 'boolean',
        ];
    }
}
