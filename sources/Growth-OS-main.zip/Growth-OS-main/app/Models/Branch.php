<?php

namespace App\Models;

use Database\Factories\BranchFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable([
    'business_id',
    'manager_user_id',
    'name',
    'code',
    'address',
    'phone',
    'is_active',
    'check_in_cooldown_minutes',
])]
class Branch extends Model
{
    /** @use HasFactory<BranchFactory> */
    use HasFactory;

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function manager(): BelongsTo
    {
        return $this->belongsTo(User::class, 'manager_user_id');
    }

    public function checkIns(): HasMany
    {
        return $this->hasMany(CustomerCheckIn::class);
    }

    public function productServices(): HasMany
    {
        return $this->hasMany(ProductService::class);
    }

    public function scopeAccessibleTo(Builder $query, User $user): Builder
    {
        if ($user->isSystemManager() || $user->isSystemAdmin()) {
            return $query;
        }

        return $query->where(function (Builder $query) use ($user): void {
            if ($user->isOwner()) {
                $query->whereHas('business', fn (Builder $businessQuery) => $businessQuery->where('owner_user_id', $user->id));
            }

            $scopedBusinessIds = $user->scopedBusinessIds();
            $scopedBranchIds = $user->scopedBranchIds();

            if ($user->isOwner() && $scopedBusinessIds !== []) {
                $query->orWhereIn('business_id', $scopedBusinessIds);
            }

            if ($user->isBranchManager() && $scopedBranchIds !== []) {
                $query->orWhereIn('id', $scopedBranchIds);
            }
        });
    }

    protected function casts(): array
    {
        return [
            'is_active' => 'boolean',
            'check_in_cooldown_minutes' => 'integer',
        ];
    }
}
