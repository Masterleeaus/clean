<?php

namespace App\Models;

use Database\Factories\LoyaltyProgramFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable([
    'business_id',
    'name',
    'stamps_required',
    'reward_name',
    'reward_description',
    'welcome_stamp_enabled',
    'is_active',
])]
class LoyaltyProgram extends Model
{
    /** @use HasFactory<LoyaltyProgramFactory> */
    use HasFactory;

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function loyaltyAccounts(): HasMany
    {
        return $this->hasMany(CustomerLoyaltyAccount::class);
    }

    public function checkIns(): HasMany
    {
        return $this->hasMany(CustomerCheckIn::class);
    }

    public function stampTransactions(): HasMany
    {
        return $this->hasMany(StampTransaction::class);
    }

    public function rewardRedemptions(): HasMany
    {
        return $this->hasMany(RewardRedemption::class);
    }

    public function scopeActive(Builder $query): Builder
    {
        return $query->where('is_active', true);
    }

    protected function casts(): array
    {
        return [
            'stamps_required' => 'integer',
            'welcome_stamp_enabled' => 'boolean',
            'is_active' => 'boolean',
        ];
    }
}
