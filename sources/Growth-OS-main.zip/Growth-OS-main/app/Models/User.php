<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Database\Factories\UserFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Attributes\Hidden;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

#[Fillable(['name', 'email', 'password', 'role', 'secondary_role', 'access_scope'])]
#[Hidden(['password', 'remember_token'])]
class User extends Authenticatable
{
    public const ROLE_SYSTEM_MANAGER = 'system_manager';

    public const ROLE_SYSTEM_ADMIN = 'system_admin';

    public const ROLE_BUSINESS_OWNER = 'business_owner';

    public const ROLE_BRANCH_MANAGER = 'branch_manager';

    public const ROLE_CUSTOMER = 'customer';

    public const ROLE_ADMIN = self::ROLE_SYSTEM_ADMIN;

    public const ROLE_OWNER = self::ROLE_BUSINESS_OWNER;

    /** @use HasFactory<UserFactory> */
    use HasFactory, Notifiable;

    public function businesses(): HasMany
    {
        return $this->hasMany(Business::class, 'owner_user_id');
    }

    public function verifiedRewardRedemptions(): HasMany
    {
        return $this->hasMany(RewardRedemption::class, 'verified_by_user_id');
    }

    public function managedBranches(): HasMany
    {
        return $this->hasMany(Branch::class, 'manager_user_id');
    }

    public function isAdmin(): bool
    {
        return $this->hasRole(self::ROLE_SYSTEM_ADMIN) || $this->hasRole('admin');
    }

    public function isOwner(): bool
    {
        return $this->hasRole(self::ROLE_BUSINESS_OWNER) || $this->hasRole('owner');
    }

    public function isSystemManager(): bool
    {
        return $this->hasRole(self::ROLE_SYSTEM_MANAGER);
    }

    public function isSystemAdmin(): bool
    {
        return $this->isAdmin();
    }

    public function isBranchManager(): bool
    {
        return $this->hasRole(self::ROLE_BRANCH_MANAGER);
    }

    public function isCustomer(): bool
    {
        return $this->hasRole(self::ROLE_CUSTOMER);
    }

    public function hasRole(string $role): bool
    {
        return in_array($role, $this->roles(), true);
    }

    /**
     * @return array<int, string>
     */
    public function roles(): array
    {
        return array_values(array_filter(array_unique([
            $this->role,
            $this->secondaryRoleIsAllowed() ? $this->secondary_role : null,
        ])));
    }

    public function hasInternalCombinedAccess(): bool
    {
        return $this->isSystemManager() && $this->isSystemAdmin();
    }

    public function hasBusinessCombinedAccess(): bool
    {
        return $this->isOwner() && $this->isBranchManager();
    }

    public function dashboardRouteName(): string
    {
        if ($this->hasInternalCombinedAccess()) {
            return 'dashboards.internal-combined';
        }

        if ($this->isSystemManager()) {
            return 'dashboards.system-manager';
        }

        if ($this->isSystemAdmin()) {
            return 'dashboards.system-admin';
        }

        if ($this->hasBusinessCombinedAccess()) {
            return 'dashboards.business-branch-combined';
        }

        if ($this->isOwner()) {
            return 'dashboards.business-owner';
        }

        if ($this->isBranchManager()) {
            return 'dashboards.branch-manager';
        }

        return 'customer.portal';
    }

    /**
     * @return array<int, int>
     */
    public function scopedBusinessIds(): array
    {
        $ids = $this->access_scope['business_ids'] ?? [];

        return collect(is_array($ids) ? $ids : [])
            ->map(fn ($id) => (int) $id)
            ->filter()
            ->unique()
            ->values()
            ->all();
    }

    /**
     * @return array<int, int>
     */
    public function scopedBranchIds(): array
    {
        $ids = $this->access_scope['branch_ids'] ?? [];

        return collect(is_array($ids) ? $ids : [])
            ->map(fn ($id) => (int) $id)
            ->filter()
            ->unique()
            ->values()
            ->all();
    }

    public function canAccessBusiness(Business $business): bool
    {
        if ($this->isSystemManager() || $this->isSystemAdmin()) {
            return true;
        }

        if ($this->isOwner() && $business->owner_user_id === $this->id) {
            return true;
        }

        if ($this->isOwner() && in_array($business->id, $this->scopedBusinessIds(), true)) {
            return true;
        }

        if ($this->isBranchManager() && in_array($business->id, $this->scopedBusinessIds(), true)) {
            return true;
        }

        return $this->isBranchManager()
            && $this->scopedBranchIds() !== []
            && $business->branches()->whereIn('id', $this->scopedBranchIds())->exists();
    }

    public function canAccessBranch(Branch $branch): bool
    {
        if ($this->isSystemManager() || $this->isSystemAdmin()) {
            return true;
        }

        if ($this->isOwner() && $branch->business?->owner_user_id === $this->id) {
            return true;
        }

        if ($this->isOwner() && in_array($branch->business_id, $this->scopedBusinessIds(), true)) {
            return true;
        }

        return $this->isBranchManager()
            && (
                $branch->manager_user_id === $this->id
                || in_array($branch->id, $this->scopedBranchIds(), true)
            );
    }

    private function secondaryRoleIsAllowed(): bool
    {
        if (! $this->secondary_role) {
            return false;
        }

        $roles = collect([$this->role, $this->secondary_role])->sort()->values()->all();

        return $roles === collect([self::ROLE_BUSINESS_OWNER, self::ROLE_BRANCH_MANAGER])->sort()->values()->all()
            || $roles === collect([self::ROLE_SYSTEM_MANAGER, self::ROLE_SYSTEM_ADMIN])->sort()->values()->all();
    }

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'access_scope' => 'array',
        ];
    }
}
