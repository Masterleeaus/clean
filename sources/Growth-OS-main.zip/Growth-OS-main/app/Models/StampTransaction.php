<?php

namespace App\Models;

use Database\Factories\StampTransactionFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable([
    'business_id',
    'branch_id',
    'customer_id',
    'loyalty_program_id',
    'type',
    'stamps',
    'description',
])]
class StampTransaction extends Model
{
    /** @use HasFactory<StampTransactionFactory> */
    use HasFactory;

    public const TYPE_EARNED = 'earned';

    public const TYPE_REDEEMED_RESET = 'redeemed_reset';

    public const TYPE_ADJUSTMENT = 'adjustment';

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function loyaltyProgram(): BelongsTo
    {
        return $this->belongsTo(LoyaltyProgram::class);
    }

    public function scopeEarned(Builder $query): Builder
    {
        return $query->where('type', self::TYPE_EARNED);
    }

    protected function casts(): array
    {
        return [
            'stamps' => 'integer',
        ];
    }
}
