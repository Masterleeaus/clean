<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable([
    'business_id',
    'branch_id',
    'customer_id',
    'product_service_id',
    'created_by_user_id',
    'claimed_by_user_id',
    'claimed_check_in_id',
    'code',
    'purchase_reference',
    'quantity',
    'price_at_purchase',
    'total_amount',
    'capture_type',
    'status',
    'claimed_at',
])]
class OnlineCheckInReference extends Model
{
    use HasFactory;

    public const STATUS_PENDING = 'pending';

    public const STATUS_CLAIMED = 'claimed';

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function productService(): BelongsTo
    {
        return $this->belongsTo(ProductService::class);
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by_user_id');
    }

    public function claimedBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'claimed_by_user_id');
    }

    public function claimedCheckIn(): BelongsTo
    {
        return $this->belongsTo(CustomerCheckIn::class, 'claimed_check_in_id');
    }

    public function scopePending(Builder $query): Builder
    {
        return $query->where('status', self::STATUS_PENDING);
    }

    protected function casts(): array
    {
        return [
            'quantity' => 'integer',
            'price_at_purchase' => 'decimal:2',
            'total_amount' => 'decimal:2',
            'claimed_at' => 'datetime',
        ];
    }
}
