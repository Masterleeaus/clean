<?php

namespace App\Models;

use Database\Factories\CustomerCheckInFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

#[Fillable([
    'business_id',
    'branch_id',
    'customer_id',
    'user_id',
    'loyalty_program_id',
    'check_in_date',
    'check_in_at',
    'stamps_earned',
    'source',
    'check_in_type',
    'reward_status',
    'reward_granted_at',
    'purchase_reference',
    'is_suspicious',
])]
class CustomerCheckIn extends Model
{
    /** @use HasFactory<CustomerCheckInFactory> */
    use HasFactory;

    public const CHECK_IN_TYPE_PHYSICAL = 'physical';

    public const CHECK_IN_TYPE_ONLINE = 'online';

    public const CHECK_IN_TYPES = [
        self::CHECK_IN_TYPE_PHYSICAL,
        self::CHECK_IN_TYPE_ONLINE,
    ];

    public const REWARD_STATUS_PENDING_PRODUCT = 'pending_product';

    public const REWARD_STATUS_GRANTED = 'granted';

    public const REWARD_STATUS_NO_PURCHASE = 'no_reward_no_purchase';

    public const PURCHASE_STATUS_PENDING = 'pending_purchase_capture';

    public const PURCHASE_STATUS_OVERDUE = 'overdue_purchase_capture';

    public const PURCHASE_STATUS_MANUAL_REVIEW = 'manual_review_required';

    public const PURCHASE_STATUS_CONFIRMED = 'confirmed_reward';

    public const PURCHASE_STATUS_NO_PURCHASE = 'no_reward_no_purchase';

    public const OVERDUE_PURCHASE_CAPTURE_HOURS = 24;

    public const MANUAL_REVIEW_HOURS = 48;

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function loyaltyProgram(): BelongsTo
    {
        return $this->belongsTo(LoyaltyProgram::class);
    }

    public function productServiceCaptures(): HasMany
    {
        return $this->hasMany(CheckInProductService::class);
    }

    public function scopeOnDate(Builder $query, string $date): Builder
    {
        return $query->whereDate('check_in_date', $date);
    }

    public function purchaseCaptureStatus(): string
    {
        if ($this->reward_status === self::REWARD_STATUS_GRANTED) {
            return self::PURCHASE_STATUS_CONFIRMED;
        }

        if ($this->reward_status === self::REWARD_STATUS_NO_PURCHASE) {
            return self::PURCHASE_STATUS_NO_PURCHASE;
        }

        if ($this->reward_status !== self::REWARD_STATUS_PENDING_PRODUCT) {
            return (string) $this->reward_status;
        }

        if ($this->check_in_at?->lte(now()->subHours(self::MANUAL_REVIEW_HOURS))) {
            return self::PURCHASE_STATUS_MANUAL_REVIEW;
        }

        if ($this->check_in_at?->lte(now()->subHours(self::OVERDUE_PURCHASE_CAPTURE_HOURS))) {
            return self::PURCHASE_STATUS_OVERDUE;
        }

        return self::PURCHASE_STATUS_PENDING;
    }

    public function purchaseCaptureStatusLabel(): string
    {
        return match ($this->purchaseCaptureStatus()) {
            self::PURCHASE_STATUS_PENDING => 'Pending Purchase Capture',
            self::PURCHASE_STATUS_OVERDUE => 'Overdue Purchase Capture',
            self::PURCHASE_STATUS_MANUAL_REVIEW => 'Manual Review Required',
            self::PURCHASE_STATUS_CONFIRMED => 'Confirmed Reward',
            self::PURCHASE_STATUS_NO_PURCHASE => 'No Reward - No Purchase',
            default => 'No Reward / Blocked',
        };
    }

    public function checkInTypeLabel(): string
    {
        return match ($this->check_in_type) {
            self::CHECK_IN_TYPE_ONLINE => 'Online',
            default => 'Physical',
        };
    }

    public function pendingPurchaseCaptureLabel(): string
    {
        return 'Pending Purchase Capture — '.$this->checkInTypeLabel();
    }

    public function isAwaitingPurchaseCapture(): bool
    {
        return $this->reward_status === self::REWARD_STATUS_PENDING_PRODUCT;
    }

    protected function casts(): array
    {
        return [
            'check_in_date' => 'date',
            'check_in_at' => 'datetime',
            'stamps_earned' => 'integer',
            'reward_granted_at' => 'datetime',
            'is_suspicious' => 'boolean',
        ];
    }
}
