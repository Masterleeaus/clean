<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable([
    'business_id',
    'branch_id',
    'customer_id',
    'customer_check_in_id',
    'product_service_id',
    'check_in_product_service_id',
    'food_rating',
    'service_rating',
    'rating',
    'price_feedback',
    'comment',
    'source',
    'status',
    'submitted_at',
    'summary_main_meaning',
    'summary_positive_point',
    'summary_negative_point',
    'summary_customer_expectation',
    'summary_issue_category',
    'summary_product_service_mentioned',
    'summary_needs_review',
])]
class CustomerFeedback extends Model
{
    public const STATUS_PENDING = 'pending';

    public const STATUS_SUBMITTED = 'submitted';

    public const STATUS_REVIEWED = 'reviewed';

    public const STATUS_ACTION_NEEDED = 'action_needed';

    public const STATUS_RESOLVED = 'resolved';

    public const PRICE_CHEAP = 'cheap';

    public const PRICE_OK = 'ok';

    public const PRICE_EXPENSIVE = 'expensive';

    public function business(): BelongsTo
    {
        return $this->belongsTo(Business::class);
    }

    public function branch(): BelongsTo
    {
        return $this->belongsTo(Branch::class);
    }

    public function customer(): BelongsTo
    {
        return $this->belongsTo(Customer::class);
    }

    public function checkIn(): BelongsTo
    {
        return $this->belongsTo(CustomerCheckIn::class, 'customer_check_in_id');
    }

    public function productService(): BelongsTo
    {
        return $this->belongsTo(ProductService::class);
    }

    public function capture(): BelongsTo
    {
        return $this->belongsTo(CheckInProductService::class, 'check_in_product_service_id');
    }

    public static function statuses(): array
    {
        return [
            self::STATUS_PENDING,
            self::STATUS_SUBMITTED,
            self::STATUS_REVIEWED,
            self::STATUS_ACTION_NEEDED,
            self::STATUS_RESOLVED,
        ];
    }

    protected function casts(): array
    {
        return [
            'food_rating' => 'integer',
            'service_rating' => 'integer',
            'rating' => 'integer',
            'submitted_at' => 'datetime',
            'summary_needs_review' => 'boolean',
        ];
    }
}
