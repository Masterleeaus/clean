<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Attributes\Description;
use Illuminate\Console\Attributes\Signature;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;

#[Signature('users:create-owner {--name=} {--email=} {--password=}')]
#[Description('Create a Business Owner user for supervised staging or pilot setup')]
class CreateOwnerUserCommand extends Command
{
    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $name = trim((string) ($this->option('name') ?: $this->ask('Business Owner name')));
        $email = strtolower(trim((string) ($this->option('email') ?: $this->ask('Business Owner email'))));
        $password = (string) ($this->option('password') ?: $this->secret('Temporary password'));

        $validator = Validator::make([
            'name' => $name,
            'email' => $email,
            'password' => $password,
        ], [
            'name' => ['required', 'string', 'max:255'],
            'email' => ['required', 'string', 'lowercase', 'email', 'max:255', 'unique:users,email'],
            'password' => ['required', Password::defaults()],
        ]);

        if ($validator->fails()) {
            foreach ($validator->errors()->all() as $error) {
                $this->error($error);
            }

            return self::FAILURE;
        }

        $user = User::query()->create([
            'name' => $name,
            'email' => $email,
            'password' => Hash::make($password),
            'role' => User::ROLE_BUSINESS_OWNER,
        ]);

        $user->forceFill([
            'email_verified_at' => now(),
        ])->save();

        $this->info("Business Owner user created: {$user->email}");
        $this->warn('Change temporary pilot passwords before using real customer data.');

        return self::SUCCESS;
    }
}
