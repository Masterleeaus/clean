<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\CustomerLoyaltyAccount;
use App\Services\CustomerCheckInService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class CustomerPortalController extends Controller
{
    public function show(Request $request): View
    {
        abort_unless($request->user()->isCustomer(), 403);

        return view('customer.portal', [
            'branches' => Branch::query()
                ->with('business')
                ->where('is_active', true)
                ->orderBy('name')
                ->get(),
            'recentCheckIns' => CustomerCheckIn::query()
                ->with(['business', 'branch', 'productServiceCaptures.productService'])
                ->where('user_id', $request->user()->id)
                ->latest('check_in_at')
                ->limit(5)
                ->get(),
            'loyaltyAccounts' => CustomerLoyaltyAccount::query()
                ->with(['business', 'loyaltyProgram'])
                ->whereHas('customer', fn (Builder $query) => $query->where('user_id', $request->user()->id))
                ->get(),
            'recentFeedback' => CustomerFeedback::query()
                ->with(['business', 'branch'])
                ->where('status', '!=', CustomerFeedback::STATUS_PENDING)
                ->whereHas('customer', fn (Builder $query) => $query->where('user_id', $request->user()->id))
                ->latest('submitted_at')
                ->limit(5)
                ->get(),
        ]);
    }

    public function checkIn(Request $request, CustomerCheckInService $checkIns): View|RedirectResponse
    {
        abort_unless($request->user()->isCustomer(), 403);

        $validated = $request->validate([
            'branch_id' => ['required', 'exists:branches,id'],
            'whatsapp_number' => ['required', 'string', 'max:30', 'regex:/^(?=(?:.*\d){7,})[0-9+()\-\s]{7,30}$/'],
            'check_in_mode' => ['nullable', Rule::in(CustomerCheckIn::CHECK_IN_TYPES)],
        ]);

        $branch = Branch::query()
            ->with('business')
            ->where('is_active', true)
            ->findOrFail($validated['branch_id']);

        $result = $checkIns->checkInOrCreateCustomer(
            $branch,
            $request->user(),
            $validated['whatsapp_number'],
            $validated['check_in_mode'] ?? CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL,
        );

        if ($result['status'] === 'program_unavailable') {
            return back()
                ->withInput()
                ->withErrors(['check_in' => 'Check-in belum tersedia untuk branch ini.']);
        }

        return view('customer.check-in-status', $result);
    }

    public function onlineCheckIn(Request $request, CustomerCheckInService $checkIns): View|RedirectResponse
    {
        abort_unless($request->user()->isCustomer(), 403);

        $validated = $request->validate([
            'code' => ['required', 'string', 'max:50'],
        ]);

        $result = $checkIns->completeOnlineCheckIn($validated['code'], $request->user());

        return view('customer.check-in-status', $result);
    }
}
