<?php

namespace App\Http\Controllers;

use App\Models\Business;
use App\Models\ProductService;
use App\Services\ProductServiceReviewService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class ProductServiceController extends Controller
{
    public function index(Request $request, Business $business): View
    {
        $this->authorize('view', $business);
        $this->authorize('viewAny', ProductService::class);

        $products = $business->productServices()
            ->with('branch')
            ->withCount('captures')
            ->when(
                $request->user()->isBranchManager() && ! $request->user()->isOwner(),
                fn ($query) => $query->where(function ($query) use ($request): void {
                    $query->whereNull('branch_id')
                        ->orWhereIn('branch_id', $request->user()->scopedBranchIds());
                }),
            )
            ->orderBy('category')
            ->orderBy('name')
            ->get();

        $groupedProducts = $products
            ->groupBy(fn (ProductService $product): string => ProductService::normalizeCategory($product->category))
            ->sortBy(fn ($items, string $category): string => str_pad((string) ProductService::categorySortIndex($category), 2, '0', STR_PAD_LEFT).'|'.mb_strtolower($category))
            ->map(fn ($items) => $items->sortBy(fn (ProductService $product): string => mb_strtolower($product->name))->values());

        $categoryTabs = collect(ProductService::DEFAULT_CATEGORIES)
            ->merge($groupedProducts->keys())
            ->unique(fn (string $category): string => mb_strtolower($category))
            ->sortBy(fn (string $category): string => str_pad((string) ProductService::categorySortIndex($category), 2, '0', STR_PAD_LEFT).'|'.mb_strtolower($category))
            ->values();
        $activeCategory = $request->string('category')->trim()->toString();
        $activeCategory = $activeCategory === '' ? null : ProductService::normalizeCategory($activeCategory, $categoryTabs);
        $visibleGroupedProducts = $activeCategory
            ? collect([$activeCategory => $groupedProducts->get($activeCategory, collect())])
            : $groupedProducts;

        return view('product-services.index', [
            'business' => $business,
            'products' => $products,
            'groupedProducts' => $groupedProducts,
            'visibleGroupedProducts' => $visibleGroupedProducts,
            'categoryTabs' => $categoryTabs,
            'activeCategory' => $activeCategory,
        ]);
    }

    public function create(Request $request, Business $business): View
    {
        $this->authorize('view', $business);
        $this->authorize('create', ProductService::class);

        $categoryOptions = ProductService::categoryOptionsFor($business);
        $selectedCategory = $request->string('category')->trim()->toString();
        $selectedCategory = $selectedCategory === ''
            ? null
            : ProductService::normalizeCategory($selectedCategory, $categoryOptions);

        return view('product-services.create', [
            'business' => $business,
            'branches' => $this->manageableBranches($business),
            'categoryOptions' => $categoryOptions,
            'selectedCategory' => in_array($selectedCategory, $categoryOptions, true) ? $selectedCategory : null,
        ]);
    }

    public function store(Request $request, Business $business, ProductServiceReviewService $reviews): RedirectResponse
    {
        $this->authorize('view', $business);
        $this->authorize('create', ProductService::class);

        $existingCategories = $this->existingCategories($business);
        $validated = $this->validatedProduct($request, $business, existingCategories: $existingCategories);
        $isNewCategory = $this->isNewCustomCategory($validated['category'], $existingCategories);
        $product = $business->productServices()->create($validated);
        $issues = $reviews->reviewSaved($product, actor: $request->user());

        if ($isNewCategory) {
            $issues = array_merge($issues, $reviews->reviewNewCategory($product, $request->user()));
        }

        return redirect()
            ->route('businesses.product-services.index', $business)
            ->with('status', "Product/Service saved: {$product->name}")
            ->with('review_warnings', collect($issues)->pluck('message')->all());
    }

    public function edit(Business $business, ProductService $productService): View
    {
        $this->ensureProductBelongsToBusiness($business, $productService);
        $this->authorize('update', $productService);

        return view('product-services.edit', [
            'business' => $business,
            'productService' => $productService,
            'branches' => $this->manageableBranches($business),
            'categoryOptions' => ProductService::categoryOptionsFor($business),
        ]);
    }

    public function update(Request $request, Business $business, ProductService $productService, ProductServiceReviewService $reviews): RedirectResponse
    {
        $this->ensureProductBelongsToBusiness($business, $productService);
        $this->authorize('update', $productService);

        $previous = $productService->only(['name', 'price', 'category']);
        $existingCategories = $this->existingCategories($business, $productService);
        $validated = $this->validatedProduct($request, $business, $productService, $existingCategories);
        $isNewCategory = $this->isNewCustomCategory($validated['category'], $existingCategories);
        $productService->update($validated);
        $issues = $reviews->reviewSaved($productService, $previous, $request->user());

        if ($isNewCategory) {
            $issues = array_merge($issues, $reviews->reviewNewCategory($productService, $request->user()));
        }

        return redirect()
            ->route('businesses.product-services.index', $business)
            ->with('status', 'Product/Service updated.')
            ->with('review_warnings', collect($issues)->pluck('message')->all());
    }

    public function destroy(Request $request, Business $business, ProductService $productService, ProductServiceReviewService $reviews): RedirectResponse
    {
        $this->ensureProductBelongsToBusiness($business, $productService);
        $this->authorize('delete', $productService);

        $productService->loadCount('captures');

        if ($productService->captures_count > 0) {
            $issues = $reviews->reviewArchiveUsed($productService, $request->user());

            return redirect()
                ->route('businesses.product-services.index', $business)
                ->with('status', 'Product/Service archived because it has purchase capture history.')
                ->with('review_warnings', collect($issues)->pluck('message')->all());
        }

        $name = $productService->name;
        $productService->delete();

        return redirect()
            ->route('businesses.product-services.index', $business)
            ->with('status', "Product/Service deleted: {$name}");
    }

    private function ensureProductBelongsToBusiness(Business $business, ProductService $productService): void
    {
        abort_unless($productService->business_id === $business->id, 404);
    }

    /**
     * @return array<string, mixed>
     */
    private function validatedProduct(Request $request, Business $business, ?ProductService $productService = null, ?array $existingCategories = null): array
    {
        $validated = $request->validate([
            'branch_id' => ['nullable', Rule::exists('branches', 'id')->where('business_id', $business->id)],
            'name' => ['required', 'string', 'max:255'],
            'category' => ['required', 'string', 'max:100'],
            'category_new' => ['nullable', 'string', 'max:100'],
            'type' => ['required', 'string', 'max:50'],
            'price' => ['required', 'numeric', 'min:0', 'max:999999.99'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        if ($validated['category'] === '__new') {
            $request->validate([
                'category_new' => ['required', 'string', 'max:100'],
            ]);

            $validated['category'] = $validated['category_new'];
        }

        if ($request->user()?->isBranchManager() && ! $request->user()?->isOwner() && ! $request->user()?->isSystemAdmin()) {
            abort_unless($validated['branch_id'] !== null && in_array((int) $validated['branch_id'], $request->user()->scopedBranchIds(), true), 403);
        }

        unset($validated['category_new']);

        $validated['category'] = ProductService::normalizeCategory($validated['category'], $existingCategories ?? $this->existingCategories($business, $productService));
        $validated['is_active'] = $request->boolean('is_active');
        $validated['price'] = number_format((float) $validated['price'], 2, '.', '');
        $validated['archived_at'] = $validated['is_active'] ? null : now();

        return $validated;
    }

    private function manageableBranches(Business $business)
    {
        $user = request()->user();

        return $business->branches()
            ->when(
                $user?->isBranchManager() && ! $user?->isOwner() && ! $user?->isSystemAdmin(),
                fn ($query) => $query->whereIn('id', $user->scopedBranchIds()),
            )
            ->orderBy('name')
            ->get();
    }

    /**
     * @return array<int, string>
     */
    private function existingCategories(Business $business, ?ProductService $except = null): array
    {
        return $business->productServices()
            ->when($except, fn ($query) => $query->whereKeyNot($except->id))
            ->whereNotNull('category')
            ->pluck('category')
            ->map(fn (?string $category): string => ProductService::normalizeCategory($category))
            ->filter()
            ->unique(fn (string $category): string => mb_strtolower($category))
            ->values()
            ->all();
    }

    /**
     * @param  array<int, string>  $existingCategories
     */
    private function isNewCustomCategory(string $category, array $existingCategories): bool
    {
        if (ProductService::categorySortIndex($category) !== 99) {
            return false;
        }

        return ! collect($existingCategories)
            ->contains(fn (string $existing): bool => mb_strtolower($existing) === mb_strtolower($category));
    }
}
