<?php

namespace App\Http\Controllers;

use App\Models\Business;
use App\Services\WeeklyGrowthReportService;
use Illuminate\View\View;

class WeeklyGrowthReportController extends Controller
{
    public function show(Business $business, WeeklyGrowthReportService $reports): View
    {
        abort_unless(request()->user()?->isOwner() && (int) $business->owner_user_id === (int) request()->user()->id, 403);
        $this->authorize('view', $business);

        return view('businesses.reports.weekly', [
            'business' => $business,
            'report' => $reports->reportFor($business),
        ]);
    }
}
