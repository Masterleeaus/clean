<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Business;
use App\Models\CustomerCheckIn;
use App\Models\OnlineCheckInReference;
use App\Models\ProductService;
use Illuminate\Http\Request;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class CustomerCheckInController extends Controller
{
    public function businessIndex(Request $request, Business $business): View
    {
        $this->abortInternalOperationPersona($request);
        $this->authorize('view', $business);

        $checkIns = CustomerCheckIn::query()
            ->with(['branch', 'customer', 'user', 'productServiceCaptures.productService'])
            ->where('business_id', $business->id)
            ->when(
                $request->user()->isBranchManager(),
                fn ($query) => $query->whereIn('branch_id', $request->user()->scopedBranchIds()),
            )
            ->latest('check_in_at')
            ->latest()
            ->get();

        return view('check-ins.index', [
            'title' => 'Business Check-ins',
            'business' => $business,
            'branch' => null,
            'checkIns' => $checkIns,
            'customers' => $business->customers()->orderBy('name')->get(),
            'onlineReferences' => OnlineCheckInReference::query()
                ->with(['customer', 'branch', 'productService'])
                ->where('business_id', $business->id)
                ->when(
                    $request->user()->isBranchManager(),
                    fn ($query) => $query->whereIn('branch_id', $request->user()->scopedBranchIds()),
                )
                ->latest()
                ->limit(10)
                ->get(),
            'productsForBranch' => fn ($branch) => $branch
                ? $this->productsForBranch($branch)
                : collect(),
            'canOperateCheckIns' => $request->user()->isBranchManager(),
        ]);
    }

    public function branchIndex(Request $request, Business $business, Branch $branch): View
    {
        $this->abortInternalOperationPersona($request);
        abort_unless($branch->business_id === $business->id, 404);
        abort_unless($this->canOperateAssignedBranch($request, $branch), 403);
        $this->authorize('view', $branch);

        return view('check-ins.index', [
            'title' => 'Branch Check-ins',
            'business' => $business,
            'branch' => $branch,
            'checkIns' => $branch->checkIns()
                ->with(['customer', 'user', 'productServiceCaptures.productService'])
                ->latest('check_in_at')
                ->latest()
                ->get(),
            'customers' => $business->customers()->orderBy('name')->get(),
            'onlineReferences' => OnlineCheckInReference::query()
                ->with(['customer', 'branch', 'productService'])
                ->where('branch_id', $branch->id)
                ->latest()
                ->limit(10)
                ->get(),
            'productsForBranch' => fn ($branch) => $this->productsForBranch($branch),
            'canOperateCheckIns' => true,
        ]);
    }

    public function storeOnlineReference(Request $request, Business $business, Branch $branch): RedirectResponse
    {
        $this->abortInternalOperationPersona($request);
        abort_unless($branch->business_id === $business->id, 404);
        abort_unless($this->canOperateAssignedBranch($request, $branch), 403);
        $this->authorize('view', $branch);

        $validated = $request->validate([
            'customer_id' => [
                'required',
                Rule::exists('customers', 'id')->where('business_id', $business->id),
            ],
            'product_service_id' => [
                'required',
                Rule::exists('product_services', 'id')->where('business_id', $business->id),
            ],
            'purchase_reference' => ['nullable', 'string', 'max:255'],
            'quantity' => ['required', 'integer', 'min:1', 'max:100'],
            'capture_type' => ['required', 'string', 'max:50'],
        ]);

        $product = ProductService::query()->findOrFail($validated['product_service_id']);
        abort_unless($product->is_active, 422);
        abort_unless($product->branch_id === null || $product->branch_id === $branch->id, 403);
        $this->authorize('view', $product);

        if (($validated['purchase_reference'] ?? null) && OnlineCheckInReference::query()
            ->where('business_id', $business->id)
            ->where('purchase_reference', $validated['purchase_reference'])
            ->exists()) {
            return redirect()
                ->route('businesses.branches.check-ins', ['business' => $business, 'branch' => $branch])
                ->with('status', 'Duplicate online check-in link reference ignored.');
        }

        $reference = OnlineCheckInReference::query()->create([
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'customer_id' => $validated['customer_id'],
            'product_service_id' => $product->id,
            'created_by_user_id' => $request->user()->id,
            'code' => Str::upper(Str::random(10)),
            'purchase_reference' => $validated['purchase_reference'] ?? null,
            'quantity' => $validated['quantity'],
            'price_at_purchase' => $product->price,
            'total_amount' => number_format((float) $product->price * (int) $validated['quantity'], 2, '.', ''),
            'capture_type' => $validated['capture_type'],
            'status' => OnlineCheckInReference::STATUS_PENDING,
        ]);

        return redirect()
            ->route('businesses.branches.check-ins', ['business' => $business, 'branch' => $branch])
            ->with('status', 'Online check-in link created: '.$reference->code);
    }

    private function productsForBranch(Branch $branch)
    {
        return $branch->business->productServices()
            ->visibleForBranch($branch)
            ->active()
            ->orderBy('category')
            ->orderBy('name')
            ->get();
    }

    private function abortInternalOperationPersona(Request $request): void
    {
        abort_if($request->user()->isSystemManager() || $request->user()->isSystemAdmin(), 403);
    }

    private function canOperateAssignedBranch(Request $request, Branch $branch): bool
    {
        $user = $request->user();

        return $user->isBranchManager()
            && in_array($branch->id, $user->scopedBranchIds(), true);
    }
}
