<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Business;
use App\Models\CheckInProductService;
use App\Models\CustomerCheckIn;
use App\Models\ProductService;
use App\Services\CustomerCheckInService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;

class CheckInProductServiceController extends Controller
{
    public function store(Request $request, Business $business, Branch $branch, CustomerCheckIn $checkIn, CustomerCheckInService $checkIns): RedirectResponse
    {
        $this->abortInternalOperationPersona($request);
        abort_unless($branch->business_id === $business->id, 404);
        abort_unless($checkIn->business_id === $business->id && $checkIn->branch_id === $branch->id, 404);
        abort_unless($this->canOperateAssignedBranch($request, $branch), 403);

        $this->authorize('view', $branch);

        if ($checkIn->reward_status === CustomerCheckIn::REWARD_STATUS_NO_PURCHASE) {
            return redirect()
                ->route('businesses.branches.check-ins', ['business' => $business, 'branch' => $branch])
                ->with('status', 'Purchase capture blocked because this check-in was marked No Purchase.');
        }

        $validated = $request->validate([
            'product_service_id' => [
                'required',
                Rule::exists('product_services', 'id')->where('business_id', $business->id),
            ],
            'quantity' => ['required', 'integer', 'min:1', 'max:100'],
            'capture_type' => ['required', 'string', 'max:50'],
            'capture_reference' => ['nullable', 'string', 'max:255'],
            'notes' => ['nullable', 'string', 'max:500'],
        ]);

        if (($validated['capture_reference'] ?? null) && CheckInProductService::query()->where('capture_reference', $validated['capture_reference'])->exists()) {
            return redirect()
                ->route('businesses.branches.check-ins', ['business' => $business, 'branch' => $branch])
                ->with('status', 'Duplicate Product/Service capture ignored. Reward not updated again.');
        }

        $product = ProductService::query()->findOrFail($validated['product_service_id']);
        abort_unless($product->is_active, 422);
        abort_unless($product->branch_id === null || $product->branch_id === $branch->id, 403);
        $this->authorize('view', $product);

        $checkIn->productServiceCaptures()->create([
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'customer_id' => $checkIn->customer_id,
            'product_service_id' => $product->id,
            'captured_by_user_id' => $request->user()->id,
            'quantity' => $validated['quantity'],
            'price_at_capture' => $product->price,
            'total_amount' => number_format((float) $product->price * (int) $validated['quantity'], 2, '.', ''),
            'capture_type' => $validated['capture_type'],
            'capture_source' => 'staff_manual',
            'capture_reference' => $validated['capture_reference'] ?? null,
            'notes' => $validated['notes'] ?? null,
        ]);

        $rewardGranted = $checkIns->grantRewardForCheckIn($checkIn);

        return redirect()
            ->route('businesses.branches.check-ins', ['business' => $business, 'branch' => $branch])
            ->with('status', $rewardGranted
                ? 'Product/Service captured. Reward updated.'
                : 'Product/Service captured. Reward not updated again.');
    }

    public function noPurchase(Request $request, Business $business, Branch $branch, CustomerCheckIn $checkIn): RedirectResponse
    {
        $this->abortInternalOperationPersona($request);
        abort_unless($branch->business_id === $business->id, 404);
        abort_unless($checkIn->business_id === $business->id && $checkIn->branch_id === $branch->id, 404);
        abort_unless($this->canOperateAssignedBranch($request, $branch), 403);

        $this->authorize('view', $branch);

        $request->validate([
            'no_purchase_reason' => ['nullable', 'string', 'max:255'],
        ]);

        $checkIn->loadCount('productServiceCaptures');

        if ($checkIn->product_service_captures_count > 0 || $checkIn->reward_status === CustomerCheckIn::REWARD_STATUS_GRANTED) {
            return redirect()
                ->route('businesses.branches.check-ins', ['business' => $business, 'branch' => $branch])
                ->with('status', 'No Purchase not applied because purchase was already captured.');
        }

        $checkIn->forceFill([
            'reward_status' => CustomerCheckIn::REWARD_STATUS_NO_PURCHASE,
            'stamps_earned' => 0,
            'reward_granted_at' => null,
        ])->save();

        return redirect()
            ->route('businesses.branches.check-ins', ['business' => $business, 'branch' => $branch])
            ->with('status', 'No Reward - No Purchase recorded. Reward was not created.');
    }

    private function abortInternalOperationPersona(Request $request): void
    {
        abort_if($request->user()->isSystemManager() || $request->user()->isSystemAdmin(), 403);
    }

    private function canOperateAssignedBranch(Request $request, Branch $branch): bool
    {
        $user = $request->user();

        return $user->isBranchManager()
            && in_array($branch->id, $user->scopedBranchIds(), true);
    }
}
