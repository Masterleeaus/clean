<?php

namespace App\Http\Controllers;

use App\Models\Business;
use App\Models\User;
use App\Models\Customer;
use App\Models\LoyaltyProgram;
use App\Services\ManualFollowUpService;
use App\Services\RewardRedemptionService;
use Carbon\Carbon;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class BusinessController extends Controller
{
    private const DORMANT_DAYS = 30;

    public function index(Request $request): View
    {
        $this->authorize('viewAny', Business::class);

        $businesses = Business::query()
            ->with('loyaltyPrograms')
            ->withCount(['branches', 'customers', 'checkIns', 'rewardRedemptions'])
            ->accessibleTo($request->user())
            ->orderBy('name')
            ->get();

        return view('businesses.index', [
            'businesses' => $businesses,
        ]);
    }

    public function create(): View
    {
        $this->authorize('create', Business::class);

        return view('businesses.create', [
            'owners' => User::query()
                ->whereIn('role', [User::ROLE_BUSINESS_OWNER, 'owner'])
                ->orderBy('name')
                ->get(),
        ]);
    }

    public function store(Request $request): RedirectResponse
    {
        $this->authorize('create', Business::class);

        $request->merge([
            'slug' => Str::slug((string) $request->input('slug')),
        ]);

        $validated = $request->validate([
            'owner_user_id' => ['required', 'exists:users,id'],
            'name' => ['required', 'string', 'max:255'],
            'slug' => ['required', 'string', 'max:255', Rule::unique('businesses', 'slug')],
            'owner_name' => ['required', 'string', 'max:255'],
            'owner_whatsapp' => ['required', 'string', 'max:30'],
            'business_type' => ['required', 'string', 'max:100'],
        ]);

        $business = Business::query()->create([
            ...$validated,
            'public_qr_token' => (string) Str::uuid(),
        ]);

        return redirect()
            ->route('businesses.show', $business)
            ->with('status', 'Business created.');
    }

    public function show(Business $business): View
    {
        $this->authorize('view', $business);

        $business->load([
            'owner',
            'branches' => fn ($query) => $query->with('manager')->orderBy('name'),
            'loyaltyPrograms' => fn ($query) => $query->active()->latest(),
        ]);
        $business->loadCount(['branches', 'customers', 'checkIns', 'rewardRedemptions']);
        $loyaltyProgram = $business->loyaltyPrograms->first();

        $recentCheckIns = $business->checkIns()
            ->with('customer')
            ->latest()
            ->limit(10)
            ->get();

        $eligibleAccounts = $loyaltyProgram
            ? $business->loyaltyAccounts()
                ->with('customer')
                ->where('loyalty_program_id', $loyaltyProgram->id)
                ->where('current_stamps', '>=', $loyaltyProgram->stamps_required)
                ->orderByDesc('current_stamps')
                ->limit(10)
                ->get()
            : collect();

        $redemptions = $business->rewardRedemptions()
            ->with(['customer', 'verifiedBy'])
            ->latest('redeemed_at')
            ->limit(10)
            ->get();

        return view('businesses.show', [
            'business' => $business,
            'loyaltyProgram' => $loyaltyProgram,
            'recentCheckIns' => $recentCheckIns,
            'eligibleAccounts' => $eligibleAccounts,
            'redemptions' => $redemptions,
        ]);
    }

    public function dashboard(Business $business): View
    {
        $this->abortInternalOperationPersona();
        $this->abortUnlessBusinessOwner($business);
        $this->authorize('view', $business);

        $loyaltyProgram = $this->activeProgramFor($business);
        $today = now()->toDateString();

        $recentCheckIns = $business->checkIns()
            ->with('customer')
            ->latest()
            ->limit(8)
            ->get();

        $recentRedemptions = $business->rewardRedemptions()
            ->with(['customer', 'verifiedBy'])
            ->latest('redeemed_at')
            ->limit(8)
            ->get();

        return view('businesses.dashboard', [
            'business' => $business,
            'loyaltyProgram' => $loyaltyProgram,
            'publicUrl' => route('public.business.show', ['business' => $business->slug]),
            'totalCustomers' => $business->customers()->count(),
            'newCustomersToday' => $business->customers()->whereDate('created_at', $today)->count(),
            'checkInsToday' => $business->checkIns()->whereDate('check_in_date', $today)->count(),
            'repeatCustomersCount' => $business->checkIns()
                ->select('customer_id')
                ->groupBy('customer_id')
                ->havingRaw('COUNT(*) > 1')
                ->get()
                ->count(),
            'eligibleRewardsCount' => $this->eligibleAccountsQuery($business, $loyaltyProgram)->count(),
            'rewardsRedeemedCount' => $business->rewardRedemptions()->count(),
            'recentCheckIns' => $recentCheckIns,
            'recentRedemptions' => $recentRedemptions,
        ]);
    }

    public function customers(Request $request, Business $business): View
    {
        $this->abortInternalOperationPersona();
        $this->abortUnlessBusinessOwner($business);
        $this->authorize('view', $business);

        $loyaltyProgram = $this->activeProgramFor($business);
        $search = trim((string) $request->query('search', ''));
        $filter = (string) $request->query('filter', '');

        $customers = $business->customers()
            ->with([
                'loyaltyAccounts' => fn ($query) => $loyaltyProgram
                    ? $query->where('loyalty_program_id', $loyaltyProgram->id)
                    : $query,
                'checkIns' => fn ($query) => $query->latest('check_in_date')->limit(1),
            ])
            ->withMax('checkIns', 'check_in_date')
            ->when($search !== '', fn ($query) => $query->where(function ($query) use ($search): void {
                $query->where('name', 'like', "%{$search}%")
                    ->orWhere('whatsapp_number', 'like', "%{$search}%");
            }))
            ->when($filter === 'eligible' && $loyaltyProgram, fn ($query) => $query->whereHas(
                'loyaltyAccounts',
                fn ($accountQuery) => $accountQuery
                    ->where('loyalty_program_id', $loyaltyProgram->id)
                    ->where('current_stamps', '>=', $loyaltyProgram->stamps_required),
            ))
            ->when($filter === 'dormant', fn ($query) => $query->where(function ($query): void {
                $query->whereDoesntHave('checkIns')
                    ->orWhereDoesntHave('checkIns', fn ($checkInQuery) => $checkInQuery->whereDate('check_in_date', '>=', now()->subDays(self::DORMANT_DAYS)->toDateString()));
            }))
            ->orderBy('name')
            ->get();

        return view('businesses.customers.index', [
            'business' => $business,
            'customers' => $customers,
            'loyaltyProgram' => $loyaltyProgram,
            'search' => $search,
            'filter' => $filter,
            'statusFor' => fn (Customer $customer) => $this->customerStatus($customer, $loyaltyProgram),
            'accountFor' => fn (Customer $customer) => $this->accountFor($customer, $loyaltyProgram),
        ]);
    }

    public function customerShow(Business $business, Customer $customer): View
    {
        $this->abortInternalOperationPersona();
        $this->abortUnlessBusinessOwner($business);
        $this->authorize('view', $business);
        abort_unless($customer->business_id === $business->id, 404);

        $loyaltyProgram = $this->activeProgramFor($business);
        $account = $this->accountFor($customer, $loyaltyProgram);

        return view('businesses.customers.show', [
            'business' => $business,
            'customer' => $customer->load('business'),
            'loyaltyProgram' => $loyaltyProgram,
            'account' => $account,
            'status' => $this->customerStatus($customer, $loyaltyProgram),
            'checkIns' => $customer->checkIns()
                ->where('business_id', $business->id)
                ->latest('check_in_date')
                ->get(),
            'stampTransactions' => $customer->stampTransactions()
                ->where('business_id', $business->id)
                ->latest()
                ->get(),
            'redemptions' => $customer->rewardRedemptions()
                ->with('verifiedBy')
                ->where('business_id', $business->id)
                ->latest('redeemed_at')
                ->get(),
        ]);
    }

    public function followUps(Business $business, ManualFollowUpService $followUps): View
    {
        $this->abortInternalOperationPersona();
        $this->abortUnlessBusinessOwner($business);
        $this->authorize('view', $business);

        $loyaltyProgram = $this->activeProgramFor($business);

        return view('businesses.follow-ups', [
            'business' => $business,
            'loyaltyProgram' => $loyaltyProgram,
            'groups' => $followUps->groupsFor($business, $loyaltyProgram),
        ]);
    }

    public function edit(Business $business): View
    {
        $this->authorize('update', $business);

        return view('businesses.edit', [
            'business' => $business,
        ]);
    }

    public function update(Request $request, Business $business): RedirectResponse
    {
        $this->authorize('update', $business);

        $request->merge([
            'slug' => Str::slug((string) $request->input('slug')),
        ]);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'slug' => ['required', 'string', 'max:255', Rule::unique('businesses', 'slug')->ignore($business)],
            'owner_name' => ['required', 'string', 'max:255'],
            'owner_whatsapp' => ['required', 'string', 'max:30'],
            'business_type' => ['required', 'string', 'max:100'],
        ]);

        $business->update($validated);

        return redirect()
            ->route('businesses.show', $business)
            ->with('status', 'Business updated.');
    }

    public function editLoyalty(Business $business): View
    {
        $this->abortInternalOperationPersona();
        $this->abortUnlessBusinessOwner($business);
        $this->authorize('manageLoyalty', $business);

        return view('businesses.loyalty', [
            'business' => $business,
            'loyaltyProgram' => $this->loyaltyProgramFor($business),
        ]);
    }

    public function updateLoyalty(Request $request, Business $business): RedirectResponse
    {
        $this->abortInternalOperationPersona();
        $this->abortUnlessBusinessOwner($business);
        $this->authorize('manageLoyalty', $business);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'stamps_required' => ['required', 'integer', 'min:1', 'max:1000'],
            'reward_name' => ['required', 'string', 'max:255'],
            'reward_description' => ['nullable', 'string', 'max:1000'],
            'welcome_stamp_enabled' => ['nullable', 'boolean'],
            'check_in_cooldown_minutes' => ['required', 'integer', 'min:15', 'max:1440'],
            'is_active' => ['nullable', 'boolean'],
        ]);

        $validated['welcome_stamp_enabled'] = $request->boolean('welcome_stamp_enabled');
        $validated['is_active'] = $request->boolean('is_active');

        $this->loyaltyProgramFor($business)->update($validated);

        return redirect()
            ->route('businesses.show', $business)
            ->with('status', 'Loyalty program updated.');
    }

    public function redeem(Request $request, Business $business, Customer $customer, RewardRedemptionService $redemptions): RedirectResponse
    {
        $this->abortInternalOperationPersona();
        $this->abortUnlessBusinessOwner($business);
        $this->authorize('update', $business);

        $redemptions->redeem($business, $customer, $request->user());

        return redirect()
            ->route('businesses.show', $business)
            ->with('status', 'Ganjaran berjaya diverify.');
    }

    private function loyaltyProgramFor(Business $business): LoyaltyProgram
    {
        return $business->loyaltyPrograms()
            ->active()
            ->firstOr(fn () => $business->loyaltyPrograms()->create([
                'name' => 'Default Loyalty Program',
                'stamps_required' => 8,
                'reward_name' => 'Ganjaran percuma',
                'welcome_stamp_enabled' => true,
                'check_in_cooldown_minutes' => 60,
                'is_active' => true,
            ]));
    }

    private function activeProgramFor(Business $business): ?LoyaltyProgram
    {
        return $business->loyaltyPrograms()
            ->active()
            ->first();
    }

    private function eligibleAccountsQuery(Business $business, ?LoyaltyProgram $loyaltyProgram)
    {
        $query = $business->loyaltyAccounts();

        if (! $loyaltyProgram) {
            return $query->whereRaw('1 = 0');
        }

        return $query
            ->where('loyalty_program_id', $loyaltyProgram->id)
            ->where('current_stamps', '>=', $loyaltyProgram->stamps_required);
    }

    private function accountFor(Customer $customer, ?LoyaltyProgram $loyaltyProgram)
    {
        if (! $loyaltyProgram) {
            return null;
        }

        return $customer->loyaltyAccounts
            ->firstWhere('loyalty_program_id', $loyaltyProgram->id);
    }

    private function customerStatus(Customer $customer, ?LoyaltyProgram $loyaltyProgram): string
    {
        $account = $this->accountFor($customer, $loyaltyProgram);

        if ($account && $loyaltyProgram && $account->current_stamps >= $loyaltyProgram->stamps_required) {
            return 'layak ganjaran';
        }

        if ($customer->created_at?->isToday()) {
            return 'new';
        }

        $lastCheckIn = $customer->check_ins_max_check_in_date
            ? Carbon::parse($customer->check_ins_max_check_in_date)
            : $customer->checkIns->first()?->check_in_date;

        if (! $lastCheckIn || $lastCheckIn->lt(now()->subDays(self::DORMANT_DAYS))) {
            return 'dormant';
        }

        return 'active';
    }

    private function abortInternalOperationPersona(): void
    {
        $user = request()->user();

        abort_if($user?->isSystemManager() || $user?->isSystemAdmin(), 403);
    }

    private function abortUnlessBusinessOwner(Business $business): void
    {
        abort_unless(request()->user()?->isOwner() && (int) $business->owner_user_id === (int) request()->user()->id, 403);
    }
}
