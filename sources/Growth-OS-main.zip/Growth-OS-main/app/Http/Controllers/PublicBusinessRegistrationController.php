<?php

namespace App\Http\Controllers;

use App\Models\Business;
use App\Models\CustomerCheckIn;
use App\Services\CustomerCheckInService;
use App\Services\CustomerRegistrationService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class PublicBusinessRegistrationController extends Controller
{
    public function show(Business $business): View
    {
        $loyaltyProgram = $business->loyaltyPrograms()
            ->active()
            ->latest()
            ->first();

        return view('public.business-register', [
            'business' => $business,
            'loyaltyProgram' => $loyaltyProgram,
        ]);
    }

    public function store(
        Request $request,
        Business $business,
        CustomerRegistrationService $registrations,
    ): View|RedirectResponse {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'whatsapp_number' => ['required', 'string', 'max:30', 'regex:/^(?=(?:.*\d){7,})[0-9+()\-\s]{7,30}$/'],
            'birthday' => ['nullable', 'date', 'before_or_equal:today'],
            'consent_promo' => ['nullable', 'boolean'],
        ]);

        $result = $registrations->register($business, $validated);

        if (! $result['available']) {
            return back()
                ->withInput($request->except('whatsapp_number'))
                ->withErrors(['loyalty_program' => 'This loyalty program is not available yet.']);
        }

        return view('public.registration-status', $result);
    }

    public function checkIn(
        Request $request,
        Business $business,
        CustomerCheckInService $checkIns,
    ): View|RedirectResponse {
        $validated = $request->validate([
            'whatsapp_number' => ['required', 'string', 'max:30', 'regex:/^(?=(?:.*\d){7,})[0-9+()\-\s]{7,30}$/'],
            'check_in_mode' => ['nullable', Rule::in(CustomerCheckIn::CHECK_IN_TYPES)],
        ]);

        $result = $checkIns->checkIn(
            $business,
            $validated['whatsapp_number'],
            $business->branches()->where('is_active', true)->orderBy('name')->first(),
            checkInType: $validated['check_in_mode'] ?? CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL,
        );

        if ($result['status'] === 'program_unavailable') {
            return back()
                ->withInput()
                ->withErrors(['check_in' => 'This loyalty program is not available yet.']);
        }

        if ($result['status'] === 'customer_missing') {
            return back()
                ->withInput()
                ->withErrors(['check_in' => 'We could not find this WhatsApp number here yet. Please register first.']);
        }

        return view('public.registration-status', $result);
    }
}
