<?php

namespace App\Http\Controllers;

use App\Models\Business;
use App\Models\Branch;
use App\Models\Customer;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Services\CustomerFeedbackService;
use App\Services\CustomerRegistrationService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;

class CustomerFeedbackController extends Controller
{
    public function show(Business $business): View
    {
        return view('public.feedback', [
            'business' => $business,
        ]);
    }

    public function store(Request $request, Business $business, CustomerFeedbackService $feedbackService): RedirectResponse
    {
        $validated = $request->validate([
            'whatsapp_number' => ['nullable', 'string', 'max:30', 'regex:/^(?=(?:.*\d){7,})[0-9+()\-\s]{7,30}$/'],
            'food_rating' => ['nullable', 'integer', 'between:1,5'],
            'service_rating' => ['nullable', 'integer', 'between:1,5'],
            'price_feedback' => ['nullable', Rule::in([
                CustomerFeedback::PRICE_CHEAP,
                CustomerFeedback::PRICE_OK,
                CustomerFeedback::PRICE_EXPENSIVE,
            ])],
            'comment' => ['nullable', 'string', 'max:2000'],
        ]);

        if (
            empty($validated['food_rating'])
            && empty($validated['service_rating'])
            && trim((string) ($validated['comment'] ?? '')) === ''
        ) {
            throw ValidationException::withMessages([
                'feedback' => 'Sila pilih sekurang-kurangnya satu rating atau tulis komen ringkas sebelum hantar feedback.',
            ]);
        }

        $customer = $this->matchingCustomer($business, $validated['whatsapp_number'] ?? null);

        CustomerFeedback::query()->create([
            'business_id' => $business->id,
            'customer_id' => $customer?->id,
            'food_rating' => $validated['food_rating'] ?? null,
            'service_rating' => $validated['service_rating'] ?? null,
            'price_feedback' => $validated['price_feedback'] ?? null,
            'comment' => $validated['comment'] ?? null,
            'submitted_at' => now(),
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            ...$feedbackService->summarize($validated['comment'] ?? null),
        ]);

        return redirect()->route('public.business.feedback.success', $business);
    }

    public function success(Business $business): View
    {
        return view('public.feedback-success', [
            'business' => $business,
        ]);
    }

    public function index(Business $business): View
    {
        $this->authorize('view', $business);

        $feedbackQuery = $this->feedbackQueryFor($business, request()->user());

        $feedback = (clone $feedbackQuery)
            ->with(['customer', 'branch', 'checkIn', 'productService', 'capture'])
            ->latest('submitted_at')
            ->latest()
            ->get();

        return view('businesses.feedback', [
            'business' => $business,
            'feedback' => $feedback,
            'summary' => $this->summaryFor($feedbackQuery),
            'branch' => null,
        ]);
    }

    public function branchIndex(Business $business, Branch $branch): View
    {
        abort_unless($branch->business_id === $business->id, 404);

        $this->authorize('view', $branch);

        $feedbackQuery = $this->feedbackQueryFor($business, request()->user())
            ->where('branch_id', $branch->id);

        return view('businesses.feedback', [
            'business' => $business,
            'branch' => $branch,
            'feedback' => (clone $feedbackQuery)
                ->with(['customer', 'branch', 'checkIn', 'productService', 'capture'])
                ->latest('submitted_at')
                ->latest()
                ->get(),
            'summary' => $this->summaryFor($feedbackQuery),
        ]);
    }

    public function customerIndex(Request $request): View
    {
        abort_unless($request->user()->isCustomer(), 403);

        $branches = Branch::query()
            ->with('business')
            ->where('is_active', true)
            ->orderBy('name')
            ->get();

        return view('customer.feedback', [
            'branches' => $branches,
            'productServices' => ProductService::query()
                ->active()
                ->orderBy('name')
                ->get(),
            'feedback' => CustomerFeedback::query()
                ->with(['business', 'branch', 'productService', 'capture'])
                ->where('status', '!=', CustomerFeedback::STATUS_PENDING)
                ->whereHas('customer', fn (Builder $query) => $query->where('user_id', $request->user()->id))
                ->latest('submitted_at')
                ->latest()
                ->get(),
        ]);
    }

    public function customerStore(Request $request, CustomerFeedbackService $feedbackService): RedirectResponse
    {
        abort_unless($request->user()->isCustomer(), 403);

        $validated = $request->validate([
            'branch_id' => ['required', 'integer', 'exists:branches,id'],
            'product_service_id' => ['nullable', 'integer', 'exists:product_services,id'],
            'rating' => ['nullable', 'integer', 'between:1,5'],
            'comment' => ['nullable', 'string', 'max:2000'],
        ]);

        if (trim((string) ($validated['comment'] ?? '')) === '') {
            throw ValidationException::withMessages([
                'feedback' => 'Sila tulis maklumbalas ringkas sebelum hantar.',
            ]);
        }

        $branch = Branch::query()->with('business')->findOrFail($validated['branch_id']);
        $productService = null;

        if (! empty($validated['product_service_id'])) {
            $productService = ProductService::query()
                ->visibleForBranch($branch)
                ->whereKey($validated['product_service_id'])
                ->firstOrFail();
        }

        $customer = Customer::query()
            ->where('user_id', $request->user()->id)
            ->where('business_id', $branch->business_id)
            ->first();

        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer?->id,
            'product_service_id' => $productService?->id,
            'rating' => $validated['rating'] ?? null,
            'comment' => $validated['comment'],
            'source' => 'customer_portal',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'submitted_at' => now(),
            ...$feedbackService->summarize($validated['comment'], $productService?->name),
        ]);

        return redirect()->route('customer.feedback')->with('status', 'Feedback berjaya dihantar.');
    }

    public function updateStatus(Request $request, Business $business, Branch $branch, CustomerFeedback $feedback): RedirectResponse
    {
        abort_unless($branch->business_id === $business->id, 404);
        abort_unless($feedback->business_id === $business->id && $feedback->branch_id === $branch->id, 404);
        $this->authorize('view', $branch);

        $validated = $request->validate([
            'status' => ['required', Rule::in(CustomerFeedback::statuses())],
        ]);

        abort_if($validated['status'] === CustomerFeedback::STATUS_PENDING && $feedback->submitted_at !== null, 422);

        $feedback->update(['status' => $validated['status']]);

        return redirect()
            ->route('businesses.branches.feedback', ['business' => $business, 'branch' => $branch])
            ->with('status', 'Feedback status updated.');
    }

    private function matchingCustomer(Business $business, ?string $whatsappNumber): ?Customer
    {
        if (! $whatsappNumber) {
            return null;
        }

        return $business->customers()
            ->where('whatsapp_number', CustomerRegistrationService::normalizeWhatsappNumber($whatsappNumber))
            ->first();
    }

    private function summaryFor(Builder $feedbackQuery): array
    {
        $averages = (clone $feedbackQuery)
            ->selectRaw('AVG(food_rating) as average_food_rating, AVG(service_rating) as average_service_rating')
            ->first();

        $priceCounts = (clone $feedbackQuery)
            ->select('price_feedback', DB::raw('COUNT(*) as total'))
            ->whereNotNull('price_feedback')
            ->groupBy('price_feedback')
            ->pluck('total', 'price_feedback');

        return [
            'average_food_rating' => $averages?->average_food_rating ? round((float) $averages->average_food_rating, 1) : null,
            'average_service_rating' => $averages?->average_service_rating ? round((float) $averages->average_service_rating, 1) : null,
            'price_counts' => [
                CustomerFeedback::PRICE_CHEAP => (int) ($priceCounts[CustomerFeedback::PRICE_CHEAP] ?? 0),
                CustomerFeedback::PRICE_OK => (int) ($priceCounts[CustomerFeedback::PRICE_OK] ?? 0),
                CustomerFeedback::PRICE_EXPENSIVE => (int) ($priceCounts[CustomerFeedback::PRICE_EXPENSIVE] ?? 0),
            ],
        ];
    }

    private function feedbackQueryFor(Business $business, $user): Builder
    {
        $query = CustomerFeedback::query()->where('business_id', $business->id);

        if ($user->isBranchManager() && ! $user->isOwner() && ! $user->isSystemManager() && ! $user->isSystemAdmin()) {
            $query->whereIn('branch_id', $user->scopedBranchIds());
        }

        return $query;
    }
}
