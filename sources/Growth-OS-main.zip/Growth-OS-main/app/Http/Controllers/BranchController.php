<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Business;
use App\Models\User;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use Illuminate\View\View;

class BranchController extends Controller
{
    public function show(Business $business, Branch $branch): View
    {
        $this->ensureBranchBelongsToBusiness($business, $branch);
        $this->authorize('view', $branch);

        return view('branches.show', [
            'business' => $business,
            'branch' => $branch->load('manager')->loadCount('checkIns'),
        ]);
    }

    public function create(Business $business): View
    {
        $this->authorize('view', $business);
        $this->authorize('create', Branch::class);

        return view('branches.create', [
            'business' => $business,
            'managers' => $this->branchManagers(),
        ]);
    }

    public function store(Request $request, Business $business): RedirectResponse
    {
        $this->authorize('view', $business);
        $this->authorize('create', Branch::class);

        $validated = $this->validatedBranch($request, $business);
        $branch = $business->branches()->create($validated);

        $this->syncBranchManagerScope(null, $branch->manager_user_id, $branch);

        return redirect()
            ->route('businesses.branches.show', ['business' => $business, 'branch' => $branch])
            ->with('status', 'Branch created.');
    }

    public function edit(Business $business, Branch $branch): View
    {
        $this->ensureBranchBelongsToBusiness($business, $branch);
        $this->authorize('update', $branch);

        return view('branches.edit', [
            'business' => $business,
            'branch' => $branch,
            'managers' => $this->branchManagers(),
        ]);
    }

    public function update(Request $request, Business $business, Branch $branch): RedirectResponse
    {
        $this->ensureBranchBelongsToBusiness($business, $branch);
        $this->authorize('update', $branch);

        $oldManagerId = $branch->manager_user_id;
        $branch->update($this->validatedBranch($request, $business, $branch));
        $this->syncBranchManagerScope($oldManagerId, $branch->manager_user_id, $branch);

        return redirect()
            ->route('businesses.branches.show', ['business' => $business, 'branch' => $branch])
            ->with('status', 'Branch updated.');
    }

    public function updateCooldown(Request $request, Business $business, Branch $branch): RedirectResponse
    {
        $this->ensureBranchBelongsToBusiness($business, $branch);

        abort_unless(
            $request->user()->isSystemAdmin()
                || ($request->user()->isOwner() && $business->owner_user_id === $request->user()->id)
                || ($request->user()->isBranchManager() && $request->user()->canAccessBranch($branch)),
            403,
        );

        $validated = $request->validate([
            'check_in_cooldown_minutes' => ['required', 'integer', 'min:15', 'max:1440'],
        ]);

        $branch->update([
            'check_in_cooldown_minutes' => $validated['check_in_cooldown_minutes'],
        ]);

        return redirect()
            ->route('businesses.branches.show', ['business' => $business, 'branch' => $branch])
            ->with('status', 'Check-in cooldown updated.');
    }

    private function ensureBranchBelongsToBusiness(Business $business, Branch $branch): void
    {
        abort_unless($branch->business_id === $business->id, 404);
    }

    /**
     * @return array<string, mixed>
     */
    private function validatedBranch(Request $request, Business $business, ?Branch $branch = null): array
    {
        $validated = $request->validate([
            'manager_user_id' => [
                'nullable',
                Rule::exists('users', 'id')
                    ->where(fn ($query) => $query
                        ->where('role', User::ROLE_BRANCH_MANAGER)
                        ->orWhere('secondary_role', User::ROLE_BRANCH_MANAGER)),
            ],
            'name' => ['required', 'string', 'max:255'],
            'code' => [
                'nullable',
                'string',
                'max:50',
                Rule::unique('branches', 'code')
                    ->where('business_id', $business->id)
                    ->ignore($branch),
            ],
            'address' => ['nullable', 'string', 'max:255'],
            'phone' => ['nullable', 'string', 'max:30'],
            'is_active' => ['nullable', 'boolean'],
            'check_in_cooldown_minutes' => ['nullable', 'integer', 'min:15', 'max:1440'],
        ]);

        $validated['is_active'] = $request->boolean('is_active');
        $validated['check_in_cooldown_minutes'] = $validated['check_in_cooldown_minutes'] ?? 60;

        return $validated;
    }

    private function branchManagers()
    {
        return User::query()
            ->where('role', User::ROLE_BRANCH_MANAGER)
            ->orWhere('secondary_role', User::ROLE_BRANCH_MANAGER)
            ->orderBy('name')
            ->get();
    }

    private function syncBranchManagerScope(?int $oldManagerId, ?int $newManagerId, Branch $branch): void
    {
        foreach (array_filter([$oldManagerId, $newManagerId]) as $managerId) {
            $manager = User::query()->find($managerId);

            if (! $manager) {
                continue;
            }

            $branchIds = collect($manager->scopedBranchIds());

            if ($managerId === $newManagerId) {
                $branchIds->push($branch->id);
            } else {
                $branchIds = $branchIds->reject(fn (int $id) => $id === $branch->id);
            }

            $scope = $manager->access_scope ?? [];
            $scope['branch_ids'] = $branchIds->unique()->values()->all();

            $manager->forceFill(['access_scope' => $scope])->save();
        }
    }
}
