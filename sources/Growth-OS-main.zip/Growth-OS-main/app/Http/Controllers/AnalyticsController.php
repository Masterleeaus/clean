<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Business;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\RewardRedemption;
use App\Models\StampTransaction;
use App\Models\User;
use App\Services\Ai\AiProviderManager;
use App\Services\AiActionService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Carbon;
use Illuminate\View\View;

class AnalyticsController extends Controller
{
    public function __invoke(Request $request, AiProviderManager $ai): View
    {
        $user = $request->user();

        abort_if($user->isCustomer(), 403);

        $period = $this->period($request);

        if ($user->isSystemManager()) {
            return $this->platformAnalytics($period, $ai);
        }

        if ($user->isSystemAdmin()) {
            return $this->adminAnalytics($period, $ai);
        }

        abort_unless($user->isOwner() || $user->isBranchManager(), 403);

        return $this->businessAnalytics($request, $period, $ai);
    }

    private function platformAnalytics(array $period, AiProviderManager $ai): View
    {
        $businesses = Business::query()->orderBy('name')->get();
        $branches = Branch::query()->with('business')->orderBy('name')->get();
        $businessIds = $businesses->pluck('id');
        $branchIds = $branches->pluck('id');

        $payload = $this->analyticsPayload(
                title: 'System Manager Analytics',
                subtitle: 'GOS Sdn Bhd platform/business performance monitoring untuk vertical F&B.',
                scopeLabel: 'GOS platform/business analytics',
                businesses: $businesses,
                branches: $branches,
                businessIds: $businessIds,
                branchIds: $branchIds,
                period: $period,
                combinedBranches: collect(),
            );
        $payload['personaScope'] = 'system_manager';
        $payload['platformMetrics'] = $this->platformMetrics($payload, $businesses, $branches);

        $payload = $this->withAi($payload, $ai);

        return view('analytics.index', $payload);
    }

    private function adminAnalytics(array $period, AiProviderManager $ai): View
    {
        $businesses = Business::query()->orderBy('name')->get();
        $branches = Branch::query()->with('business')->orderBy('name')->get();
        $businessIds = $businesses->pluck('id');
        $branchIds = $branches->pluck('id');

        $payload = $this->analyticsPayload(
                title: 'System Admin Analytics',
                subtitle: 'System/admin/support analytics untuk setup, access, dan platform usage support.',
                scopeLabel: 'System & Access Support Analytics',
                businesses: $businesses,
                branches: $branches,
                businessIds: $businessIds,
                branchIds: $branchIds,
                period: $period,
                combinedBranches: collect(),
            );
        $payload['personaScope'] = 'system_admin';
        $payload['adminSupportMetrics'] = $this->adminSupportMetrics($businesses, $branches);
        $payload['summary'] = [
            'Total users' => $payload['adminSupportMetrics']['System & Access']['Total users'],
            'Total businesses' => $payload['adminSupportMetrics']['Setup Completeness']['Total businesses'],
            'Total branches' => $payload['adminSupportMetrics']['Setup Completeness']['Total branches'],
            'Branch without assigned manager' => $payload['adminSupportMetrics']['Setup Completeness']['Branch without assigned manager'],
            'Product/Service configuration missing' => $payload['adminSupportMetrics']['Platform Usage & Growth Support']['Product/Service configuration missing'],
            'Check-ins recorded' => $payload['adminSupportMetrics']['Platform Usage & Growth Support']['Check-ins recorded'],
            'Feedback records' => $payload['adminSupportMetrics']['Platform Usage & Growth Support']['Feedback records'],
        ];
        $payload['emptyState'] = null;

        $payload = $this->withAi($payload, $ai);
        $payload['aiProviderStatus'] = $ai->status();

        return view('analytics.index', $payload);
    }

    private function businessAnalytics(Request $request, array $period, AiProviderManager $ai): View
    {
        $user = $request->user();
        $businesses = Business::query()->accessibleTo($user)->orderBy('name')->get();
        $branches = Branch::query()->accessibleTo($user)->with('business')->orderBy('name')->get();

        $payload = $this->analyticsPayload(
                title: $user->hasBusinessCombinedAccess()
                    ? 'Business Owner / Branch Manager Analytics'
                    : ($user->isBranchManager() ? 'Branch Manager Analytics' : 'Business Owner Analytics'),
                subtitle: $user->isBranchManager() && ! $user->isOwner()
                    ? 'Assigned branch analytics sahaja.'
                    : 'Business-level analytics untuk business dalam scope.',
                scopeLabel: $user->hasBusinessCombinedAccess()
                    ? 'Business-level dan assigned branch-level analytics'
                    : ($user->isBranchManager() ? 'Assigned branch analytics' : 'Business analytics'),
                businesses: $businesses,
                branches: $branches,
                businessIds: $businesses->pluck('id'),
                branchIds: $branches->pluck('id'),
                period: $period,
                combinedBranches: $user->hasBusinessCombinedAccess()
                    ? Branch::query()->whereIn('id', $user->scopedBranchIds())->with('business')->get()
                    : collect(),
            );

        $payload = $this->withAi($payload, $ai);

        return view('analytics.index', $payload);
    }

    private function withAi(array $payload, AiProviderManager $ai): array
    {
        $insightResult = $ai->insights($payload);
        $payload['aiInsights'] = $insightResult->items;
        $payload['aiInsightProvider'] = $insightResult->metadata();

        $actionResult = $ai->actions($payload);
        $payload['aiActions'] = $actionResult->items;
        $payload['aiActionProvider'] = $actionResult->metadata();
        $payload['aiActionStatuses'] = AiActionService::statuses();

        return $payload;
    }

    private function analyticsPayload(
        string $title,
        string $subtitle,
        string $scopeLabel,
        $businesses,
        $branches,
        $businessIds,
        $branchIds,
        array $period,
        $combinedBranches,
    ): array {
        $captures = $this->captures($businessIds, $branchIds, $period);
        $checkIns = $this->checkIns($businessIds, $branchIds, $period);
        $feedback = $this->feedback($businessIds, $branchIds, $period);
        $customers = Customer::query()
            ->whereIn('business_id', $businessIds)
            ->when($period['start'], fn (Builder $query) => $query->where('created_at', '<=', $period['end']));

        $totalSales = (float) (clone $captures)->sum('total_amount');
        $transactionCount = (clone $captures)->count();
        $activeCustomerIds = (clone $checkIns)->distinct('customer_id')->pluck('customer_id');
        $repeatCustomers = (clone $checkIns)
            ->select('customer_id')
            ->groupBy('customer_id')
            ->havingRaw('COUNT(*) > 1')
            ->get()
            ->count();

        $salesByProduct = $this->salesByProduct(clone $captures);
        $branchAnalytics = $this->branchAnalytics($branches, $period);
        $operationAnalytics = $this->operationAnalytics($businessIds, $branchIds, $period);
        $feedbackStatusCounts = $this->feedbackStatusCounts(clone $feedback);
        $summaryCategories = $this->summaryCategoryCounts(clone $feedback);

        return [
            'title' => $title,
            'subtitle' => $subtitle,
            'scopeLabel' => $scopeLabel,
            'period' => $period,
            'periodOptions' => ['today' => 'Today', 'week' => 'This week', 'month' => 'This month', 'custom' => 'Custom'],
            'summary' => [
                'Total sales/value' => 'RM '.number_format($totalSales, 2),
                'Total transaction/capture' => $transactionCount,
                'Average transaction value' => 'RM '.number_format($transactionCount > 0 ? $totalSales / $transactionCount : 0, 2),
                'Total customers' => (clone $customers)->count(),
                'New customers' => Customer::query()
                    ->whereIn('business_id', $businessIds)
                    ->whereBetween('created_at', [$period['start'], $period['end']])
                    ->count(),
                'Repeat customers' => $repeatCustomers,
                'Active customers' => $activeCustomerIds->filter()->unique()->count(),
                'Total check-ins' => (clone $checkIns)->count(),
                'Purchase count' => $transactionCount,
                'Customer value' => 'RM '.number_format($activeCustomerIds->filter()->unique()->count() > 0 ? $totalSales / $activeCustomerIds->filter()->unique()->count() : 0, 2),
            ],
            'salesAnalytics' => [
                'salesByPeriod' => $this->salesByPeriod(clone $captures),
                'salesByBranch' => $this->salesByBranch(clone $captures),
                'salesByProduct' => $salesByProduct,
            ],
            'customerAnalytics' => [
                'total' => (clone $customers)->count(),
                'new' => Customer::query()->whereIn('business_id', $businessIds)->whereBetween('created_at', [$period['start'], $period['end']])->count(),
                'repeat' => $repeatCustomers,
                'active' => $activeCustomerIds->filter()->unique()->count(),
                'checkIns' => (clone $checkIns)->count(),
                'purchases' => $transactionCount,
                'value' => $totalSales,
            ],
            'productAnalytics' => [
                'popular' => $salesByProduct->sortByDesc('quantity')->first(),
                'highestSales' => $salesByProduct->sortByDesc('total')->first(),
                'mostPurchased' => $salesByProduct->sortByDesc('captures')->first(),
                'lowActivity' => $this->lowActivityProducts($businessIds, $branchIds, $salesByProduct),
                'items' => $salesByProduct,
            ],
            'branchAnalytics' => $branchAnalytics,
            'operationAnalytics' => $operationAnalytics,
            'rewardAnalytics' => [
                'Reward/stamp issued' => (int) StampTransaction::query()
                    ->whereIn('business_id', $businessIds)
                    ->when($branchIds->isNotEmpty(), fn (Builder $query) => $query->whereIn('branch_id', $branchIds))
                    ->where('type', StampTransaction::TYPE_EARNED)
                    ->whereBetween('created_at', [$period['start'], $period['end']])
                    ->sum('stamps'),
                'Reward redeemed' => RewardRedemption::query()
                    ->whereIn('business_id', $businessIds)
                    ->when($branchIds->isNotEmpty(), fn (Builder $query) => $query->whereIn('branch_id', $branchIds))
                    ->whereBetween('created_at', [$period['start'], $period['end']])
                    ->count(),
                'Reward pending' => RewardRedemption::query()
                    ->whereIn('business_id', $businessIds)
                    ->when($branchIds->isNotEmpty(), fn (Builder $query) => $query->whereIn('branch_id', $branchIds))
                    ->whereNull('redeemed_at')
                    ->count(),
            ],
            'feedbackAnalytics' => [
                'Total feedback' => (clone $feedback)->count(),
                ...$feedbackStatusCounts,
                ...$summaryCategories,
            ],
            'dataCompleteness' => $this->dataCompleteness($businessIds, $branchIds, $branches, $period),
            'emptyState' => $transactionCount === 0 && (clone $checkIns)->count() === 0
                ? 'Data belum cukup untuk analytics yang tepat.'
                : null,
            'combinedBranches' => $combinedBranches,
            'personaScope' => 'business',
            'platformMetrics' => [],
            'adminSupportMetrics' => [],
            'aiActions' => [],
            'aiActionStatuses' => AiActionService::statuses(),
            'aiProviderStatus' => [],
            'aiInsightProvider' => [],
            'aiActionProvider' => [],
        ];
    }

    private function platformMetrics(array $payload, $businesses, $branches): array
    {
        $activeBusinesses = $businesses->where('is_active', true)->count();
        $activeBranches = $branches->where('is_active', true)->count();

        return [
            'GOS platform/business performance' => [
                'Total businesses/subscribers' => $businesses->count(),
                'Active businesses' => $activeBusinesses,
                'Inactive businesses' => $businesses->count() - $activeBusinesses,
                'Total branches' => $branches->count(),
                'Active branches' => $activeBranches,
                'Inactive branches' => $branches->count() - $activeBranches,
            ],
            'Business category/vertical performance' => [
                'Current vertical' => 'F&B',
                'F&B businesses' => $businesses->count(),
                'F&B branches' => $branches->count(),
                'Platform sales/value from recorded captures' => $payload['summary']['Total sales/value'] ?? 'RM 0.00',
            ],
            'Platform effectiveness by usage' => [
                'Check-ins' => $payload['summary']['Total check-ins'] ?? 0,
                'Physical check-ins' => $payload['operationAnalytics']['Physical check-ins'] ?? 0,
                'Online check-ins' => $payload['operationAnalytics']['Online check-ins'] ?? 0,
                'Product/Service captures' => $payload['summary']['Total transaction/capture'] ?? 0,
                'Pending purchase capture' => $payload['operationAnalytics']['Pending purchase capture'] ?? 0,
                'No purchase / check-in without purchase' => $payload['operationAnalytics']['No purchase / check-in without purchase'] ?? 0,
                'Feedback records' => $payload['feedbackAnalytics']['Total feedback'] ?? 0,
                'Reward/stamp issued' => $payload['rewardAnalytics']['Reward/stamp issued'] ?? 0,
            ],
            'Revenue/subscription data gap' => [
                'Subscription revenue' => 'Data belum tersedia',
                'GOS billing/payment data' => 'Belum dibina dalam MVP ini',
                'Impact' => 'GOS revenue/subscriber growth tidak boleh dikira dengan tepat sehingga subscription/billing data tersedia.',
            ],
        ];
    }

    private function adminSupportMetrics($businesses, $branches): array
    {
        $missingOwner = $businesses->whereNull('owner_user_id')->count();
        $unassignedBranches = $branches->whereNull('manager_user_id')->count();
        $inactiveBusinesses = $businesses->where('is_active', false)->count();
        $inactiveBranches = $branches->where('is_active', false)->count();
        $incompleteProducts = ProductService::query()
            ->where(function (Builder $query): void {
                $query->whereNull('category')->orWhere('category', '')->orWhere('price', '<=', 0);
            })
            ->count();

        return [
            'System & Access' => [
                'Total users' => User::query()->count(),
                'System Managers' => User::query()->where('role', User::ROLE_SYSTEM_MANAGER)->orWhere('secondary_role', User::ROLE_SYSTEM_MANAGER)->count(),
                'System Admins' => User::query()->where('role', User::ROLE_SYSTEM_ADMIN)->orWhere('secondary_role', User::ROLE_SYSTEM_ADMIN)->count(),
                'Business Owners' => User::query()->where('role', User::ROLE_BUSINESS_OWNER)->orWhere('secondary_role', User::ROLE_BUSINESS_OWNER)->count(),
                'Branch Managers' => User::query()->where('role', User::ROLE_BRANCH_MANAGER)->orWhere('secondary_role', User::ROLE_BRANCH_MANAGER)->count(),
                'Customers' => User::query()->where('role', User::ROLE_CUSTOMER)->orWhere('secondary_role', User::ROLE_CUSTOMER)->count(),
            ],
            'Setup Completeness' => [
                'Total businesses' => $businesses->count(),
                'Total branches' => $branches->count(),
                'Business missing owner' => $missingOwner,
                'Branch without assigned manager' => $unassignedBranches,
                'Inactive businesses' => $inactiveBusinesses,
                'Inactive branches' => $inactiveBranches,
            ],
            'Platform Usage & Growth Support' => [
                'Check-ins recorded' => CustomerCheckIn::query()->count(),
                'Product/Service captures recorded' => CheckInProductService::query()->count(),
                'Feedback records' => CustomerFeedback::query()->count(),
                'Product/Service configuration missing' => $incompleteProducts,
            ],
        ];
    }

    private function period(Request $request): array
    {
        $filter = $request->string('period', 'month')->toString();
        $now = now();

        if ($filter === 'today') {
            $start = $now->copy()->startOfDay();
            $end = $now->copy()->endOfDay();
        } elseif ($filter === 'week') {
            $start = $now->copy()->startOfWeek();
            $end = $now->copy()->endOfWeek();
        } elseif ($filter === 'custom' && $request->filled(['date_from', 'date_to'])) {
            $start = Carbon::parse($request->input('date_from'))->startOfDay();
            $end = Carbon::parse($request->input('date_to'))->endOfDay();
        } else {
            $filter = 'month';
            $start = $now->copy()->startOfMonth();
            $end = $now->copy()->endOfMonth();
        }

        return [
            'filter' => $filter,
            'start' => $start,
            'end' => $end,
            'date_from' => $start->toDateString(),
            'date_to' => $end->toDateString(),
        ];
    }

    private function captures($businessIds, $branchIds, array $period): Builder
    {
        return CheckInProductService::query()
            ->with(['branch.business', 'productService', 'customer'])
            ->whereIn('business_id', $businessIds)
            ->when($branchIds->isNotEmpty(), fn (Builder $query) => $query->whereIn('branch_id', $branchIds))
            ->whereNotNull('customer_check_in_id')
            ->where('total_amount', '>', 0)
            ->whereBetween('created_at', [$period['start'], $period['end']]);
    }

    private function checkIns($businessIds, $branchIds, array $period): Builder
    {
        return CustomerCheckIn::query()
            ->whereIn('business_id', $businessIds)
            ->when($branchIds->isNotEmpty(), fn (Builder $query) => $query->whereIn('branch_id', $branchIds))
            ->whereBetween('check_in_at', [$period['start'], $period['end']]);
    }

    private function feedback($businessIds, $branchIds, array $period): Builder
    {
        return CustomerFeedback::query()
            ->whereIn('business_id', $businessIds)
            ->when($branchIds->isNotEmpty(), fn (Builder $query) => $query->whereIn('branch_id', $branchIds))
            ->where(function (Builder $query) use ($period): void {
                $query->whereBetween('submitted_at', [$period['start'], $period['end']])
                    ->orWhere(function (Builder $query) use ($period): void {
                        $query->where('status', CustomerFeedback::STATUS_PENDING)
                            ->whereBetween('created_at', [$period['start'], $period['end']]);
                    });
            });
    }

    private function salesByPeriod(Builder $captures)
    {
        return $captures->get()
            ->groupBy(fn (CheckInProductService $capture) => $capture->created_at?->toDateString() ?? 'Unknown')
            ->map(fn ($items, string $date) => [
                'label' => $date,
                'total' => (float) $items->sum('total_amount'),
                'captures' => $items->count(),
            ])
            ->values();
    }

    private function salesByBranch(Builder $captures)
    {
        return $captures->get()
            ->groupBy(fn (CheckInProductService $capture) => $capture->branch?->name ?? 'Unknown branch')
            ->map(fn ($items, string $name) => [
                'name' => $name,
                'total' => (float) $items->sum('total_amount'),
                'captures' => $items->count(),
            ])
            ->values();
    }

    private function salesByProduct(Builder $captures)
    {
        return $captures->get()
            ->groupBy(fn (CheckInProductService $capture) => $capture->productService?->name ?? 'Unknown product')
            ->map(fn ($items, string $name) => [
                'name' => $name,
                'quantity' => (int) $items->sum('quantity'),
                'total' => (float) $items->sum('total_amount'),
                'captures' => $items->count(),
            ])
            ->values();
    }

    private function lowActivityProducts($businessIds, $branchIds, $salesByProduct)
    {
        $activeNames = $salesByProduct->pluck('name')->all();

        return ProductService::query()
            ->whereIn('business_id', $businessIds)
            ->when($branchIds->isNotEmpty(), fn (Builder $query) => $query->where(function (Builder $query) use ($branchIds): void {
                $query->whereNull('branch_id')->orWhereIn('branch_id', $branchIds);
            }))
            ->whereNotIn('name', $activeNames)
            ->orderBy('name')
            ->limit(5)
            ->get()
            ->map(fn (ProductService $product) => ['name' => $product->name, 'quantity' => 0, 'total' => 0.0, 'captures' => 0]);
    }

    private function branchAnalytics($branches, array $period)
    {
        return $branches->map(function (Branch $branch) use ($period): array {
            $captures = $this->captures(collect([$branch->business_id]), collect([$branch->id]), $period);
            $checkIns = $this->checkIns(collect([$branch->business_id]), collect([$branch->id]), $period);
            $feedback = $this->feedback(collect([$branch->business_id]), collect([$branch->id]), $period);

            return [
                'name' => $branch->business?->name.' - '.$branch->name,
                'sales' => (float) (clone $captures)->sum('total_amount'),
                'check_ins' => (clone $checkIns)->count(),
                'customers' => (clone $checkIns)->distinct('customer_id')->count('customer_id'),
                'repeat_customers' => (clone $checkIns)->select('customer_id')->groupBy('customer_id')->havingRaw('COUNT(*) > 1')->get()->count(),
                'feedback_pending' => (clone $feedback)->where('status', CustomerFeedback::STATUS_PENDING)->count(),
                'feedback_action_needed' => (clone $feedback)->where('status', CustomerFeedback::STATUS_ACTION_NEEDED)->count(),
            ];
        });
    }

    private function operationAnalytics($businessIds, $branchIds, array $period): array
    {
        $checkIns = $this->checkIns($businessIds, $branchIds, $period);

        return [
            'Physical check-ins' => (clone $checkIns)
                ->where('check_in_type', CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL)
                ->count(),
            'Online check-ins' => (clone $checkIns)
                ->where('check_in_type', CustomerCheckIn::CHECK_IN_TYPE_ONLINE)
                ->count(),
            'Pending purchase capture' => (clone $checkIns)
                ->where('reward_status', CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT)
                ->where('check_in_at', '>', now()->subHours(CustomerCheckIn::OVERDUE_PURCHASE_CAPTURE_HOURS))
                ->count(),
            'Pending purchase capture - physical' => (clone $checkIns)
                ->where('check_in_type', CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL)
                ->where('reward_status', CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT)
                ->where('check_in_at', '>', now()->subHours(CustomerCheckIn::OVERDUE_PURCHASE_CAPTURE_HOURS))
                ->count(),
            'Pending purchase capture - online' => (clone $checkIns)
                ->where('check_in_type', CustomerCheckIn::CHECK_IN_TYPE_ONLINE)
                ->where('reward_status', CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT)
                ->where('check_in_at', '>', now()->subHours(CustomerCheckIn::OVERDUE_PURCHASE_CAPTURE_HOURS))
                ->count(),
            'Overdue purchase capture' => (clone $checkIns)
                ->where('reward_status', CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT)
                ->where('check_in_at', '<=', now()->subHours(CustomerCheckIn::OVERDUE_PURCHASE_CAPTURE_HOURS))
                ->where('check_in_at', '>', now()->subHours(CustomerCheckIn::MANUAL_REVIEW_HOURS))
                ->count(),
            'Manual review required' => (clone $checkIns)
                ->where('reward_status', CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT)
                ->where('check_in_at', '<=', now()->subHours(CustomerCheckIn::MANUAL_REVIEW_HOURS))
                ->count(),
            'No purchase / check-in without purchase' => (clone $checkIns)
                ->where('reward_status', CustomerCheckIn::REWARD_STATUS_NO_PURCHASE)
                ->count(),
            'No purchase - physical' => (clone $checkIns)
                ->where('check_in_type', CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL)
                ->where('reward_status', CustomerCheckIn::REWARD_STATUS_NO_PURCHASE)
                ->count(),
            'No purchase - online' => (clone $checkIns)
                ->where('check_in_type', CustomerCheckIn::CHECK_IN_TYPE_ONLINE)
                ->where('reward_status', CustomerCheckIn::REWARD_STATUS_NO_PURCHASE)
                ->count(),
            'Check-ins without Product/Service capture' => (clone $checkIns)
                ->whereDoesntHave('productServiceCaptures')
                ->count(),
            'Check-ins with Product/Service capture' => (clone $checkIns)
                ->whereHas('productServiceCaptures')
                ->count(),
            'Capture conversion - physical' => $this->captureConversionByMode($checkIns, CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL),
            'Capture conversion - online' => $this->captureConversionByMode($checkIns, CustomerCheckIn::CHECK_IN_TYPE_ONLINE),
        ];
    }

    private function captureConversionByMode(Builder $checkIns, string $checkInType): string
    {
        $total = (clone $checkIns)
            ->where('check_in_type', $checkInType)
            ->count();

        $captured = (clone $checkIns)
            ->where('check_in_type', $checkInType)
            ->whereHas('productServiceCaptures')
            ->count();

        $percentage = $total > 0 ? round(($captured / $total) * 100) : 0;

        return $captured.' / '.$total.' ('.$percentage.'%)';
    }

    private function feedbackStatusCounts(Builder $feedback): array
    {
        $counts = $feedback->selectRaw('status, COUNT(*) as total')->groupBy('status')->pluck('total', 'status');

        return [
            'Pending feedback' => (int) ($counts[CustomerFeedback::STATUS_PENDING] ?? 0),
            'Submitted feedback' => (int) ($counts[CustomerFeedback::STATUS_SUBMITTED] ?? 0),
            'Reviewed feedback' => (int) ($counts[CustomerFeedback::STATUS_REVIEWED] ?? 0),
            'Action needed feedback' => (int) ($counts[CustomerFeedback::STATUS_ACTION_NEEDED] ?? 0),
            'Resolved feedback' => (int) ($counts[CustomerFeedback::STATUS_RESOLVED] ?? 0),
        ];
    }

    private function summaryCategoryCounts(Builder $feedback): array
    {
        $counts = $feedback->selectRaw('summary_issue_category, COUNT(*) as total')
            ->whereNotNull('summary_issue_category')
            ->groupBy('summary_issue_category')
            ->pluck('total', 'summary_issue_category');

        return [
            'Positive summary' => (int) ($counts['positive_feedback'] ?? 0),
            'Negative/general issue summary' => (int) (($counts['general_issue'] ?? 0) + ($counts['service'] ?? 0) + ($counts['price'] ?? 0) + ($counts['product_quality'] ?? 0)),
            'Unclear summary' => (int) ($counts['unclear'] ?? 0),
        ];
    }

    private function dataCompleteness($businessIds, $branchIds, $branches, array $period): array
    {
        $items = [];
        $checkInCount = (clone $this->checkIns($businessIds, $branchIds, $period))->count();
        $captureCount = (clone $this->captures($businessIds, $branchIds, $period))->count();
        $pendingFeedback = (clone $this->feedback($businessIds, $branchIds, $period))->where('status', CustomerFeedback::STATUS_PENDING)->count();
        $customers = Customer::query()->whereIn('business_id', $businessIds)->count();
        $repeatCustomers = (clone $this->checkIns($businessIds, $branchIds, $period))->select('customer_id')->groupBy('customer_id')->havingRaw('COUNT(*) > 1')->get()->count();
        $rewardIssued = StampTransaction::query()->whereIn('business_id', $businessIds)->where('type', StampTransaction::TYPE_EARNED)->count();
        $incompleteProducts = ProductService::query()
            ->whereIn('business_id', $businessIds)
            ->where(function (Builder $query): void {
                $query->whereNull('category')->orWhere('category', '')->orWhere('price', '<=', 0);
            })
            ->count();

        if ($checkInCount < 5) {
            $items[] = $this->recommendation('Insufficient check-in data', 'Check-in masih rendah, jadi trend customer belum stabil.', 'Analytics repeat/active customer kurang tepat.', 'aktifkan QR check-in di branch');
        }

        if ($captureCount < $checkInCount) {
            $items[] = $this->recommendation('Inconsistent Product/Service capture', 'Tidak semua check-in mempunyai Product/Service capture.', 'Sales dan product analytics boleh jadi rendah daripada realiti.', 'pastikan staff capture Product/Service setiap transaksi');
        }

        if ($incompleteProducts > 0) {
            $items[] = $this->recommendation('Incomplete price/category data', 'Ada Product/Service tanpa harga atau kategori lengkap.', 'Revenue dan product comparison kurang tepat.', 'lengkapkan harga/kategori Product/Service');
        }

        if ($pendingFeedback > 0) {
            $items[] = $this->recommendation('Low feedback signal', 'Feedback customer masih rendah atau belum lengkap.', 'Feedback analytics belum menggambarkan pengalaman penuh customer.', 'galakkan Customer hantar maklumbalas apabila perlu');
        }

        if ($customers < 5) {
            $items[] = $this->recommendation('Insufficient customer data', 'Jumlah customer masih rendah.', 'Customer analytics dan customer value belum kuat.', 'galakkan lebih ramai customer check-in');
        }

        if ($repeatCustomers < 2) {
            $items[] = $this->recommendation('Insufficient repeat customer data', 'Repeat customer masih rendah.', 'Retention analytics belum cukup kuat.', 'galakkan repeat check-in');
        }

        foreach ($branches as $branch) {
            if ((clone $this->checkIns(collect([$branch->business_id]), collect([$branch->id]), $period))->count() === 0) {
                $items[] = $this->recommendation('Branch with weak data', "{$branch->name} belum mempunyai check-in dalam tempoh ini.", 'Branch comparison tidak seimbang.', 'aktifkan QR check-in di branch');
                break;
            }
        }

        if ($rewardIssued === 0) {
            $items[] = $this->recommendation('Insufficient reward data', 'Belum ada reward/stamp issued.', 'Reward analytics belum boleh menilai loyalty activity.', 'pastikan Product/Service capture valid memberi stamp');
        }

        if ($captureCount === 0) {
            $items[] = $this->recommendation('Product/Service capture missing', 'Belum ada sales capture yang lengkap.', 'Revenue analytics belum tersedia.', 'rekod Capture Purchase selepas purchase disahkan');
        }

        return $items;
    }

    private function recommendation(string $missing, string $reason, string $effect, string $recommendation): array
    {
        return compact('missing', 'reason', 'effect', 'recommendation');
    }
}
