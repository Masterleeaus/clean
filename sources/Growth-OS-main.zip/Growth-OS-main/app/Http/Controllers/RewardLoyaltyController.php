<?php

namespace App\Http\Controllers;

use App\Models\Branch;
use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerLoyaltyAccount;
use App\Models\RewardRedemption;
use App\Models\StampTransaction;
use App\Services\RewardRedemptionService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class RewardLoyaltyController extends Controller
{
    public function customerStatus(Request $request): View
    {
        abort_unless($request->user()->isCustomer(), 403);

        $customerIds = Customer::query()
            ->where('user_id', $request->user()->id)
            ->pluck('id');

        return view('customer.rewards', [
            'accounts' => CustomerLoyaltyAccount::query()
                ->with(['business', 'customer', 'loyaltyProgram'])
                ->whereIn('customer_id', $customerIds)
                ->orderByDesc('updated_at')
                ->get(),
            'stampTransactions' => StampTransaction::query()
                ->with(['business', 'branch', 'loyaltyProgram'])
                ->whereIn('customer_id', $customerIds)
                ->latest()
                ->limit(10)
                ->get(),
            'rewardRedemptions' => RewardRedemption::query()
                ->with(['business', 'branch', 'loyaltyProgram'])
                ->whereIn('customer_id', $customerIds)
                ->latest('redeemed_at')
                ->latest()
                ->limit(10)
                ->get(),
        ]);
    }

    public function businessIndex(Request $request, Business $business): View
    {
        $this->authorize('view', $business);

        $accounts = CustomerLoyaltyAccount::query()
            ->with(['customer', 'loyaltyProgram'])
            ->where('business_id', $business->id)
            ->when(
                $request->user()->isBranchManager() && ! $request->user()->isOwner(),
                fn ($query) => $query->whereHas('customer.checkIns', fn ($checkInQuery) => $checkInQuery->whereIn('branch_id', $request->user()->scopedBranchIds())),
            )
            ->orderByDesc('current_stamps')
            ->get();

        return view('rewards.index', [
            'title' => 'Business Reward/Loyalty',
            'business' => $business,
            'branch' => null,
            'accounts' => $accounts,
        ]);
    }

    public function branchIndex(Business $business, Branch $branch): View
    {
        abort_unless($branch->business_id === $business->id, 404);
        abort_unless($this->canOperateAssignedBranch(request(), $branch), 403);
        $this->authorize('view', $branch);

        return view('rewards.index', [
            'title' => 'Branch Reward/Loyalty',
            'business' => $business,
            'branch' => $branch,
            'accounts' => CustomerLoyaltyAccount::query()
                ->with(['customer', 'loyaltyProgram'])
                ->where('business_id', $business->id)
                ->whereHas('customer.checkIns', fn ($query) => $query->where('branch_id', $branch->id))
                ->orderByDesc('current_stamps')
                ->get(),
        ]);
    }

    public function redeem(
        Request $request,
        Business $business,
        Branch $branch,
        Customer $customer,
        RewardRedemptionService $redemptions,
    ): RedirectResponse {
        abort_unless($branch->business_id === $business->id, 404);
        abort_unless($customer->business_id === $business->id, 404);
        abort_unless($this->canOperateAssignedBranch($request, $branch), 403);
        $this->authorize('view', $branch);

        $redemptions->redeem($business, $customer, $request->user(), $branch);

        return redirect()
            ->route('businesses.branches.rewards.index', ['business' => $business, 'branch' => $branch])
            ->with('status', 'Ganjaran berjaya direkodkan.');
    }

    private function canOperateAssignedBranch(Request $request, Branch $branch): bool
    {
        $user = $request->user();

        return $user->isBranchManager()
            && in_array($branch->id, $user->scopedBranchIds(), true);
    }
}
