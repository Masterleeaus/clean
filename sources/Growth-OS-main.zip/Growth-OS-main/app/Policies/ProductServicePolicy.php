<?php

namespace App\Policies;

use App\Models\ProductService;
use App\Models\User;

class ProductServicePolicy
{
    public function viewAny(User $user): bool
    {
        return $user->isSystemManager() || $user->isSystemAdmin() || $user->isOwner() || $user->isBranchManager();
    }

    public function view(User $user, ProductService $productService): bool
    {
        if ($user->isSystemManager() || $user->isSystemAdmin()) {
            return true;
        }

        if (! $user->canAccessBusiness($productService->business)) {
            return false;
        }

        return $productService->branch_id === null
            || $user->canAccessBranch($productService->branch);
    }

    public function create(User $user): bool
    {
        return $user->isSystemAdmin() || $user->isOwner() || $user->isBranchManager();
    }

    public function update(User $user, ProductService $productService): bool
    {
        return $user->isSystemAdmin()
            || ($user->isOwner() && $productService->business?->owner_user_id === $user->id)
            || ($user->isOwner() && in_array($productService->business_id, $user->scopedBusinessIds(), true))
            || ($user->isBranchManager() && $productService->branch_id !== null && $user->canAccessBranch($productService->branch));
    }

    public function delete(User $user, ProductService $productService): bool
    {
        return $this->update($user, $productService);
    }
}
