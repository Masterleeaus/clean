<?php

namespace App\Services;

use Illuminate\Support\Collection;

class AiActionService
{
    public const STATUS_SUGGESTED = 'Suggested';

    public const STATUS_PLANNED = 'Planned';

    public const STATUS_IN_PROGRESS = 'In Progress';

    public const STATUS_DONE = 'Done';

    public const STATUS_DISMISSED = 'Dismissed';

    /**
     * @return array<int, array{
     *     title: string,
     *     recommended_action: string,
     *     reason: string,
     *     linked_insight: string,
     *     evidence: array<int, string>,
     *     target: string,
     *     owner: string,
     *     priority: string,
     *     confidence: string,
     *     success_metric: string,
     *     suggested_period: string,
     *     data_gap: ?string,
     *     status: string,
     *     target_lists: array<int, array{title: string, items: array<int, array<string, string>>}>
     * }>
     */
    public function fromAnalytics(array $analytics): array
    {
        return match ($analytics['personaScope'] ?? 'business') {
            'system_admin' => $this->systemAdminActions($analytics),
            'system_manager' => $this->systemManagerActions($analytics),
            default => $this->businessActions($analytics),
        };
    }

    /**
     * @return array<int, string>
     */
    public static function statuses(): array
    {
        return [
            self::STATUS_SUGGESTED,
            self::STATUS_PLANNED,
            self::STATUS_IN_PROGRESS,
            self::STATUS_DONE,
            self::STATUS_DISMISSED,
        ];
    }

    private function businessActions(array $analytics): array
    {
        $insights = collect($analytics['aiInsights'] ?? []);
        $productAnalytics = $analytics['productAnalytics'] ?? [];
        $operationAnalytics = $analytics['operationAnalytics'] ?? [];
        $feedbackAnalytics = $analytics['feedbackAnalytics'] ?? [];
        $branchAnalytics = collect($analytics['branchAnalytics'] ?? []);
        $dataCompleteness = collect($analytics['dataCompleteness'] ?? []);
        $pureBranchManager = str_contains((string) ($analytics['title'] ?? ''), 'Branch Manager')
            && ! str_contains((string) ($analytics['title'] ?? ''), 'Business Owner / Branch Manager');
        $owner = $pureBranchManager ? 'Branch Manager' : 'Business Owner';
        $target = $pureBranchManager ? 'Assigned branch' : 'Owned business/branches';

        $negativeFeedback = (int) ($feedbackAnalytics['Negative/general issue summary'] ?? 0)
            + (int) ($feedbackAnalytics['Action needed feedback'] ?? 0);
        $pendingPurchaseCapture = (int) ($operationAnalytics['Pending purchase capture'] ?? 0);
        $overduePurchaseCapture = (int) ($operationAnalytics['Overdue purchase capture'] ?? 0);
        $manualReviewRequired = (int) ($operationAnalytics['Manual review required'] ?? 0);
        $noPurchase = (int) ($operationAnalytics['No purchase / check-in without purchase'] ?? 0);
        $checkInsWithoutCapture = (int) ($operationAnalytics['Check-ins without Product/Service capture'] ?? 0);

        if ($overduePurchaseCapture > 0 || $manualReviewRequired > 0) {
            return [
                $this->action(
                    title: 'Follow up overdue purchase review',
                    recommendedAction: 'Review overdue and manual-review check-ins, then record Capture Purchase or Mark No Purchase with a clear reason.',
                    reason: 'Delayed purchase review can hide reward eligibility and weaken analytics accuracy.',
                    linkedInsight: $this->insightTitle($insights, 'Operational follow-up risk insight'),
                    evidence: $this->evidenceFor($insights, 'Operational follow-up risk insight', [
                        'Overdue purchase capture: '.$overduePurchaseCapture,
                        'Manual review required: '.$manualReviewRequired,
                    ]),
                    target: $target.' overdue/manual review check-ins',
                    owner: $owner,
                    priority: 'High',
                    confidence: ($overduePurchaseCapture + $manualReviewRequired) >= 3 ? 'medium' : 'low',
                    successMetric: 'Overdue/manual review count decreases after human review.',
                    suggestedPeriod: '3 days',
                    dataGap: ($overduePurchaseCapture + $manualReviewRequired) >= 3 ? null : 'Volume is still low, but follow-up prevents stale pending records.',
                    targetLists: [[
                        'title' => 'Related Branch Targets',
                        'items' => $this->branchTargetItems($analytics),
                    ]],
                ),
            ];
        }

        if ($pendingPurchaseCapture > 0 || $checkInsWithoutCapture > 0) {
            return [
                $this->action(
                    title: 'Review pending purchase capture backlog',
                    recommendedAction: 'Ask branch staff to verify pending check-ins and record valid Product/Service capture or Mark No Purchase.',
                    reason: 'Check-ins without purchase capture cannot confirm reward and make revenue/product analytics incomplete.',
                    linkedInsight: $this->insightTitle($insights, 'Purchase conversion / capture backlog insight'),
                    evidence: $this->evidenceFor($insights, 'Purchase conversion / capture backlog insight', [
                        'Pending purchase capture: '.$pendingPurchaseCapture,
                        'Check-ins without Product/Service capture: '.$checkInsWithoutCapture,
                    ]),
                    target: $target.' pending purchase capture list',
                    owner: $owner,
                    priority: $checkInsWithoutCapture >= 5 ? 'High' : 'Medium',
                    confidence: $checkInsWithoutCapture >= 5 ? 'medium' : 'low',
                    successMetric: 'Pending purchase capture count is reduced and valid captures/no-purchase decisions are recorded.',
                    suggestedPeriod: '7 days',
                    dataGap: 'Some check-ins still lack Product/Service capture or no-purchase decision.',
                    targetLists: [[
                        'title' => 'Related Branch Targets',
                        'items' => $this->branchTargetItems($analytics),
                    ]],
                ),
            ];
        }

        if ($noPurchase > 0) {
            return [
                $this->action(
                    title: 'Improve check-in to purchase conversion signal',
                    recommendedAction: 'Review No Purchase check-ins with branch staff and confirm whether check-in placement or staff capture process needs clarification.',
                    reason: 'Repeated No Purchase records can indicate check-ins before actual purchase or missed purchase capture.',
                    linkedInsight: $this->insightTitle($insights, 'No Purchase pattern insight'),
                    evidence: $this->evidenceFor($insights, 'No Purchase pattern insight', [
                        'No purchase / check-in without purchase: '.$noPurchase,
                    ]),
                    target: $target.' no-purchase check-ins',
                    owner: $owner,
                    priority: 'Medium',
                    confidence: $noPurchase >= 3 ? 'medium' : 'low',
                    successMetric: 'No Purchase pattern is reviewed and valid purchase captures are recorded correctly.',
                    suggestedPeriod: '7 days',
                    dataGap: $noPurchase >= 3 ? null : 'No Purchase data is still low.',
                    targetLists: [[
                        'title' => 'Related Branch Targets',
                        'items' => $this->branchTargetItems($analytics),
                    ]],
                ),
            ];
        }

        if ($negativeFeedback > 0) {
            return [
                $this->action(
                    title: 'Follow up recurring negative feedback',
                    recommendedAction: 'Review submitted negative/action-needed feedback and close the visible service issue with human follow-up.',
                    reason: 'Recurring negative feedback can reduce repeat visits and trust if it is not reviewed.',
                    linkedInsight: $this->insightTitle($insights, 'Feedback pattern insight'),
                    evidence: $this->evidenceFor($insights, 'Feedback pattern insight', [
                        'Negative/action-needed feedback: '.$negativeFeedback,
                        'Total feedback: '.($feedbackAnalytics['Total feedback'] ?? 0),
                    ]),
                    target: $target.' feedback records',
                    owner: $owner,
                    priority: 'High',
                    confidence: ((int) ($feedbackAnalytics['Total feedback'] ?? 0)) >= 5 ? 'medium' : 'low',
                    successMetric: 'Action-needed feedback decreases or reaches Resolved status after review.',
                    suggestedPeriod: '7 days',
                    dataGap: ((int) ($feedbackAnalytics['Total feedback'] ?? 0)) >= 5 ? null : 'Feedback volume is still low, so review outcome carefully.',
                    targetLists: [[
                        'title' => 'Related Feedback Targets',
                        'items' => $this->feedbackTargetItems($analytics),
                    ]],
                ),
            ];
        }

        $popularProduct = $productAnalytics['popular'] ?? null;
        $lowActivityProduct = $this->firstItem($productAnalytics['lowActivity'] ?? collect());

        if ($popularProduct) {
            return [
                $this->action(
                    title: 'Increase sales for high-potential Product/Service',
                    recommendedAction: 'Use the current high-interest Product/Service as the first item to monitor for sales lift and operational readiness.',
                    reason: 'A Product/Service with the strongest capture signal can anchor business learning without guessing demand.',
                    linkedInsight: $this->insightTitle($insights, 'Product/Service performance insight'),
                    evidence: array_values(array_unique(array_merge($this->evidenceFor($insights, 'Product/Service performance insight', [
                        'Popular Product/Service: '.$popularProduct['name'],
                        'Quantity sold/subscribed: '.$popularProduct['quantity'],
                    ]), [
                        'Quantity sold/subscribed: '.$popularProduct['quantity'],
                    ]))),
                    target: $popularProduct['name'],
                    owner: $owner,
                    priority: ((int) $popularProduct['quantity']) >= 5 ? 'High' : 'Medium',
                    confidence: ((int) $popularProduct['quantity']) >= 5 ? 'medium' : 'low',
                    successMetric: 'Captured quantity and sales/value for the target Product/Service increase in the next period.',
                    suggestedPeriod: '14 days',
                    dataGap: ((int) $popularProduct['quantity']) >= 5 ? null : 'More Product/Service capture is needed before treating this as a strong product signal.',
                    targetLists: [[
                        'title' => 'Related Product/Service Targets',
                        'items' => $this->productTargetItems($analytics),
                    ]],
                ),
            ];
        }

        if ($lowActivityProduct) {
            return [
                $this->action(
                    title: 'Improve weak Product/Service data',
                    recommendedAction: 'Check whether the weak Product/Service is actually offered, visible to staff, and captured correctly.',
                    reason: 'Low activity can mean weak demand, missing setup, or staff not capturing the item.',
                    linkedInsight: $this->insightTitle($insights, 'Product/Service performance insight'),
                    evidence: ['Weak/low activity Product/Service: '.$lowActivityProduct['name']],
                    target: $lowActivityProduct['name'],
                    owner: $owner,
                    priority: 'Medium',
                    confidence: 'low',
                    successMetric: 'The item has valid capture data or is marked inactive if not offered.',
                    suggestedPeriod: '7 days',
                    dataGap: 'Product/Service capture is not sufficient to separate weak demand from missing capture.',
                    targetLists: [[
                        'title' => 'Related Product/Service Targets',
                        'items' => $this->productTargetItems($analytics),
                    ]],
                ),
            ];
        }

        $weakBranch = $branchAnalytics
            ->sortBy(fn (array $branch): float => (float) $branch['sales'] + (int) $branch['check_ins'])
            ->first();

        if ($weakBranch) {
            return [
                $this->action(
                    title: 'Improve weak branch performance signal',
                    recommendedAction: 'Review the branch with weak usage signal and make sure check-in, Product/Service capture, feedback, and reward flow are used by staff.',
                    reason: 'A branch with weak data cannot be measured reliably and may hide operational issues.',
                    linkedInsight: $this->insightTitle($insights, 'Branch performance insight'),
                    evidence: $this->evidenceFor($insights, 'Branch performance insight', [
                        'Weak branch: '.$weakBranch['name'],
                        'Check-ins: '.$weakBranch['check_ins'],
                        'Sales/value: RM '.number_format((float) $weakBranch['sales'], 2),
                    ]),
                    target: $weakBranch['name'],
                    owner: $owner,
                    priority: 'Medium',
                    confidence: ((int) $weakBranch['check_ins']) > 0 ? 'medium' : 'low',
                    successMetric: 'Branch records valid check-ins, Product/Service captures, and feedback in the next period.',
                    suggestedPeriod: '14 days',
                    dataGap: ((int) $weakBranch['check_ins']) > 0 ? null : 'Branch usage data is missing or too low.',
                    targetLists: [[
                        'title' => 'Related Branch Targets',
                        'items' => $this->branchTargetItems($analytics),
                    ]],
                ),
            ];
        }

        return [
            $this->dataCompletionAction($dataCompleteness, $owner, $target),
        ];
    }

    private function systemAdminActions(array $analytics): array
    {
        $metrics = $analytics['adminSupportMetrics'] ?? [];
        $setup = $metrics['Setup Completeness'] ?? [];
        $usage = $metrics['Platform Usage & Growth Support'] ?? [];
        $branchesWithoutManager = (int) ($setup['Branch without assigned manager'] ?? 0);
        $missingConfig = (int) ($usage['Product/Service configuration missing'] ?? 0);

        if ($branchesWithoutManager > 0) {
            return [
                $this->action(
                    title: 'Complete branch manager assignment',
                    recommendedAction: 'Review branches without assigned manager and complete the manager assignment or mark setup status clearly.',
                    reason: 'Unassigned branches create support and access gaps for branch-level operation.',
                    linkedInsight: 'Setup completeness insight',
                    evidence: ['Branch without assigned manager: '.$branchesWithoutManager],
                    target: 'Branch setup',
                    owner: 'System Admin',
                    priority: 'High',
                    confidence: 'medium',
                    successMetric: 'Every active branch has an assigned manager or a clear setup exception.',
                    suggestedPeriod: '7 days',
                    dataGap: null,
                    targetLists: [[
                        'title' => 'Related Admin Setup Targets',
                        'items' => [[
                            'Issue' => 'Branch without assigned manager',
                            'Evidence Count' => (string) $branchesWithoutManager,
                            'Scope' => 'System/admin/support',
                        ]],
                    ]],
                ),
            ];
        }

        return [
            $this->action(
                title: 'Resolve setup/access/support issue',
                recommendedAction: 'Review platform setup completeness and missing configuration before supporting business usage.',
                reason: 'Support quality depends on complete setup, correct access, and usable Product/Service configuration.',
                linkedInsight: 'Platform usage support insight',
                evidence: [
                    'Product/Service configuration missing: '.$missingConfig,
                    'Check-ins recorded: '.($usage['Check-ins recorded'] ?? 0),
                    'Feedback records: '.($usage['Feedback records'] ?? 0),
                ],
                target: 'System/admin/support configuration',
                owner: 'System Admin',
                priority: $missingConfig > 0 ? 'Medium' : 'Low',
                confidence: $missingConfig > 0 ? 'medium' : 'low',
                successMetric: 'Missing setup/configuration items are reviewed and reduced.',
                suggestedPeriod: '7 days',
                dataGap: $missingConfig > 0 ? null : 'Support issues are limited by available setup/status indicators.',
                targetLists: [],
            ),
        ];
    }

    private function systemManagerActions(array $analytics): array
    {
        $platformMetrics = $analytics['platformMetrics'] ?? [];
        $usage = $platformMetrics['Platform effectiveness by usage'] ?? [];
        $revenueGap = $platformMetrics['Revenue/subscription data gap'] ?? [];
        $checkIns = (int) ($usage['Check-ins'] ?? 0);
        $captures = (int) ($usage['Product/Service captures'] ?? 0);

        if (($revenueGap['Subscription revenue'] ?? null) === 'Data belum tersedia') {
            return [
                $this->action(
                    title: 'Complete GOS revenue/subscription data gap',
                    recommendedAction: 'Track subscription/revenue readiness as a data gap for GOS platform performance monitoring.',
                    reason: 'GOS business performance cannot include subscription revenue until the data exists; showing the gap prevents fake revenue conclusions.',
                    linkedInsight: 'GOS revenue/subscription data gap insight',
                    evidence: [
                        'Subscription revenue: '.($revenueGap['Subscription revenue'] ?? 'Data belum tersedia'),
                        'GOS billing/payment data: '.($revenueGap['GOS billing/payment data'] ?? 'Belum dibina dalam MVP ini'),
                        'Platform check-ins: '.$checkIns,
                        'Product/Service captures: '.$captures,
                    ],
                    target: 'GOS platform/business performance monitoring',
                    owner: 'System Manager',
                    priority: 'Medium',
                    confidence: 'low',
                    successMetric: 'Revenue/subscription data remains clearly marked as unavailable until a real source exists.',
                    suggestedPeriod: '14 days',
                    dataGap: 'Subscription revenue and billing/payment data are not available in this MVP.',
                    targetLists: [[
                        'title' => 'Related Platform Targets',
                        'items' => [[
                            'Target' => 'F&B vertical',
                            'Issue/Metric' => 'Revenue/subscription data gap',
                            'Evidence Count' => 'No subscription revenue source',
                        ]],
                    ]],
                ),
            ];
        }

        return [
            $this->action(
                title: 'Support GOS platform effectiveness monitoring',
                recommendedAction: 'Monitor platform usage by vertical/category and identify inactive business or branch usage gaps.',
                reason: 'Platform effectiveness improves when active usage signals are visible across businesses and branches.',
                linkedInsight: 'GOS platform performance insight',
                evidence: [
                    'Check-ins: '.$checkIns,
                    'Product/Service captures: '.$captures,
                    'Feedback records: '.($usage['Feedback records'] ?? 0),
                    'Reward/stamp issued: '.($usage['Reward/stamp issued'] ?? 0),
                ],
                target: 'GOS platform/category monitoring',
                owner: 'System Manager',
                priority: $checkIns + $captures > 0 ? 'Medium' : 'Low',
                confidence: $checkIns + $captures > 0 ? 'medium' : 'low',
                successMetric: 'Active/inactive usage and data completeness are visible by vertical/category.',
                suggestedPeriod: '14 days',
                dataGap: $checkIns + $captures > 0 ? null : 'Platform usage data is still low.',
                targetLists: [],
            ),
        ];
    }

    private function dataCompletionAction(Collection $dataCompleteness, string $owner, string $target): array
    {
        $firstGap = $dataCompleteness->first();

        return $this->action(
            title: 'Complete missing or weak data',
            recommendedAction: 'Complete the weakest missing data before relying on stronger AI Action decisions.',
            reason: 'Low or incomplete data makes business action less reliable.',
            linkedInsight: 'Data gap insight',
            evidence: $firstGap ? [
                'Data gap: '.$firstGap['missing'],
                'Why it matters: '.$firstGap['reason'],
                'Accuracy effect: '.$firstGap['effect'],
            ] : ['Data is insufficient for a strong action.'],
            target: $target,
            owner: $owner,
            priority: 'Medium',
            confidence: 'low',
            successMetric: 'Missing data is completed and next analytics period has stronger evidence.',
            suggestedPeriod: '7 days',
            dataGap: $firstGap['missing'] ?? 'Data belum cukup untuk action yang kuat.',
            targetLists: [],
        );
    }

    private function action(
        string $title,
        string $recommendedAction,
        string $reason,
        string $linkedInsight,
        array $evidence,
        string $target,
        string $owner,
        string $priority,
        string $confidence,
        string $successMetric,
        string $suggestedPeriod,
        ?string $dataGap,
        array $targetLists,
    ): array {
        return [
            'title' => $title,
            'recommended_action' => $recommendedAction,
            'reason' => $reason,
            'linked_insight' => $linkedInsight,
            'evidence' => $evidence,
            'target' => $target,
            'owner' => $owner,
            'priority' => $priority,
            'confidence' => $confidence,
            'success_metric' => $successMetric,
            'suggested_period' => $suggestedPeriod,
            'data_gap' => $dataGap,
            'status' => self::STATUS_SUGGESTED,
            'target_lists' => $targetLists,
        ];
    }

    private function insightTitle(Collection $insights, string $title): string
    {
        return $insights->firstWhere('title', $title)['title'] ?? 'Data gap insight';
    }

    private function evidenceFor(Collection $insights, string $title, array $fallback): array
    {
        return $insights->firstWhere('title', $title)['evidence'] ?? $fallback;
    }

    private function firstItem(mixed $value): ?array
    {
        if ($value instanceof Collection) {
            return $value->first();
        }

        return is_array($value) ? ($value[0] ?? null) : null;
    }

    private function productTargetItems(array $analytics): array
    {
        return collect($analytics['salesAnalytics']['salesByProduct'] ?? [])
            ->map(fn (array $row) => [
                'Product/Service' => (string) $row['name'],
                'Related Activity' => ($row['quantity'] ?? 0).' sold/subscribed',
                'Sales/Value' => 'RM '.number_format((float) ($row['total'] ?? 0), 2),
            ])
            ->values()
            ->all();
    }

    private function branchTargetItems(array $analytics): array
    {
        return collect($analytics['branchAnalytics'] ?? [])
            ->map(fn (array $row) => [
                'Branch' => (string) $row['name'],
                'Sales/Value' => 'RM '.number_format((float) ($row['sales'] ?? 0), 2),
                'Check-ins' => (string) ($row['check_ins'] ?? 0),
                'Feedback Status' => ($row['feedback_pending'] ?? 0).' pending / '.($row['feedback_action_needed'] ?? 0).' action',
            ])
            ->values()
            ->all();
    }

    private function feedbackTargetItems(array $analytics): array
    {
        return [[
            'Feedback Type' => 'Negative/action needed',
            'Evidence Count' => (string) (($analytics['feedbackAnalytics']['Negative/general issue summary'] ?? 0) + ($analytics['feedbackAnalytics']['Action needed feedback'] ?? 0)),
            'Scope' => (string) ($analytics['scopeLabel'] ?? 'Allowed scope'),
        ]];
    }
}
