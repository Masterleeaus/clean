<?php

namespace App\Services;

use App\Models\Branch;
use App\Models\Business;
use App\Models\Customer;
use App\Models\User;

class RoleAccessPilotGuard
{
    /**
     * @param  array<int, int>  $branchIds
     * @return array{allowed: bool, errors: array<int, string>, warnings: array<int, string>, intentional_dual_role: bool}
     */
    public function validateControlledPilotSetup(
        User $actor,
        User $target,
        ?Business $business = null,
        array $branchIds = [],
        ?string $primaryRole = null,
        ?string $secondaryRole = null,
        bool $intentionalDualRole = false,
    ): array {
        $errors = [];
        $warnings = [];
        $roles = collect([$primaryRole ?? $target->role, $secondaryRole ?? $target->secondary_role])
            ->filter()
            ->unique()
            ->values();

        if (! $actor->isSystemAdmin()) {
            $errors[] = 'Controlled Pilot user setup must be completed by System Admin.';
        }

        if ($target->roles() !== $roles->all()) {
            $warnings[] = 'User already has role/access values. Review before saving changes.';
        }

        if ($target->scopedBusinessIds() !== []) {
            $warnings[] = 'User already has business scope. Confirm this is intentional.';
        }

        if ($target->scopedBranchIds() !== []) {
            $warnings[] = 'User already has branch scope. Confirm this is intentional.';
        }

        if ($roles->contains(User::ROLE_CUSTOMER) && $roles->count() > 1) {
            $errors[] = 'Customer role cannot be combined with internal, business, or branch roles.';
        }

        if ($roles->contains(User::ROLE_CUSTOMER) && ($business || $branchIds !== [])) {
            $errors[] = 'Customer onboarding must be organic through QR/check-in/customer portal.';
        }

        if (
            Customer::query()->where('user_id', $target->id)->exists()
            && ! ($roles->count() === 1 && $roles->first() === User::ROLE_CUSTOMER)
        ) {
            $errors[] = 'Customer profile conflict detected. Do not convert customer into internal/business user without review.';
        }

        $businessDualRole = $roles->contains(User::ROLE_BUSINESS_OWNER)
            && $roles->contains(User::ROLE_BRANCH_MANAGER);

        $internalDualRole = $roles->contains(User::ROLE_SYSTEM_MANAGER)
            && $roles->contains(User::ROLE_SYSTEM_ADMIN);

        if ($roles->count() > 1 && ! $businessDualRole && ! $internalDualRole) {
            $errors[] = 'Only Business Owner / Branch Manager or System Manager / System Admin combined roles are allowed.';
        }

        if ($businessDualRole && ! $intentionalDualRole) {
            $errors[] = 'Business Owner / Branch Manager dual role requires intentional confirmation.';
        }

        if ($branchIds !== [] && ! $roles->contains(User::ROLE_BRANCH_MANAGER)) {
            $errors[] = 'Branch scope requires Branch Manager role.';
        }

        if ($business && $roles->contains(User::ROLE_BUSINESS_OWNER)) {
            $ownsOrScoped = (int) $business->owner_user_id === (int) $target->id
                || in_array($business->id, $target->scopedBusinessIds(), true);

            if (! $ownsOrScoped) {
                $errors[] = 'Business Owner cannot be assigned to a business they do not own or have approved scope for.';
            }
        }

        $branches = Branch::query()->whereIn('id', $branchIds)->get();

        if ($branches->count() !== count(array_unique($branchIds))) {
            $errors[] = 'One or more branch assignments are invalid.';
        }

        if ($business && $branches->contains(fn (Branch $branch): bool => (int) $branch->business_id !== (int) $business->id)) {
            $errors[] = 'Branch Manager cannot be assigned to branch outside the selected business.';
        }

        return [
            'allowed' => $errors === [],
            'errors' => $errors,
            'warnings' => $warnings,
            'intentional_dual_role' => $businessDualRole && $intentionalDualRole,
        ];
    }

    /**
     * @return array{allowed: bool, errors: array<int, string>}
     */
    public function validateBusinessOwnerInvite(User $actor, Business $business, string $role): array
    {
        $errors = ['Business Owner user invite is disabled during Controlled Pilot. System Admin must set up users first.'];

        if (! $actor->isOwner() || (int) $business->owner_user_id !== (int) $actor->id) {
            $errors[] = 'Business Owner can only invite users within own business.';
        }

        if ($role === User::ROLE_CUSTOMER) {
            $errors[] = 'Business Owner cannot create Customer manually. Customer onboarding must be organic.';
        }

        if (in_array($role, [User::ROLE_SYSTEM_ADMIN, User::ROLE_SYSTEM_MANAGER, User::ROLE_BUSINESS_OWNER], true)) {
            $errors[] = 'Business Owner cannot assign System Admin, System Manager, or another Business Owner role.';
        }

        if ($role !== User::ROLE_BRANCH_MANAGER) {
            $errors[] = 'Business Owner later-phase invite is limited to Branch Manager or approved branch staff roles.';
        }

        return [
            'allowed' => false,
            'errors' => array_values(array_unique($errors)),
        ];
    }
}
