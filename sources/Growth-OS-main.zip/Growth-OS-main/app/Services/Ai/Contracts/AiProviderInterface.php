<?php

namespace App\Services\Ai\Contracts;

use App\Services\Ai\AiProviderResult;

interface AiProviderInterface
{
    public function name(): string;

    public function label(): string;

    public function isEnabled(): bool;

    public function isConfigured(): bool;

    public function configurationStatus(): string;

    public function insights(array $analytics): AiProviderResult;

    public function actions(array $analytics): AiProviderResult;
}
