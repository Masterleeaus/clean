<?php

namespace App\Services\Ai\Providers;

use App\Services\Ai\AiProviderResult;
use App\Services\Ai\Contracts\AiProviderInterface;
use App\Services\AiActionService;
use App\Services\AiInsightService;

class RuleBasedAiProvider implements AiProviderInterface
{
    public function __construct(
        private readonly AiInsightService $insights,
        private readonly AiActionService $actions,
    ) {
    }

    public function name(): string
    {
        return 'rule_based';
    }

    public function label(): string
    {
        return (string) config('ai.providers.rule_based.label', 'Rule-based');
    }

    public function isEnabled(): bool
    {
        return (bool) config('ai.providers.rule_based.enabled', true);
    }

    public function isConfigured(): bool
    {
        return true;
    }

    public function configurationStatus(): string
    {
        return $this->isEnabled() ? 'Available' : 'Disabled';
    }

    public function insights(array $analytics): AiProviderResult
    {
        return AiProviderResult::success($this->name(), $this->insights->fromAnalytics($analytics));
    }

    public function actions(array $analytics): AiProviderResult
    {
        return AiProviderResult::success($this->name(), $this->actions->fromAnalytics($analytics));
    }
}
