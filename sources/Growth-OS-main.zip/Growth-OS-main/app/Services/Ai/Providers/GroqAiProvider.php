<?php

namespace App\Services\Ai\Providers;

use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;

class GroqAiProvider extends ExternalAiProvider
{
    public function name(): string
    {
        return 'groq';
    }

    protected function post(string $task, array $analytics): Response
    {
        return Http::timeout($this->timeout())
            ->acceptJson()
            ->withToken($this->apiKey())
            ->post($this->baseUrl(), [
                'model' => $this->configuredModel('llama-3.1-8b-instant'),
                'messages' => [
                    ['role' => 'system', 'content' => $this->instruction($task)],
                    ['role' => 'user', 'content' => json_encode($this->promptPayload($task, $analytics))],
                ],
                'temperature' => 0.2,
                'response_format' => ['type' => 'json_object'],
            ]);
    }

    protected function extractContent(array $response): ?string
    {
        return $response['choices'][0]['message']['content'] ?? null;
    }
}
