<?php

namespace App\Services\Ai\Providers;

use App\Services\Ai\AiProviderResult;
use App\Services\Ai\Contracts\AiProviderInterface;
use App\Services\AiActionService;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Arr;

abstract class ExternalAiProvider implements AiProviderInterface
{
    public function label(): string
    {
        return (string) config("ai.providers.{$this->name()}.label", ucfirst($this->name()));
    }

    public function isEnabled(): bool
    {
        return (bool) config("ai.providers.{$this->name()}.enabled", false);
    }

    public function isConfigured(): bool
    {
        return trim((string) config("ai.providers.{$this->name()}.api_key", '')) !== '';
    }

    public function configurationStatus(): string
    {
        if (! $this->isEnabled()) {
            return 'Disabled';
        }

        return $this->isConfigured() ? 'Configured' : 'Missing key';
    }

    public function insights(array $analytics): AiProviderResult
    {
        return $this->generate('insights', $analytics);
    }

    public function actions(array $analytics): AiProviderResult
    {
        return $this->generate('actions', $analytics);
    }

    abstract protected function post(string $task, array $analytics): Response;

    abstract protected function extractContent(array $response): ?string;

    protected function generate(string $task, array $analytics): AiProviderResult
    {
        try {
            $response = $this->post($task, $analytics);
        } catch (ConnectionException) {
            return AiProviderResult::failure($this->name(), 'timeout', 'Provider request timed out or could not connect.');
        } catch (\Throwable) {
            return AiProviderResult::failure($this->name(), 'provider_error', 'Provider request failed.');
        }

        if ($response->status() === 429) {
            return AiProviderResult::failure($this->name(), 'quota_exhausted', 'Provider quota or rate limit reached.');
        }

        if (! $response->successful()) {
            return AiProviderResult::failure($this->name(), 'provider_error', 'Provider returned an error status.');
        }

        $decoded = $response->json();
        $items = $this->itemsFromContent($this->extractContent(is_array($decoded) ? $decoded : []), $task);

        if ($items === []) {
            return AiProviderResult::failure($this->name(), 'invalid_response', 'Provider returned an invalid response.');
        }

        return AiProviderResult::success($this->name(), $items);
    }

    protected function timeout(): int
    {
        return max(1, (int) config('ai.timeout', 10));
    }

    protected function apiKey(): string
    {
        return (string) config("ai.providers.{$this->name()}.api_key", '');
    }

    protected function baseUrl(): string
    {
        return rtrim((string) config("ai.providers.{$this->name()}.base_url", ''), '/');
    }

    protected function configuredModel(string $default): string
    {
        return (string) (config("ai.providers.{$this->name()}.model") ?: $default);
    }

    /**
     * @return array<string, mixed>
     */
    protected function promptPayload(string $task, array $analytics): array
    {
        return [
            'task' => $task,
            'mode' => (string) config('ai.action_mode', 'suggestion_only'),
            'format' => $task === 'actions' ? $this->actionFormat() : $this->insightFormat(),
            'analytics' => $this->safeAnalytics($analytics),
        ];
    }

    protected function instruction(string $task): string
    {
        $rootKey = $task === 'actions' ? 'actions' : 'insights';

        return "Return strict JSON only with a top-level {$rootKey} array. Keep output evidence-based. AI Action must be suggestion-only: no auto-send, no campaign execution, no reward/stamp/data change.";
    }

    /**
     * @return array<string, mixed>
     */
    private function safeAnalytics(array $analytics): array
    {
        $safe = Arr::only($analytics, [
            'title',
            'scopeLabel',
            'personaScope',
            'summary',
            'salesAnalytics',
            'customerAnalytics',
            'productAnalytics',
            'branchAnalytics',
            'operationAnalytics',
            'rewardAnalytics',
            'feedbackAnalytics',
            'dataCompleteness',
            'platformMetrics',
            'adminSupportMetrics',
            'aiInsights',
        ]);

        return json_decode((string) json_encode($safe), true) ?: [];
    }

    /**
     * @return array<string, string>
     */
    private function insightFormat(): array
    {
        return [
            'title' => 'string',
            'explanation' => 'string',
            'evidence' => 'array of strings',
            'confidence' => 'high|medium|low',
            'confidence_reason' => 'string',
            'data_gap' => 'string|null',
            'action_ready_context' => 'object',
        ];
    }

    /**
     * @return array<string, string>
     */
    private function actionFormat(): array
    {
        return [
            'title' => 'string',
            'recommended_action' => 'string',
            'reason' => 'string',
            'linked_insight' => 'string',
            'evidence' => 'array of strings',
            'target' => 'string',
            'owner' => 'string',
            'priority' => 'High|Medium|Low',
            'confidence' => 'high|medium|low',
            'success_metric' => 'string',
            'suggested_period' => 'string',
            'data_gap' => 'string|null',
            'status' => 'Suggested',
            'target_lists' => 'array',
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function itemsFromContent(?string $content, string $task): array
    {
        if (! is_string($content) || trim($content) === '') {
            return [];
        }

        $content = trim($content);
        $content = preg_replace('/^```(?:json)?\s*/i', '', $content) ?? $content;
        $content = preg_replace('/\s*```$/', '', $content) ?? $content;
        $decoded = json_decode($content, true);

        if (! is_array($decoded)) {
            return [];
        }

        $rootKey = $task === 'actions' ? 'actions' : 'insights';
        $items = $decoded[$rootKey] ?? $decoded;

        if (! is_array($items) || ! array_is_list($items)) {
            return [];
        }

        return $task === 'actions'
            ? $this->normalizeActions($items)
            : $this->normalizeInsights($items);
    }

    /**
     * @param  array<int, mixed>  $items
     * @return array<int, array<string, mixed>>
     */
    private function normalizeInsights(array $items): array
    {
        $normalized = [];

        foreach ($items as $item) {
            if (! is_array($item) || empty($item['title']) || empty($item['explanation'])) {
                continue;
            }

            $normalized[] = [
                'title' => (string) $item['title'],
                'explanation' => (string) $item['explanation'],
                'evidence' => $this->stringList($item['evidence'] ?? []),
                'confidence' => $this->confidence($item['confidence'] ?? 'low'),
                'confidence_reason' => (string) ($item['confidence_reason'] ?? 'Provider confidence reason was not supplied.'),
                'data_gap' => isset($item['data_gap']) ? (string) $item['data_gap'] : null,
                'action_ready_context' => is_array($item['action_ready_context'] ?? null) ? $item['action_ready_context'] : [],
            ];
        }

        return $normalized;
    }

    /**
     * @param  array<int, mixed>  $items
     * @return array<int, array<string, mixed>>
     */
    private function normalizeActions(array $items): array
    {
        $normalized = [];

        foreach ($items as $item) {
            if (! is_array($item) || empty($item['title']) || empty($item['recommended_action'])) {
                continue;
            }

            $normalized[] = [
                'title' => (string) $item['title'],
                'recommended_action' => (string) $item['recommended_action'],
                'reason' => (string) ($item['reason'] ?? 'Provider reason was not supplied.'),
                'linked_insight' => (string) ($item['linked_insight'] ?? 'Data gap insight'),
                'evidence' => $this->stringList($item['evidence'] ?? []),
                'target' => (string) ($item['target'] ?? 'Allowed scope'),
                'owner' => (string) ($item['owner'] ?? 'Human reviewer'),
                'priority' => (string) ($item['priority'] ?? 'Medium'),
                'confidence' => $this->confidence($item['confidence'] ?? 'low'),
                'success_metric' => (string) ($item['success_metric'] ?? 'Human review completed.'),
                'suggested_period' => (string) ($item['suggested_period'] ?? '7 days'),
                'data_gap' => isset($item['data_gap']) ? (string) $item['data_gap'] : null,
                'status' => AiActionService::STATUS_SUGGESTED,
                'target_lists' => is_array($item['target_lists'] ?? null) ? $item['target_lists'] : [],
            ];
        }

        return $normalized;
    }

    /**
     * @param  mixed  $value
     * @return array<int, string>
     */
    private function stringList(mixed $value): array
    {
        if (! is_array($value)) {
            return [];
        }

        return collect($value)
            ->filter(fn (mixed $item): bool => is_scalar($item))
            ->map(fn (mixed $item): string => (string) $item)
            ->values()
            ->all();
    }

    private function confidence(mixed $value): string
    {
        $confidence = strtolower((string) $value);

        return in_array($confidence, ['high', 'medium', 'low'], true) ? $confidence : 'low';
    }
}
