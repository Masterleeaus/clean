<?php

namespace App\Services\Ai\Providers;

use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;

class OpenRouterAiProvider extends ExternalAiProvider
{
    public function name(): string
    {
        return 'openrouter';
    }

    protected function post(string $task, array $analytics): Response
    {
        return Http::timeout($this->timeout())
            ->acceptJson()
            ->withHeaders([
                'Authorization' => 'Bearer '.$this->apiKey(),
                'X-Title' => config('app.name', 'Growth OS'),
            ])
            ->post($this->baseUrl(), [
                'model' => $this->configuredModel('meta-llama/llama-3.1-8b-instruct:free'),
                'messages' => [
                    ['role' => 'system', 'content' => $this->instruction($task)],
                    ['role' => 'user', 'content' => json_encode($this->promptPayload($task, $analytics))],
                ],
                'temperature' => 0.2,
                'response_format' => ['type' => 'json_object'],
            ]);
    }

    protected function extractContent(array $response): ?string
    {
        return $response['choices'][0]['message']['content'] ?? null;
    }
}
