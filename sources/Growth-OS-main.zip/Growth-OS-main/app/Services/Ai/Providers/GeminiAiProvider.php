<?php

namespace App\Services\Ai\Providers;

use Illuminate\Http\Client\Response;
use Illuminate\Support\Facades\Http;

class GeminiAiProvider extends ExternalAiProvider
{
    public function name(): string
    {
        return 'gemini';
    }

    protected function post(string $task, array $analytics): Response
    {
        $url = $this->baseUrl().'/models/'.$this->configuredModel('gemini-1.5-flash').':generateContent?key='.$this->apiKey();

        return Http::timeout($this->timeout())
            ->acceptJson()
            ->post($url, [
                'contents' => [[
                    'parts' => [[
                        'text' => $this->instruction($task)."\n".json_encode($this->promptPayload($task, $analytics)),
                    ]],
                ]],
                'generationConfig' => [
                    'temperature' => 0.2,
                    'response_mime_type' => 'application/json',
                ],
            ]);
    }

    protected function extractContent(array $response): ?string
    {
        return $response['candidates'][0]['content']['parts'][0]['text'] ?? null;
    }
}
