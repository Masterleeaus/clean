<?php

namespace App\Services\Ai;

use App\Services\Ai\Contracts\AiProviderInterface;
use App\Services\Ai\Providers\GeminiAiProvider;
use App\Services\Ai\Providers\GroqAiProvider;
use App\Services\Ai\Providers\OpenAiProvider;
use App\Services\Ai\Providers\OpenRouterAiProvider;
use App\Services\Ai\Providers\RuleBasedAiProvider;
use Illuminate\Contracts\Container\Container;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Log;

class AiProviderManager
{
    private const LAST_RESULT_CACHE_KEY = 'growth_os.ai_provider.last_result';

    public function __construct(private readonly Container $container)
    {
    }

    public function insights(array $analytics): AiProviderResult
    {
        return $this->run('insights', $analytics);
    }

    public function actions(array $analytics): AiProviderResult
    {
        return $this->run('actions', $analytics);
    }

    /**
     * @return array<int, string>
     */
    public function priorityChain(): array
    {
        $priority = config('ai.priority', 'openai,gemini,groq,openrouter,rule_based');

        if (is_string($priority)) {
            $priority = explode(',', $priority);
        }

        $chain = collect(is_array($priority) ? $priority : [])
            ->map(fn (mixed $provider): string => strtolower(trim((string) $provider)))
            ->filter()
            ->unique()
            ->values()
            ->all();

        return in_array($this->fallbackProvider(), $chain, true)
            ? $chain
            : [...$chain, $this->fallbackProvider()];
    }

    /**
     * @return array<string, mixed>
     */
    public function status(): array
    {
        $last = Cache::get(self::LAST_RESULT_CACHE_KEY);

        return [
            'external_enabled' => (bool) config('ai.external_enabled', true),
            'default_provider' => $this->defaultProvider(),
            'default_provider_label' => $this->providerLabel($this->defaultProvider()),
            'fallback_provider' => $this->fallbackProvider(),
            'fallback_provider_label' => $this->providerLabel($this->fallbackProvider()),
            'action_mode' => (string) config('ai.action_mode', 'suggestion_only'),
            'last_used_provider' => is_array($last) ? ($last['provider'] ?? null) : null,
            'last_used_provider_label' => is_array($last) ? $this->providerLabel((string) ($last['provider'] ?? '')) : null,
            'last_task' => is_array($last) ? ($last['task'] ?? null) : null,
            'fallback_used' => is_array($last) ? (bool) ($last['fallback_used'] ?? false) : false,
            'priority_chain' => collect($this->priorityChain())
                ->map(fn (string $provider): array => $this->providerStatus($provider))
                ->values()
                ->all(),
        ];
    }

    private function run(string $task, array $analytics): AiProviderResult
    {
        $attempts = [];

        foreach ($this->priorityChain() as $name) {
            $provider = $this->provider($name);

            if (! $provider) {
                $attempts[] = $this->attempt($name, 'skipped', 'unknown_provider');
                continue;
            }

            if (! $this->externalAllowed($provider)) {
                $attempts[] = $this->attempt($provider->name(), 'skipped', 'external_disabled');
                continue;
            }

            if (! $provider->isEnabled()) {
                $attempts[] = $this->attempt($provider->name(), 'skipped', 'disabled');
                continue;
            }

            if (! $provider->isConfigured()) {
                $attempts[] = $this->attempt($provider->name(), 'skipped', 'missing_key');
                continue;
            }

            $result = $task === 'actions'
                ? $provider->actions($analytics)
                : $provider->insights($analytics);

            if ($result->successful && $result->items !== []) {
                $attempts[] = $this->attempt($provider->name(), 'used', null);
                $final = $result->withRunMetadata(
                    fallbackUsed: $provider->name() !== $this->defaultProvider(),
                    attempts: $attempts,
                );

                $this->remember($task, $final);

                return $final;
            }

            $attempts[] = $this->attempt($provider->name(), 'failed', $result->errorCategory ?? 'invalid_response');
        }

        $fallback = $this->provider($this->fallbackProvider()) ?? $this->container->make(RuleBasedAiProvider::class);
        $result = $task === 'actions'
            ? $fallback->actions($analytics)
            : $fallback->insights($analytics);
        $attempts[] = $this->attempt($fallback->name(), 'used', 'safety_fallback');
        $final = $result->withRunMetadata(fallbackUsed: true, attempts: $attempts);

        $this->remember($task, $final);

        return $final;
    }

    private function provider(string $name): ?AiProviderInterface
    {
        return match ($name) {
            'openai' => $this->container->make(OpenAiProvider::class),
            'gemini' => $this->container->make(GeminiAiProvider::class),
            'groq' => $this->container->make(GroqAiProvider::class),
            'openrouter' => $this->container->make(OpenRouterAiProvider::class),
            'rule_based' => $this->container->make(RuleBasedAiProvider::class),
            default => null,
        };
    }

    /**
     * @return array<string, string|null>
     */
    private function attempt(string $provider, string $status, ?string $reason): array
    {
        return [
            'provider' => $provider,
            'status' => $status,
            'reason' => $reason,
        ];
    }

    private function remember(string $task, AiProviderResult $result): void
    {
        $payload = [
            'task' => $task,
            'provider' => $result->providerName,
            'fallback_used' => $result->fallbackUsed,
            'error_category' => $result->errorCategory,
        ];

        Cache::put(self::LAST_RESULT_CACHE_KEY, $payload, now()->addHours(12));
        Log::info('AI provider selected', $payload);
    }

    private function externalAllowed(AiProviderInterface $provider): bool
    {
        return $provider->name() === 'rule_based' || (bool) config('ai.external_enabled', true);
    }

    private function defaultProvider(): string
    {
        return strtolower((string) config('ai.default_provider', 'gemini'));
    }

    private function fallbackProvider(): string
    {
        return strtolower((string) config('ai.fallback_provider', 'rule_based'));
    }

    private function providerLabel(string $provider): string
    {
        return (string) config("ai.providers.{$provider}.label", str_replace('_', ' ', ucfirst($provider)));
    }

    /**
     * @return array<string, mixed>
     */
    private function providerStatus(string $name): array
    {
        $provider = $this->provider($name);

        if (! $provider) {
            return [
                'name' => $name,
                'label' => $this->providerLabel($name),
                'status' => 'Unknown',
                'enabled' => false,
                'configured' => false,
            ];
        }

        $status = $this->externalAllowed($provider)
            ? $provider->configurationStatus()
            : 'External disabled';

        return [
            'name' => $provider->name(),
            'label' => $provider->label(),
            'status' => $status,
            'enabled' => $provider->isEnabled(),
            'configured' => $provider->isConfigured(),
        ];
    }
}
