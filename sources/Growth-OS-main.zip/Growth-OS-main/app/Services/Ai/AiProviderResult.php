<?php

namespace App\Services\Ai;

class AiProviderResult
{
    /**
     * @param  array<int, array<string, mixed>>  $items
     * @param  array<int, array<string, string|null>>  $attempts
     */
    public function __construct(
        public readonly string $providerName,
        public readonly bool $successful,
        public readonly array $items = [],
        public readonly ?string $errorCategory = null,
        public readonly ?string $message = null,
        public readonly bool $fallbackUsed = false,
        public readonly array $attempts = [],
    ) {
    }

    /**
     * @param  array<int, array<string, mixed>>  $items
     */
    public static function success(string $providerName, array $items): self
    {
        return new self($providerName, true, $items);
    }

    public static function failure(string $providerName, string $errorCategory, ?string $message = null): self
    {
        return new self($providerName, false, [], $errorCategory, $message);
    }

    /**
     * @param  array<int, array<string, string|null>>  $attempts
     */
    public function withRunMetadata(bool $fallbackUsed, array $attempts): self
    {
        return new self(
            providerName: $this->providerName,
            successful: $this->successful,
            items: $this->items,
            errorCategory: $this->errorCategory,
            message: $this->message,
            fallbackUsed: $fallbackUsed,
            attempts: $attempts,
        );
    }

    /**
     * @return array<string, mixed>
     */
    public function metadata(): array
    {
        return [
            'provider' => $this->providerName,
            'successful' => $this->successful,
            'fallback_used' => $this->fallbackUsed,
            'error_category' => $this->errorCategory,
            'attempts' => $this->attempts,
        ];
    }
}
