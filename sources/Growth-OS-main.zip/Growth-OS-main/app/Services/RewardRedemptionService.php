<?php

namespace App\Services;

use App\Models\Business;
use App\Models\Branch;
use App\Models\Customer;
use App\Models\CustomerLoyaltyAccount;
use App\Models\RewardRedemption;
use App\Models\StampTransaction;
use App\Models\User;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class RewardRedemptionService
{
    public function redeem(Business $business, Customer $customer, User $verifiedBy, ?Branch $branch = null): RewardRedemption
    {
        return DB::transaction(function () use ($business, $customer, $verifiedBy, $branch): RewardRedemption {
            if ($customer->business_id !== $business->id) {
                throw ValidationException::withMessages([
                    'customer' => 'This customer does not belong to this business.',
                ]);
            }

            $program = $business->loyaltyPrograms()
                ->active()
                ->latest()
                ->first();

            if (! $program) {
                throw ValidationException::withMessages([
                    'redemption' => 'This loyalty program is not available yet.',
                ]);
            }

            $account = CustomerLoyaltyAccount::query()
                ->where('business_id', $business->id)
                ->where('customer_id', $customer->id)
                ->where('loyalty_program_id', $program->id)
                ->lockForUpdate()
                ->first();

            if (! $account || $account->current_stamps < $program->stamps_required) {
                throw ValidationException::withMessages([
                    'redemption' => 'Customer ini belum layak untuk ganjaran ini.',
                ]);
            }

            $stampsSpent = $program->stamps_required;

            $redemption = RewardRedemption::query()->create([
                'business_id' => $business->id,
                'branch_id' => $branch?->id,
                'customer_id' => $customer->id,
                'loyalty_program_id' => $program->id,
                'reward_name' => $program->reward_name,
                'stamps_spent' => $stampsSpent,
                'verified_by_user_id' => $verifiedBy->id,
                'redeemed_at' => now(),
            ]);

            $account->forceFill([
                'current_stamps' => 0,
                'total_rewards_redeemed' => $account->total_rewards_redeemed + 1,
            ])->save();

            StampTransaction::query()->create([
                'business_id' => $business->id,
                'branch_id' => $branch?->id,
                'customer_id' => $customer->id,
                'loyalty_program_id' => $program->id,
                'type' => StampTransaction::TYPE_REDEEMED_RESET,
                'stamps' => -$stampsSpent,
                'description' => 'Ganjaran ditebus dan current stamps reset.',
            ]);

            return $redemption;
        });
    }
}
