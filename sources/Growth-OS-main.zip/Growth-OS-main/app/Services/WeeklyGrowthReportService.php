<?php

namespace App\Services;

use App\Models\Business;
use App\Models\CustomerFeedback;
use App\Models\LoyaltyProgram;
use Carbon\CarbonImmutable;

class WeeklyGrowthReportService
{
    private const DORMANT_DAYS = 30;

    public function reportFor(Business $business): array
    {
        $start = CarbonImmutable::now()->startOfWeek();
        $end = CarbonImmutable::now()->endOfWeek();
        $loyaltyProgram = $business->loyaltyPrograms()->active()->first();

        $metrics = [
            'new_customers' => $business->customers()
                ->whereBetween('created_at', [$start, $end])
                ->count(),
            'check_ins' => $business->checkIns()
                ->whereBetween('check_in_date', [$start->toDateString(), $end->toDateString()])
                ->count(),
            'repeat_customers' => $this->repeatCustomersThisWeek($business, $start, $end),
            'dormant_customers' => $this->dormantCustomers($business),
            'rewards_redeemed' => $business->rewardRedemptions()
                ->whereBetween('redeemed_at', [$start, $end])
                ->count(),
            'feedback_submitted' => $business->feedback()
                ->whereBetween('submitted_at', [$start, $end])
                ->count(),
            'average_food_rating' => $this->averageFeedbackRating($business, 'food_rating', $start, $end),
            'average_service_rating' => $this->averageFeedbackRating($business, 'service_rating', $start, $end),
            'price_feedback' => $this->priceFeedbackSummary($business, $start, $end),
            'near_reward_customers' => $this->nearRewardCustomers($business, $loyaltyProgram),
        ];

        $suggestions = $this->suggestionsFor($metrics);

        return [
            'business' => $business,
            'period_start' => $start,
            'period_end' => $end,
            'metrics' => $metrics,
            'suggestions' => $suggestions,
            'copy_summary' => $this->copySummary($business, $metrics, $suggestions),
        ];
    }

    private function repeatCustomersThisWeek(Business $business, CarbonImmutable $start, CarbonImmutable $end): int
    {
        return $business->checkIns()
            ->select('customer_id')
            ->whereBetween('check_in_date', [$start->toDateString(), $end->toDateString()])
            ->groupBy('customer_id')
            ->havingRaw('COUNT(*) > 1')
            ->get()
            ->count();
    }

    private function dormantCustomers(Business $business): int
    {
        return $business->customers()
            ->where(function ($query): void {
                $query->whereDoesntHave('checkIns')
                    ->orWhereDoesntHave('checkIns', fn ($checkInQuery) => $checkInQuery->whereDate('check_in_date', '>=', now()->subDays(self::DORMANT_DAYS)->toDateString()));
            })
            ->count();
    }

    private function averageFeedbackRating(Business $business, string $column, CarbonImmutable $start, CarbonImmutable $end): ?float
    {
        $average = $business->feedback()
            ->whereBetween('submitted_at', [$start, $end])
            ->avg($column);

        return $average === null ? null : round((float) $average, 1);
    }

    private function priceFeedbackSummary(Business $business, CarbonImmutable $start, CarbonImmutable $end): array
    {
        $counts = $business->feedback()
            ->whereBetween('submitted_at', [$start, $end])
            ->whereNotNull('price_feedback')
            ->selectRaw('price_feedback, COUNT(*) as total')
            ->groupBy('price_feedback')
            ->pluck('total', 'price_feedback');

        return [
            CustomerFeedback::PRICE_CHEAP => (int) ($counts[CustomerFeedback::PRICE_CHEAP] ?? 0),
            CustomerFeedback::PRICE_OK => (int) ($counts[CustomerFeedback::PRICE_OK] ?? 0),
            CustomerFeedback::PRICE_EXPENSIVE => (int) ($counts[CustomerFeedback::PRICE_EXPENSIVE] ?? 0),
        ];
    }

    private function nearRewardCustomers(Business $business, ?LoyaltyProgram $loyaltyProgram): int
    {
        if (! $loyaltyProgram) {
            return 0;
        }

        return $business->loyaltyAccounts()
            ->where('loyalty_program_id', $loyaltyProgram->id)
            ->where('current_stamps', $loyaltyProgram->stamps_required - 1)
            ->count();
    }

    private function suggestionsFor(array $metrics): array
    {
        $suggestions = [];

        if ($metrics['dormant_customers'] > 0) {
            $suggestions[] = 'Send a win-back WhatsApp follow-up to dormant customers this week.';
        }

        if ($metrics['new_customers'] > 0 && $metrics['repeat_customers'] === 0) {
            $suggestions[] = 'Follow up with new customers within 3 days so they come back for their next stamp.';
        }

        if ($metrics['rewards_redeemed'] === 0 && $metrics['near_reward_customers'] > 0) {
            $suggestions[] = 'Remind near-reward customers that they are only 1 stamp away from claiming a reward.';
        }

        if ($metrics['price_feedback'][CustomerFeedback::PRICE_EXPENSIVE] >= 2) {
            $suggestions[] = 'Test a value meal or combo because several customers marked the price as expensive.';
        }

        if ($metrics['average_food_rating'] !== null && $metrics['average_food_rating'] < 4) {
            $suggestions[] = 'Check food consistency because the average food rating is below 4 this week.';
        }

        if ($metrics['average_service_rating'] !== null && $metrics['average_service_rating'] < 4) {
            $suggestions[] = 'Review the service flow because the average service rating is below 4 this week.';
        }

        if ($metrics['check_ins'] === 0) {
            $suggestions[] = 'Place the QR link more visibly and explain the reward to customers at the counter.';
        }

        return $suggestions ?: ['Keep collecting check-ins and feedback this week.'];
    }

    private function copySummary(Business $business, array $metrics, array $suggestions): string
    {
        return implode(PHP_EOL, [
            "Weekly Growth Report - {$business->name}",
            "New customers: {$metrics['new_customers']}",
            "Check-ins: {$metrics['check_ins']}",
            "Repeat customers: {$metrics['repeat_customers']}",
            "Dormant customers: {$metrics['dormant_customers']}",
            "Rewards redeemed: {$metrics['rewards_redeemed']}",
            "Feedback submitted: {$metrics['feedback_submitted']}",
            'Next action: '.$suggestions[0],
        ]);
    }
}
