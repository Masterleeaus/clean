<?php

namespace App\Services;

use App\Models\ProductService;
use App\Models\ProductServiceReviewAlert;
use App\Models\User;
use Illuminate\Support\Str;

class ProductServiceReviewService
{
    /**
     * @param  array{name?: string, price?: mixed}|null  $previous
     * @return array<int, array{type: string, message: string, suggested_review: string}>
     */
    public function reviewSaved(ProductService $productService, ?array $previous = null, ?User $actor = null): array
    {
        $issues = $this->detectIssues($productService, $previous);
        $this->applyReviewStatus($productService, $issues);
        $this->recordAlerts($productService, $issues, $actor, $previous ? 'updated' : 'created');

        return $issues;
    }

    /**
     * @return array<int, array{type: string, message: string, suggested_review: string}>
     */
    public function reviewArchiveUsed(ProductService $productService, ?User $actor = null): array
    {
        $issues = [[
            'type' => 'archive_used_item',
            'message' => "Product/Service '{$productService->name}' has purchase capture history and was archived instead of hard-deleted.",
            'suggested_review' => 'Business Owner should review whether the item should stay archived or be corrected for future capture.',
        ]];

        $productService->forceFill([
            'review_status' => 'archived',
            'review_flags' => $this->mergeFlags($productService, $issues),
            'review_note' => $this->issueSummary($issues),
            'archived_at' => now(),
            'is_active' => false,
        ])->save();

        $this->recordAlerts($productService, $issues, $actor, 'archived');

        return $issues;
    }

    /**
     * @return array<int, array{type: string, message: string, suggested_review: string}>
     */
    public function reviewNewCategory(ProductService $productService, ?User $actor = null): array
    {
        $issues = [[
            'type' => 'new_category_created',
            'message' => "Product/Service '{$productService->name}' created a new category '{$productService->category}'.",
            'suggested_review' => 'BO should confirm the new category should remain available for branch capture and analytics grouping.',
        ]];

        $this->recordAlerts($productService, $issues, $actor, 'category_created');

        return $issues;
    }

    /**
     * @param  array{name?: string, price?: mixed}|null  $previous
     * @return array<int, array{type: string, message: string, suggested_review: string}>
     */
    private function detectIssues(ProductService $productService, ?array $previous): array
    {
        $issues = [];
        $name = trim((string) $productService->name);
        $price = (float) $productService->price;

        if ($name === '') {
            $issues[] = [
                'type' => 'invalid_name',
                'message' => 'Product/Service name is missing or invalid.',
                'suggested_review' => 'BM should enter a clear menu or service name before using this item for capture.',
            ];
        }

        if ($price <= 0) {
            $issues[] = [
                'type' => 'invalid_price',
                'message' => "Product/Service '{$name}' has an invalid price.",
                'suggested_review' => 'BM should correct the price before using this item for capture.',
            ];
        } elseif ($price < 0.50) {
            $issues[] = [
                'type' => 'suspicious_low_price',
                'message' => "Product/Service '{$name}' price RM ".number_format($price, 2).' looks unusually low.',
                'suggested_review' => 'BO should confirm whether this is a real promo/add-on price or a key-in mistake.',
            ];
        } elseif ($price > 150) {
            $issues[] = [
                'type' => 'suspicious_high_price',
                'message' => "Product/Service '{$name}' price RM ".number_format($price, 2).' looks unusually high.',
                'suggested_review' => 'BO should confirm whether this is a valid premium/set item or a key-in mistake.',
            ];
        }

        if ($previous && isset($previous['price'])) {
            $oldPrice = (float) $previous['price'];

            if ($oldPrice > 0 && ($price > $oldPrice * 3 || $price < $oldPrice * 0.3)) {
                $issues[] = [
                    'type' => 'large_price_change',
                    'message' => "Product/Service '{$name}' price changed from RM ".number_format($oldPrice, 2).' to RM '.number_format($price, 2).'.',
                    'suggested_review' => 'BO should review this large price movement before relying on analytics trend.',
                ];
            }
        }

        $existing = ProductService::query()
            ->where('business_id', $productService->business_id)
            ->whereKeyNot($productService->id)
            ->get(['id', 'name', 'branch_id']);

        $normalizedName = $this->normalizeName($name);

        foreach ($existing as $other) {
            $otherNormalized = $this->normalizeName((string) $other->name);

            if ($otherNormalized === '' || ! $this->overlapsScope($productService, $other->branch_id)) {
                continue;
            }

            if ($normalizedName === $otherNormalized) {
                $issues[] = [
                    'type' => 'duplicate_name',
                    'message' => "Product/Service '{$name}' duplicates '{$other->name}' in this business scope.",
                    'suggested_review' => 'BO should merge, rename, or archive duplicate items to keep capture analytics clean.',
                ];

                continue;
            }

            if ($this->looksSimilar($normalizedName, $otherNormalized)) {
                $issues[] = [
                    'type' => 'similar_name',
                    'message' => "Product/Service '{$name}' looks similar to '{$other->name}'.",
                    'suggested_review' => 'BO should review spelling/category so staff capture the intended item.',
                ];
            }
        }

        return $this->uniqueIssues($issues);
    }

    /**
     * @param  array<int, array{type: string, message: string, suggested_review: string}>  $issues
     */
    private function applyReviewStatus(ProductService $productService, array $issues): void
    {
        $status = 'active';
        $types = collect($issues)->pluck('type');

        if ($types->isNotEmpty()) {
            $status = $types->contains(fn (string $type): bool => in_array($type, [
                'duplicate_name',
                'invalid_price',
                'suspicious_low_price',
                'suspicious_high_price',
                'large_price_change',
            ], true)) ? 'flagged' : 'needs_review';
        }

        $productService->forceFill([
            'review_status' => $status,
            'review_flags' => collect($issues)->pluck('type')->values()->all(),
            'review_note' => $issues === [] ? null : $this->issueSummary($issues),
            'archived_at' => $productService->is_active ? null : $productService->archived_at,
        ])->save();
    }

    /**
     * @param  array<int, array{type: string, message: string, suggested_review: string}>  $issues
     */
    private function recordAlerts(ProductService $productService, array $issues, ?User $actor, string $action): void
    {
        foreach ($issues as $issue) {
            $dedupeKey = sha1(implode('|', [
                $productService->id,
                $issue['type'],
                $action,
                $this->normalizeName((string) $productService->name),
                number_format((float) $productService->price, 2, '.', ''),
            ]));

            ProductServiceReviewAlert::query()->updateOrCreate(
                ['dedupe_key' => $dedupeKey],
                [
                    'business_id' => $productService->business_id,
                    'branch_id' => $productService->branch_id,
                    'product_service_id' => $productService->id,
                    'actor_user_id' => $actor?->id,
                    'issue_type' => $issue['type'],
                    'title' => 'Product/Service Review Alerts',
                    'message' => $issue['message'],
                    'suggested_review' => $issue['suggested_review'],
                    'status' => ProductServiceReviewAlert::STATUS_OPEN,
                    'metadata' => [
                        'action' => $action,
                        'product_name' => $productService->name,
                        'category' => $productService->category,
                        'price' => number_format((float) $productService->price, 2, '.', ''),
                    ],
                ],
            );
        }
    }

    private function normalizeName(string $name): string
    {
        $name = Str::ascii(Str::lower($name));
        $name = preg_replace('/[^a-z0-9]+/', ' ', $name) ?? '';

        return trim(preg_replace('/\s+/', ' ', $name) ?? '');
    }

    private function looksSimilar(string $name, string $other): bool
    {
        if ($name === '' || $other === '') {
            return false;
        }

        similar_text($name, $other, $percent);

        if ($percent >= 82) {
            return true;
        }

        $distance = levenshtein($name, $other);

        if ($distance <= 3) {
            return true;
        }

        $tokens = collect(explode(' ', $name))->filter()->unique();
        $otherTokens = collect(explode(' ', $other))->filter()->unique();

        if ($tokens->count() < 2 || $otherTokens->count() < 2) {
            return false;
        }

        $overlap = $tokens->intersect($otherTokens)->count() / max(1, min($tokens->count(), $otherTokens->count()));

        return $overlap >= 0.75;
    }

    private function overlapsScope(ProductService $productService, ?int $otherBranchId): bool
    {
        return $productService->branch_id === null
            || $otherBranchId === null
            || (int) $productService->branch_id === (int) $otherBranchId;
    }

    /**
     * @param  array<int, array{type: string, message: string, suggested_review: string}>  $issues
     * @return array<int, string>
     */
    private function mergeFlags(ProductService $productService, array $issues): array
    {
        return collect($productService->review_flags ?? [])
            ->merge(collect($issues)->pluck('type'))
            ->filter()
            ->unique()
            ->values()
            ->all();
    }

    /**
     * @param  array<int, array{type: string, message: string, suggested_review: string}>  $issues
     */
    private function issueSummary(array $issues): string
    {
        return collect($issues)->pluck('message')->join(' ');
    }

    /**
     * @param  array<int, array{type: string, message: string, suggested_review: string}>  $issues
     * @return array<int, array{type: string, message: string, suggested_review: string}>
     */
    private function uniqueIssues(array $issues): array
    {
        return collect($issues)
            ->unique(fn (array $issue): string => $issue['type'].'|'.$issue['message'])
            ->values()
            ->all();
    }
}
