<?php

namespace App\Services;

class CustomerFeedbackService
{
    /**
     * @return array<string, mixed>
     */
    public function summarize(?string $comment, ?string $productName = null): array
    {
        $text = trim((string) $comment);
        $lower = mb_strtolower($text);

        if ($text === '' || mb_strlen($text) < 8) {
            return [
                'summary_main_meaning' => 'Maklumbalas tidak cukup jelas untuk diringkaskan.',
                'summary_positive_point' => null,
                'summary_negative_point' => null,
                'summary_customer_expectation' => 'Perlu semakan manusia.',
                'summary_issue_category' => 'unclear',
                'summary_product_service_mentioned' => null,
                'summary_needs_review' => true,
            ];
        }

        $positive = $this->containsAny($lower, ['sedap', 'bagus', 'baik', 'cepat', 'puas hati', 'friendly', 'good', 'nice', 'excellent']);
        $negative = $this->containsAny($lower, ['lambat', 'mahal', 'sejuk', 'kurang', 'teruk', 'bad', 'slow', 'rude', 'masin', 'tawar']);

        $category = match (true) {
            $this->containsAny($lower, ['lambat', 'cepat', 'service', 'staf', 'staff', 'rude', 'friendly']) => 'service',
            $this->containsAny($lower, ['mahal', 'harga', 'price', 'murah']) => 'price',
            $this->containsAny($lower, ['sedap', 'masin', 'tawar', 'sejuk', 'food', 'drink', 'makanan', 'minuman']) => 'product_quality',
            default => $negative ? 'general_issue' : ($positive ? 'positive_feedback' : 'unclear'),
        };

        $mentionedProduct = null;

        if ($productName && str_contains($lower, mb_strtolower($productName))) {
            $mentionedProduct = $productName;
        }

        return [
            'summary_main_meaning' => mb_substr($text, 0, 180),
            'summary_positive_point' => $positive ? 'Customer menyatakan pengalaman positif.' : null,
            'summary_negative_point' => $negative ? 'Customer menyatakan isu atau ketidakpuasan.' : null,
            'summary_customer_expectation' => $negative
                ? 'Customer menjangka penambahbaikan dibuat.'
                : ($positive ? 'Customer menjangka standard ini dikekalkan.' : 'Perlu semakan manusia.'),
            'summary_issue_category' => $category,
            'summary_product_service_mentioned' => $mentionedProduct,
            'summary_needs_review' => $category === 'unclear',
        ];
    }

    private function containsAny(string $text, array $needles): bool
    {
        foreach ($needles as $needle) {
            if (str_contains($text, $needle)) {
                return true;
            }
        }

        return false;
    }
}
