<?php

namespace App\Services;

use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerLoyaltyAccount;
use App\Models\LoyaltyProgram;
use App\Models\StampTransaction;
use Illuminate\Support\Facades\DB;

class CustomerRegistrationService
{
    public function register(Business $business, array $attributes): array
    {
        return DB::transaction(function () use ($business, $attributes): array {
            $program = $this->activeProgramFor($business);

            if (! $program) {
                return [
                    'available' => false,
                    'business' => $business,
                    'program' => null,
                    'customer' => null,
                    'account' => null,
                    'existing_customer' => false,
                    'welcome_stamp_granted' => false,
                ];
            }

            $whatsappNumber = self::normalizeWhatsappNumber($attributes['whatsapp_number']);

            $customer = Customer::query()
                ->where('business_id', $business->id)
                ->where('whatsapp_number', $whatsappNumber)
                ->first();

            $existingCustomer = $customer !== null;

            if (! $customer) {
                $customer = Customer::query()->create([
                    'business_id' => $business->id,
                    'name' => $attributes['name'],
                    'whatsapp_number' => $whatsappNumber,
                    'birthday' => $attributes['birthday'] ?? null,
                    'consent_promo' => (bool) ($attributes['consent_promo'] ?? false),
                ]);
            }

            $account = CustomerLoyaltyAccount::query()->firstOrCreate(
                [
                    'business_id' => $business->id,
                    'customer_id' => $customer->id,
                    'loyalty_program_id' => $program->id,
                ],
                [
                    'current_stamps' => 0,
                    'total_stamps_earned' => 0,
                    'total_rewards_redeemed' => 0,
                ],
            );

            $welcomeStampGranted = false;

            if (! $existingCustomer && $program->welcome_stamp_enabled) {
                $alreadyCheckedInToday = CustomerCheckIn::query()
                    ->where('business_id', $business->id)
                    ->where('customer_id', $customer->id)
                    ->whereDate('check_in_date', now()->toDateString())
                    ->exists();

                if (! $alreadyCheckedInToday) {
                    CustomerCheckIn::query()->create([
                        'business_id' => $business->id,
                        'customer_id' => $customer->id,
                        'check_in_date' => now()->toDateString(),
                        'loyalty_program_id' => $program->id,
                        'stamps_earned' => 1,
                    ]);

                    $account->increment('current_stamps');
                    $account->increment('total_stamps_earned');

                    StampTransaction::query()->create([
                        'business_id' => $business->id,
                        'customer_id' => $customer->id,
                        'loyalty_program_id' => $program->id,
                        'type' => StampTransaction::TYPE_EARNED,
                        'stamps' => 1,
                        'description' => 'Welcome stamp for first registration.',
                    ]);

                    $welcomeStampGranted = true;
                    $account->refresh();
                }
            }

            return [
                'available' => true,
                'business' => $business,
                'program' => $program,
                'customer' => $customer,
                'account' => $account,
                'existing_customer' => $existingCustomer,
                'welcome_stamp_granted' => $welcomeStampGranted,
            ];
        });
    }

    public static function normalizeWhatsappNumber(string $value): string
    {
        return preg_replace('/\D+/', '', $value) ?? '';
    }

    private function activeProgramFor(Business $business): ?LoyaltyProgram
    {
        return $business->loyaltyPrograms()
            ->active()
            ->latest()
            ->first();
    }
}
