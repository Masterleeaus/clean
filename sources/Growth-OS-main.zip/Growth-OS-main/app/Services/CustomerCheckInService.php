<?php

namespace App\Services;

use App\Models\Business;
use App\Models\Branch;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerLoyaltyAccount;
use App\Models\LoyaltyProgram;
use App\Models\OnlineCheckInReference;
use App\Models\StampTransaction;
use App\Models\User;
use Carbon\CarbonInterface;
use Illuminate\Support\Facades\DB;

class CustomerCheckInService
{
    public const STATUS_CHECKED_IN = 'checked_in';

    public const STATUS_CHECK_IN_TOO_SOON = 'check_in_too_soon';

    public const STATUS_INVALID_ONLINE_REFERENCE = 'invalid_online_reference';

    public const STATUS_ONLINE_REFERENCE_USED = 'online_reference_used';

    public const STATUS_CUSTOMER_MISMATCH = 'customer_mismatch';

    public const STATUS_ONLINE_CHECK_IN_RECORDED = 'online_check_in_recorded';

    public function checkIn(
        Business $business,
        string $whatsappNumber,
        ?Branch $branch = null,
        ?User $user = null,
        string $checkInType = CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL,
    ): array
    {
        $checkInType = $this->normalizeCheckInType($checkInType);

        return DB::transaction(function () use ($business, $whatsappNumber, $branch, $user, $checkInType): array {
            $program = $this->activeProgramFor($business);

            if (! $program) {
                return $this->result('program_unavailable', $business, $branch, null, null, null, false, checkInType: $checkInType);
            }

            $customer = Customer::query()
                ->where('business_id', $business->id)
                ->where('whatsapp_number', CustomerRegistrationService::normalizeWhatsappNumber($whatsappNumber))
                ->first();

            if (! $customer) {
                return $this->result('customer_missing', $business, $branch, $program, null, null, false, checkInType: $checkInType);
            }

            $account = CustomerLoyaltyAccount::query()->firstOrCreate(
                [
                    'business_id' => $business->id,
                    'customer_id' => $customer->id,
                    'loyalty_program_id' => $program->id,
                ],
                [
                    'current_stamps' => 0,
                    'total_stamps_earned' => 0,
                    'total_rewards_redeemed' => 0,
                ],
            );

            $lastCheckIn = CustomerCheckIn::query()
                ->where('business_id', $business->id)
                ->when($branch, fn ($query) => $query->where('branch_id', $branch->id))
                ->where('customer_id', $customer->id)
                ->latest('check_in_at')
                ->first();

            $cooldownMinutes = $this->cooldownMinutesFor($program, $branch);

            if ($lastCheckIn && $this->insideCooldown($lastCheckIn->check_in_at, $cooldownMinutes)) {
                return $this->result(self::STATUS_CHECK_IN_TOO_SOON, $business, $branch, $program, $customer, $account->refresh(), false, $cooldownMinutes, $checkInType);
            }

            CustomerCheckIn::query()->create([
                'business_id' => $business->id,
                'branch_id' => $branch?->id,
                'customer_id' => $customer->id,
                'user_id' => $user?->id,
                'check_in_date' => now()->toDateString(),
                'check_in_at' => now(),
                'loyalty_program_id' => $program->id,
                'stamps_earned' => 0,
                'source' => $user ? 'customer_portal' : 'public_business',
                'check_in_type' => $checkInType,
                'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            ]);

            return $this->result(self::STATUS_CHECKED_IN, $business, $branch, $program, $customer, $account->refresh(), false, $cooldownMinutes, $checkInType);
        });
    }

    public function completeOnlineCheckIn(string $code, User $user): array
    {
        return DB::transaction(function () use ($code, $user): array {
            $reference = OnlineCheckInReference::query()
                ->with(['business', 'branch', 'customer'])
                ->where('code', $code)
                ->lockForUpdate()
                ->first();

            if (! $reference) {
                return $this->result(self::STATUS_INVALID_ONLINE_REFERENCE, new Business, null, null, null, null, false, checkInType: CustomerCheckIn::CHECK_IN_TYPE_ONLINE);
            }

            $business = $reference->business;
            $branch = $reference->branch;
            $program = $this->activeProgramFor($business);

            if (! $program) {
                return $this->result('program_unavailable', $business, $branch, null, null, null, false, checkInType: CustomerCheckIn::CHECK_IN_TYPE_ONLINE);
            }

            $account = CustomerLoyaltyAccount::query()->firstOrCreate(
                [
                    'business_id' => $business->id,
                    'customer_id' => $reference->customer_id,
                    'loyalty_program_id' => $program->id,
                ],
                [
                    'current_stamps' => 0,
                    'total_stamps_earned' => 0,
                    'total_rewards_redeemed' => 0,
                ],
            );

            if ($reference->status !== OnlineCheckInReference::STATUS_PENDING || $reference->claimed_at !== null) {
                return $this->result(self::STATUS_ONLINE_REFERENCE_USED, $business, $branch, $program, $reference->customer, $account->refresh(), false, checkInType: CustomerCheckIn::CHECK_IN_TYPE_ONLINE);
            }

            if ((int) $reference->customer?->user_id !== (int) $user->id) {
                return $this->result(self::STATUS_CUSTOMER_MISMATCH, $business, $branch, $program, $reference->customer, $account->refresh(), false, checkInType: CustomerCheckIn::CHECK_IN_TYPE_ONLINE);
            }

            $cooldownMinutes = $this->cooldownMinutesFor($program, $branch);
            $lastCheckIn = CustomerCheckIn::query()
                ->where('business_id', $business->id)
                ->where('branch_id', $branch->id)
                ->where('customer_id', $reference->customer_id)
                ->latest('check_in_at')
                ->first();

            if ($lastCheckIn && $this->insideCooldown($lastCheckIn->check_in_at, $cooldownMinutes)) {
                return $this->result(self::STATUS_CHECK_IN_TOO_SOON, $business, $branch, $program, $reference->customer, $account->refresh(), false, $cooldownMinutes, CustomerCheckIn::CHECK_IN_TYPE_ONLINE);
            }

            $checkIn = CustomerCheckIn::query()->create([
                'business_id' => $business->id,
                'branch_id' => $branch->id,
                'customer_id' => $reference->customer_id,
                'user_id' => $user->id,
                'check_in_date' => now()->toDateString(),
                'check_in_at' => now(),
                'loyalty_program_id' => $program->id,
                'stamps_earned' => 0,
                'source' => 'online_reference',
                'check_in_type' => CustomerCheckIn::CHECK_IN_TYPE_ONLINE,
                'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
                'purchase_reference' => $reference->purchase_reference ?: $reference->code,
            ]);

            $reference->update([
                'status' => OnlineCheckInReference::STATUS_CLAIMED,
                'claimed_by_user_id' => $user->id,
                'claimed_check_in_id' => $checkIn->id,
                'claimed_at' => now(),
            ]);

            return $this->result(self::STATUS_ONLINE_CHECK_IN_RECORDED, $business, $branch, $program, $reference->customer, $account->refresh(), false, $cooldownMinutes, CustomerCheckIn::CHECK_IN_TYPE_ONLINE);
        });
    }

    public function grantRewardForCheckIn(CustomerCheckIn $checkIn): bool
    {
        return DB::transaction(function () use ($checkIn): bool {
            $checkIn = CustomerCheckIn::query()
                ->with(['business', 'productServiceCaptures'])
                ->whereKey($checkIn->id)
                ->lockForUpdate()
                ->firstOrFail();

            if ($checkIn->reward_granted_at !== null || $checkIn->stamps_earned > 0) {
                return false;
            }

            if ($checkIn->productServiceCaptures->isEmpty()) {
                $checkIn->forceFill(['reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT])->save();

                return false;
            }

            $program = $checkIn->loyaltyProgram ?: $this->activeProgramFor($checkIn->business);

            if (! $program) {
                $checkIn->forceFill(['reward_status' => 'program_unavailable'])->save();

                return false;
            }

            $account = CustomerLoyaltyAccount::query()->firstOrCreate(
                [
                    'business_id' => $checkIn->business_id,
                    'customer_id' => $checkIn->customer_id,
                    'loyalty_program_id' => $program->id,
                ],
                [
                    'current_stamps' => 0,
                    'total_stamps_earned' => 0,
                    'total_rewards_redeemed' => 0,
                ],
            );

            $account->increment('current_stamps');
            $account->increment('total_stamps_earned');

            StampTransaction::query()->create([
                'business_id' => $checkIn->business_id,
                'branch_id' => $checkIn->branch_id,
                'customer_id' => $checkIn->customer_id,
                'loyalty_program_id' => $program->id,
                'type' => StampTransaction::TYPE_EARNED,
                'stamps' => 1,
                'description' => $checkIn->check_in_type === CustomerCheckIn::CHECK_IN_TYPE_ONLINE
                    ? 'Online check-in Product/Service capture stamp.'
                    : 'Physical check-in purchase/subscription stamp.',
            ]);

            $checkIn->forceFill([
                'loyalty_program_id' => $program->id,
                'stamps_earned' => 1,
                'reward_status' => CustomerCheckIn::REWARD_STATUS_GRANTED,
                'reward_granted_at' => now(),
            ])->save();

            return true;
        });
    }

    public function checkInOrCreateCustomer(
        Branch $branch,
        User $user,
        string $whatsappNumber,
        string $checkInType = CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL,
    ): array
    {
        $business = $branch->business;
        $normalizedWhatsapp = CustomerRegistrationService::normalizeWhatsappNumber($whatsappNumber);

        $customer = Customer::query()->firstOrCreate(
            [
                'business_id' => $business->id,
                'whatsapp_number' => $normalizedWhatsapp,
            ],
            [
                'name' => $user->name,
                'consent_promo' => false,
            ],
        );

        if (! $customer->user_id) {
            $customer->forceFill(['user_id' => $user->id])->save();
        }

        return $this->checkIn($business, $normalizedWhatsapp, $branch, $user, $checkInType);
    }

    private function normalizeCheckInType(string $checkInType): string
    {
        return in_array($checkInType, CustomerCheckIn::CHECK_IN_TYPES, true)
            ? $checkInType
            : CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL;
    }

    private function activeProgramFor(Business $business): ?LoyaltyProgram
    {
        return $business->loyaltyPrograms()
            ->active()
            ->latest()
            ->first();
    }

    private function cooldownMinutesFor(LoyaltyProgram $program, ?Branch $branch): int
    {
        return min(1440, max(15, $branch?->check_in_cooldown_minutes ?? $program->check_in_cooldown_minutes ?? 60));
    }

    private function insideCooldown(?CarbonInterface $lastCheckInAt, int $cooldownMinutes): bool
    {
        return $lastCheckInAt !== null
            && $lastCheckInAt->gt(now()->subMinutes($cooldownMinutes));
    }

    private function result(
        string $status,
        Business $business,
        ?Branch $branch,
        ?LoyaltyProgram $program,
        ?Customer $customer,
        ?CustomerLoyaltyAccount $account,
        bool $stampGranted,
        int $cooldownMinutes = 60,
        string $checkInType = CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL,
    ): array {
        return [
            'available' => $program !== null,
            'status' => $status,
            'business' => $business,
            'branch' => $branch,
            'program' => $program,
            'customer' => $customer,
            'account' => $account,
            'existing_customer' => $customer !== null,
            'welcome_stamp_granted' => false,
            'check_in_stamp_granted' => $stampGranted,
            'check_in_cooldown_minutes' => $cooldownMinutes,
            'check_in_type' => $checkInType,
        ];
    }
}
