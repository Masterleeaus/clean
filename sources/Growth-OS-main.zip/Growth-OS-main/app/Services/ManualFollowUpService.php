<?php

namespace App\Services;

use App\Models\Business;
use App\Models\Customer;
use App\Models\LoyaltyProgram;
use Illuminate\Support\Collection;

class ManualFollowUpService
{
    public function groupsFor(Business $business, ?LoyaltyProgram $loyaltyProgram): array
    {
        return [
            'dormant' => $this->formatCustomers(
                $business,
                $loyaltyProgram,
                'Dormant',
                $business->customers()
                    ->with(['loyaltyAccounts', 'checkIns' => fn ($query) => $query->latest('check_in_date')->limit(1)])
                    ->withMax('checkIns', 'check_in_date')
                    ->where(function ($query): void {
                        $query->whereDoesntHave('checkIns')
                            ->orWhereDoesntHave('checkIns', fn ($checkInQuery) => $checkInQuery->whereDate('check_in_date', '>=', now()->subDays(30)->toDateString()));
                    })
                    ->orderBy('name')
                    ->get(),
            ),
            'new' => $this->formatCustomers(
                $business,
                $loyaltyProgram,
                'New customer',
                $business->customers()
                    ->with(['loyaltyAccounts', 'checkIns' => fn ($query) => $query->latest('check_in_date')->limit(1)])
                    ->withMax('checkIns', 'check_in_date')
                    ->whereDate('created_at', '>=', now()->subDays(7)->toDateString())
                    ->orderBy('name')
                    ->get(),
            ),
            'near_reward' => $this->formatCustomers(
                $business,
                $loyaltyProgram,
                'Near reward',
                $this->stampBasedCustomers($business, $loyaltyProgram, nearReward: true),
            ),
            'eligible_reward' => $this->formatCustomers(
                $business,
                $loyaltyProgram,
                'Eligible reward',
                $this->stampBasedCustomers($business, $loyaltyProgram, nearReward: false),
            ),
        ];
    }

    public function messageFor(string $type, Customer $customer, Business $business, ?LoyaltyProgram $loyaltyProgram): string
    {
        return match ($type) {
            'Dormant' => "Hi {$customer->name}, kami rindu nak jumpa anda di {$business->name}. Minggu ini boleh singgah lagi ya 😊",
            'New customer' => "Hi {$customer->name}, terima kasih kerana singgah di {$business->name}. Jangan lupa datang lagi untuk kumpul stamp reward anda 😊",
            'Near reward' => "Hi {$customer->name}, anda tinggal 1 stamp sahaja lagi untuk claim reward di {$business->name}. Jemput datang lagi 😊",
            'Eligible reward' => "Hi {$customer->name}, tahniah! Anda sudah layak claim reward {$loyaltyProgram?->reward_name} di {$business->name}. Tunjukkan mesej ini masa datang ya 😊",
            default => "Hi {$customer->name}, terima kasih kerana menyokong {$business->name}.",
        };
    }

    public function waMeUrlFor(Customer $customer, string $message): ?string
    {
        $number = $this->normalizedWhatsapp($customer);

        if ($number === null) {
            return null;
        }

        return 'https://wa.me/'.$number.'?text='.rawurlencode($message);
    }

    public function normalizedWhatsapp(Customer $customer): ?string
    {
        $number = preg_replace('/\D+/', '', $customer->whatsapp_number) ?? '';

        return strlen($number) >= 7 ? $number : null;
    }

    private function stampBasedCustomers(Business $business, ?LoyaltyProgram $loyaltyProgram, bool $nearReward): Collection
    {
        if (! $loyaltyProgram) {
            return collect();
        }

        return $business->customers()
            ->with(['loyaltyAccounts', 'checkIns' => fn ($query) => $query->latest('check_in_date')->limit(1)])
            ->withMax('checkIns', 'check_in_date')
            ->whereHas('loyaltyAccounts', function ($query) use ($loyaltyProgram, $nearReward): void {
                $query->where('loyalty_program_id', $loyaltyProgram->id);

                if ($nearReward) {
                    $query->where('current_stamps', $loyaltyProgram->stamps_required - 1);
                } else {
                    $query->where('current_stamps', '>=', $loyaltyProgram->stamps_required);
                }
            })
            ->orderBy('name')
            ->get();
    }

    private function formatCustomers(Business $business, ?LoyaltyProgram $loyaltyProgram, string $type, Collection $customers): Collection
    {
        return $customers->map(function (Customer $customer) use ($business, $loyaltyProgram, $type): array {
            $message = $this->messageFor($type, $customer, $business, $loyaltyProgram);
            $account = $loyaltyProgram
                ? $customer->loyaltyAccounts->firstWhere('loyalty_program_id', $loyaltyProgram->id)
                : null;

            return [
                'customer' => $customer,
                'type' => $type,
                'message' => $message,
                'wa_url' => $this->waMeUrlFor($customer, $message),
                'current_stamps' => $account?->current_stamps ?? 0,
                'last_check_in' => $customer->check_ins_max_check_in_date,
            ];
        });
    }
}
