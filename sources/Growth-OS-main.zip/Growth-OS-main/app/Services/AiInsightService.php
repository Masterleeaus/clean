<?php

namespace App\Services;

use Illuminate\Support\Collection;

class AiInsightService
{
    public const INSUFFICIENT_DATA = 'Data belum cukup untuk insight yang kuat.';

    /**
     * @return array<int, array{
     *     title: string,
     *     explanation: string,
     *     evidence: array<int, string>,
     *     confidence: string,
     *     confidence_reason: string,
     *     data_gap: ?string,
     *     action_ready_context: array<string, mixed>
     * }>
     */
    public function fromAnalytics(array $analytics): array
    {
        if (($analytics['personaScope'] ?? null) === 'system_admin') {
            return $this->adminSupportInsights($analytics);
        }

        $insights = [];

        $summary = $analytics['summary'] ?? [];
        $sales = $analytics['salesAnalytics'] ?? [];
        $customers = $analytics['customerAnalytics'] ?? [];
        $products = $analytics['productAnalytics'] ?? [];
        $branches = collect($analytics['branchAnalytics'] ?? []);
        $operations = $analytics['operationAnalytics'] ?? [];
        $rewards = $analytics['rewardAnalytics'] ?? [];
        $feedback = $analytics['feedbackAnalytics'] ?? [];
        $dataCompleteness = collect($analytics['dataCompleteness'] ?? []);

        $totalSales = $this->moneyToFloat($summary['Total sales/value'] ?? 0);
        $transactionCount = (int) ($summary['Total transaction/capture'] ?? 0);
        $totalCheckIns = (int) ($summary['Total check-ins'] ?? 0);
        $totalFeedback = (int) ($feedback['Total feedback'] ?? 0);
        $pendingPurchaseCapture = (int) ($operations['Pending purchase capture'] ?? 0);
        $physicalCheckIns = (int) ($operations['Physical check-ins'] ?? 0);
        $onlineCheckIns = (int) ($operations['Online check-ins'] ?? 0);
        $pendingPhysical = (int) ($operations['Pending purchase capture - physical'] ?? 0);
        $pendingOnline = (int) ($operations['Pending purchase capture - online'] ?? 0);
        $overduePurchaseCapture = (int) ($operations['Overdue purchase capture'] ?? 0);
        $manualReviewRequired = (int) ($operations['Manual review required'] ?? 0);
        $noPurchase = (int) ($operations['No purchase / check-in without purchase'] ?? 0);
        $noPurchasePhysical = (int) ($operations['No purchase - physical'] ?? 0);
        $noPurchaseOnline = (int) ($operations['No purchase - online'] ?? 0);
        $checkInsWithoutCapture = (int) ($operations['Check-ins without Product/Service capture'] ?? 0);

        if (($analytics['personaScope'] ?? null) === 'system_manager') {
            foreach ($this->systemManagerInsights($analytics) as $insight) {
                $insights[] = $insight;
            }
        }

        if ($pendingPurchaseCapture > 0 || $checkInsWithoutCapture > 0) {
            $insights[] = $this->insight(
                title: 'Purchase conversion / capture backlog insight',
                explanation: 'Ada check-in yang belum lengkap dengan Product/Service capture, jadi conversion daripada check-in kepada purchase belum boleh dibaca penuh.',
                evidence: [
                    'Pending purchase capture: '.$pendingPurchaseCapture,
                    'Pending purchase capture - physical: '.$pendingPhysical,
                    'Pending purchase capture - online: '.$pendingOnline,
                    'Physical check-ins: '.$physicalCheckIns,
                    'Online check-ins: '.$onlineCheckIns,
                    'Check-ins without Product/Service capture: '.$checkInsWithoutCapture,
                    'Total check-ins: '.$totalCheckIns,
                    'Total transaction/capture: '.$transactionCount,
                ],
                confidence: $checkInsWithoutCapture >= 5 ? 'medium' : 'low',
                confidenceReason: $checkInsWithoutCapture >= 5
                    ? 'Jumlah check-in tanpa capture cukup jelas untuk menunjukkan capture backlog.'
                    : 'Signal backlog wujud, tetapi volume masih rendah.',
                dataGap: 'Product/Service capture perlu dilengkapkan untuk check-in pending supaya analytics conversion lebih tepat.',
                context: ['type' => 'purchase_capture_backlog', 'pending' => $pendingPurchaseCapture, 'without_capture' => $checkInsWithoutCapture, 'pending_physical' => $pendingPhysical, 'pending_online' => $pendingOnline],
            );
        }

        if ($overduePurchaseCapture > 0 || $manualReviewRequired > 0) {
            $insights[] = $this->insight(
                title: 'Operational follow-up risk insight',
                explanation: 'Pending purchase capture yang overdue atau manual review menunjukkan risiko operasi kerana staff belum mengesahkan purchase/no purchase.',
                evidence: [
                    'Overdue purchase capture: '.$overduePurchaseCapture,
                    'Manual review required: '.$manualReviewRequired,
                ],
                confidence: ($overduePurchaseCapture + $manualReviewRequired) >= 3 ? 'medium' : 'low',
                confidenceReason: 'Insight berdasarkan jumlah check-in yang masih belum selesai selepas threshold operasi.',
                dataGap: ($overduePurchaseCapture + $manualReviewRequired) >= 3 ? null : 'Lebih banyak data diperlukan untuk menilai sama ada ini pattern berulang.',
                context: ['type' => 'operational_follow_up_risk', 'overdue' => $overduePurchaseCapture, 'manual_review' => $manualReviewRequired],
            );
        }

        if ($noPurchase > 0) {
            $insights[] = $this->insight(
                title: 'No Purchase pattern insight',
                explanation: 'Sebahagian check-in ditandakan No Purchase, jadi ada signal customer check-in yang tidak bertukar menjadi purchase.',
                evidence: [
                    'No purchase / check-in without purchase: '.$noPurchase,
                    'No purchase - physical: '.$noPurchasePhysical,
                    'No purchase - online: '.$noPurchaseOnline,
                    'Total check-ins: '.$totalCheckIns,
                    'Total transaction/capture: '.$transactionCount,
                ],
                confidence: $noPurchase >= 3 ? 'medium' : 'low',
                confidenceReason: $noPurchase >= 3
                    ? 'No Purchase berlaku beberapa kali dalam scope ini.'
                    : 'No Purchase wujud tetapi belum cukup tinggi untuk kesimpulan kuat.',
                dataGap: 'Lebih banyak check-in dan staff capture diperlukan untuk menilai conversion sebenar.',
                context: ['type' => 'no_purchase_pattern', 'no_purchase' => $noPurchase, 'no_purchase_physical' => $noPurchasePhysical, 'no_purchase_online' => $noPurchaseOnline],
            );
        }

        if ($transactionCount > 0) {
            $insights[] = $this->insight(
                title: 'Sales trend insight',
                explanation: $transactionCount >= 3
                    ? 'Sales activity sudah menunjukkan signal revenue yang boleh dibaca untuk tempoh ini.'
                    : 'Sales activity sudah wujud, tetapi trend masih perlu lebih banyak transaksi untuk kesimpulan kuat.',
                evidence: [
                    'Total sales/value: RM '.number_format($totalSales, 2),
                    'Total transaction/capture: '.$transactionCount,
                    'Average transaction value: '.($summary['Average transaction value'] ?? 'RM 0.00'),
                ],
                confidence: $transactionCount >= 5 ? 'high' : 'medium',
                confidenceReason: $transactionCount >= 5
                    ? 'Jumlah transaction/capture mencukupi untuk bacaan sales asas.'
                    : 'Sales sudah direkod, tetapi jumlah transaction/capture masih sederhana.',
                dataGap: $transactionCount >= 5 ? null : 'Lebih banyak Product/Service capture diperlukan untuk trend sales yang lebih kuat.',
                context: ['type' => 'sales', 'total_sales' => $totalSales, 'transactions' => $transactionCount],
            );
        }

        $popularProduct = $products['popular'] ?? null;
        $highestSalesProduct = $products['highestSales'] ?? null;
        $lowActivityProduct = $this->firstCollectionItem($products['lowActivity'] ?? collect());

        if ($popularProduct || $highestSalesProduct || $lowActivityProduct) {
            $evidence = [];

            if ($popularProduct) {
                $evidence[] = 'Popular Product/Service: '.$popularProduct['name'].' (qty '.$popularProduct['quantity'].')';
            }

            if ($highestSalesProduct) {
                $evidence[] = 'Highest sales Product/Service: '.$highestSalesProduct['name'].' (RM '.number_format((float) $highestSalesProduct['total'], 2).')';
            }

            if ($lowActivityProduct) {
                $evidence[] = 'Weak/low activity Product/Service: '.$lowActivityProduct['name'];
            }

            $insights[] = $this->insight(
                title: 'Product/Service performance insight',
                explanation: $popularProduct
                    ? 'Product/Service activity menunjukkan item yang mendapat minat customer dan item yang masih lemah.'
                    : 'Product/Service list sudah tersedia, tetapi capture belum cukup untuk menentukan item kuat.',
                evidence: $evidence,
                confidence: $popularProduct ? 'medium' : 'low',
                confidenceReason: $popularProduct
                    ? 'Insight disokong oleh quantity dan sales capture.'
                    : 'Product/Service belum mempunyai capture yang mencukupi.',
                dataGap: $popularProduct ? null : 'Product/Service capture masih tidak mencukupi untuk mengenal pasti demand sebenar.',
                context: ['type' => 'product_service', 'popular' => $popularProduct, 'low_activity' => $lowActivityProduct],
            );
        }

        $topBranch = $branches
            ->sortByDesc(fn (array $branch): float => (float) $branch['sales'])
            ->first();
        $weakBranch = $branches
            ->sortBy(fn (array $branch): float => (float) $branch['sales'] + (int) $branch['check_ins'])
            ->first();

        if ($topBranch) {
            $evidence = [
                'Top branch by sales/check-in signal: '.$topBranch['name'],
                'Branch sales/value: RM '.number_format((float) $topBranch['sales'], 2),
                'Branch check-in count: '.$topBranch['check_ins'],
            ];

            if ($weakBranch && $weakBranch['name'] !== $topBranch['name']) {
                $evidence[] = 'Weak branch signal: '.$weakBranch['name'].' (RM '.number_format((float) $weakBranch['sales'], 2).', '.$weakBranch['check_ins'].' check-ins)';
            }

            $insights[] = $this->insight(
                title: 'Branch performance insight',
                explanation: ((float) $topBranch['sales'] > 0 || (int) $topBranch['check_ins'] > 0)
                    ? 'Branch performance menunjukkan perbezaan aktiviti antara branch dalam scope.'
                    : 'Branch sudah wujud, tetapi activity belum cukup untuk perbandingan prestasi yang kuat.',
                evidence: $evidence,
                confidence: ((float) $topBranch['sales'] > 0 && (int) $topBranch['check_ins'] > 0) ? 'medium' : 'low',
                confidenceReason: ((float) $topBranch['sales'] > 0 && (int) $topBranch['check_ins'] > 0)
                    ? 'Perbandingan disokong oleh sales dan check-in branch.'
                    : 'Branch data masih rendah atau kosong.',
                dataGap: ((float) $topBranch['sales'] > 0 && (int) $topBranch['check_ins'] > 0) ? null : 'Branch memerlukan lebih banyak check-in dan Product/Service capture.',
                context: ['type' => 'branch_performance', 'top_branch' => $topBranch, 'weak_branch' => $weakBranch],
            );
        }

        $totalCustomers = (int) ($customers['total'] ?? 0);
        $repeatCustomers = (int) ($customers['repeat'] ?? 0);
        $activeCustomers = (int) ($customers['active'] ?? 0);

        if ($totalCustomers > 0 || $totalCheckIns > 0) {
            $repeatRate = $activeCustomers > 0 ? $repeatCustomers / $activeCustomers : 0;

            $insights[] = $this->insight(
                title: 'Repeat customer pattern insight',
                explanation: $repeatCustomers > 0
                    ? 'Repeat customer sudah muncul, menandakan ada customer yang kembali dalam tempoh ini.'
                    : 'Repeat customer pattern masih lemah, jadi retention belum boleh dibaca dengan kuat.',
                evidence: [
                    'Total customers: '.$totalCustomers,
                    'Active customers: '.$activeCustomers,
                    'Repeat customers: '.$repeatCustomers,
                    'Check-in count: '.$totalCheckIns,
                ],
                confidence: $repeatCustomers > 1 ? 'medium' : 'low',
                confidenceReason: $repeatCustomers > 1
                    ? 'Ada lebih daripada satu repeat customer dalam scope.'
                    : 'Repeat customer data masih rendah.',
                dataGap: $repeatCustomers > 1 ? null : 'Lebih banyak repeat check-in diperlukan untuk insight retention yang kuat.',
                context: ['type' => 'customer_repeat', 'repeat_rate' => $repeatRate, 'repeat_customers' => $repeatCustomers],
            );
        }

        $negativeFeedback = (int) ($feedback['Negative/general issue summary'] ?? 0);
        $actionNeededFeedback = (int) ($feedback['Action needed feedback'] ?? 0);
        $positiveFeedback = (int) ($feedback['Positive summary'] ?? 0);
        $unclearFeedback = (int) ($feedback['Unclear summary'] ?? 0);

        if ($totalFeedback > 0) {
            $issueCount = $negativeFeedback + $actionNeededFeedback;

            $insights[] = $this->insight(
                title: 'Feedback pattern insight',
                explanation: $issueCount > 0
                    ? 'Feedback menunjukkan isu atau signal negatif yang berulang dalam scope.'
                    : 'Feedback yang direkod belum menunjukkan isu negatif yang kuat.',
                evidence: [
                    'Total feedback: '.$totalFeedback,
                    'Negative/general issue summary: '.$negativeFeedback,
                    'Action needed feedback: '.$actionNeededFeedback,
                    'Positive summary: '.$positiveFeedback,
                    'Unclear summary: '.$unclearFeedback,
                ],
                confidence: $totalFeedback >= 5 ? 'medium' : 'low',
                confidenceReason: $totalFeedback >= 5
                    ? 'Feedback volume mencukupi untuk bacaan pattern asas.'
                    : 'Feedback volume masih rendah.',
                dataGap: $totalFeedback >= 5 ? null : 'Lebih banyak submitted feedback diperlukan untuk sentiment pattern yang lebih kuat.',
                context: ['type' => 'feedback_pattern', 'issues' => $issueCount, 'positive' => $positiveFeedback],
            );
        }

        $rewardIssued = (int) ($rewards['Reward/stamp issued'] ?? 0);
        $rewardRedeemed = (int) ($rewards['Reward redeemed'] ?? 0);

        if ($rewardIssued > 0 || $rewardRedeemed > 0) {
            $insights[] = $this->insight(
                title: 'Reward effectiveness insight',
                explanation: $rewardIssued > 0 && $rewardRedeemed === 0
                    ? 'Reward/stamp sudah issued, tetapi redemption belum kelihatan dalam data ini.'
                    : 'Reward activity sudah wujud dan boleh menjadi signal loyalty.',
                evidence: [
                    'Reward/stamp issued: '.$rewardIssued,
                    'Reward redeemed: '.$rewardRedeemed,
                    'Reward pending: '.($rewards['Reward pending'] ?? 0),
                ],
                confidence: $rewardIssued >= 5 ? 'medium' : 'low',
                confidenceReason: $rewardIssued >= 5
                    ? 'Reward issued mencukupi untuk bacaan loyalty asas.'
                    : 'Reward data masih rendah.',
                dataGap: $rewardIssued >= 5 ? null : 'Lebih banyak valid check-in dan redemption diperlukan untuk menilai reward effectiveness.',
                context: ['type' => 'reward_effectiveness', 'issued' => $rewardIssued, 'redeemed' => $rewardRedeemed],
            );
        }

        if ($dataCompleteness->isNotEmpty()) {
            $firstGap = $dataCompleteness->first();

            $insights[] = $this->insight(
                title: 'Data gap insight',
                explanation: self::INSUFFICIENT_DATA,
                evidence: [
                    'Data gap: '.$firstGap['missing'],
                    'Why it matters: '.$firstGap['reason'],
                    'Accuracy effect: '.$firstGap['effect'],
                ],
                confidence: 'low',
                confidenceReason: 'Analytics Data Completeness menunjukkan data masih lemah atau tidak lengkap.',
                dataGap: $dataCompleteness->pluck('missing')->implode(', '),
                context: ['type' => 'data_gap', 'gaps' => $dataCompleteness->pluck('missing')->values()->all()],
            );
        }

        if ($insights === []) {
            return [
                $this->insight(
                    title: 'Data gap insight',
                    explanation: self::INSUFFICIENT_DATA,
                    evidence: ['Belum ada sales, check-in, feedback, reward, atau Product/Service capture yang cukup dalam scope ini.'],
                    confidence: 'low',
                    confidenceReason: 'Tiada data mencukupi untuk membentuk pattern business yang kuat.',
                    dataGap: 'Sales, check-in, Product/Service capture, customer, reward, dan feedback masih tidak mencukupi.',
                    context: ['type' => 'insufficient_data'],
                ),
            ];
        }

        return $insights;
    }

    private function systemManagerInsights(array $analytics): array
    {
        $platformMetrics = $analytics['platformMetrics'] ?? [];
        $performance = $platformMetrics['GOS platform/business performance'] ?? [];
        $usage = $platformMetrics['Platform effectiveness by usage'] ?? [];
        $revenueGap = $platformMetrics['Revenue/subscription data gap'] ?? [];

        return [
            $this->insight(
                title: 'GOS platform performance insight',
                explanation: 'GOS platform monitoring menunjukkan status awal business, branch, dan usage untuk vertical F&B.',
                evidence: [
                    'Total businesses/subscribers: '.($performance['Total businesses/subscribers'] ?? 0),
                    'Active businesses: '.($performance['Active businesses'] ?? 0),
                    'Active branches: '.($performance['Active branches'] ?? 0),
                    'Check-ins: '.($usage['Check-ins'] ?? 0),
                    'Product/Service captures: '.($usage['Product/Service captures'] ?? 0),
                    'Feedback records: '.($usage['Feedback records'] ?? 0),
                ],
                confidence: ((int) ($usage['Check-ins'] ?? 0) + (int) ($usage['Product/Service captures'] ?? 0)) > 0 ? 'medium' : 'low',
                confidenceReason: 'Insight menggunakan business, branch, check-in, Product/Service capture, feedback, dan reward usage yang tersedia.',
                dataGap: ((int) ($usage['Check-ins'] ?? 0) + (int) ($usage['Product/Service captures'] ?? 0)) > 0
                    ? null
                    : 'Platform usage data masih rendah untuk melihat effectiveness yang kuat.',
                context: ['type' => 'gos_platform_performance', 'metrics' => $platformMetrics],
            ),
            $this->insight(
                title: 'Business category/vertical performance insight',
                explanation: 'Data yang tersedia sekarang tertumpu kepada vertical F&B. Vertical lain seperti Carwash atau Salon belum mempunyai data dalam sistem ini.',
                evidence: [
                    'Current vertical: F&B',
                    'F&B businesses: '.($platformMetrics['Business category/vertical performance']['F&B businesses'] ?? 0),
                    'F&B branches: '.($platformMetrics['Business category/vertical performance']['F&B branches'] ?? 0),
                    'Platform sales/value from recorded captures: '.($platformMetrics['Business category/vertical performance']['Platform sales/value from recorded captures'] ?? 'RM 0.00'),
                ],
                confidence: 'low',
                confidenceReason: 'Perbandingan category/vertical belum kuat kerana hanya F&B data tersedia dalam MVP ini.',
                dataGap: 'Data vertical lain seperti Carwash dan Salon belum tersedia untuk comparison.',
                context: ['type' => 'vertical_performance', 'vertical' => 'F&B'],
            ),
            $this->insight(
                title: 'GOS revenue/subscription data gap insight',
                explanation: 'GOS revenue/subscription performance belum boleh dikira kerana billing/subscription data belum wujud dalam MVP ini.',
                evidence: [
                    'Subscription revenue: '.($revenueGap['Subscription revenue'] ?? 'Data belum tersedia'),
                    'GOS billing/payment data: '.($revenueGap['GOS billing/payment data'] ?? 'Belum dibina dalam MVP ini'),
                    'Impact: '.($revenueGap['Impact'] ?? 'Revenue/subscriber growth belum boleh dikira dengan tepat.'),
                ],
                confidence: 'low',
                confidenceReason: 'Revenue/subscription insight memerlukan subscription atau billing data yang belum tersedia.',
                dataGap: 'Subscription revenue dan billing/payment data belum tersedia.',
                context: ['type' => 'gos_revenue_subscription_gap'],
            ),
        ];
    }

    private function adminSupportInsights(array $analytics): array
    {
        $metrics = $analytics['adminSupportMetrics'] ?? [];
        $system = $metrics['System & Access'] ?? [];
        $setup = $metrics['Setup Completeness'] ?? [];
        $usage = $metrics['Platform Usage & Growth Support'] ?? [];

        return [
            $this->insight(
                title: 'System setup/access insight',
                explanation: 'System Admin view menunjukkan user role dan setup access untuk kerja admin/support.',
                evidence: [
                    'Total users: '.($system['Total users'] ?? 0),
                    'System Admins: '.($system['System Admins'] ?? 0),
                    'Business Owners: '.($system['Business Owners'] ?? 0),
                    'Branch Managers: '.($system['Branch Managers'] ?? 0),
                    'Customers: '.($system['Customers'] ?? 0),
                ],
                confidence: 'medium',
                confidenceReason: 'Insight menggunakan role/access records yang tersedia dalam sistem.',
                dataGap: null,
                context: ['type' => 'system_access_support', 'metrics' => $system],
            ),
            $this->insight(
                title: 'Setup completeness insight',
                explanation: 'Setup completeness memberi signal admin/support tentang business atau branch yang memerlukan semakan konfigurasi.',
                evidence: [
                    'Business missing owner: '.($setup['Business missing owner'] ?? 0),
                    'Branch without assigned manager: '.($setup['Branch without assigned manager'] ?? 0),
                    'Inactive businesses: '.($setup['Inactive businesses'] ?? 0),
                    'Inactive branches: '.($setup['Inactive branches'] ?? 0),
                ],
                confidence: 'medium',
                confidenceReason: 'Insight disokong oleh rekod Business, Branch, manager assignment, dan status aktif/tidak aktif.',
                dataGap: ((int) ($setup['Branch without assigned manager'] ?? 0)) > 0
                    ? 'Ada branch yang belum mempunyai assigned manager.'
                    : null,
                context: ['type' => 'setup_completeness_support', 'metrics' => $setup],
            ),
            $this->insight(
                title: 'Platform usage support insight',
                explanation: 'Usage/support insight membantu System Admin mengenal pasti konfigurasi atau usage yang perlu disokong.',
                evidence: [
                    'Check-ins recorded: '.($usage['Check-ins recorded'] ?? 0),
                    'Product/Service captures recorded: '.($usage['Product/Service captures recorded'] ?? 0),
                    'Feedback records: '.($usage['Feedback records'] ?? 0),
                    'Product/Service configuration missing: '.($usage['Product/Service configuration missing'] ?? 0),
                ],
                confidence: ((int) ($usage['Check-ins recorded'] ?? 0)) > 0 ? 'medium' : 'low',
                confidenceReason: 'Insight menggunakan usage records dan configuration completeness yang tersedia.',
                dataGap: ((int) ($usage['Product/Service configuration missing'] ?? 0)) > 0
                    ? 'Ada Product/Service configuration yang belum lengkap.'
                    : null,
                context: ['type' => 'platform_usage_support', 'metrics' => $usage],
            ),
        ];
    }

    private function insight(
        string $title,
        string $explanation,
        array $evidence,
        string $confidence,
        string $confidenceReason,
        ?string $dataGap,
        array $context,
    ): array {
        return [
            'title' => $title,
            'explanation' => $explanation,
            'evidence' => $evidence,
            'confidence' => $confidence,
            'confidence_reason' => $confidenceReason,
            'data_gap' => $dataGap,
            'action_ready_context' => $context,
        ];
    }

    private function moneyToFloat(mixed $value): float
    {
        if (is_numeric($value)) {
            return (float) $value;
        }

        return (float) preg_replace('/[^0-9.]/', '', (string) $value);
    }

    private function firstCollectionItem(mixed $value): ?array
    {
        if ($value instanceof Collection) {
            return $value->first();
        }

        if (is_array($value)) {
            return $value[0] ?? null;
        }

        return null;
    }
}
