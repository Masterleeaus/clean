<?php

namespace App\Providers;

use App\Models\Business;
use App\Models\Branch;
use App\Models\ProductService;
use App\Policies\BranchPolicy;
use App\Policies\BusinessPolicy;
use App\Policies\ProductServicePolicy;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Gate::policy(Business::class, BusinessPolicy::class);
        Gate::policy(Branch::class, BranchPolicy::class);
        Gate::policy(ProductService::class, ProductServicePolicy::class);
    }
}
