#!/usr/bin/env bash
set -euo pipefail

export PORT="${PORT:-10000}"

if [ -z "${APP_KEY:-}" ]; then
    echo "APP_KEY is required. Set it in Render environment variables."
    exit 1
fi

mkdir -p storage/framework/cache/data storage/framework/sessions storage/framework/views storage/logs bootstrap/cache /var/run/php-fpm
chown -R www-data:www-data storage bootstrap/cache /var/run/php-fpm
chmod -R ug+rwX storage bootstrap/cache

envsubst '${PORT}' < /etc/nginx/templates/default.conf.template > /etc/nginx/conf.d/default.conf
rm -f /etc/nginx/sites-enabled/default

php artisan config:clear --no-interaction
php artisan view:clear --no-interaction

if [ "${CACHE_CONFIG:-true}" = "true" ]; then
    php artisan config:cache --no-interaction
fi

if [ "${CACHE_VIEWS:-false}" = "true" ]; then
    php artisan view:cache --no-interaction
fi

exec /usr/bin/supervisord -c /etc/supervisor/conf.d/supervisord.conf
