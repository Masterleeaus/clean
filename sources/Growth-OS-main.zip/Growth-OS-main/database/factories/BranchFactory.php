<?php

namespace Database\Factories;

use App\Models\Branch;
use App\Models\Business;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Branch>
 */
class BranchFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'business_id' => Business::factory(),
            'manager_user_id' => null,
            'name' => fake()->city().' Outlet',
            'code' => fake()->unique()->bothify('BR-###'),
            'address' => fake()->address(),
            'phone' => fake()->numerify('60#########'),
            'is_active' => true,
            'check_in_cooldown_minutes' => 60,
        ];
    }
}
