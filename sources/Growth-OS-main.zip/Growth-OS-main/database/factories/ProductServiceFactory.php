<?php

namespace Database\Factories;

use App\Models\Business;
use App\Models\ProductService;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<ProductService>
 */
class ProductServiceFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'business_id' => Business::factory(),
            'branch_id' => null,
            'name' => fake()->randomElement(['Nasi Lemak', 'Iced Latte', 'Lunch Combo']),
            'category' => fake()->randomElement(['food', 'drink', 'combo']),
            'type' => 'product',
            'price' => fake()->randomFloat(2, 3, 30),
            'is_active' => true,
        ];
    }
}
