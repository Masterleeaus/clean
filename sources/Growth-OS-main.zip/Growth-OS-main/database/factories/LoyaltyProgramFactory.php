<?php

namespace Database\Factories;

use App\Models\Business;
use App\Models\LoyaltyProgram;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<LoyaltyProgram>
 */
class LoyaltyProgramFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'business_id' => Business::factory(),
            'name' => 'Classic Stamp Card',
            'stamps_required' => 8,
            'reward_name' => fake()->randomElement(['Free drink', 'Free dessert', 'RM10 voucher']),
            'reward_description' => fake()->optional()->sentence(),
            'welcome_stamp_enabled' => true,
            'is_active' => true,
        ];
    }
}
