<?php

namespace Database\Factories;

use App\Models\Business;
use App\Models\Branch;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\LoyaltyProgram;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<CustomerCheckIn>
 */
class CustomerCheckInFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'business_id' => Business::factory(),
            'branch_id' => Branch::factory(),
            'customer_id' => Customer::factory(),
            'loyalty_program_id' => LoyaltyProgram::factory(),
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'stamps_earned' => 1,
            'source' => 'factory',
        ];
    }
}
