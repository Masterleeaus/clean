<?php

namespace Database\Factories;

use App\Models\Business;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Str;

/**
 * @extends Factory<Business>
 */
class BusinessFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $name = fake()->company();

        return [
            'owner_user_id' => User::factory(),
            'name' => $name,
            'slug' => Str::slug($name).'-'.fake()->unique()->numberBetween(1000, 9999),
            'owner_name' => fake()->name(),
            'owner_whatsapp' => fake()->numerify('60#########'),
            'business_type' => fake()->randomElement(['restaurant', 'cafe', 'food_stall']),
            'public_qr_token' => (string) Str::uuid(),
        ];
    }
}
