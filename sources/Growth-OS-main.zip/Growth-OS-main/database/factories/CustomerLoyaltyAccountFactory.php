<?php

namespace Database\Factories;

use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerLoyaltyAccount;
use App\Models\LoyaltyProgram;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<CustomerLoyaltyAccount>
 */
class CustomerLoyaltyAccountFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'business_id' => Business::factory(),
            'customer_id' => Customer::factory(),
            'loyalty_program_id' => LoyaltyProgram::factory(),
            'current_stamps' => 0,
            'total_stamps_earned' => 0,
            'total_rewards_redeemed' => 0,
        ];
    }
}
