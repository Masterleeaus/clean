<?php

namespace Database\Factories;

use App\Models\Business;
use App\Models\Customer;
use App\Models\LoyaltyProgram;
use App\Models\RewardRedemption;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<RewardRedemption>
 */
class RewardRedemptionFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'business_id' => Business::factory(),
            'customer_id' => Customer::factory(),
            'loyalty_program_id' => LoyaltyProgram::factory(),
            'reward_name' => fake()->randomElement(['Free drink', 'Free dessert', 'RM10 voucher']),
            'stamps_spent' => 8,
            'verified_by_user_id' => null,
            'redeemed_at' => null,
        ];
    }
}
