<?php

namespace Database\Seeders;

use App\Models\Business;
use App\Models\Branch;
use App\Models\LoyaltyProgram;
use App\Models\Customer;
use App\Models\ProductService;
use App\Models\User;
use App\Services\ProductServiceReviewService;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class FnbCoreSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        $this->command?->warn('F&B Growth demo users use password: password. Change all pilot account passwords before using real customer data.');

        User::query()->updateOrCreate(
            ['email' => 'admin@fbgrowth.local'],
            [
                'name' => 'GOS-F&B System Admin',
                'password' => Hash::make('password'),
                'role' => User::ROLE_SYSTEM_ADMIN,
                'secondary_role' => null,
                'access_scope' => null,
                'email_verified_at' => now(),
            ],
        );

        User::query()->updateOrCreate(
            ['email' => 'manager@gos-fnb.local'],
            [
                'name' => 'GOS-F&B System Manager',
                'password' => Hash::make('password'),
                'role' => User::ROLE_SYSTEM_MANAGER,
                'secondary_role' => null,
                'access_scope' => null,
                'email_verified_at' => now(),
            ],
        );

        User::query()->updateOrCreate(
            ['email' => 'internal@gos-fnb.local'],
            [
                'name' => 'GOS-F&B Internal Combined',
                'password' => Hash::make('password'),
                'role' => User::ROLE_SYSTEM_MANAGER,
                'secondary_role' => User::ROLE_SYSTEM_ADMIN,
                'access_scope' => null,
                'email_verified_at' => now(),
            ],
        );

        User::query()->updateOrCreate(
            ['email' => 'manager@gos-fnb.pilot'],
            [
                'name' => 'GOS-F&B System Manager',
                'password' => Hash::make('password'),
                'role' => User::ROLE_SYSTEM_MANAGER,
                'secondary_role' => null,
                'access_scope' => null,
                'email_verified_at' => now(),
            ],
        );

        User::query()->updateOrCreate(
            ['email' => 'admin@gos-fnb.pilot'],
            [
                'name' => 'GOS-F&B System Admin',
                'password' => Hash::make('password'),
                'role' => User::ROLE_SYSTEM_ADMIN,
                'secondary_role' => null,
                'access_scope' => null,
                'email_verified_at' => now(),
            ],
        );

        $wanChuOwner = User::query()->updateOrCreate(
            ['email' => 'owner+wanchu@fbgrowth.local'],
            [
                'name' => 'WanChu Corner Owner',
                'password' => Hash::make('password'),
                'role' => User::ROLE_BUSINESS_OWNER,
                'secondary_role' => null,
                'access_scope' => null,
                'email_verified_at' => now(),
            ],
        );

        $cheNaOwner = User::query()->updateOrCreate(
            ['email' => 'owner+restoran-che-na@fbgrowth.local'],
            [
                'name' => 'Restoran Che Na Owner',
                'password' => Hash::make('password'),
                'role' => User::ROLE_BUSINESS_OWNER,
                'secondary_role' => null,
                'access_scope' => null,
                'email_verified_at' => now(),
            ],
        );

        $wanChu = Business::query()->updateOrCreate(
            ['slug' => 'wanchu-corner'],
            [
                'owner_user_id' => $wanChuOwner->id,
                'name' => 'WanChu Corner',
                'owner_name' => 'WanChu Corner Owner',
                'owner_whatsapp' => '60123456789',
                'business_type' => 'restaurant',
                'public_qr_token' => 'qr_wanchu_corner_phase1',
            ],
        );

        $cheNa = Business::query()->updateOrCreate(
            ['slug' => 'restoran-che-na'],
            [
                'owner_user_id' => $cheNaOwner->id,
                'name' => 'Restoran Che Na',
                'owner_name' => 'Restoran Che Na Owner',
                'owner_whatsapp' => '60198765432',
                'business_type' => 'restaurant',
                'public_qr_token' => 'qr_restoran_che_na_phase1',
            ],
        );

        User::query()->updateOrCreate(
            ['email' => 'owner+wanchu@gos-fnb.pilot'],
            [
                'name' => 'WanChu Corner Owner',
                'password' => Hash::make('password'),
                'role' => User::ROLE_BUSINESS_OWNER,
                'secondary_role' => null,
                'access_scope' => ['business_ids' => [$wanChu->id]],
                'email_verified_at' => now(),
            ],
        );

        User::query()->updateOrCreate(
            ['email' => 'owner+chena@gos-fnb.pilot'],
            [
                'name' => 'Restoran Che Na Owner',
                'password' => Hash::make('password'),
                'role' => User::ROLE_BUSINESS_OWNER,
                'secondary_role' => null,
                'access_scope' => ['business_ids' => [$cheNa->id]],
                'email_verified_at' => now(),
            ],
        );

        $wanChuPilotBranchManager = User::query()->updateOrCreate(
            ['email' => 'branch+wanchu@gos-fnb.pilot'],
            [
                'name' => 'WanChu Branch Manager',
                'password' => Hash::make('password'),
                'role' => User::ROLE_BRANCH_MANAGER,
                'secondary_role' => null,
                'access_scope' => ['business_ids' => [$wanChu->id]],
                'email_verified_at' => now(),
            ],
        );

        $cheNaPilotBranchManager = User::query()->updateOrCreate(
            ['email' => 'branch+chena@gos-fnb.pilot'],
            [
                'name' => 'Restoran Che Na Branch Manager',
                'password' => Hash::make('password'),
                'role' => User::ROLE_BRANCH_MANAGER,
                'secondary_role' => null,
                'access_scope' => ['business_ids' => [$cheNa->id]],
                'email_verified_at' => now(),
            ],
        );

        LoyaltyProgram::query()->updateOrCreate(
            ['business_id' => $wanChu->id, 'name' => 'WanChu Repeat Rewards'],
            [
                'stamps_required' => 8,
                'reward_name' => 'Free drink',
                'reward_description' => 'Redeem one house drink after collecting enough stamps.',
                'welcome_stamp_enabled' => true,
                'check_in_cooldown_minutes' => 60,
                'is_active' => true,
            ],
        );

        LoyaltyProgram::query()->updateOrCreate(
            ['business_id' => $cheNa->id, 'name' => 'Che Na Loyalty Card'],
            [
                'stamps_required' => 10,
                'reward_name' => 'RM10 voucher',
                'reward_description' => 'Redeem RM10 off a future dine-in purchase.',
                'welcome_stamp_enabled' => true,
                'check_in_cooldown_minutes' => 60,
                'is_active' => true,
            ],
        );

        $branchManager = User::query()->updateOrCreate(
            ['email' => 'branch+wanchu@fbgrowth.local'],
            [
                'name' => 'WanChu Branch Manager',
                'password' => Hash::make('password'),
                'role' => User::ROLE_BRANCH_MANAGER,
                'secondary_role' => null,
                'access_scope' => null,
                'email_verified_at' => now(),
            ],
        );

        $wanChuMainBranch = Branch::query()->updateOrCreate(
            ['business_id' => $wanChu->id, 'code' => 'WANCHU-MAIN'],
            [
                'manager_user_id' => $branchManager->id,
                'name' => 'WanChu Corner Main Branch',
                'address' => 'Demo outlet under WanChu Corner',
                'phone' => '60123456789',
                'is_active' => true,
                'check_in_cooldown_minutes' => 60,
            ],
        );

        Branch::query()->updateOrCreate(
            ['business_id' => $cheNa->id, 'code' => 'CHENA-MAIN'],
            [
                'manager_user_id' => $cheNaPilotBranchManager->id,
                'name' => 'Restoran Che Na - Main Branch',
                'address' => 'Demo outlet under Restoran Che Na',
                'phone' => '60198765432',
                'is_active' => true,
                'check_in_cooldown_minutes' => 60,
            ],
        );

        $cheNaMainBranch = Branch::query()
            ->where('business_id', $cheNa->id)
            ->where('code', 'CHENA-MAIN')
            ->firstOrFail();

        $branchManager->forceFill([
            'access_scope' => ['business_ids' => [$wanChu->id], 'branch_ids' => [$wanChuMainBranch->id]],
        ])->save();

        $wanChuPilotBranchManager->forceFill([
            'access_scope' => ['business_ids' => [$wanChu->id], 'branch_ids' => [$wanChuMainBranch->id]],
        ])->save();

        $cheNaPilotBranchManager->forceFill([
            'access_scope' => ['business_ids' => [$cheNa->id], 'branch_ids' => [$cheNaMainBranch->id]],
        ])->save();

        User::query()->updateOrCreate(
            ['email' => 'owner-branch+wanchu@fbgrowth.local'],
            [
                'name' => 'WanChu Owner Branch Combined',
                'password' => Hash::make('password'),
                'role' => User::ROLE_BUSINESS_OWNER,
                'secondary_role' => User::ROLE_BRANCH_MANAGER,
                'access_scope' => ['business_ids' => [$wanChu->id], 'branch_ids' => [$wanChuMainBranch->id]],
                'email_verified_at' => now(),
            ],
        );

        User::query()->updateOrCreate(
            ['email' => 'owner-branch+wanchu@gos-fnb.pilot'],
            [
                'name' => 'WanChu Owner Branch Combined',
                'password' => Hash::make('password'),
                'role' => User::ROLE_BUSINESS_OWNER,
                'secondary_role' => User::ROLE_BRANCH_MANAGER,
                'access_scope' => ['business_ids' => [$wanChu->id], 'branch_ids' => [$wanChuMainBranch->id]],
                'email_verified_at' => now(),
            ],
        );

        User::query()->updateOrCreate(
            ['email' => 'owner-branch+chena@gos-fnb.pilot'],
            [
                'name' => 'Restoran Che Na Owner Branch Combined',
                'password' => Hash::make('password'),
                'role' => User::ROLE_BUSINESS_OWNER,
                'secondary_role' => User::ROLE_BRANCH_MANAGER,
                'access_scope' => ['business_ids' => [$cheNa->id], 'branch_ids' => [$cheNaMainBranch->id]],
                'email_verified_at' => now(),
            ],
        );

        $demoCustomerUser = User::query()->updateOrCreate(
            ['email' => 'customer@fbgrowth.local'],
            [
                'name' => 'GOS-F&B Demo Customer',
                'password' => Hash::make('password'),
                'role' => User::ROLE_CUSTOMER,
                'secondary_role' => null,
                'access_scope' => null,
                'email_verified_at' => now(),
            ],
        );

        $pilotCustomerUser = User::query()->updateOrCreate(
            ['email' => 'customer@gos-fnb.pilot'],
            [
                'name' => 'GOS-F&B Demo Customer',
                'password' => Hash::make('password'),
                'role' => User::ROLE_CUSTOMER,
                'secondary_role' => null,
                'access_scope' => null,
                'email_verified_at' => now(),
            ],
        );

        Customer::query()->updateOrCreate(
            ['business_id' => $wanChu->id, 'whatsapp_number' => '60111112222'],
            [
                'user_id' => $demoCustomerUser->id,
                'name' => 'GOS-F&B Demo Customer',
                'consent_promo' => false,
            ],
        );

        Customer::query()->updateOrCreate(
            ['business_id' => $wanChu->id, 'whatsapp_number' => '60111113333'],
            [
                'user_id' => $pilotCustomerUser->id,
                'name' => 'GOS-F&B Demo Customer',
                'consent_promo' => false,
            ],
        );

        ProductService::query()->updateOrCreate(
            ['business_id' => $wanChu->id, 'name' => 'Nasi Lemak Ayam'],
            [
                'branch_id' => null,
                'category' => 'Makanan',
                'type' => 'product',
                'price' => 12.90,
                'is_active' => true,
            ],
        );

        ProductService::query()->updateOrCreate(
            ['business_id' => $wanChu->id, 'name' => 'Teh Ais'],
            [
                'branch_id' => $wanChuMainBranch->id,
                'category' => 'Minuman',
                'type' => 'product',
                'price' => 3.50,
                'is_active' => true,
            ],
        );

        ProductService::query()->updateOrCreate(
            ['business_id' => $cheNa->id, 'name' => 'Lunch Set'],
            [
                'branch_id' => null,
                'category' => 'Set Kombo',
                'type' => 'product',
                'price' => 15.00,
                'is_active' => true,
            ],
        );

        $cheNaProducts = [
            ['Nasi Lemak Biasa', 4.50, 'Makanan'],
            ['Nasi Lemak Ayam Goreng', 9.90, 'Makanan'],
            ['Nasi Lemak Sambal Sotong', 10.90, 'Makanan'],
            ['Mee Goreng Mamak', 7.50, 'Makanan'],
            ['Bihun Goreng', 6.50, 'Makanan'],
            ['Roti Canai', 2.00, 'Makanan'],
            ['Roti Telur', 3.50, 'Makanan'],
            ['Lontong', 6.90, 'Makanan'],
            ['Soto Ayam', 7.90, 'Makanan'],
            ['Nasi Campur Ayam', 10.90, 'Makanan'],
            ['Nasi Campur Ikan', 11.90, 'Makanan'],
            ['Nasi Ayam Penyet', 12.90, 'Makanan'],
            ['Nasi Kerabu Ayam', 11.90, 'Makanan'],
            ['Nasi Kukus Ayam Berempah', 12.50, 'Makanan'],
            ['Sup Tulang', 15.90, 'Makanan'],
            ['Tomyam Ayam', 9.90, 'Makanan'],
            ['Tomyam Seafood', 14.90, 'Makanan'],
            ['Siakap Tiga Rasa', 38.00, 'Makanan'],
            ['Kailan Ikan Masin', 8.90, 'Makanan'],
            ['Telur Dadar', 4.00, 'Add-on'],
            ['Ayam Goreng Berempah', 6.50, 'Add-on'],
            ['Sambal Sotong Add-on', 6.90, 'Add-on'],
            ['Set Lunch Ayam + Air', 13.90, 'Set Kombo'],
            ['Set Family Dinner', 49.90, 'Set Kombo'],
            ['Teh O Panas', 1.80, 'Minuman'],
            ['Teh Ais', 2.50, 'Minuman'],
            ['Kopi O Panas', 1.80, 'Minuman'],
            ['Kopi Ais', 2.80, 'Minuman'],
            ['Milo Ais', 3.50, 'Minuman'],
            ['Sirap Bandung', 3.20, 'Minuman'],
            ['Nasi Lemak Aym', 9.90, 'Makanan'],
            ['Kopi Ice', 2.80, 'Minuman'],
            ['Teh Ais Special', 0.10, 'Minuman'],
            ['Set Premium Dinner', 199.90, 'Set Kombo'],
            ['Nasi Campur Ayam Large', 29.90, 'Makanan'],
        ];

        $reviewService = app(ProductServiceReviewService::class);

        foreach ($cheNaProducts as [$name, $price, $category]) {
            $product = ProductService::query()->updateOrCreate(
                ['business_id' => $cheNa->id, 'branch_id' => $cheNaMainBranch->id, 'name' => $name],
                [
                    'category' => $category,
                    'type' => 'product',
                    'price' => $price,
                    'is_active' => true,
                    'archived_at' => null,
                ],
            );

            $reviewService->reviewSaved($product, actor: $cheNaPilotBranchManager);
        }
    }
}
