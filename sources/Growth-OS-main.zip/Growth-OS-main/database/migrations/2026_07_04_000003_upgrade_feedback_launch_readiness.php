<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('customer_feedback', function (Blueprint $table) {
            if (! Schema::hasColumn('customer_feedback', 'check_in_product_service_id')) {
                $table->foreignId('check_in_product_service_id')->nullable()->after('product_service_id')->constrained('check_in_product_services')->nullOnDelete();
            }

            if (! Schema::hasColumn('customer_feedback', 'status')) {
                $table->string('status', 30)->default('submitted')->after('source');
            }

            if (! Schema::hasColumn('customer_feedback', 'summary_main_meaning')) {
                $table->text('summary_main_meaning')->nullable()->after('submitted_at');
            }

            if (! Schema::hasColumn('customer_feedback', 'summary_positive_point')) {
                $table->text('summary_positive_point')->nullable()->after('summary_main_meaning');
            }

            if (! Schema::hasColumn('customer_feedback', 'summary_negative_point')) {
                $table->text('summary_negative_point')->nullable()->after('summary_positive_point');
            }

            if (! Schema::hasColumn('customer_feedback', 'summary_customer_expectation')) {
                $table->text('summary_customer_expectation')->nullable()->after('summary_negative_point');
            }

            if (! Schema::hasColumn('customer_feedback', 'summary_issue_category')) {
                $table->string('summary_issue_category')->nullable()->after('summary_customer_expectation');
            }

            if (! Schema::hasColumn('customer_feedback', 'summary_product_service_mentioned')) {
                $table->string('summary_product_service_mentioned')->nullable()->after('summary_issue_category');
            }

            if (! Schema::hasColumn('customer_feedback', 'summary_needs_review')) {
                $table->boolean('summary_needs_review')->default(false)->after('summary_product_service_mentioned');
            }

            $table->unique('check_in_product_service_id', 'customer_feedback_capture_unique');
            $table->index(['business_id', 'branch_id', 'status'], 'customer_feedback_status_scope_index');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('customer_feedback', function (Blueprint $table) {
            $table->dropIndex('customer_feedback_status_scope_index');
            $table->dropUnique('customer_feedback_capture_unique');
            $table->dropColumn([
                'summary_needs_review',
                'summary_product_service_mentioned',
                'summary_issue_category',
                'summary_customer_expectation',
                'summary_negative_point',
                'summary_positive_point',
                'summary_main_meaning',
                'status',
            ]);
            $table->dropConstrainedForeignId('check_in_product_service_id');
        });
    }
};
