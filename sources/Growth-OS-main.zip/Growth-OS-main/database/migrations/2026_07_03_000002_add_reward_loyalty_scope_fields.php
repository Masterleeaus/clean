<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('customers', function (Blueprint $table) {
            if (! Schema::hasColumn('customers', 'user_id')) {
                $table->foreignId('user_id')->nullable()->after('business_id')->constrained()->nullOnDelete();
            }
        });

        Schema::table('stamp_transactions', function (Blueprint $table) {
            if (! Schema::hasColumn('stamp_transactions', 'branch_id')) {
                $table->foreignId('branch_id')->nullable()->after('business_id')->constrained()->nullOnDelete();
            }
        });

        Schema::table('reward_redemptions', function (Blueprint $table) {
            if (! Schema::hasColumn('reward_redemptions', 'branch_id')) {
                $table->foreignId('branch_id')->nullable()->after('business_id')->constrained()->nullOnDelete();
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('reward_redemptions', function (Blueprint $table) {
            if (Schema::hasColumn('reward_redemptions', 'branch_id')) {
                $table->dropConstrainedForeignId('branch_id');
            }
        });

        Schema::table('stamp_transactions', function (Blueprint $table) {
            if (Schema::hasColumn('stamp_transactions', 'branch_id')) {
                $table->dropConstrainedForeignId('branch_id');
            }
        });

        Schema::table('customers', function (Blueprint $table) {
            if (Schema::hasColumn('customers', 'user_id')) {
                $table->dropConstrainedForeignId('user_id');
            }
        });
    }
};
