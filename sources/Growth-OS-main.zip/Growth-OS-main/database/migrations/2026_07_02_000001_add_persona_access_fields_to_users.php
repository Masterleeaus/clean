<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table) {
            if (! Schema::hasColumn('users', 'secondary_role')) {
                $table->string('secondary_role', 30)->nullable()->after('role')->index();
            }

            if (! Schema::hasColumn('users', 'access_scope')) {
                $table->json('access_scope')->nullable()->after('secondary_role');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('users', function (Blueprint $table) {
            if (Schema::hasColumn('users', 'access_scope')) {
                $table->dropColumn('access_scope');
            }

            if (Schema::hasColumn('users', 'secondary_role')) {
                $table->dropColumn('secondary_role');
            }
        });
    }
};
