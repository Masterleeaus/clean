<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('product_services', function (Blueprint $table) {
            $table->id();
            $table->foreignId('business_id')->constrained()->cascadeOnDelete();
            $table->foreignId('branch_id')->nullable()->constrained()->nullOnDelete();
            $table->string('name');
            $table->string('category')->nullable();
            $table->string('type', 50)->default('product');
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index(['business_id', 'branch_id', 'is_active'], 'product_services_scope_index');
        });

        Schema::create('check_in_product_services', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_check_in_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_service_id')->constrained()->cascadeOnDelete();
            $table->foreignId('captured_by_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->unsignedInteger('quantity')->default(1);
            $table->string('capture_type', 50)->default('purchase');
            $table->text('notes')->nullable();
            $table->timestamps();

            $table->index(['customer_check_in_id', 'product_service_id'], 'check_in_product_service_lookup_index');
        });

        if (
            Schema::hasTable('customer_feedback')
            && Schema::hasColumn('customer_feedback', 'product_service_id')
            && ! $this->hasForeignKey('customer_feedback', 'customer_feedback_product_service_id_foreign')
        ) {
            Schema::table('customer_feedback', function (Blueprint $table): void {
                $table->foreign('product_service_id')
                    ->references('id')
                    ->on('product_services')
                    ->nullOnDelete();
            });
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        if (
            Schema::hasTable('customer_feedback')
            && Schema::hasColumn('customer_feedback', 'product_service_id')
            && $this->hasForeignKey('customer_feedback', 'customer_feedback_product_service_id_foreign')
        ) {
            Schema::table('customer_feedback', function (Blueprint $table): void {
                $table->dropForeign(['product_service_id']);
            });
        }

        Schema::dropIfExists('check_in_product_services');
        Schema::dropIfExists('product_services');
    }

    private function hasForeignKey(string $table, string $name): bool
    {
        return collect(Schema::getForeignKeys($table))
            ->contains(fn (array $foreignKey): bool => ($foreignKey['name'] ?? null) === $name);
    }
};
