<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('product_services', function (Blueprint $table) {
            if (! Schema::hasColumn('product_services', 'price')) {
                $table->decimal('price', 10, 2)->default(0)->after('type');
            }
        });

        Schema::table('check_in_product_services', function (Blueprint $table) {
            if (! Schema::hasColumn('check_in_product_services', 'business_id')) {
                $table->foreignId('business_id')->nullable()->after('id')->constrained()->cascadeOnDelete();
            }

            if (! Schema::hasColumn('check_in_product_services', 'branch_id')) {
                $table->foreignId('branch_id')->nullable()->after('business_id')->constrained()->nullOnDelete();
            }

            if (! Schema::hasColumn('check_in_product_services', 'customer_id')) {
                $table->foreignId('customer_id')->nullable()->after('branch_id')->constrained()->cascadeOnDelete();
            }

            if (! Schema::hasColumn('check_in_product_services', 'price_at_capture')) {
                $table->decimal('price_at_capture', 10, 2)->default(0)->after('quantity');
            }

            if (! Schema::hasColumn('check_in_product_services', 'total_amount')) {
                $table->decimal('total_amount', 10, 2)->default(0)->after('price_at_capture');
            }

            if (! Schema::hasColumn('check_in_product_services', 'capture_source')) {
                $table->string('capture_source', 50)->default('staff_manual')->after('capture_type');
            }

            if (! Schema::hasColumn('check_in_product_services', 'capture_reference')) {
                $table->string('capture_reference')->nullable()->after('capture_source');
            }

            $table->index(['business_id', 'branch_id', 'customer_id'], 'check_in_product_services_scope_index');
            $table->unique('capture_reference', 'check_in_product_services_reference_unique');
        });

        Schema::table('online_check_in_references', function (Blueprint $table) {
            if (! Schema::hasColumn('online_check_in_references', 'price_at_purchase')) {
                $table->decimal('price_at_purchase', 10, 2)->default(0)->after('quantity');
            }

            if (! Schema::hasColumn('online_check_in_references', 'total_amount')) {
                $table->decimal('total_amount', 10, 2)->default(0)->after('price_at_purchase');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('online_check_in_references', function (Blueprint $table) {
            $table->dropColumn(['price_at_purchase', 'total_amount']);
        });

        Schema::table('check_in_product_services', function (Blueprint $table) {
            $table->dropUnique('check_in_product_services_reference_unique');
            $table->dropIndex('check_in_product_services_scope_index');
            $table->dropColumn([
                'capture_reference',
                'capture_source',
                'total_amount',
                'price_at_capture',
            ]);
            $table->dropConstrainedForeignId('customer_id');
            $table->dropConstrainedForeignId('branch_id');
            $table->dropConstrainedForeignId('business_id');
        });

        Schema::table('product_services', function (Blueprint $table) {
            $table->dropColumn('price');
        });
    }
};
