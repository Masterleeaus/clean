<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('customer_feedback', function (Blueprint $table): void {
            if (! Schema::hasColumn('customer_feedback', 'branch_id')) {
                $table->foreignId('branch_id')->nullable()->after('business_id')->constrained()->nullOnDelete();
            }

            if (! Schema::hasColumn('customer_feedback', 'customer_check_in_id')) {
                $table->foreignId('customer_check_in_id')->nullable()->after('customer_id')->constrained()->nullOnDelete();
            }

            if (! Schema::hasColumn('customer_feedback', 'product_service_id')) {
                if (Schema::hasTable('product_services')) {
                    $table->foreignId('product_service_id')->nullable()->after('customer_check_in_id')->constrained()->nullOnDelete();
                } else {
                    $table->foreignId('product_service_id')->nullable()->after('customer_check_in_id');
                }
            }

            if (! Schema::hasColumn('customer_feedback', 'rating')) {
                $table->unsignedTinyInteger('rating')->nullable()->after('service_rating');
            }

            if (! Schema::hasColumn('customer_feedback', 'source')) {
                $table->string('source')->nullable()->after('comment');
            }
        });
    }

    public function down(): void
    {
        Schema::table('customer_feedback', function (Blueprint $table): void {
            if (Schema::hasColumn('customer_feedback', 'branch_id')) {
                $table->dropConstrainedForeignId('branch_id');
            }

            if (Schema::hasColumn('customer_feedback', 'customer_check_in_id')) {
                $table->dropConstrainedForeignId('customer_check_in_id');
            }

            if (Schema::hasColumn('customer_feedback', 'product_service_id')) {
                if ($this->hasForeignKey('customer_feedback', 'customer_feedback_product_service_id_foreign')) {
                    $table->dropConstrainedForeignId('product_service_id');
                } else {
                    $table->dropColumn('product_service_id');
                }
            }

            $columns = array_values(array_filter(
                ['rating', 'source'],
                fn (string $column): bool => Schema::hasColumn('customer_feedback', $column)
            ));

            if ($columns !== []) {
                $table->dropColumn($columns);
            }
        });
    }

    private function hasForeignKey(string $table, string $name): bool
    {
        return collect(Schema::getForeignKeys($table))
            ->contains(fn (array $foreignKey): bool => ($foreignKey['name'] ?? null) === $name);
    }
};
