<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('product_services', function (Blueprint $table): void {
            if (! Schema::hasColumn('product_services', 'review_status')) {
                $table->string('review_status', 30)->default('active')->after('is_active');
            }

            if (! Schema::hasColumn('product_services', 'review_flags')) {
                $table->json('review_flags')->nullable()->after('review_status');
            }

            if (! Schema::hasColumn('product_services', 'review_note')) {
                $table->text('review_note')->nullable()->after('review_flags');
            }

            if (! Schema::hasColumn('product_services', 'archived_at')) {
                $table->timestamp('archived_at')->nullable()->after('review_note');
            }
        });
    }

    public function down(): void
    {
        Schema::table('product_services', function (Blueprint $table): void {
            $table->dropColumn([
                'archived_at',
                'review_note',
                'review_flags',
                'review_status',
            ]);
        });
    }
};
