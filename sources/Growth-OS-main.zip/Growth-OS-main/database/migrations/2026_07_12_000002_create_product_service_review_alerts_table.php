<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('product_service_review_alerts', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('business_id')->constrained()->cascadeOnDelete();
            $table->foreignId('branch_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('product_service_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('actor_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->string('issue_type', 80);
            $table->string('title');
            $table->text('message');
            $table->text('suggested_review')->nullable();
            $table->string('status', 30)->default('open');
            $table->json('metadata')->nullable();
            $table->string('dedupe_key')->nullable()->unique();
            $table->timestamp('reviewed_at')->nullable();
            $table->timestamps();

            $table->index(['business_id', 'status'], 'product_service_alert_business_status_index');
            $table->index(['branch_id', 'status'], 'product_service_alert_branch_status_index');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('product_service_review_alerts');
    }
};
