<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('loyalty_programs', function (Blueprint $table) {
            if (! Schema::hasColumn('loyalty_programs', 'check_in_cooldown_minutes')) {
                $table->unsignedInteger('check_in_cooldown_minutes')->default(60)->after('welcome_stamp_enabled');
            }
        });

        Schema::table('customer_check_ins', function (Blueprint $table) {
            if (! Schema::hasIndex('customer_check_ins', 'customer_check_in_lookup_index')) {
                $table->index(['business_id', 'customer_id', 'check_in_date'], 'customer_check_in_lookup_index');
            }

            if (Schema::hasIndex('customer_check_ins', 'customer_daily_check_in_unique')) {
                $table->dropUnique('customer_daily_check_in_unique');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('customer_check_ins', function (Blueprint $table) {
            if (! Schema::hasIndex('customer_check_ins', 'customer_daily_check_in_unique')) {
                $table->unique(['business_id', 'customer_id', 'check_in_date'], 'customer_daily_check_in_unique');
            }

            if (Schema::hasIndex('customer_check_ins', 'customer_check_in_lookup_index')) {
                $table->dropIndex('customer_check_in_lookup_index');
            }
        });

        Schema::table('loyalty_programs', function (Blueprint $table) {
            if (Schema::hasColumn('loyalty_programs', 'check_in_cooldown_minutes')) {
                $table->dropColumn('check_in_cooldown_minutes');
            }
        });
    }
};
