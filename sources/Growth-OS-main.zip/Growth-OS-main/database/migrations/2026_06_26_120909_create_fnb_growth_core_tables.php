<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('businesses', function (Blueprint $table) {
            $table->id();
            $table->foreignId('owner_user_id')->constrained('users')->cascadeOnDelete();
            $table->string('name');
            $table->string('slug')->unique();
            $table->string('owner_name');
            $table->string('owner_whatsapp');
            $table->string('business_type');
            $table->string('public_qr_token')->nullable()->unique();
            $table->timestamps();
        });

        Schema::create('loyalty_programs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('business_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->unsignedInteger('stamps_required');
            $table->string('reward_name');
            $table->text('reward_description')->nullable();
            $table->boolean('welcome_stamp_enabled')->default(true);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('customers', function (Blueprint $table) {
            $table->id();
            $table->foreignId('business_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('whatsapp_number');
            $table->date('birthday')->nullable();
            $table->boolean('consent_promo')->default(false);
            $table->timestamps();

            $table->unique(['business_id', 'whatsapp_number']);
        });

        Schema::create('customer_loyalty_accounts', function (Blueprint $table) {
            $table->id();
            $table->foreignId('business_id')->constrained()->cascadeOnDelete();
            $table->foreignId('customer_id')->constrained()->cascadeOnDelete();
            $table->foreignId('loyalty_program_id')->constrained()->cascadeOnDelete();
            $table->unsignedInteger('current_stamps')->default(0);
            $table->unsignedInteger('total_stamps_earned')->default(0);
            $table->unsignedInteger('total_rewards_redeemed')->default(0);
            $table->timestamps();

            $table->unique(['business_id', 'customer_id', 'loyalty_program_id'], 'customer_loyalty_unique');
        });

        Schema::create('customer_check_ins', function (Blueprint $table) {
            $table->id();
            $table->foreignId('business_id')->constrained()->cascadeOnDelete();
            $table->foreignId('customer_id')->constrained()->cascadeOnDelete();
            $table->foreignId('loyalty_program_id')->constrained()->cascadeOnDelete();
            $table->date('check_in_date');
            $table->unsignedInteger('stamps_earned')->default(1);
            $table->timestamps();

            $table->unique(['business_id', 'customer_id', 'check_in_date'], 'customer_daily_check_in_unique');
        });

        Schema::create('stamp_transactions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('business_id')->constrained()->cascadeOnDelete();
            $table->foreignId('customer_id')->constrained()->cascadeOnDelete();
            $table->foreignId('loyalty_program_id')->constrained()->cascadeOnDelete();
            $table->string('type');
            $table->integer('stamps');
            $table->text('description')->nullable();
            $table->timestamps();
        });

        Schema::create('reward_redemptions', function (Blueprint $table) {
            $table->id();
            $table->foreignId('business_id')->constrained()->cascadeOnDelete();
            $table->foreignId('customer_id')->constrained()->cascadeOnDelete();
            $table->foreignId('loyalty_program_id')->constrained()->cascadeOnDelete();
            $table->string('reward_name');
            $table->unsignedInteger('stamps_spent');
            $table->foreignId('verified_by_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('redeemed_at')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('reward_redemptions');
        Schema::dropIfExists('stamp_transactions');
        Schema::dropIfExists('customer_check_ins');
        Schema::dropIfExists('customer_loyalty_accounts');
        Schema::dropIfExists('customers');
        Schema::dropIfExists('loyalty_programs');
        Schema::dropIfExists('businesses');
    }
};
