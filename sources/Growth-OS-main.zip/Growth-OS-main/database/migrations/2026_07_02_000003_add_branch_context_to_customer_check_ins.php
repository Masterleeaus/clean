<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('customer_check_ins', function (Blueprint $table) {
            if (! Schema::hasColumn('customer_check_ins', 'branch_id')) {
                $table->foreignId('branch_id')->nullable()->after('business_id')->constrained()->nullOnDelete();
            }

            if (! Schema::hasColumn('customer_check_ins', 'user_id')) {
                $table->foreignId('user_id')->nullable()->after('customer_id')->constrained()->nullOnDelete();
            }

            if (! Schema::hasColumn('customer_check_ins', 'check_in_at')) {
                $table->timestamp('check_in_at')->nullable()->after('check_in_date')->index();
            }

            if (! Schema::hasColumn('customer_check_ins', 'source')) {
                $table->string('source', 50)->nullable()->after('stamps_earned');
            }

            $table->index(['business_id', 'branch_id', 'customer_id'], 'customer_check_in_branch_lookup_index');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('customer_check_ins', function (Blueprint $table) {
            $table->dropIndex('customer_check_in_branch_lookup_index');

            if (Schema::hasColumn('customer_check_ins', 'source')) {
                $table->dropColumn('source');
            }

            if (Schema::hasColumn('customer_check_ins', 'check_in_at')) {
                $table->dropColumn('check_in_at');
            }

            if (Schema::hasColumn('customer_check_ins', 'user_id')) {
                $table->dropConstrainedForeignId('user_id');
            }

            if (Schema::hasColumn('customer_check_ins', 'branch_id')) {
                $table->dropConstrainedForeignId('branch_id');
            }
        });
    }
};
