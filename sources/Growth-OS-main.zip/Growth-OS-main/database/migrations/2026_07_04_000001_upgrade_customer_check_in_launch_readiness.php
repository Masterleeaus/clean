<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('customer_check_ins', function (Blueprint $table) {
            if (! Schema::hasColumn('customer_check_ins', 'check_in_type')) {
                $table->string('check_in_type', 30)->default('physical')->after('source');
            }

            if (! Schema::hasColumn('customer_check_ins', 'reward_status')) {
                $table->string('reward_status', 30)->default('pending_product')->after('check_in_type');
            }

            if (! Schema::hasColumn('customer_check_ins', 'reward_granted_at')) {
                $table->timestamp('reward_granted_at')->nullable()->after('reward_status');
            }

            if (! Schema::hasColumn('customer_check_ins', 'purchase_reference')) {
                $table->string('purchase_reference')->nullable()->after('reward_granted_at');
            }

            if (! Schema::hasColumn('customer_check_ins', 'is_suspicious')) {
                $table->boolean('is_suspicious')->default(false)->after('purchase_reference');
            }

            $table->index(['business_id', 'branch_id', 'check_in_type'], 'customer_check_in_launch_scope_index');
            $table->index(['reward_status', 'reward_granted_at'], 'customer_check_in_reward_status_index');
        });

        Schema::create('online_check_in_references', function (Blueprint $table) {
            $table->id();
            $table->foreignId('business_id')->constrained()->cascadeOnDelete();
            $table->foreignId('branch_id')->constrained()->cascadeOnDelete();
            $table->foreignId('customer_id')->constrained()->cascadeOnDelete();
            $table->foreignId('product_service_id')->constrained()->cascadeOnDelete();
            $table->foreignId('created_by_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('claimed_by_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('claimed_check_in_id')->nullable()->constrained('customer_check_ins')->nullOnDelete();
            $table->string('code')->unique();
            $table->string('purchase_reference')->nullable();
            $table->unsignedInteger('quantity')->default(1);
            $table->string('capture_type', 50)->default('purchase');
            $table->string('status', 30)->default('pending');
            $table->timestamp('claimed_at')->nullable();
            $table->timestamps();

            $table->unique(['business_id', 'purchase_reference'], 'online_check_in_purchase_reference_unique');
            $table->index(['business_id', 'branch_id', 'status'], 'online_check_in_reference_scope_index');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('online_check_in_references');

        Schema::table('customer_check_ins', function (Blueprint $table) {
            $table->dropIndex('customer_check_in_launch_scope_index');
            $table->dropIndex('customer_check_in_reward_status_index');
            $table->dropColumn([
                'check_in_type',
                'reward_status',
                'reward_granted_at',
                'purchase_reference',
                'is_suspicious',
            ]);
        });
    }
};
