<?php

return [
    'external_enabled' => env('AI_EXTERNAL_ENABLED', true),
    'priority' => env('AI_PROVIDER_PRIORITY', 'openai,gemini,groq,openrouter,rule_based'),
    'default_provider' => env('AI_DEFAULT_PROVIDER', 'gemini'),
    'fallback_provider' => env('AI_FALLBACK_PROVIDER', 'rule_based'),
    'timeout' => (int) env('AI_TIMEOUT', 10),
    'action_mode' => env('AI_ACTION_MODE', 'suggestion_only'),

    'providers' => [
        'openai' => [
            'label' => 'OpenAI',
            'enabled' => env('OPENAI_ENABLED', false),
            'api_key' => env('OPENAI_API_KEY', ''),
            'model' => env('OPENAI_MODEL', ''),
            'base_url' => env('OPENAI_BASE_URL', 'https://api.openai.com/v1/chat/completions'),
        ],
        'gemini' => [
            'label' => 'Gemini',
            'enabled' => env('GEMINI_ENABLED', true),
            'api_key' => env('GEMINI_API_KEY', ''),
            'model' => env('GEMINI_MODEL', ''),
            'base_url' => env('GEMINI_BASE_URL', 'https://generativelanguage.googleapis.com/v1beta'),
        ],
        'groq' => [
            'label' => 'Groq',
            'enabled' => env('GROQ_ENABLED', true),
            'api_key' => env('GROQ_API_KEY', ''),
            'model' => env('GROQ_MODEL', ''),
            'base_url' => env('GROQ_BASE_URL', 'https://api.groq.com/openai/v1/chat/completions'),
        ],
        'openrouter' => [
            'label' => 'OpenRouter',
            'enabled' => env('OPENROUTER_ENABLED', true),
            'api_key' => env('OPENROUTER_API_KEY', ''),
            'model' => env('OPENROUTER_MODEL', ''),
            'base_url' => env('OPENROUTER_BASE_URL', 'https://openrouter.ai/api/v1/chat/completions'),
        ],
        'rule_based' => [
            'label' => 'Rule-based',
            'enabled' => env('RULE_BASED_AI_ENABLED', true),
        ],
    ],
];
