<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FeedbackLaunchReadinessTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_feedback_form_is_free_general_feedback_not_pending_feedback(): void
    {
        $this->actingAs($this->customer())
            ->get(route('customer.feedback'))
            ->assertOk()
            ->assertSee('Hantar Maklumbalas')
            ->assertDontSee('Hantar Maklumbalas Lain')
            ->assertDontSee('Pending Feedback')
            ->assertDontSee('feedback belum dihantar');
    }

    public function test_customer_can_submit_feedback_without_purchase_or_check_in(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->submitFeedback($branch, 'Aplikasi check-in mudah digunakan dan reward jelas.')
            ->assertRedirect(route('customer.feedback'))
            ->assertSessionHas('status', 'Feedback berjaya dihantar.');

        $feedback = CustomerFeedback::query()->firstOrFail();

        $this->assertSame(CustomerFeedback::STATUS_SUBMITTED, $feedback->status);
        $this->assertSame($branch->business_id, $feedback->business_id);
        $this->assertSame($branch->id, $feedback->branch_id);
        $this->assertSame($this->customerRecord()->id, $feedback->customer_id);
        $this->assertNull($feedback->customer_check_in_id);
        $this->assertNull($feedback->check_in_product_service_id);
        $this->assertNotNull($feedback->submitted_at);
    }

    public function test_invalid_feedback_is_rejected_and_valid_feedback_is_accepted(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($this->customer())
            ->from(route('customer.feedback'))
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'rating' => 6,
                'comment' => 'Rating invalid.',
            ])
            ->assertRedirect(route('customer.feedback'))
            ->assertSessionHasErrors('rating');

        $this->actingAs($this->customer())
            ->from(route('customer.feedback'))
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'rating' => 5,
                'comment' => '',
            ])
            ->assertRedirect(route('customer.feedback'))
            ->assertSessionHasErrors('feedback');

        $this->submitFeedback($branch, 'Service staff bagus dan check-in lancar.', rating: 5)
            ->assertRedirect(route('customer.feedback'));

        $this->assertDatabaseHas('customer_feedback', [
            'branch_id' => $branch->id,
            'rating' => 5,
            'comment' => 'Service staff bagus dan check-in lancar.',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
        ]);
    }

    public function test_feedback_summary_is_stored_as_analytics_ai_signal(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        $this->actingAs($this->customer())
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'product_service_id' => $product->id,
                'rating' => 4,
                'comment' => 'Teh Ais sedap tapi service lambat.',
            ])
            ->assertRedirect(route('customer.feedback'));

        $feedback = CustomerFeedback::query()->firstOrFail();

        $this->assertSame($product->id, $feedback->product_service_id);
        $this->assertStringContainsString('Teh Ais sedap', $feedback->summary_main_meaning);
        $this->assertSame('Customer menyatakan pengalaman positif.', $feedback->summary_positive_point);
        $this->assertSame('Customer menyatakan isu atau ketidakpuasan.', $feedback->summary_negative_point);
        $this->assertSame('Customer menjangka penambahbaikan dibuat.', $feedback->summary_customer_expectation);
        $this->assertSame('service', $feedback->summary_issue_category);
        $this->assertSame('Teh Ais', $feedback->summary_product_service_mentioned);
        $this->assertFalse($feedback->summary_needs_review);
    }

    public function test_unclear_feedback_is_marked_as_needs_review(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->submitFeedback($branch, 'ok')->assertRedirect(route('customer.feedback'));

        $feedback = CustomerFeedback::query()->firstOrFail();

        $this->assertSame('unclear', $feedback->summary_issue_category);
        $this->assertTrue($feedback->summary_needs_review);
    }

    public function test_feedback_does_not_trigger_reward_or_stamp(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->submitFeedback($branch, 'Saya cadang tambah arahan check-in yang lebih jelas.')
            ->assertRedirect(route('customer.feedback'));

        $this->assertDatabaseCount('customer_check_ins', 0);
        $this->assertDatabaseCount('stamp_transactions', 0);
        $this->assertDatabaseCount('customer_loyalty_accounts', 0);
    }

    public function test_capture_purchase_does_not_create_mandatory_pending_feedback(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $checkIn = $this->physicalCheckIn($branch);

        $this->captureProduct($branch, $checkIn)->assertRedirect();

        $this->assertDatabaseMissing('customer_feedback', [
            'customer_check_in_id' => $checkIn->id,
            'status' => CustomerFeedback::STATUS_PENDING,
        ]);
        $this->assertDatabaseCount('customer_feedback', 0);
    }

    public function test_online_check_in_purchase_does_not_create_mandatory_pending_feedback(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->post(route('businesses.branches.online-check-ins.store', ['business' => $branch->business, 'branch' => $branch]), [
                'customer_id' => $branch->business->customers()->firstOrFail()->id,
                'product_service_id' => $product->id,
                'purchase_reference' => 'ORDER-'.uniqid(),
                'quantity' => 1,
                'capture_type' => 'purchase',
            ])
            ->assertRedirect();

        $code = \App\Models\OnlineCheckInReference::query()->firstOrFail()->code;

        $this->actingAs($this->customer())
            ->post(route('customer.online-check-in.store'), ['code' => $code])
            ->assertOk();

        $this->assertDatabaseCount('customer_feedback', 0);
    }

    public function test_branch_manager_can_view_and_update_feedback_status_for_assigned_branch(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->submitFeedback($branch, 'Service lambat tetapi makanan sedap.');
        $feedback = CustomerFeedback::query()->firstOrFail();
        $manager = $this->user('branch+wanchu@fbgrowth.local');

        $this->actingAs($manager)
            ->get(route('businesses.branches.feedback', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('Service lambat');

        $this->actingAs($manager)
            ->patch(route('businesses.branches.feedback.status.update', ['business' => $branch->business, 'branch' => $branch, 'feedback' => $feedback]), [
                'status' => CustomerFeedback::STATUS_ACTION_NEEDED,
            ])
            ->assertRedirect(route('businesses.branches.feedback', ['business' => $branch->business, 'branch' => $branch]));

        $this->assertSame(CustomerFeedback::STATUS_ACTION_NEEDED, $feedback->refresh()->status);
    }

    public function test_branch_manager_cannot_view_or_update_feedback_from_other_branch(): void
    {
        $otherBranch = $this->branch('CHENA-MAIN');
        $otherCustomer = Customer::factory()->create(['business_id' => $otherBranch->business_id]);
        $feedback = CustomerFeedback::query()->create([
            'business_id' => $otherBranch->business_id,
            'branch_id' => $otherBranch->id,
            'customer_id' => $otherCustomer->id,
            'comment' => 'Other branch feedback.',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'submitted_at' => now(),
        ]);
        $manager = $this->user('branch+wanchu@fbgrowth.local');

        $this->actingAs($manager)
            ->get(route('businesses.branches.feedback', ['business' => $otherBranch->business, 'branch' => $otherBranch]))
            ->assertForbidden();

        $this->actingAs($manager)
            ->patch(route('businesses.branches.feedback.status.update', ['business' => $otherBranch->business, 'branch' => $otherBranch, 'feedback' => $feedback]), [
                'status' => CustomerFeedback::STATUS_REVIEWED,
            ])
            ->assertForbidden();
    }

    public function test_business_owner_can_view_feedback_for_owned_business(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->submitFeedback($branch, 'Owner boleh lihat feedback ini.');

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('businesses.feedback', $branch->business))
            ->assertOk()
            ->assertSee('Owner boleh lihat feedback ini.')
            ->assertSee('WanChu Corner Main Branch');
    }

    public function test_customer_can_view_own_submitted_feedback_only(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->submitFeedback($branch, 'Feedback milik saya.');
        $otherCustomer = Customer::factory()->create(['business_id' => $branch->business_id]);

        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $otherCustomer->id,
            'comment' => 'Feedback orang lain.',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'submitted_at' => now(),
        ]);

        $this->actingAs($this->customer())
            ->get(route('customer.feedback'))
            ->assertOk()
            ->assertSee('Feedback milik saya.')
            ->assertDontSee('Feedback orang lain.')
            ->assertDontSee('Pending Feedback');
    }

    public function test_customer_cannot_access_internal_admin_feedback_surfaces(): void
    {
        $customer = $this->customer();
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($customer)
            ->get(route('businesses.feedback', $branch->business))
            ->assertForbidden();

        $this->actingAs($customer)
            ->get(route('businesses.branches.feedback', ['business' => $branch->business, 'branch' => $branch]))
            ->assertForbidden();
    }

    public function test_feedback_status_supports_launch_statuses(): void
    {
        $this->assertSame([
            'pending',
            'submitted',
            'reviewed',
            'action_needed',
            'resolved',
        ], CustomerFeedback::statuses());
    }

    private function submitFeedback(Branch $branch, string $comment, int $rating = 4)
    {
        return $this->actingAs($this->customer())
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'rating' => $rating,
                'comment' => $comment,
            ]);
    }

    private function physicalCheckIn(Branch $branch): CustomerCheckIn
    {
        $this->actingAs($this->customer())
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
            ])
            ->assertOk();

        return CustomerCheckIn::query()->where('branch_id', $branch->id)->latest()->firstOrFail();
    }

    private function captureProduct(Branch $branch, CustomerCheckIn $checkIn)
    {
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        return $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
                'capture_reference' => 'feedback-capture-'.uniqid(),
            ]);
    }

    private function customerRecord(): Customer
    {
        return Customer::query()->where('user_id', $this->customer()->id)->firstOrFail();
    }

    private function customer(): User
    {
        return $this->user('customer@fbgrowth.local');
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business.customers')->where('code', $code)->firstOrFail();
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
