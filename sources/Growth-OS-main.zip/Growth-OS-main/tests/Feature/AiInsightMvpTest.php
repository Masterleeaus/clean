<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\StampTransaction;
use App\Models\User;
use App\Services\AiInsightService;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AiInsightMvpTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_business_owner_sees_ai_insight_for_owned_business_only(): void
    {
        $ownedBranch = $this->branch('WANCHU-MAIN');
        $otherBranch = $this->branch('CHENA-MAIN');

        $this->createInsightActivity($ownedBranch, productName: 'Owner Insight Set', quantity: 3, price: 12.00);
        $this->createInsightActivity($otherBranch, productName: 'Hidden Other Business Set', quantity: 5, price: 25.00);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Insight Engine')
            ->assertSee('Sales trend insight')
            ->assertSee('Product/Service performance insight')
            ->assertSee('Owner Insight Set')
            ->assertDontSee($otherBranch->name)
            ->assertDontSee('Hidden Other Business Set');
    }

    public function test_branch_manager_sees_ai_insight_for_assigned_branch_only(): void
    {
        $assignedBranch = $this->branch('WANCHU-MAIN');
        $otherBranch = Branch::query()->create([
            'business_id' => $assignedBranch->business_id,
            'name' => 'WanChu Insight Hidden',
            'code' => 'WANCHU-INSIGHT-HIDDEN',
            'is_active' => true,
        ]);

        $this->createInsightActivity($assignedBranch, productName: 'Assigned Branch Insight Set', quantity: 2, price: 8.00);
        $this->createInsightActivity($otherBranch, productName: 'Hidden Branch Insight Set', quantity: 2, price: 8.00);

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Insight Engine')
            ->assertSee('Branch performance insight')
            ->assertSee($assignedBranch->name)
            ->assertSee('Assigned Branch Insight Set')
            ->assertDontSee($otherBranch->name)
            ->assertDontSee('Hidden Branch Insight Set');
    }

    public function test_customer_cannot_access_ai_insight_results(): void
    {
        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertForbidden();
    }

    public function test_system_admin_can_access_admin_support_ai_insight_without_commercial_strategy(): void
    {
        $this->actingAs($this->user('admin@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('System Admin Analytics')
            ->assertSee('AI Insight Engine')
            ->assertSee('System setup/access insight')
            ->assertSee('Setup completeness insight')
            ->assertSee('Platform usage support insight')
            ->assertSee('Branch without assigned manager')
            ->assertDontSee('GOS revenue/subscription data gap insight')
            ->assertDontSee('which vertical is most profitable')
            ->assertDontSee('GOS revenue strategy')
            ->assertDontSee('subscriber revenue optimization');
    }

    public function test_system_manager_can_access_high_level_ai_insight(): void
    {
        $this->createInsightActivity($this->branch('WANCHU-MAIN'), productName: 'Platform Insight Set', quantity: 2, price: 9.00);

        $this->actingAs($this->user('manager@gos-fnb.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('System Manager Analytics')
            ->assertSee('AI Insight Engine')
            ->assertSee('GOS platform performance insight')
            ->assertSee('Business category/vertical performance insight')
            ->assertSee('GOS revenue/subscription data gap insight')
            ->assertSee('Subscription revenue')
            ->assertSee('Sales trend insight')
            ->assertSee('Branch performance insight');
    }

    public function test_ai_insight_uses_analytics_data_sources_and_generates_required_insight_types(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $customer = $this->createInsightActivity(
            $branch,
            productName: 'Signature Laksa',
            quantity: 4,
            price: 11.50,
            feedbackStatus: CustomerFeedback::STATUS_ACTION_NEEDED,
            summaryCategory: 'service',
            rating: 2,
        );
        $this->createCheckIn($branch, $customer);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Sales trend insight')
            ->assertSee('Product/Service performance insight')
            ->assertSee('Branch performance insight')
            ->assertSee('Repeat customer pattern insight')
            ->assertSee('Feedback pattern insight')
            ->assertSee('Reward effectiveness insight')
            ->assertSee('Total sales/value')
            ->assertSee('Total transaction/capture')
            ->assertSee('Signature Laksa')
            ->assertSee('Action needed feedback');
    }

    public function test_ai_insight_includes_evidence_confidence_reason_and_data_gap(): void
    {
        $this->createInsightActivity($this->branch('WANCHU-MAIN'), productName: 'Evidence Coffee', quantity: 1, price: 6.50);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Supporting data/evidence')
            ->assertSee('Confidence reason')
            ->assertSee('Data gap')
            ->assertSee('medium')
            ->assertSee('low');
    }

    public function test_low_data_state_identifies_gap_and_does_not_fabricate_strong_conclusion(): void
    {
        $owner = User::factory()->create([
            'role' => User::ROLE_BUSINESS_OWNER,
            'access_scope' => null,
        ]);

        $this->actingAs($owner)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee(AiInsightService::INSUFFICIENT_DATA)
            ->assertSee('Data gap insight')
            ->assertSee('Confidence reason')
            ->assertSee('low')
            ->assertDontSee('high');
    }

    public function test_ai_insight_output_is_structured_for_later_ai_action_and_has_no_detailed_action_plan(): void
    {
        $insights = app(AiInsightService::class)->fromAnalytics([
            'summary' => [
                'Total sales/value' => 'RM 25.00',
                'Total transaction/capture' => 2,
                'Average transaction value' => 'RM 12.50',
                'Total check-ins' => 2,
            ],
            'salesAnalytics' => [],
            'customerAnalytics' => ['total' => 2, 'repeat' => 0, 'active' => 2],
            'productAnalytics' => [
                'popular' => ['name' => 'Structured Tea', 'quantity' => 2, 'total' => 25.00, 'captures' => 2],
                'highestSales' => ['name' => 'Structured Tea', 'quantity' => 2, 'total' => 25.00, 'captures' => 2],
                'lowActivity' => collect(),
            ],
            'branchAnalytics' => [
                ['name' => 'WanChu Corner - Main', 'sales' => 25.00, 'check_ins' => 2],
            ],
            'rewardAnalytics' => ['Reward/stamp issued' => 2, 'Reward redeemed' => 0, 'Reward pending' => 0],
            'feedbackAnalytics' => ['Total feedback' => 0],
            'dataCompleteness' => [],
        ]);

        $this->assertNotEmpty($insights);

        foreach ($insights as $insight) {
            $this->assertArrayHasKey('title', $insight);
            $this->assertArrayHasKey('explanation', $insight);
            $this->assertArrayHasKey('evidence', $insight);
            $this->assertArrayHasKey('confidence', $insight);
            $this->assertArrayHasKey('confidence_reason', $insight);
            $this->assertArrayHasKey('data_gap', $insight);
            $this->assertArrayHasKey('action_ready_context', $insight);
            $this->assertNotContains('Recommended Action', $insight['evidence']);
            $this->assertStringNotContainsString('Success Metric', $insight['explanation']);
        }
    }

    public function test_combined_business_owner_branch_manager_ai_insight_works(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createInsightActivity($branch, productName: 'Combined Insight Set', quantity: 2, price: 10.00);

        $this->actingAs($this->user('owner-branch+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Business Owner / Branch Manager Analytics')
            ->assertSee('Combined Role Analytics')
            ->assertSee('AI Insight Engine')
            ->assertSee('Combined Insight Set');
    }

    private function createInsightActivity(
        Branch $branch,
        string $productName,
        int $quantity,
        float $price,
        string $feedbackStatus = CustomerFeedback::STATUS_SUBMITTED,
        string $summaryCategory = 'positive_feedback',
        int $rating = 5,
    ): Customer {
        $customer = Customer::query()->create([
            'business_id' => $branch->business_id,
            'name' => 'Insight Customer '.uniqid(),
            'whatsapp_number' => '601'.random_int(100000000, 999999999),
        ]);
        $checkIn = $this->createCheckIn($branch, $customer);
        $product = ProductService::query()->updateOrCreate(
            ['business_id' => $branch->business_id, 'name' => $productName],
            ['branch_id' => $branch->id, 'category' => 'food', 'type' => 'product', 'price' => $price, 'is_active' => true],
        );
        $capture = CheckInProductService::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'captured_by_user_id' => $this->user('owner+wanchu@fbgrowth.local')->id,
            'quantity' => $quantity,
            'price_at_capture' => $price,
            'total_amount' => $quantity * $price,
            'capture_type' => 'purchase',
            'capture_source' => 'ai_insight_test',
            'capture_reference' => 'insight-'.uniqid(),
        ]);

        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'check_in_product_service_id' => $capture->id,
            'rating' => $rating,
            'comment' => 'AI Insight feedback for '.$productName,
            'source' => 'ai_insight_test',
            'status' => $feedbackStatus,
            'summary_issue_category' => $summaryCategory,
            'submitted_at' => now(),
        ]);

        return $customer;
    }

    private function createCheckIn(Branch $branch, Customer $customer): CustomerCheckIn
    {
        $program = $branch->business->loyaltyPrograms()->active()->firstOrFail();

        $checkIn = CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'stamps_earned' => 1,
            'source' => 'ai_insight_test',
            'check_in_type' => 'physical',
            'reward_status' => 'granted',
            'reward_granted_at' => now(),
        ]);

        StampTransaction::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'type' => StampTransaction::TYPE_EARNED,
            'stamps' => 1,
        ]);

        return $checkIn;
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business.loyaltyPrograms')->where('code', $code)->firstOrFail();
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
