<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CheckInProductService;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\CustomerLoyaltyAccount;
use App\Models\ProductService;
use App\Models\StampTransaction;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PurchaseCaptureAlignmentTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_valid_check_in_creates_pending_purchase_capture_for_branch_processing_not_customer(): void
    {
        $branch = $this->branch();

        $this->customerCheckIn($branch)
            ->assertOk()
            ->assertSee('Check-in berjaya direkodkan.')
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Reward will be confirmed after purchase is verified');

        $checkIn = CustomerCheckIn::query()->firstOrFail();
        $account = CustomerLoyaltyAccount::query()->firstOrFail();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $checkIn->reward_status);
        $this->assertSame(CustomerCheckIn::PURCHASE_STATUS_PENDING, $checkIn->purchaseCaptureStatus());
        $this->assertSame(0, $checkIn->stamps_earned);
        $this->assertSame(0, $account->current_stamps);

        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Reward will be confirmed after purchase is verified')
            ->assertDontSee('Confirmed Reward');
    }

    public function test_pending_purchase_capture_visible_to_branch_manager(): void
    {
        $branch = $this->branch();
        $this->customerCheckIn($branch);

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('Pending Purchase Capture')
            ->assertSee('Capture Purchase')
            ->assertSee('Mark No Purchase');
    }

    public function test_cooldown_blocked_check_in_does_not_create_pending_purchase_or_reward(): void
    {
        $branch = $this->branch();

        $this->customerCheckIn($branch)->assertOk();
        $this->travel(30)->minutes();
        $this->customerCheckIn($branch)
            ->assertOk()
            ->assertSee('Cooldown belum selesai');

        $this->assertSame(1, CustomerCheckIn::query()->count());
        $this->assertSame(1, CustomerCheckIn::query()->where('reward_status', CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT)->count());
        $this->assertDatabaseCount('stamp_transactions', 0);
    }

    public function test_branch_manager_capture_purchase_converts_pending_to_confirmed_reward_without_mandatory_feedback(): void
    {
        $branch = $this->branch();
        $checkIn = $this->createPendingCheckIn($branch);

        $this->captureProduct($branch, $checkIn, reference: 'pilot-capture-1')
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]));

        $checkIn->refresh();
        $account = CustomerLoyaltyAccount::query()->firstOrFail();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_GRANTED, $checkIn->reward_status);
        $this->assertSame(CustomerCheckIn::PURCHASE_STATUS_CONFIRMED, $checkIn->purchaseCaptureStatus());
        $this->assertSame(1, $checkIn->stamps_earned);
        $this->assertSame(1, $account->current_stamps);
        $this->assertDatabaseMissing('customer_feedback', [
            'customer_check_in_id' => $checkIn->id,
            'status' => CustomerFeedback::STATUS_PENDING,
        ]);
    }

    public function test_branch_manager_mark_no_purchase_creates_no_reward_no_purchase_without_feedback(): void
    {
        $branch = $this->branch();
        $checkIn = $this->createPendingCheckIn($branch);

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'no_purchase_reason' => 'Customer did not buy after check-in.',
            ])
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]));

        $checkIn->refresh();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_NO_PURCHASE, $checkIn->reward_status);
        $this->assertSame(CustomerCheckIn::PURCHASE_STATUS_NO_PURCHASE, $checkIn->purchaseCaptureStatus());
        $this->assertSame(0, $checkIn->stamps_earned);
        $this->assertDatabaseCount('stamp_transactions', 0);
        $this->assertDatabaseCount('customer_feedback', 0);
    }

    public function test_delayed_pending_purchase_capture_does_not_auto_cancel_as_no_reward(): void
    {
        $branch = $this->branch();
        $checkIn = $this->createPendingCheckIn($branch);

        $checkIn->forceFill(['check_in_at' => now()->subHours(CustomerCheckIn::MANUAL_REVIEW_HOURS + 1)])->save();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $checkIn->refresh()->reward_status);
        $this->assertSame(CustomerCheckIn::PURCHASE_STATUS_MANUAL_REVIEW, $checkIn->purchaseCaptureStatus());

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('dashboards.branch-manager'))
            ->assertOk()
            ->assertSee('Manual Review Required')
            ->assertDontSee('No Reward - No Purchase');
    }

    public function test_overdue_pending_purchase_capture_is_displayed_without_auto_cancel(): void
    {
        $branch = $this->branch();
        $checkIn = $this->createPendingCheckIn($branch);

        $checkIn->forceFill(['check_in_at' => now()->subHours(CustomerCheckIn::OVERDUE_PURCHASE_CAPTURE_HOURS + 1)])->save();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $checkIn->refresh()->reward_status);
        $this->assertSame(CustomerCheckIn::PURCHASE_STATUS_OVERDUE, $checkIn->purchaseCaptureStatus());

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('Overdue Purchase Capture');
    }

    public function test_same_product_can_be_captured_again_if_separate_valid_purchase_and_quantity_more_than_one_is_valid(): void
    {
        $branch = $this->branch();
        $checkIn = $this->createPendingCheckIn($branch);

        $this->captureProduct($branch, $checkIn, quantity: 2, reference: 'separate-purchase-1')->assertRedirect();
        $this->captureProduct($branch, $checkIn, quantity: 3, reference: 'separate-purchase-2')->assertRedirect();

        $this->assertSame(2, CheckInProductService::query()->count());
        $this->assertSame(5, CheckInProductService::query()->sum('quantity'));
        $this->assertSame(1, StampTransaction::query()->count());
    }

    public function test_false_duplicate_purchase_capture_reference_is_blocked(): void
    {
        $branch = $this->branch();
        $checkIn = $this->createPendingCheckIn($branch);

        $this->captureProduct($branch, $checkIn, reference: 'retry-reference-1')->assertRedirect();
        $this->captureProduct($branch, $checkIn, reference: 'retry-reference-1')->assertRedirect();

        $this->assertSame(1, CheckInProductService::query()->where('capture_reference', 'retry-reference-1')->count());
        $this->assertSame(1, StampTransaction::query()->count());
    }

    private function createPendingCheckIn(Branch $branch): CustomerCheckIn
    {
        $this->customerCheckIn($branch)->assertOk();

        return CustomerCheckIn::query()
            ->where('branch_id', $branch->id)
            ->latest()
            ->firstOrFail();
    }

    private function customerCheckIn(Branch $branch)
    {
        return $this->actingAs($this->user('customer@fbgrowth.local'))
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
            ]);
    }

    private function captureProduct(Branch $branch, CustomerCheckIn $checkIn, int $quantity = 1, string $reference = 'pilot-capture')
    {
        return $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $this->product($branch)->id,
                'quantity' => $quantity,
                'capture_type' => 'purchase',
                'capture_reference' => $reference,
            ]);
    }

    private function product(Branch $branch): ProductService
    {
        return ProductService::query()
            ->where('business_id', $branch->business_id)
            ->where(function ($query) use ($branch): void {
                $query->whereNull('branch_id')->orWhere('branch_id', $branch->id);
            })
            ->active()
            ->firstOrFail();
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function branch(): Branch
    {
        return Branch::query()->with('business')->where('code', 'WANCHU-MAIN')->firstOrFail();
    }
}
