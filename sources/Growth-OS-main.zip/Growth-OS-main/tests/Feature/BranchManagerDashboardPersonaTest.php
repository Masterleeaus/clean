<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\RewardRedemption;
use App\Models\User;
use App\Services\RoleAccessPilotGuard;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BranchManagerDashboardPersonaTest extends TestCase
{
    use RefreshDatabase;

    private User $branchManager;

    private Business $business;

    private Branch $branch;

    private Branch $otherBranch;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);

        $this->branchManager = User::query()->where('email', 'branch+wanchu@fbgrowth.local')->firstOrFail();
        $this->business = Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
        $this->branch = Branch::query()->where('code', 'WANCHU-MAIN')->firstOrFail();
        $this->otherBranch = Branch::query()->where('code', 'CHENA-MAIN')->firstOrFail();
    }

    public function test_branch_manager_dashboard_is_assigned_branch_operation_scoped(): void
    {
        $this->createBranchActivity($this->branch, 'Assigned branch persona feedback.');
        $hiddenBranch = Branch::factory()->create([
            'business_id' => $this->business->id,
            'name' => 'WanChu Hidden Branch Persona',
            'code' => 'WANCHU-HIDDEN-PERSONA',
            'is_active' => true,
        ]);
        $this->createBranchActivity($hiddenBranch, 'Hidden same business branch feedback.');
        $this->createBranchActivity($this->otherBranch, 'Hidden other business branch feedback.');

        $this->actingAs($this->branchManager)
            ->get(route('dashboards.branch-manager'))
            ->assertOk()
            ->assertSee('Branch Manager Dashboard')
            ->assertSee('assigned sahaja')
            ->assertSee($this->branch->name)
            ->assertSee('Pending Purchase Capture')
            ->assertSee('Overdue Purchase Capture')
            ->assertSee('Manual Review Required')
            ->assertSee('Branch Analytics / AI Insight / AI Action')
            ->assertSee('AI Action suggestion-only')
            ->assertSee('Open Branch Analytics / AI')
            ->assertSee('Branch Check-ins')
            ->assertSee('Branch Feedback')
            ->assertSee('Branch Rewards')
            ->assertSee('Assigned branch persona feedback.')
            ->assertDontSee($hiddenBranch->name)
            ->assertDontSee('Hidden same business branch feedback.')
            ->assertDontSee($this->otherBranch->name)
            ->assertDontSee('Hidden other business branch feedback.')
            ->assertDontSee('Business Owner cum Branch Manager')
            ->assertDontSee('Business Performance')
            ->assertDontSee('Business Profile / QR')
            ->assertDontSee('Senarai Customer')
            ->assertDontSee('Follow-up')
            ->assertDontSee('System Manager Dashboard')
            ->assertDontSee('System Admin Dashboard')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Customer Portal')
            ->assertDontSee('API key')
            ->assertDontSee('secret');
    }

    public function test_branch_manager_pending_capture_actions_are_assigned_branch_only(): void
    {
        $captureCheckIn = $this->pendingCheckIn($this->branch, 'BM Capture Customer');
        $noPurchaseCheckIn = $this->pendingCheckIn($this->branch, 'BM No Purchase Customer');
        $otherCheckIn = $this->pendingCheckIn($this->otherBranch, 'Other Branch Pending Customer');
        $product = ProductService::query()->visibleForBranch($this->branch)->active()->firstOrFail();
        $otherProduct = ProductService::query()->visibleForBranch($this->otherBranch)->active()->firstOrFail();

        $this->actingAs($this->branchManager)
            ->get(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]))
            ->assertOk()
            ->assertSee('Branch Check-ins')
            ->assertSee('Pending Purchase Capture')
            ->assertSee('Capture Purchase')
            ->assertSee('Mark No Purchase')
            ->assertSee('BM Capture Customer')
            ->assertDontSee('Other Branch Pending Customer');

        $this->actingAs($this->branchManager)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $this->business,
                'branch' => $this->branch,
                'checkIn' => $captureCheckIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
                'capture_reference' => 'branch-manager-persona-capture',
            ])
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]));

        $this->actingAs($this->branchManager)
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $this->business,
                'branch' => $this->branch,
                'checkIn' => $noPurchaseCheckIn,
            ]), [
                'no_purchase_reason' => 'Persona review no purchase.',
            ])
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]));

        $this->actingAs($this->branchManager)
            ->get(route('businesses.branches.check-ins', ['business' => $this->otherBranch->business, 'branch' => $this->otherBranch]))
            ->assertForbidden();

        $this->actingAs($this->branchManager)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $this->otherBranch->business,
                'branch' => $this->otherBranch,
                'checkIn' => $otherCheckIn,
            ]), [
                'product_service_id' => $otherProduct->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
                'capture_reference' => 'branch-manager-other-capture',
            ])
            ->assertForbidden();

        $this->actingAs($this->branchManager)
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $this->otherBranch->business,
                'branch' => $this->otherBranch,
                'checkIn' => $otherCheckIn,
            ]), [
                'no_purchase_reason' => 'Blocked other branch.',
            ])
            ->assertForbidden();
    }

    public function test_branch_manager_analytics_and_ai_are_branch_level_and_suggestion_only(): void
    {
        $this->createCapturedActivity($this->branch, 'Branch Manager AI feedback.', 'BM Persona Set', 2, 8.50);
        $hiddenBranch = Branch::factory()->create([
            'business_id' => $this->business->id,
            'name' => 'WanChu Hidden AI Branch',
            'code' => 'WANCHU-HIDDEN-AI',
            'is_active' => true,
        ]);
        $this->createCapturedActivity($hiddenBranch, 'Hidden AI feedback.', 'Hidden Persona Set', 1, 99.00);

        $this->actingAs($this->branchManager)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Branch Manager Analytics')
            ->assertSee('Assigned branch analytics')
            ->assertSee('AI Insight Engine')
            ->assertSee('AI Action Engine')
            ->assertSee('Suggested action sahaja')
            ->assertSee('Human review diperlukan')
            ->assertSee($this->branch->name)
            ->assertSee('BM Persona Set')
            ->assertDontSee($hiddenBranch->name)
            ->assertDontSee('Hidden Persona Set')
            ->assertDontSee('Business Owner Analytics')
            ->assertDontSee('System Manager Analytics')
            ->assertDontSee('System Admin Analytics')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Auto Execute')
            ->assertDontSee('Send Campaign');
    }

    public function test_branch_manager_is_blocked_from_other_personas_customer_portal_and_access_setup(): void
    {
        $guard = app(RoleAccessPilotGuard::class);
        $target = User::factory()->create(['role' => User::ROLE_BRANCH_MANAGER]);

        $this->actingAs($this->branchManager)->get(route('dashboards.business-owner'))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('dashboards.system-manager'))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('dashboards.system-admin'))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('customer.portal'))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('businesses.dashboard', $this->business))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('businesses.create'))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('businesses.edit', $this->business))->assertForbidden();

        $setup = $guard->validateControlledPilotSetup(
            actor: $this->branchManager,
            target: $target,
            business: $this->business,
            branchIds: [$this->branch->id],
            primaryRole: User::ROLE_BRANCH_MANAGER,
        );

        $this->assertFalse($setup['allowed']);
        $this->assertContains('Controlled Pilot user setup must be completed by System Admin.', $setup['errors']);
    }

    private function createBranchActivity(Branch $branch, string $feedbackComment): void
    {
        $customer = $this->customerFor($branch, 'BM Persona Customer '.uniqid());
        $checkIn = $this->pendingCheckIn($branch, $customer->name, $customer);
        $product = ProductService::query()->visibleForBranch($branch)->active()->firstOrFail();

        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'rating' => 4,
            'comment' => $feedbackComment,
            'source' => 'branch_manager_persona_review',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'summary_issue_category' => 'positive_feedback',
            'submitted_at' => now(),
        ]);
    }

    private function createCapturedActivity(Branch $branch, string $feedbackComment, string $productName, int $quantity, float $price): void
    {
        $customer = $this->customerFor($branch, 'BM Analytics Customer '.uniqid());
        $checkIn = $this->pendingCheckIn($branch, $customer->name, $customer);
        $product = ProductService::query()->updateOrCreate(
            ['business_id' => $branch->business_id, 'name' => $productName],
            ['branch_id' => $branch->id, 'category' => 'food', 'type' => 'product', 'price' => $price, 'is_active' => true],
        );
        $capture = CheckInProductService::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'captured_by_user_id' => $this->branchManager->id,
            'quantity' => $quantity,
            'price_at_capture' => $price,
            'total_amount' => number_format($quantity * $price, 2, '.', ''),
            'capture_type' => 'purchase',
            'capture_source' => 'branch_manager_persona_review',
            'capture_reference' => 'bm-persona-'.uniqid(),
        ]);

        $checkIn->forceFill([
            'reward_status' => CustomerCheckIn::REWARD_STATUS_GRANTED,
            'stamps_earned' => 1,
            'reward_granted_at' => now(),
        ])->save();

        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'check_in_product_service_id' => $capture->id,
            'product_service_id' => $product->id,
            'rating' => 4,
            'comment' => $feedbackComment,
            'source' => 'branch_manager_persona_review',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'summary_issue_category' => 'general_issue',
            'submitted_at' => now(),
        ]);
    }

    private function pendingCheckIn(Branch $branch, string $customerName, ?Customer $customer = null): CustomerCheckIn
    {
        $customer ??= $this->customerFor($branch, $customerName);

        return CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $branch->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'branch_manager_persona_review',
            'check_in_type' => 'physical',
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);
    }

    private function customerFor(Branch $branch, string $name): Customer
    {
        return Customer::query()->create([
            'business_id' => $branch->business_id,
            'name' => $name,
            'whatsapp_number' => '601'.random_int(100000000, 999999999),
        ]);
    }
}
