<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\StampTransaction;
use App\Models\User;
use App\Services\AiActionService;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Routing\Middleware\ThrottleRequests;
use Tests\TestCase;

class IntelligenceFlowTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->withoutMiddleware(ThrottleRequests::class);
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_lp_int_an_01_to_15_analytics_updates_from_core_operation_flow(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $product = $this->product($branch);

        $this->actingAs($this->owner())
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Business Owner Analytics')
            ->assertSee('Core Operation Analytics');

        $this->customerCheckIn($branch)->assertOk()->assertSee('Check-in berjaya direkodkan.');
        $pending = CustomerCheckIn::query()->where('branch_id', $branch->id)->latest('check_in_at')->firstOrFail();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $pending->reward_status);
        $this->assertSame(0, StampTransaction::query()->count());

        $this->actingAs($this->owner())
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Pending purchase capture')
            ->assertSee('Check-ins without Product/Service capture')
            ->assertSee('Inconsistent Product/Service capture');

        $this->captureProduct($branch, $pending, $product, quantity: 2, reference: 'int-an-capture-1')->assertRedirect();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_GRANTED, $pending->refresh()->reward_status);
        $this->assertSame(1, StampTransaction::query()->count());
        $this->assertSame(2, CheckInProductService::query()->where('capture_reference', 'int-an-capture-1')->firstOrFail()->quantity);

        $this->captureProduct($branch, $pending, $product, quantity: 2, reference: 'int-an-capture-1')->assertRedirect();

        $this->assertSame(1, CheckInProductService::query()->where('capture_reference', 'int-an-capture-1')->count());
        $this->assertSame(1, StampTransaction::query()->count());

        $this->actingAs($this->owner())
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Total sales/value')
            ->assertSee('Total transaction/capture')
            ->assertSee('Reward/stamp issued')
            ->assertSee('Sales by Product/Service')
            ->assertSee($product->name)
            ->assertSee('Qty: 2')
            ->assertSee('RM '.number_format((float) $product->price * 2, 2));

        $this->travel(61)->minutes();
        $this->customerCheckIn($branch)->assertOk();
        $noPurchase = CustomerCheckIn::query()->where('branch_id', $branch->id)->latest('check_in_at')->firstOrFail();
        $this->markNoPurchase($branch, $noPurchase)->assertRedirect();

        $this->actingAs($this->customer())
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'product_service_id' => $product->id,
                'rating' => 4,
                'comment' => 'Hantar Maklumbalas bebas untuk analytics signal.',
            ])
            ->assertRedirect(route('customer.feedback'));

        $this->actingAs($this->owner())
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('No purchase / check-in without purchase')
            ->assertSee('Feedback Analytics')
            ->assertSee('Submitted feedback')
            ->assertSee('Product/Service Analytics');

        $this->actingAs($this->branchManager())
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Branch Manager Analytics')
            ->assertSee($branch->name)
            ->assertDontSee($this->branch('CHENA-MAIN')->name);

        $this->actingAs($this->user('manager@gos-fnb.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('System Manager Analytics')
            ->assertSee('GOS platform/business analytics');

        $this->actingAs($this->user('admin@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('System Admin Analytics')
            ->assertSee('System &amp; Access Support Analytics', false);

        $this->actingAs($this->customer())->get(route('analytics.index'))->assertForbidden();
    }

    public function test_lp_int_aiins_01_to_15_rule_based_ai_insight_reads_analytics_signals(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $highProduct = $this->product($branch);
        $lowProduct = ProductService::factory()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'name' => 'Low Insight Pilot Item',
            'category' => 'food',
            'price' => 9.00,
        ]);

        $customer = $this->createCustomer($branch, 'Insight Purchase Customer', '60133330001');
        $granted = $this->directCheckIn($branch, $customer, CustomerCheckIn::REWARD_STATUS_GRANTED, stamps: 1);
        $this->directCapture($branch, $granted, $customer, $highProduct, quantity: 5, reference: 'insight-high-product');
        $this->directStamp($branch, $customer);
        $this->directFeedback($branch, $customer, $highProduct, rating: 2, category: 'service');

        $this->directCheckIn($branch, $this->createCustomer($branch, 'Insight Pending Customer', '60133330002'), CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT);
        $this->directCheckIn($branch, $this->createCustomer($branch, 'Insight Manual Customer', '60133330003'), CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, now()->subHours(CustomerCheckIn::MANUAL_REVIEW_HOURS + 1));
        $this->directCheckIn($branch, $this->createCustomer($branch, 'Insight No Purchase Customer', '60133330004'), CustomerCheckIn::REWARD_STATUS_NO_PURCHASE);

        $this->actingAs($this->owner())
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Rule-based MVP, data-based')
            ->assertSee('AI Insight Engine')
            ->assertSee('Sales trend insight')
            ->assertSee('Purchase conversion / capture backlog insight')
            ->assertSee('Operational follow-up risk insight')
            ->assertSee('No Purchase pattern insight')
            ->assertSee('Reward effectiveness insight')
            ->assertSee('Feedback pattern insight')
            ->assertSee('Product/Service performance insight')
            ->assertSee($highProduct->name)
            ->assertSee($lowProduct->name)
            ->assertSee('Supporting data/evidence')
            ->assertSee('Confidence reason')
            ->assertSee('Data gap');

        $this->actingAs($this->branchManager())
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Insight Engine')
            ->assertSee($branch->name)
            ->assertDontSee($this->branch('CHENA-MAIN')->name);

        $this->actingAs($this->user('manager@gos-fnb.local'))->get(route('analytics.index'))->assertOk()->assertSee('GOS platform performance insight');
        $this->actingAs($this->user('admin@fbgrowth.local'))->get(route('analytics.index'))->assertOk()->assertSee('System setup/access insight');
        $this->actingAs($this->customer())->get(route('analytics.index'))->assertForbidden();

        $this->assertNoExternalAiDependency();
    }

    public function test_lp_int_aiact_01_to_15_rule_based_ai_action_suggests_without_auto_execute(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $product = $this->product($branch);
        $customer = $this->createCustomer($branch, 'Action Customer', '60144440001');
        $checkIn = $this->directCheckIn($branch, $customer, CustomerCheckIn::REWARD_STATUS_GRANTED, stamps: 1);
        $this->directCapture($branch, $checkIn, $customer, $product, quantity: 6, reference: 'action-high-product');
        $this->directStamp($branch, $customer);
        $this->directFeedback($branch, $customer, $product, rating: 2, category: 'service');

        $before = [
            CustomerCheckIn::query()->count(),
            CheckInProductService::query()->count(),
            CustomerFeedback::query()->count(),
            StampTransaction::query()->count(),
        ];

        $this->actingAs($this->owner())
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Action Engine')
            ->assertSee('Human review diperlukan')
            ->assertSee('Recommended Action')
            ->assertSee('Reason / Why It Matters')
            ->assertSee('Linked Insight')
            ->assertSee('Evidence')
            ->assertSee('Target')
            ->assertSee('Owner / Person In Charge')
            ->assertSee('Priority')
            ->assertSee('Confidence')
            ->assertSee('Success Metric')
            ->assertSee('Suggested Period')
            ->assertSee('Suggested')
            ->assertDontSee('Auto Execute')
            ->assertDontSee('Send Campaign')
            ->assertDontSee('Send Message');

        $this->assertSame($before, [
            CustomerCheckIn::query()->count(),
            CheckInProductService::query()->count(),
            CustomerFeedback::query()->count(),
            StampTransaction::query()->count(),
        ]);

        $actions = app(AiActionService::class);
        $this->assertSame('Review pending purchase capture backlog', $actions->fromAnalytics($this->actionPayload(['Pending purchase capture' => 5, 'Check-ins without Product/Service capture' => 5]))[0]['title']);
        $this->assertSame('Follow up overdue purchase review', $actions->fromAnalytics($this->actionPayload(['Overdue purchase capture' => 3, 'Manual review required' => 1]))[0]['title']);
        $this->assertSame('Improve check-in to purchase conversion signal', $actions->fromAnalytics($this->actionPayload(['No purchase / check-in without purchase' => 4]))[0]['title']);
        $this->assertSame('Follow up recurring negative feedback', $actions->fromAnalytics($this->actionPayload([], feedbackIssues: 2))[0]['title']);
        $this->assertSame('Increase sales for high-potential Product/Service', $actions->fromAnalytics($this->actionPayload([], popularProduct: true))[0]['title']);
        $this->assertSame('Improve weak Product/Service data', $actions->fromAnalytics($this->actionPayload([], lowProduct: true))[0]['title']);

        $this->actingAs($this->branchManager())->get(route('analytics.index'))->assertOk()->assertSee('AI Action Engine')->assertSee($branch->name);
        $this->actingAs($this->user('manager@gos-fnb.local'))->get(route('analytics.index'))->assertOk()->assertSee('GOS platform/business performance monitoring');
        $this->actingAs($this->user('admin@fbgrowth.local'))->get(route('analytics.index'))->assertOk()->assertSee('System Admin')->assertDontSee('vertical expansion');
        $this->actingAs($this->customer())->get(route('analytics.index'))->assertForbidden();

        $this->assertNoExternalAiDependency();
    }

    private function customerCheckIn(Branch $branch)
    {
        return $this->actingAs($this->customer())
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
            ]);
    }

    private function captureProduct(Branch $branch, CustomerCheckIn $checkIn, ProductService $product, int $quantity, string $reference)
    {
        return $this->actingAs($this->branchManager())
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => $quantity,
                'capture_type' => 'purchase',
                'capture_reference' => $reference,
            ]);
    }

    private function markNoPurchase(Branch $branch, CustomerCheckIn $checkIn)
    {
        return $this->actingAs($this->branchManager())
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'no_purchase_reason' => 'Pilot no purchase scenario.',
            ]);
    }

    private function directCheckIn(Branch $branch, Customer $customer, string $status, mixed $createdAt = null, int $stamps = 0): CustomerCheckIn
    {
        $createdAt ??= now();

        return CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'user_id' => $customer->user_id,
            'loyalty_program_id' => $branch->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'check_in_date' => $createdAt->toDateString(),
            'check_in_at' => $createdAt,
            'stamps_earned' => $stamps,
            'source' => 'intelligence_test',
            'check_in_type' => 'physical',
            'reward_status' => $status,
            'reward_granted_at' => $status === CustomerCheckIn::REWARD_STATUS_GRANTED ? $createdAt : null,
            'created_at' => $createdAt,
            'updated_at' => $createdAt,
        ]);
    }

    private function directCapture(Branch $branch, CustomerCheckIn $checkIn, Customer $customer, ProductService $product, int $quantity, string $reference): CheckInProductService
    {
        return CheckInProductService::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'captured_by_user_id' => $this->branchManager()->id,
            'quantity' => $quantity,
            'price_at_capture' => $product->price,
            'total_amount' => $quantity * (float) $product->price,
            'capture_type' => 'purchase',
            'capture_source' => 'intelligence_test',
            'capture_reference' => $reference,
        ]);
    }

    private function directFeedback(Branch $branch, Customer $customer, ProductService $product, int $rating, string $category): void
    {
        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'product_service_id' => $product->id,
            'rating' => $rating,
            'comment' => 'Service issue for '.$product->name,
            'source' => 'intelligence_test',
            'status' => CustomerFeedback::STATUS_ACTION_NEEDED,
            'summary_issue_category' => $category,
            'submitted_at' => now(),
        ]);
    }

    private function directStamp(Branch $branch, Customer $customer): void
    {
        StampTransaction::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $branch->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'type' => StampTransaction::TYPE_EARNED,
            'stamps' => 1,
        ]);
    }

    private function actionPayload(array $operationAnalytics, int $feedbackIssues = 0, bool $popularProduct = false, bool $lowProduct = false): array
    {
        return [
            'title' => 'Business Owner Analytics',
            'personaScope' => 'business',
            'summary' => ['Total check-ins' => 10, 'Total transaction/capture' => 2],
            'operationAnalytics' => array_merge([
                'Pending purchase capture' => 0,
                'Overdue purchase capture' => 0,
                'Manual review required' => 0,
                'No purchase / check-in without purchase' => 0,
                'Check-ins without Product/Service capture' => 0,
            ], $operationAnalytics),
            'feedbackAnalytics' => [
                'Total feedback' => $feedbackIssues,
                'Negative/general issue summary' => $feedbackIssues,
                'Action needed feedback' => 0,
            ],
            'productAnalytics' => [
                'popular' => $popularProduct ? ['name' => 'Pilot Best Seller', 'quantity' => 6, 'total' => 60.00, 'captures' => 2] : null,
                'lowActivity' => $lowProduct ? collect([['name' => 'Pilot Weak Item', 'quantity' => 0, 'total' => 0.0, 'captures' => 0]]) : collect(),
            ],
            'branchAnalytics' => [
                ['name' => 'WanChu Corner - Main', 'sales' => 0, 'check_ins' => 1, 'customers' => 1, 'repeat_customers' => 0, 'feedback_pending' => 0, 'feedback_action_needed' => 0],
            ],
            'dataCompleteness' => [],
            'aiInsights' => [
                ['title' => 'Purchase conversion / capture backlog insight', 'evidence' => ['Pending purchase capture: 5']],
                ['title' => 'Operational follow-up risk insight', 'evidence' => ['Manual review required: 1']],
                ['title' => 'No Purchase pattern insight', 'evidence' => ['No purchase / check-in without purchase: 4']],
                ['title' => 'Feedback pattern insight', 'evidence' => ['Negative/action-needed feedback: '.$feedbackIssues]],
                ['title' => 'Product/Service performance insight', 'evidence' => ['Popular Product/Service: Pilot Best Seller']],
            ],
        ];
    }

    private function assertNoExternalAiDependency(): void
    {
        $source = file_get_contents(app_path('Services/AiInsightService.php'))
            .file_get_contents(app_path('Services/AiActionService.php'))
            .file_get_contents(app_path('Http/Controllers/AnalyticsController.php'));

        $this->assertStringNotContainsString('OpenAI', $source);
        $this->assertStringNotContainsString('Gemini', $source);
        $this->assertStringNotContainsString('OPENAI_API_KEY', $source);
        $this->assertStringNotContainsString('Http::post', $source);
    }

    private function createCustomer(Branch $branch, string $name, string $whatsapp): Customer
    {
        return Customer::query()->create([
            'business_id' => $branch->business_id,
            'name' => $name,
            'whatsapp_number' => $whatsapp,
        ]);
    }

    private function product(Branch $branch): ProductService
    {
        return ProductService::query()
            ->where('business_id', $branch->business_id)
            ->where(function ($query) use ($branch): void {
                $query->whereNull('branch_id')->orWhere('branch_id', $branch->id);
            })
            ->active()
            ->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business.loyaltyPrograms')->where('code', $code)->firstOrFail();
    }

    private function owner(): User
    {
        return $this->user('owner+wanchu@fbgrowth.local');
    }

    private function branchManager(): User
    {
        return $this->user('branch+wanchu@fbgrowth.local');
    }

    private function customer(): User
    {
        return $this->user('customer@fbgrowth.local');
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
