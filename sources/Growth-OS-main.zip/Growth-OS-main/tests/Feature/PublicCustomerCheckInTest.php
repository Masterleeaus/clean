<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerLoyaltyAccount;
use App\Models\LoyaltyProgram;
use App\Models\ProductService;
use App\Models\StampTransaction;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PublicCustomerCheckInTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_returning_customer_can_check_in_without_immediate_stamp_until_product_service_capture(): void
    {
        [$business, $customer, $account] = $this->registeredCustomerWithoutTodayCheckIn();

        $this->post(route('public.business.check-in', ['business' => $business->slug]), [
            'whatsapp_number' => $customer->whatsapp_number,
        ])
            ->assertOk()
            ->assertSee('Check-in direkodkan')
            ->assertSee('Reward akan disahkan selepas pembelian disahkan oleh branch')
            ->assertSee('Stamp semasa')
            ->assertSee('Stamp diperlukan');

        $account->refresh();

        $this->assertSame(0, $account->current_stamps);
        $this->assertSame(0, $account->total_stamps_earned);
    }

    public function test_check_in_creates_customer_check_in_pending_product_without_stamp_transaction(): void
    {
        [$business, $customer] = $this->registeredCustomerWithoutTodayCheckIn();
        $program = $business->loyaltyPrograms()->active()->firstOrFail();

        $this->post(route('public.business.check-in', ['business' => $business->slug]), [
            'whatsapp_number' => $customer->whatsapp_number,
        ])->assertOk();

        $this->assertDatabaseHas('customer_check_ins', [
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'stamps_earned' => 0,
            'check_in_type' => 'physical',
            'reward_status' => 'pending_product',
        ]);

        $this->assertDatabaseCount('stamp_transactions', 0);
    }

    public function test_second_check_in_within_default_60_minute_cooldown_is_blocked(): void
    {
        [$business, $customer, $account] = $this->registeredCustomerWithoutTodayCheckIn();

        $this->checkIn($business, $customer)->assertOk();
        $this->travel(30)->minutes();

        $this->checkIn($business, $customer)
            ->assertOk()
            ->assertSee('Check-in terlalu awal')
            ->assertSee('60 minit')
            ->assertSee('No Purchase tidak beri reward/stamp.');

        $account->refresh();

        $this->assertSame(0, $account->current_stamps);
        $this->assertSame(1, CustomerCheckIn::query()->where('customer_id', $customer->id)->count());
        $this->assertSame(0, StampTransaction::query()->where('customer_id', $customer->id)->count());
    }

    public function test_second_check_in_after_default_60_minute_cooldown_is_allowed(): void
    {
        [$business, $customer, $account] = $this->registeredCustomerWithoutTodayCheckIn();

        $this->checkIn($business, $customer)->assertOk();
        $this->travel(60)->minutes();

        $this->checkIn($business, $customer)
            ->assertOk()
            ->assertSee('Check-in direkodkan');

        $account->refresh();

        $this->assertSame(0, $account->current_stamps);
        $this->assertSame(2, CustomerCheckIn::query()->where('customer_id', $customer->id)->count());
        $this->assertSame(0, StampTransaction::query()->where('customer_id', $customer->id)->count());
    }

    public function test_multiple_same_day_purchases_can_earn_multiple_stamps_after_cooldown(): void
    {
        [$business, $customer, $account] = $this->registeredCustomerWithoutTodayCheckIn();

        $this->checkIn($business, $customer)->assertOk();
        $this->travel(60)->minutes();
        $this->checkIn($business, $customer)->assertOk();
        $this->travel(60)->minutes();
        $this->checkIn($business, $customer)->assertOk();

        $account->refresh();

        $this->assertSame(0, $account->current_stamps);
        $this->assertSame(3, CustomerCheckIn::query()
            ->where('customer_id', $customer->id)
            ->whereDate('check_in_date', now()->toDateString())
            ->count());
    }

    public function test_check_in_within_configured_cooldown_is_blocked(): void
    {
        [$business, $customer, $account] = $this->registeredCustomerWithoutTodayCheckIn();
        $business->branches()->firstOrFail()->update([
            'check_in_cooldown_minutes' => 30,
        ]);

        $this->checkIn($business, $customer)->assertOk();
        $this->travel(29)->minutes();

        $this->checkIn($business, $customer)
            ->assertOk()
            ->assertSee('30 minit');

        $account->refresh();

        $this->assertSame(0, $account->current_stamps);
        $this->assertSame(1, CustomerCheckIn::query()->where('customer_id', $customer->id)->count());
    }

    public function test_check_in_after_configured_cooldown_is_allowed(): void
    {
        [$business, $customer, $account] = $this->registeredCustomerWithoutTodayCheckIn();
        $business->branches()->firstOrFail()->update([
            'check_in_cooldown_minutes' => 30,
        ]);

        $this->checkIn($business, $customer)->assertOk();
        $this->travel(31)->minutes();

        $this->checkIn($business, $customer)->assertOk();

        $account->refresh();

        $this->assertSame(0, $account->current_stamps);
        $this->assertSame(2, CustomerCheckIn::query()->where('customer_id', $customer->id)->count());
    }

    public function test_missing_customer_cannot_check_in(): void
    {
        $business = $this->wanChu();

        $this->post(route('public.business.check-in', ['business' => $business->slug]), [
            'whatsapp_number' => '60999999999',
        ])
            ->assertRedirect()
            ->assertSessionHasErrors('check_in');

        $this->assertDatabaseCount('customer_check_ins', 0);
        $this->assertDatabaseCount('stamp_transactions', 0);
    }

    public function test_check_in_under_inactive_or_missing_loyalty_program_is_handled_gracefully(): void
    {
        [$business, $customer] = $this->registeredCustomerWithoutTodayCheckIn();
        LoyaltyProgram::query()->where('business_id', $business->id)->update(['is_active' => false]);

        $this->checkIn($business, $customer)
            ->assertRedirect()
            ->assertSessionHasErrors('check_in');

        $this->assertDatabaseCount('customer_check_ins', 0);
        $this->assertDatabaseCount('stamp_transactions', 0);
    }

    public function test_reward_eligibility_message_appears_when_stamps_reach_threshold(): void
    {
        [$business, $customer, $account] = $this->registeredCustomerWithoutTodayCheckIn();
        $account->update([
            'current_stamps' => 7,
            'total_stamps_earned' => 7,
        ]);

        $this->checkIn($business, $customer)->assertOk();
        $this->captureProductForLatestCheckIn($business);

        $this->get(route('public.business.show', ['business' => $business->slug]))
            ->assertOk();

        $this->assertSame(8, $account->refresh()->current_stamps);
    }

    public function test_owner_business_detail_shows_recent_check_ins_and_eligible_customers(): void
    {
        [$business, $customer, $account] = $this->registeredCustomerWithoutTodayCheckIn();
        $owner = User::query()->where('email', 'owner+wanchu@fbgrowth.local')->firstOrFail();
        $account->update([
            'current_stamps' => 8,
            'total_stamps_earned' => 8,
        ]);

        $this->checkIn($business, $customer)->assertOk();

        $this->actingAs($owner)
            ->get(route('businesses.show', $business))
            ->assertOk()
            ->assertSee('Customer Entry QR')
            ->assertSee('Cetak atau paparkan QR ini di meja, kaunter, resit, atau bahan promosi dalam kedai.')
            ->assertSee('Recent Check-ins')
            ->assertSee($customer->name)
            ->assertSee('Pelanggan Layak Ganjaran')
            ->assertSee('Ganjaran: Free drink')
            ->assertSee('Verify Redemption')
            ->assertSee('data-qr-code', false);
    }

    public function test_owner_cannot_view_another_business_detail_due_to_existing_policy(): void
    {
        $owner = User::query()->where('email', 'owner+wanchu@fbgrowth.local')->firstOrFail();
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();

        $this->actingAs($owner)
            ->get(route('businesses.show', $otherBusiness))
            ->assertForbidden();
    }

    private function registeredCustomerWithoutTodayCheckIn(): array
    {
        $business = $this->wanChu();
        $program = $business->loyaltyPrograms()->active()->firstOrFail();
        $customer = Customer::query()->create([
            'business_id' => $business->id,
            'name' => 'Aina',
            'whatsapp_number' => '60123456789',
        ]);
        $account = CustomerLoyaltyAccount::query()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
        ]);

        return [$business, $customer, $account];
    }

    private function wanChu(): Business
    {
        return Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
    }

    private function checkIn(Business $business, Customer $customer)
    {
        return $this->post(route('public.business.check-in', ['business' => $business->slug]), [
            'whatsapp_number' => $customer->whatsapp_number,
        ]);
    }

    private function captureProductForLatestCheckIn(Business $business): void
    {
        $branch = $business->branches()->firstOrFail();
        $checkIn = CustomerCheckIn::query()
            ->where('business_id', $business->id)
            ->latest()
            ->firstOrFail();
        $product = ProductService::query()
            ->where('business_id', $business->id)
            ->where(function ($query) use ($branch): void {
                $query->whereNull('branch_id')->orWhere('branch_id', $branch->id);
            })
            ->firstOrFail();
        $branchManager = User::query()->where('email', 'branch+wanchu@fbgrowth.local')->firstOrFail();

        $this->actingAs($branchManager)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
            ])
            ->assertRedirect();
    }
}
