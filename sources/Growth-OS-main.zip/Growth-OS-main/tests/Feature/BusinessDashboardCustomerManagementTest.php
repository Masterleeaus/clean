<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerLoyaltyAccount;
use App\Models\RewardRedemption;
use App\Models\StampTransaction;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BusinessDashboardCustomerManagementTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_owner_can_view_own_business_dashboard(): void
    {
        [$business] = $this->seedDashboardData();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.dashboard', $business))
            ->assertOk()
            ->assertSee('Pilot operations snapshot')
            ->assertSee('Ask customers to scan this QR link');
    }

    public function test_owner_cannot_view_another_business_dashboard(): void
    {
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.dashboard', $otherBusiness))
            ->assertForbidden();
    }

    public function test_owner_can_view_own_customers_list(): void
    {
        [$business] = $this->seedDashboardData();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.customers.index', $business))
            ->assertOk()
            ->assertSee('Aina')
            ->assertSee('60111111111')
            ->assertSee('eligible reward');
    }

    public function test_owner_cannot_view_another_business_customers_list(): void
    {
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.customers.index', $otherBusiness))
            ->assertForbidden();
    }

    public function test_owner_can_view_own_customer_detail(): void
    {
        [$business, $eligibleCustomer] = $this->seedDashboardData();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.customers.show', ['business' => $business, 'customer' => $eligibleCustomer]))
            ->assertOk()
            ->assertSee('Customer Profile')
            ->assertSee('Stamp Progress')
            ->assertSee('Check-in History')
            ->assertSee('Stamp Transactions');
    }

    public function test_owner_cannot_view_another_business_customer_detail(): void
    {
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();
        $otherCustomer = Customer::query()->create([
            'business_id' => $otherBusiness->id,
            'name' => 'Che Na Customer',
            'whatsapp_number' => '60222222222',
        ]);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.customers.show', ['business' => $otherBusiness, 'customer' => $otherCustomer]))
            ->assertForbidden();
    }

    public function test_dashboard_counts_are_correct_for_test_data(): void
    {
        [$business] = $this->seedDashboardData();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.dashboard', $business))
            ->assertOk()
            ->assertSee('Total customers')
            ->assertSee('New customers today')
            ->assertSee('Check-ins today')
            ->assertSee('Repeat customers')
            ->assertSee('Eligible rewards')
            ->assertSee('Rewards redeemed')
            ->assertSee('3')
            ->assertSee('2')
            ->assertSee('1');
    }

    public function test_customers_list_shows_stamp_and_reward_status(): void
    {
        [$business] = $this->seedDashboardData();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.customers.index', ['business' => $business, 'filter' => 'eligible']))
            ->assertOk()
            ->assertSee('Aina')
            ->assertSee('Current stamps')
            ->assertSee('Total earned')
            ->assertSee('Rewards redeemed')
            ->assertSee('eligible reward')
            ->assertDontSee('Ben');
    }

    private function seedDashboardData(): array
    {
        $business = Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
        $program = $business->loyaltyPrograms()->active()->firstOrFail();
        $owner = $this->wanChuOwner();

        $eligible = Customer::query()->create([
            'business_id' => $business->id,
            'name' => 'Aina',
            'whatsapp_number' => '60111111111',
            'created_at' => now()->subDays(10),
            'updated_at' => now()->subDays(10),
        ]);
        CustomerLoyaltyAccount::query()->create([
            'business_id' => $business->id,
            'customer_id' => $eligible->id,
            'loyalty_program_id' => $program->id,
            'current_stamps' => 8,
            'total_stamps_earned' => 12,
            'total_rewards_redeemed' => 1,
        ]);
        CustomerCheckIn::query()->create([
            'business_id' => $business->id,
            'customer_id' => $eligible->id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => now()->subDay()->toDateString(),
        ]);
        CustomerCheckIn::query()->create([
            'business_id' => $business->id,
            'customer_id' => $eligible->id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => now()->toDateString(),
        ]);
        StampTransaction::query()->create([
            'business_id' => $business->id,
            'customer_id' => $eligible->id,
            'loyalty_program_id' => $program->id,
            'type' => StampTransaction::TYPE_EARNED,
            'stamps' => 1,
            'description' => 'Test check-in.',
        ]);
        RewardRedemption::query()->create([
            'business_id' => $business->id,
            'customer_id' => $eligible->id,
            'loyalty_program_id' => $program->id,
            'reward_name' => $program->reward_name,
            'stamps_spent' => $program->stamps_required,
            'verified_by_user_id' => $owner->id,
            'redeemed_at' => now()->subHour(),
        ]);

        $active = Customer::query()->create([
            'business_id' => $business->id,
            'name' => 'Ben',
            'whatsapp_number' => '60133333333',
            'created_at' => now()->subDays(5),
            'updated_at' => now()->subDays(5),
        ]);
        CustomerLoyaltyAccount::query()->create([
            'business_id' => $business->id,
            'customer_id' => $active->id,
            'loyalty_program_id' => $program->id,
            'current_stamps' => 2,
            'total_stamps_earned' => 2,
        ]);
        CustomerCheckIn::query()->create([
            'business_id' => $business->id,
            'customer_id' => $active->id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => now()->toDateString(),
        ]);

        Customer::query()->create([
            'business_id' => $business->id,
            'name' => 'Cara',
            'whatsapp_number' => '60144444444',
        ]);

        return [$business, $eligible];
    }

    private function wanChuOwner(): User
    {
        return User::query()->where('email', 'owner+wanchu@fbgrowth.local')->firstOrFail();
    }
}
