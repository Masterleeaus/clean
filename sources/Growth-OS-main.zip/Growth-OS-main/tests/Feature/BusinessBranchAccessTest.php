<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BusinessBranchAccessTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_business_owner_can_access_assigned_business_and_branches(): void
    {
        $owner = $this->user('owner+wanchu@fbgrowth.local');
        $business = $this->business('wanchu-corner');
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($owner)
            ->get(route('businesses.show', $business))
            ->assertOk()
            ->assertSee('WanChu Corner');

        $this->actingAs($owner)
            ->get(route('businesses.branches.show', ['business' => $business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('Branch Basic Profile');
    }

    public function test_branch_manager_can_access_assigned_branch_only(): void
    {
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $business = $this->business('wanchu-corner');
        $assignedBranch = $this->branch('WANCHU-MAIN');
        $otherBranch = $this->branch('CHENA-MAIN');

        $this->assertSame([$assignedBranch->id], $branchManager->fresh()->scopedBranchIds());

        $this->actingAs($branchManager)
            ->get(route('businesses.branches.show', ['business' => $business, 'branch' => $assignedBranch]))
            ->assertOk()
            ->assertSee('WanChu Corner Main Branch');

        $this->actingAs($branchManager)
            ->get(route('businesses.branches.show', ['business' => $otherBranch->business, 'branch' => $otherBranch]))
            ->assertForbidden();
    }

    public function test_branch_manager_cannot_manage_business_or_branch_setup(): void
    {
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $business = $this->business('wanchu-corner');
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($branchManager)
            ->get(route('businesses.edit', $business))
            ->assertForbidden();

        $this->actingAs($branchManager)
            ->get(route('businesses.branches.edit', ['business' => $business, 'branch' => $branch]))
            ->assertForbidden();
    }

    public function test_combined_business_owner_branch_manager_access_works(): void
    {
        $combined = $this->user('owner-branch+wanchu@fbgrowth.local');
        $business = $this->business('wanchu-corner');
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($combined)
            ->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Business Owner / Branch Manager Dashboard');

        $this->actingAs($combined)
            ->get(route('businesses.branches.show', ['business' => $business, 'branch' => $branch]))
            ->assertOk();
    }

    public function test_customer_is_blocked_from_business_branch_admin_surfaces(): void
    {
        $customer = $this->user('customer@fbgrowth.local');
        $business = $this->business('wanchu-corner');
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($customer)
            ->get(route('businesses.index'))
            ->assertForbidden();

        $this->actingAs($customer)
            ->get(route('businesses.branches.show', ['business' => $business, 'branch' => $branch]))
            ->assertForbidden();
    }

    public function test_system_manager_and_system_admin_access_business_branch_setup_by_role(): void
    {
        $systemManager = $this->user('manager@gos-fnb.local');
        $systemAdmin = $this->user('admin@fbgrowth.local');
        $business = $this->business('wanchu-corner');
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($systemManager)
            ->get(route('businesses.branches.show', ['business' => $business, 'branch' => $branch]))
            ->assertOk();

        $this->actingAs($systemManager)
            ->get(route('businesses.branches.edit', ['business' => $business, 'branch' => $branch]))
            ->assertForbidden();

        $this->actingAs($systemAdmin)
            ->get(route('businesses.branches.edit', ['business' => $business, 'branch' => $branch]))
            ->assertOk();
    }

    public function test_system_admin_can_create_business_and_branch(): void
    {
        $systemAdmin = $this->user('admin@fbgrowth.local');
        $owner = $this->user('owner+wanchu@fbgrowth.local');

        $this->actingAs($systemAdmin)
            ->post(route('businesses.store'), [
                'owner_user_id' => $owner->id,
                'name' => 'Demo Kopitiam',
                'slug' => 'demo-kopitiam',
                'owner_name' => 'Demo Owner',
                'owner_whatsapp' => '60122220000',
                'business_type' => 'cafe',
            ])
            ->assertRedirect();

        $business = Business::query()->where('slug', 'demo-kopitiam')->firstOrFail();

        $this->actingAs($systemAdmin)
            ->post(route('businesses.branches.store', $business), [
                'name' => 'Demo Kopitiam KL',
                'code' => 'DEMO-KL',
                'manager_user_id' => $this->user('branch+wanchu@fbgrowth.local')->id,
                'address' => 'Kuala Lumpur',
                'phone' => '60133330000',
                'is_active' => '1',
            ])
            ->assertRedirect();

        $this->assertDatabaseHas('branches', [
            'business_id' => $business->id,
            'code' => 'DEMO-KL',
            'name' => 'Demo Kopitiam KL',
        ]);
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function business(string $slug): Business
    {
        return Business::query()->where('slug', $slug)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business')->where('code', $code)->firstOrFail();
    }
}
