<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\CustomerLoyaltyAccount;
use App\Models\ProductService;
use App\Models\StampTransaction;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Routing\Middleware\ThrottleRequests;
use Tests\TestCase;

class PhysicalOnlineCheckInFlowTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->withoutMiddleware(ThrottleRequests::class);
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_customer_portal_shows_physical_and_online_check_in_options_without_internal_pending_capture(): void
    {
        $this->actingAs($this->customer())
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Check-in di Premis')
            ->assertSee('Gunakan jika anda berada di kedai.')
            ->assertSee('Check-in untuk Order Online')
            ->assertSee('Gunakan jika anda membuat order melalui WhatsApp, delivery, pickup atau channel luar.')
            ->assertSee('Hantar Maklumbalas')
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Self-Claim Purchase')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Mark No Purchase');
    }

    public function test_physical_online_and_existing_qr_check_ins_store_the_correct_mode(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->customerCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL)
            ->assertOk()
            ->assertSee('Check-in premis berjaya direkodkan');

        $physical = CustomerCheckIn::query()->latest('check_in_at')->firstOrFail();
        $this->assertSame(CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL, $physical->check_in_type);
        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $physical->reward_status);
        $this->assertSame(0, $physical->stamps_earned);

        $this->travel(61)->minutes();

        $this->customerCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_ONLINE)
            ->assertOk()
            ->assertSee('Check-in order online berjaya direkodkan');

        $online = CustomerCheckIn::query()->latest('check_in_at')->firstOrFail();
        $this->assertSame(CustomerCheckIn::CHECK_IN_TYPE_ONLINE, $online->check_in_type);
        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $online->reward_status);
        $this->assertSame(0, $online->stamps_earned);

        $this->travel(61)->minutes();

        $this->post(route('public.business.check-in', ['business' => $branch->business->slug]), [
            'whatsapp_number' => '60111112222',
        ])
            ->assertOk()
            ->assertSee('Check-in premis berjaya direkodkan');

        $qrCheckIn = CustomerCheckIn::query()->latest('check_in_at')->firstOrFail();
        $this->assertSame(CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL, $qrCheckIn->check_in_type);

        $this->assertDatabaseCount('stamp_transactions', 0);
        $this->assertDatabaseCount('check_in_product_services', 0);
    }

    public function test_invalid_check_in_mode_is_rejected_and_customer_cannot_self_claim_purchase(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $product = $this->product($branch);

        $this->actingAs($this->customer())
            ->from(route('customer.portal'))
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
                'check_in_mode' => 'delivery-paid',
            ])
            ->assertRedirect(route('customer.portal'))
            ->assertSessionHasErrors('check_in_mode');

        $this->assertDatabaseCount('customer_check_ins', 0);

        $this->actingAs($this->customer())
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
                'check_in_mode' => CustomerCheckIn::CHECK_IN_TYPE_ONLINE,
                'product_service_id' => $product->id,
                'reward_status' => CustomerCheckIn::REWARD_STATUS_GRANTED,
                'stamps_earned' => 99,
                'purchase_reference' => 'CUSTOMER-SELF-CLAIM',
            ])
            ->assertOk()
            ->assertSee('Check-in order online berjaya direkodkan')
            ->assertDontSee('Pending Purchase Capture');

        $checkIn = CustomerCheckIn::query()->firstOrFail();

        $this->assertSame(CustomerCheckIn::CHECK_IN_TYPE_ONLINE, $checkIn->check_in_type);
        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $checkIn->reward_status);
        $this->assertSame(0, $checkIn->stamps_earned);
        $this->assertNull($checkIn->purchase_reference);
        $this->assertDatabaseCount('check_in_product_services', 0);
        $this->assertDatabaseCount('stamp_transactions', 0);
    }

    public function test_assigned_bm_and_bo_cum_bm_see_pending_capture_mode_labels(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->directPendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL, 'Physical Pending Customer', '60170000001');
        $this->directPendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_ONLINE, 'Online Pending Customer', '60170000002');

        foreach ([$this->branchManager(), $this->businessOwnerBranchManager()] as $actor) {
            $this->actingAs($actor)
                ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
                ->assertOk()
                ->assertSee('Mode')
                ->assertSee('Physical')
                ->assertSee('Online')
                ->assertSee('Pending Purchase Capture — Physical')
                ->assertSee('Pending Purchase Capture — Online')
                ->assertSee('Capture Purchase')
                ->assertSee('Mark No Purchase');
        }
    }

    public function test_capture_purchase_confirms_reward_for_physical_and_online_modes_only_after_valid_capture(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $product = $this->product($branch);
        $physical = $this->directPendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL, 'Physical Capture Customer', '60170000003');
        $online = $this->directPendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_ONLINE, 'Online Capture Customer', '60170000004');

        $this->assertDatabaseCount('stamp_transactions', 0);

        $this->captureProduct($branch, $physical, $product, 'physical-capture')->assertRedirect();
        $this->captureProduct($branch, $online, $product, 'online-capture')->assertRedirect();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_GRANTED, $physical->refresh()->reward_status);
        $this->assertSame(CustomerCheckIn::REWARD_STATUS_GRANTED, $online->refresh()->reward_status);
        $this->assertSame(1, $physical->stamps_earned);
        $this->assertSame(1, $online->stamps_earned);
        $this->assertSame(2, StampTransaction::query()->count());
        $this->assertSame(2, CheckInProductService::query()->count());

        $this->assertSame(1, CustomerLoyaltyAccount::query()->where('customer_id', $physical->customer_id)->firstOrFail()->current_stamps);
        $this->assertSame(1, CustomerLoyaltyAccount::query()->where('customer_id', $online->customer_id)->firstOrFail()->current_stamps);
    }

    public function test_mark_no_purchase_gives_no_reward_for_physical_and_online_modes(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $physical = $this->directPendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL, 'Physical No Purchase Customer', '60170000005');
        $online = $this->directPendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_ONLINE, 'Online No Purchase Customer', '60170000006');

        $this->markNoPurchase($branch, $physical)->assertRedirect();
        $this->markNoPurchase($branch, $online)->assertRedirect();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_NO_PURCHASE, $physical->refresh()->reward_status);
        $this->assertSame(CustomerCheckIn::REWARD_STATUS_NO_PURCHASE, $online->refresh()->reward_status);
        $this->assertSame(0, $physical->stamps_earned);
        $this->assertSame(0, $online->stamps_earned);
        $this->assertDatabaseCount('stamp_transactions', 0);
        $this->assertDatabaseCount('check_in_product_services', 0);
    }

    public function test_feedback_remains_free_and_customer_is_blocked_from_internal_operation_routes(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $pending = $this->directPendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_ONLINE, 'Blocked Customer', '60170000007', $this->customer());
        $otherBranch = $this->branch('CHENA-MAIN');
        $otherPending = $this->directPendingCheckIn($otherBranch, CustomerCheckIn::CHECK_IN_TYPE_ONLINE, 'Other Branch Customer', '60170000008');
        $product = $this->product($branch);

        $this->actingAs($this->customer())
            ->get(route('customer.feedback'))
            ->assertOk()
            ->assertSee('Hantar Maklumbalas')
            ->assertDontSee('Pending Feedback');

        $this->actingAs($this->customer())
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'rating' => 5,
                'comment' => 'Hantar Maklumbalas bebas untuk online order.',
            ])
            ->assertRedirect(route('customer.feedback'));

        $this->assertDatabaseHas('customer_feedback', [
            'branch_id' => $branch->id,
            'comment' => 'Hantar Maklumbalas bebas untuk online order.',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
        ]);
        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $pending->refresh()->reward_status);

        $this->actingAs($this->customer())
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $pending,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
            ])
            ->assertForbidden();

        $this->actingAs($this->customer())
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $pending,
            ]))
            ->assertForbidden();

        $this->captureProductAs($this->businessOwner(), $branch, $pending, $product, 'owner-blocked')->assertForbidden();
        $this->captureProductAs($this->user('manager@gos-fnb.local'), $branch, $pending, $product, 'system-manager-blocked')->assertForbidden();
        $this->captureProductAs($this->user('admin@fbgrowth.local'), $branch, $pending, $product, 'system-admin-blocked')->assertForbidden();
        $this->captureProductAs($this->branchManager(), $otherBranch, $otherPending, $this->product($otherBranch), 'other-branch-blocked')->assertForbidden();
    }

    public function test_analytics_and_ai_can_use_physical_online_mode_signals(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $product = $this->product($branch);
        $physicalPending = $this->directPendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL, 'Analytics Physical Pending', '60170000009');
        $onlineCaptured = $this->directPendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_ONLINE, 'Analytics Online Captured', '60170000010');
        $onlineNoPurchase = $this->directPendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_ONLINE, 'Analytics Online No Purchase', '60170000011');

        $this->captureProduct($branch, $onlineCaptured, $product, 'analytics-online-capture')->assertRedirect();
        $this->markNoPurchase($branch, $onlineNoPurchase)->assertRedirect();

        $this->actingAs($this->businessOwner())
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Physical check-ins')
            ->assertSee('Online check-ins')
            ->assertSee('Pending purchase capture - physical')
            ->assertSee('Pending purchase capture - online')
            ->assertSee('No purchase - physical')
            ->assertSee('No purchase - online')
            ->assertSee('Capture conversion - physical')
            ->assertSee('Capture conversion - online')
            ->assertSee('Pending purchase capture - physical: 1')
            ->assertSee('Pending purchase capture - online: 0')
            ->assertSee('No purchase - online: 1');

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $physicalPending->refresh()->reward_status);
    }

    private function customerCheckIn(Branch $branch, string $mode)
    {
        return $this->actingAs($this->customer())
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
                'check_in_mode' => $mode,
            ]);
    }

    private function directPendingCheckIn(Branch $branch, string $mode, string $name, string $whatsapp, ?User $user = null): CustomerCheckIn
    {
        $customer = Customer::query()->firstOrCreate(
            [
                'business_id' => $branch->business_id,
                'whatsapp_number' => $whatsapp,
            ],
            [
                'user_id' => $user?->id,
                'name' => $name,
                'consent_promo' => false,
            ],
        );

        if ($user && ! $customer->user_id) {
            $customer->forceFill(['user_id' => $user->id])->save();
        }

        return CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'user_id' => $customer->user_id,
            'loyalty_program_id' => $branch->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'stamps_earned' => 0,
            'source' => 'physical_online_flow_test',
            'check_in_type' => $mode,
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
        ]);
    }

    private function captureProduct(Branch $branch, CustomerCheckIn $checkIn, ProductService $product, string $reference)
    {
        return $this->captureProductAs($this->branchManager(), $branch, $checkIn, $product, $reference);
    }

    private function captureProductAs(User $actor, Branch $branch, CustomerCheckIn $checkIn, ProductService $product, string $reference)
    {
        return $this->actingAs($actor)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
                'capture_reference' => $reference,
            ]);
    }

    private function markNoPurchase(Branch $branch, CustomerCheckIn $checkIn)
    {
        return $this->actingAs($this->branchManager())
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'no_purchase_reason' => 'No valid purchase found.',
            ]);
    }

    private function product(Branch $branch): ProductService
    {
        return ProductService::query()
            ->visibleForBranch($branch)
            ->active()
            ->orderBy('name')
            ->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business.loyaltyPrograms')->where('code', $code)->firstOrFail();
    }

    private function customer(): User
    {
        return $this->user('customer@fbgrowth.local');
    }

    private function branchManager(): User
    {
        return $this->user('branch+wanchu@fbgrowth.local');
    }

    private function businessOwner(): User
    {
        return $this->user('owner+wanchu@fbgrowth.local');
    }

    private function businessOwnerBranchManager(): User
    {
        return $this->user('owner-branch+wanchu@fbgrowth.local');
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
