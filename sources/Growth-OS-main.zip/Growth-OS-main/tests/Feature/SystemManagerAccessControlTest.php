<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SystemManagerAccessControlTest extends TestCase
{
    use RefreshDatabase;

    private User $systemManager;

    private Business $business;

    private Branch $branch;

    private CustomerCheckIn $checkIn;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);

        $this->systemManager = User::query()->where('email', 'manager@gos-fnb.local')->firstOrFail();
        $this->business = Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
        $this->branch = Branch::query()->where('code', 'WANCHU-MAIN')->firstOrFail();

        $customer = Customer::query()->where('business_id', $this->business->id)->firstOrFail();

        $this->checkIn = CustomerCheckIn::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $this->business->loyaltyPrograms()->active()->first()?->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'system_manager_access_test',
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);
    }

    public function test_lp_ac_sm_01_system_manager_dashboard_is_allowed(): void
    {
        $this->actingAs($this->systemManager)
            ->get(route('dashboards.system-manager'))
            ->assertOk()
            ->assertSee('System Manager Dashboard')
            ->assertSee('GOS Sdn Bhd platform/business performance')
            ->assertSee('Strategic platform performance dan F&amp;B vertical effectiveness', false);
    }

    public function test_lp_ac_sm_02_platform_analytics_performance_is_allowed(): void
    {
        $this->actingAs($this->systemManager)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('System Manager Analytics')
            ->assertSee('GOS platform/business analytics')
            ->assertSee('GOS Platform / Business Performance');
    }

    public function test_lp_ac_sm_03_platform_ai_insight_is_allowed(): void
    {
        $this->actingAs($this->systemManager)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Insight Engine')
            ->assertSee('GOS platform performance insight');
    }

    public function test_lp_ac_sm_04_platform_ai_action_is_allowed(): void
    {
        $this->actingAs($this->systemManager)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Action Engine')
            ->assertSee('GOS platform/business performance monitoring')
            ->assertSee('Human review diperlukan')
            ->assertDontSee('Auto Execute')
            ->assertDontSee('Send Campaign')
            ->assertDontSee('Send Message');
    }

    public function test_lp_ac_sm_05_customer_portal_is_blocked(): void
    {
        $this->actingAs($this->systemManager)
            ->get(route('customer.portal'))
            ->assertForbidden();
    }

    public function test_lp_ac_sm_06_customer_only_check_in_action_is_blocked(): void
    {
        $this->actingAs($this->systemManager)
            ->post(route('customer.check-in.store'))
            ->assertForbidden();
    }

    public function test_lp_ac_sm_07_branch_operations_and_capture_purchase_are_blocked(): void
    {
        $this->actingAs($this->systemManager)
            ->get(route('businesses.branches.check-ins', [
                'business' => $this->business,
                'branch' => $this->branch,
            ]))
            ->assertForbidden();

        $this->actingAs($this->systemManager)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $this->business,
                'branch' => $this->branch,
                'checkIn' => $this->checkIn,
            ]))
            ->assertForbidden();
    }

    public function test_lp_ac_sm_08_mark_no_purchase_is_blocked(): void
    {
        $this->actingAs($this->systemManager)
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $this->business,
                'branch' => $this->branch,
                'checkIn' => $this->checkIn,
            ]))
            ->assertForbidden();
    }

    public function test_lp_ac_sm_09_business_owner_dashboard_and_owner_pages_are_blocked(): void
    {
        $this->actingAs($this->systemManager)
            ->get(route('dashboards.business-owner'))
            ->assertForbidden();

        $this->actingAs($this->systemManager)
            ->get(route('businesses.dashboard', $this->business))
            ->assertForbidden();
    }

    public function test_lp_ac_sm_10_branch_manager_dashboard_and_branch_operations_are_blocked(): void
    {
        $this->actingAs($this->systemManager)
            ->get(route('dashboards.branch-manager'))
            ->assertForbidden();

        $this->actingAs($this->systemManager)
            ->get(route('businesses.branches.check-ins', [
                'business' => $this->business,
                'branch' => $this->branch,
            ]))
            ->assertForbidden();
    }

    public function test_lp_ac_sm_11_system_admin_dashboard_is_blocked_for_pure_system_manager(): void
    {
        $this->actingAs($this->systemManager)
            ->get(route('dashboards.system-admin'))
            ->assertForbidden();
    }

    public function test_lp_ac_sm_12_system_manager_navigation_stays_platform_scoped(): void
    {
        $this->actingAs($this->systemManager)
            ->get(route('dashboards.system-manager'))
            ->assertOk()
            ->assertSee('Platform Links')
            ->assertSee('Analytics')
            ->assertSee('Platform Analytics / AI')
            ->assertDontSee('Businesses')
            ->assertDontSee('Customer Portal')
            ->assertDontSee('Branch Operations')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Mark No Purchase')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Active/default provider')
            ->assertDontSee('Business Owner Dashboard')
            ->assertDontSee('Branch Manager Dashboard')
            ->assertDontSee('Business setup')
            ->assertDontSee('Admin Links');
    }

    public function test_system_manager_analytics_does_not_show_ai_provider_admin_status_or_secrets(): void
    {
        config(['ai.providers.gemini.api_key' => 'fake-system-manager-hidden-key']);

        $this->actingAs($this->systemManager)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('System Manager Analytics')
            ->assertSee('AI Insight Engine')
            ->assertSee('AI Action Engine')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Active/default provider')
            ->assertDontSee('fake-system-manager-hidden-key');
    }
}
