<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\RewardRedemption;
use App\Models\User;
use Carbon\Carbon;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class WeeklyGrowthReportTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        Carbon::setTestNow('2026-06-24 12:00:00');
        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    protected function tearDown(): void
    {
        Carbon::setTestNow();

        parent::tearDown();
    }

    public function test_owner_can_view_own_weekly_report(): void
    {
        $business = $this->wanChu();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.reports.weekly', $business))
            ->assertOk()
            ->assertSee('Weekly Growth Report')
            ->assertSee($business->name);
    }

    public function test_owner_cannot_view_another_business_weekly_report(): void
    {
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.reports.weekly', $otherBusiness))
            ->assertForbidden();
    }

    public function test_report_shows_correct_new_customers_this_week(): void
    {
        $business = $this->wanChu();

        $this->createCustomer($business, 'New One', '60111111111', now()->subDay());
        $this->createCustomer($business, 'New Two', '60111111112', now());
        $this->createCustomer($business, 'Old One', '60111111113', now()->subWeeks(2));

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.reports.weekly', $business))
            ->assertOk()
            ->assertSee('New customers this week')
            ->assertSee('New customers: 2');
    }

    public function test_report_shows_correct_check_ins_this_week(): void
    {
        $business = $this->wanChu();
        $program = $business->loyaltyPrograms()->active()->firstOrFail();
        $customer = $this->createCustomer($business, 'Check In Customer', '60122222222');

        $this->createCheckIn($business, $customer, $program->id, now()->subDays(2)->toDateString());
        $this->createCheckIn($business, $customer, $program->id, now()->subDay()->toDateString());
        $this->createCheckIn($business, $customer, $program->id, now()->toDateString());
        $this->createCheckIn($business, $customer, $program->id, now()->subWeeks(2)->toDateString());

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.reports.weekly', $business))
            ->assertOk()
            ->assertSee('Check-ins this week')
            ->assertSee('Check-ins: 3');
    }

    public function test_report_shows_rewards_redeemed_this_week(): void
    {
        $business = $this->wanChu();
        $program = $business->loyaltyPrograms()->active()->firstOrFail();
        $customer = $this->createCustomer($business, 'Reward Customer', '60133333333');

        RewardRedemption::query()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'reward_name' => $program->reward_name,
            'stamps_spent' => $program->stamps_required,
            'verified_by_user_id' => $this->wanChuOwner()->id,
            'redeemed_at' => now(),
        ]);
        RewardRedemption::query()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'reward_name' => $program->reward_name,
            'stamps_spent' => $program->stamps_required,
            'verified_by_user_id' => $this->wanChuOwner()->id,
            'redeemed_at' => now()->subWeeks(2),
        ]);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.reports.weekly', $business))
            ->assertOk()
            ->assertSee('Rewards redeemed this week')
            ->assertSee('Rewards redeemed: 1');
    }

    public function test_report_shows_feedback_summary_this_week(): void
    {
        $business = $this->wanChu();

        $this->createFeedback($business, food: 5, service: 4, price: CustomerFeedback::PRICE_CHEAP);
        $this->createFeedback($business, food: 3, service: 2, price: CustomerFeedback::PRICE_EXPENSIVE);
        $this->createFeedback($business, food: 1, service: 1, price: CustomerFeedback::PRICE_OK, submittedAt: now()->subWeeks(2));

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.reports.weekly', $business))
            ->assertOk()
            ->assertSee('Feedback submitted: 2')
            ->assertSee('Average food rating')
            ->assertSee('Average service rating')
            ->assertSee('Price Feedback Summary')
            ->assertSee('Cheap')
            ->assertSee('Expensive');
    }

    public function test_dormant_suggestion_appears_when_dormant_customers_exist(): void
    {
        $business = $this->wanChu();

        $this->createCustomer($business, 'Dormant Customer', '60144444444', now()->subDays(60));

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.reports.weekly', $business))
            ->assertOk()
            ->assertSee('Send a win-back WhatsApp follow-up to dormant customers this week.');
    }

    public function test_qr_visibility_suggestion_appears_when_check_ins_are_zero(): void
    {
        $business = $this->wanChu();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.reports.weekly', $business))
            ->assertOk()
            ->assertSee('Place the QR link more visibly and explain the reward to customers at the counter.');
    }

    public function test_price_value_suggestion_appears_when_expensive_feedback_is_high(): void
    {
        $business = $this->wanChu();

        $this->createFeedback($business, price: CustomerFeedback::PRICE_EXPENSIVE);
        $this->createFeedback($business, price: CustomerFeedback::PRICE_EXPENSIVE);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.reports.weekly', $business))
            ->assertOk()
            ->assertSee('Test a value meal or combo because several customers marked the price as expensive.');
    }

    public function test_dashboard_and_business_detail_have_report_link(): void
    {
        $business = $this->wanChu();
        $reportUrl = route('businesses.reports.weekly', $business);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.dashboard', $business))
            ->assertOk()
            ->assertSee($reportUrl, false);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.show', $business))
            ->assertOk()
            ->assertSee($reportUrl, false);
    }

    private function createCustomer(Business $business, string $name, string $whatsapp, mixed $createdAt = null): Customer
    {
        $createdAt ??= now();

        $customer = Customer::query()->create([
            'business_id' => $business->id,
            'name' => $name,
            'whatsapp_number' => $whatsapp,
        ]);

        $customer->forceFill([
            'created_at' => $createdAt,
            'updated_at' => $createdAt,
        ])->save();

        return $customer;
    }

    private function createCheckIn(Business $business, Customer $customer, int $programId, string $date): CustomerCheckIn
    {
        return CustomerCheckIn::query()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $programId,
            'check_in_date' => $date,
            'stamps_earned' => 1,
        ]);
    }

    private function createFeedback(
        Business $business,
        int $food = 5,
        int $service = 5,
        string $price = CustomerFeedback::PRICE_OK,
        mixed $submittedAt = null,
    ): CustomerFeedback {
        $submittedAt ??= now();

        return CustomerFeedback::query()->create([
            'business_id' => $business->id,
            'food_rating' => $food,
            'service_rating' => $service,
            'price_feedback' => $price,
            'submitted_at' => $submittedAt,
        ]);
    }

    private function wanChu(): Business
    {
        return Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
    }

    private function wanChuOwner(): User
    {
        return User::query()->where('email', 'owner+wanchu@fbgrowth.local')->firstOrFail();
    }
}
