<?php

namespace Tests\Feature;

use App\Models\User;
use App\Services\Ai\AiProviderManager;
use App\Services\AiActionService;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class AiProviderChainTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
        Cache::flush();
    }

    public function test_default_priority_chain_includes_free_tier_provider_order(): void
    {
        $this->assertSame([
            'openai',
            'gemini',
            'groq',
            'openrouter',
            'rule_based',
        ], app(AiProviderManager::class)->priorityChain());
    }

    public function test_openai_is_disabled_by_default(): void
    {
        $status = app(AiProviderManager::class)->status();

        $openAi = collect($status['priority_chain'])->firstWhere('name', 'openai');

        $this->assertSame('Disabled', $openAi['status']);
        $this->assertFalse($openAi['enabled']);
    }

    public function test_gemini_is_default_active_external_provider_when_configured(): void
    {
        $this->configureExternal('gemini', true, 'fake-gemini-key');
        Http::fakeSequence()->push($this->geminiResponse('Gemini external insight'), 200);

        $result = app(AiProviderManager::class)->insights($this->analyticsPayload());

        $this->assertTrue($result->successful);
        $this->assertSame('gemini', $result->providerName);
        $this->assertFalse($result->fallbackUsed);
        $this->assertSame('Gemini external insight', $result->items[0]['title']);
    }

    public function test_missing_gemini_key_skips_and_falls_back_safely(): void
    {
        $this->configureExternal('gemini', true, '');

        $result = app(AiProviderManager::class)->insights($this->analyticsPayload());

        $this->assertTrue($result->successful);
        $this->assertSame('rule_based', $result->providerName);
        $this->assertTrue($result->fallbackUsed);
        $this->assertSame('missing_key', collect($result->attempts)->firstWhere('provider', 'gemini')['reason']);
        $this->assertNotEmpty($result->items);
    }

    public function test_gemini_failure_falls_back_to_groq(): void
    {
        $this->configureExternal('gemini', true, 'fake-gemini-key');
        $this->configureExternal('groq', true, 'fake-groq-key');
        Http::fakeSequence()
            ->push(['error' => 'provider unavailable'], 500)
            ->push($this->chatResponse('Groq fallback insight'), 200);

        $result = app(AiProviderManager::class)->insights($this->analyticsPayload());

        $this->assertSame('groq', $result->providerName);
        $this->assertTrue($result->fallbackUsed);
        $this->assertSame('provider_error', collect($result->attempts)->firstWhere('provider', 'gemini')['reason']);
        $this->assertSame('Groq fallback insight', $result->items[0]['title']);
    }

    public function test_groq_failure_falls_back_to_openrouter(): void
    {
        $this->configureExternal('gemini', false, '');
        $this->configureExternal('groq', true, 'fake-groq-key');
        $this->configureExternal('openrouter', true, 'fake-openrouter-key');
        Http::fakeSequence()
            ->push(['error' => 'provider unavailable'], 500)
            ->push($this->chatResponse('OpenRouter fallback insight'), 200);

        $result = app(AiProviderManager::class)->insights($this->analyticsPayload());

        $this->assertSame('openrouter', $result->providerName);
        $this->assertTrue($result->fallbackUsed);
        $this->assertSame('provider_error', collect($result->attempts)->firstWhere('provider', 'groq')['reason']);
        $this->assertSame('OpenRouter fallback insight', $result->items[0]['title']);
    }

    public function test_openrouter_failure_falls_back_to_rule_based(): void
    {
        $this->configureExternal('gemini', false, '');
        $this->configureExternal('groq', false, '');
        $this->configureExternal('openrouter', true, 'fake-openrouter-key');
        Http::fakeSequence()->push(['error' => 'quota reached'], 429);

        $result = app(AiProviderManager::class)->insights($this->analyticsPayload());

        $this->assertSame('rule_based', $result->providerName);
        $this->assertTrue($result->fallbackUsed);
        $this->assertSame('quota_exhausted', collect($result->attempts)->firstWhere('provider', 'openrouter')['reason']);
        $this->assertNotEmpty($result->items);
    }

    public function test_all_external_disabled_or_missing_keys_still_returns_rule_based_ai_insight(): void
    {
        Config::set('ai.external_enabled', false);

        $result = app(AiProviderManager::class)->insights($this->analyticsPayload());

        $this->assertSame('rule_based', $result->providerName);
        $this->assertTrue($result->successful);
        $this->assertSame('Data gap insight', $result->items[0]['title']);
    }

    public function test_ai_action_remains_suggestion_only(): void
    {
        $result = app(AiProviderManager::class)->actions($this->analyticsPayloadWithInsight());

        $this->assertSame('suggestion_only', config('ai.action_mode'));
        $this->assertSame('rule_based', $result->providerName);
        $this->assertSame(AiActionService::STATUS_SUGGESTED, $result->items[0]['status']);
    }

    public function test_system_admin_can_see_ai_provider_status_without_secret_values(): void
    {
        Config::set('ai.providers.gemini.api_key', 'fake-gemini-configured-key');

        $admin = $this->user('admin@fbgrowth.local');

        $this->actingAs($admin)
            ->get(route('dashboards.system-admin'))
            ->assertOk()
            ->assertSee('AI Provider Status')
            ->assertSee('Active/default provider')
            ->assertSee('Gemini')
            ->assertSee('OpenAI: Disabled')
            ->assertSee('Gemini: Configured')
            ->assertSee('Groq: Missing key')
            ->assertSee('OpenRouter: Missing key')
            ->assertSee('Rule-based: Available')
            ->assertSee('Last used provider')
            ->assertSee('Suggestion Only')
            ->assertDontSee('fake-gemini-configured-key');
    }

    public function test_customer_cannot_access_ai_provider_status(): void
    {
        $customer = $this->user('customer@fbgrowth.local');

        $this->actingAs($customer)
            ->get(route('dashboards.system-admin'))
            ->assertForbidden();

        $this->actingAs($customer)
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertDontSee('AI Provider Status');
    }

    private function configureExternal(string $provider, bool $enabled, string $key): void
    {
        Config::set("ai.providers.{$provider}.enabled", $enabled);
        Config::set("ai.providers.{$provider}.api_key", $key);
    }

    /**
     * @return array<string, mixed>
     */
    private function analyticsPayload(): array
    {
        return [
            'title' => 'Business Owner Analytics',
            'scopeLabel' => 'Business analytics',
            'personaScope' => 'business',
            'summary' => [
                'Total sales/value' => 'RM 0.00',
                'Total transaction/capture' => 0,
                'Average transaction value' => 'RM 0.00',
                'Total check-ins' => 0,
            ],
            'salesAnalytics' => [],
            'customerAnalytics' => ['total' => 0, 'repeat' => 0, 'active' => 0],
            'productAnalytics' => ['lowActivity' => []],
            'branchAnalytics' => [],
            'operationAnalytics' => [],
            'rewardAnalytics' => ['Reward/stamp issued' => 0, 'Reward redeemed' => 0, 'Reward pending' => 0],
            'feedbackAnalytics' => ['Total feedback' => 0],
            'dataCompleteness' => [[
                'missing' => 'Insufficient check-in data',
                'reason' => 'Check-in masih rendah.',
                'effect' => 'Analytics repeat/active customer kurang tepat.',
                'recommendation' => 'aktifkan QR check-in di branch',
            ]],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function analyticsPayloadWithInsight(): array
    {
        return [
            ...$this->analyticsPayload(),
            'aiInsights' => [[
                'title' => 'Data gap insight',
                'explanation' => 'Data belum cukup untuk insight yang kuat.',
                'evidence' => ['Belum ada data mencukupi.'],
                'confidence' => 'low',
                'confidence_reason' => 'Data masih lemah.',
                'data_gap' => 'Sales, check-in, dan feedback masih tidak mencukupi.',
                'action_ready_context' => ['type' => 'insufficient_data'],
            ]],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function geminiResponse(string $title): array
    {
        return [
            'candidates' => [[
                'content' => [
                    'parts' => [[
                        'text' => json_encode(['insights' => [$this->externalInsight($title)]]),
                    ]],
                ],
            ]],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function chatResponse(string $title): array
    {
        return [
            'choices' => [[
                'message' => [
                    'content' => json_encode(['insights' => [$this->externalInsight($title)]]),
                ],
            ]],
        ];
    }

    /**
     * @return array<string, mixed>
     */
    private function externalInsight(string $title): array
    {
        return [
            'title' => $title,
            'explanation' => 'External provider returned a structured insight.',
            'evidence' => ['Fake HTTP response only.'],
            'confidence' => 'low',
            'confidence_reason' => 'Generated by test fake.',
            'data_gap' => 'More data required.',
            'action_ready_context' => ['type' => 'test_external'],
        ];
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
