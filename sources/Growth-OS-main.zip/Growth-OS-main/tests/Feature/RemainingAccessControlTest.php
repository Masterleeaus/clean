<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\User;
use App\Services\RoleAccessPilotGuard;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class RemainingAccessControlTest extends TestCase
{
    use RefreshDatabase;

    private User $owner;

    private User $branchManager;

    private User $combined;

    private User $customerUser;

    private User $systemAdmin;

    private User $systemManager;

    private Business $business;

    private Business $otherBusiness;

    private Branch $branch;

    private Branch $otherBranch;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);

        $this->owner = $this->user('owner+wanchu@fbgrowth.local');
        $this->branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $this->combined = $this->user('owner-branch+wanchu@fbgrowth.local');
        $this->customerUser = $this->user('customer@fbgrowth.local');
        $this->systemAdmin = $this->user('admin@fbgrowth.local');
        $this->systemManager = $this->user('manager@gos-fnb.local');
        $this->business = $this->business('wanchu-corner');
        $this->otherBusiness = $this->business('restoran-che-na');
        $this->branch = $this->branch('WANCHU-MAIN');
        $this->otherBranch = $this->branch('CHENA-MAIN');
    }

    public function test_business_owner_access_control_scope_lp_ac_bo_01_to_15(): void
    {
        $checkIn = $this->pendingCheckIn($this->branch);
        $product = $this->product($this->branch);

        $this->actingAs($this->owner)->get(route('dashboards.business-owner'))
            ->assertOk()
            ->assertSee('Business Owner Dashboard')
            ->assertSee('Branches Summary')
            ->assertDontSee('Branch Operations')
            ->assertDontSee('Customer Portal')
            ->assertDontSee('System Admin Dashboard')
            ->assertDontSee('System Manager Dashboard');

        $this->actingAs($this->owner)->get(route('businesses.show', $this->business))
            ->assertOk()
            ->assertSee('WanChu Corner');

        $this->actingAs($this->owner)->get(route('businesses.branches.show', ['business' => $this->business, 'branch' => $this->branch]))
            ->assertOk()
            ->assertSee($this->branch->name);

        $this->actingAs($this->owner)->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Business Owner Analytics')
            ->assertSee('AI Insight Engine')
            ->assertSee('AI Action Engine')
            ->assertDontSee('System Admin Analytics')
            ->assertDontSee('System Manager Analytics');

        $this->actingAs($this->owner)->get(route('businesses.show', $this->otherBusiness))->assertForbidden();
        $this->actingAs($this->owner)->get(route('businesses.branches.show', ['business' => $this->otherBusiness, 'branch' => $this->otherBranch]))->assertForbidden();
        $this->actingAs($this->owner)->get(route('dashboards.system-admin'))->assertForbidden();
        $this->actingAs($this->owner)->get(route('dashboards.system-manager'))->assertForbidden();
        $this->actingAs($this->owner)->get(route('customer.portal'))->assertForbidden();

        $this->actingAs($this->owner)->get(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]))->assertForbidden();
        $this->actingAs($this->owner)->post(route('businesses.branches.check-ins.product-services.store', [
            'business' => $this->business,
            'branch' => $this->branch,
            'checkIn' => $checkIn,
        ]), [
            'product_service_id' => $product->id,
            'quantity' => 1,
            'capture_type' => 'purchase',
        ])->assertForbidden();
        $this->actingAs($this->owner)->patch(route('businesses.branches.check-ins.no-purchase', [
            'business' => $this->business,
            'branch' => $this->branch,
            'checkIn' => $checkIn,
        ]))->assertForbidden();

        $invite = app(RoleAccessPilotGuard::class)->validateBusinessOwnerInvite($this->owner, $this->business, User::ROLE_CUSTOMER);
        $this->assertFalse($invite['allowed']);
        $this->assertContains('Business Owner cannot create Customer manually. Customer onboarding must be organic.', $invite['errors']);
    }

    public function test_branch_manager_access_control_scope_lp_ac_bm_01_to_15(): void
    {
        $captureCheckIn = $this->pendingCheckIn($this->branch);
        $noPurchaseCheckIn = $this->pendingCheckIn($this->branch);
        $product = $this->product($this->branch);

        $this->actingAs($this->branchManager)->get(route('dashboards.branch-manager'))
            ->assertOk()
            ->assertSee('Branch Manager Dashboard')
            ->assertSee('Pending Purchase Capture')
            ->assertDontSee('Business Performance')
            ->assertDontSee('Customer Portal')
            ->assertDontSee('System Admin Dashboard')
            ->assertDontSee('System Manager Dashboard');

        $this->actingAs($this->branchManager)->get(route('businesses.branches.show', ['business' => $this->business, 'branch' => $this->branch]))
            ->assertOk()
            ->assertSee($this->branch->name);

        $this->actingAs($this->branchManager)->get(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]))
            ->assertOk()
            ->assertSee('Branch Check-ins')
            ->assertSee('Capture Purchase');

        $this->actingAs($this->branchManager)->post(route('businesses.branches.check-ins.product-services.store', [
            'business' => $this->business,
            'branch' => $this->branch,
            'checkIn' => $captureCheckIn,
        ]), [
            'product_service_id' => $product->id,
            'quantity' => 1,
            'capture_type' => 'purchase',
            'capture_reference' => 'bm-capture-'.$captureCheckIn->id,
        ])->assertRedirect(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]));

        $this->actingAs($this->branchManager)->patch(route('businesses.branches.check-ins.no-purchase', [
            'business' => $this->business,
            'branch' => $this->branch,
            'checkIn' => $noPurchaseCheckIn,
        ]))->assertRedirect(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]));

        $this->actingAs($this->branchManager)->get(route('businesses.branches.feedback', ['business' => $this->business, 'branch' => $this->branch]))->assertOk();
        $this->actingAs($this->branchManager)->get(route('businesses.branches.rewards.index', ['business' => $this->business, 'branch' => $this->branch]))->assertOk();

        $this->actingAs($this->branchManager)->get(route('dashboards.business-owner'))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('businesses.dashboard', $this->business))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('businesses.branches.show', ['business' => $this->otherBusiness, 'branch' => $this->otherBranch]))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('businesses.show', $this->otherBusiness))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('dashboards.system-admin'))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('dashboards.system-manager'))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('customer.portal'))->assertForbidden();
    }

    public function test_business_owner_branch_manager_access_control_scope_lp_ac_bobm_01_to_15(): void
    {
        $captureCheckIn = $this->pendingCheckIn($this->branch);
        $noPurchaseCheckIn = $this->pendingCheckIn($this->branch);
        $product = $this->product($this->branch);
        $unassignedOwnBusinessBranch = Branch::factory()->create([
            'business_id' => $this->business->id,
            'name' => 'WanChu Unassigned Branch',
            'code' => 'WANCHU-UNASSIGNED-ACCESS',
            'is_active' => true,
        ]);

        $this->actingAs($this->combined)->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Business Owner / Branch Manager Dashboard')
            ->assertSee('Business Performance')
            ->assertSee('Branch Operations')
            ->assertSee($this->branch->name)
            ->assertDontSee('System Admin Dashboard')
            ->assertDontSee('System Manager Dashboard')
            ->assertDontSee('Customer Portal');

        $this->actingAs($this->combined)->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Business Owner / Branch Manager Analytics')
            ->assertSee('AI Insight Engine')
            ->assertSee('AI Action Engine');

        $this->actingAs($this->combined)->get(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]))
            ->assertOk()
            ->assertSee('Capture Purchase');

        $this->actingAs($this->combined)->post(route('businesses.branches.check-ins.product-services.store', [
            'business' => $this->business,
            'branch' => $this->branch,
            'checkIn' => $captureCheckIn,
        ]), [
            'product_service_id' => $product->id,
            'quantity' => 1,
            'capture_type' => 'purchase',
            'capture_reference' => 'bobm-capture-'.$captureCheckIn->id,
        ])->assertRedirect(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]));

        $this->actingAs($this->combined)->patch(route('businesses.branches.check-ins.no-purchase', [
            'business' => $this->business,
            'branch' => $this->branch,
            'checkIn' => $noPurchaseCheckIn,
        ]))->assertRedirect(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]));

        $this->actingAs($this->combined)->get(route('businesses.show', $this->otherBusiness))->assertForbidden();
        $this->actingAs($this->combined)->get(route('businesses.branches.show', ['business' => $this->business, 'branch' => $unassignedOwnBusinessBranch]))->assertForbidden();
        $this->actingAs($this->combined)->get(route('dashboards.system-admin'))->assertForbidden();
        $this->actingAs($this->combined)->get(route('dashboards.system-manager'))->assertForbidden();
        $this->actingAs($this->combined)->get(route('customer.portal'))->assertForbidden();

        $invite = app(RoleAccessPilotGuard::class)->validateBusinessOwnerInvite($this->combined, $this->business, User::ROLE_CUSTOMER);
        $this->assertFalse($invite['allowed']);
        $this->assertContains('Business Owner cannot create Customer manually. Customer onboarding must be organic.', $invite['errors']);
    }

    public function test_customer_access_control_scope_lp_ac_cust_01_to_17(): void
    {
        $checkIn = $this->pendingCheckIn($this->branch, $this->customerUser);
        $product = $this->product($this->branch);
        $otherCustomer = Customer::factory()->create([
            'business_id' => $this->business->id,
            'name' => 'Other Access Customer',
            'whatsapp_number' => '60129998888',
        ]);
        CustomerFeedback::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => $otherCustomer->id,
            'comment' => 'Other customer feedback.',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'submitted_at' => now(),
        ]);

        $this->actingAs($this->customerUser)->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Customer Portal')
            ->assertSee('Reward/Loyalty Status')
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Pending Feedback')
            ->assertDontSee('System Admin Dashboard')
            ->assertDontSee('System Manager Dashboard')
            ->assertDontSee('Business Owner Dashboard')
            ->assertDontSee('Branch Manager Dashboard');

        $this->actingAs($this->customerUser)->get(route('customer.rewards'))->assertOk();
        $this->actingAs($this->customerUser)->get(route('customer.feedback'))
            ->assertOk()
            ->assertSee('Hantar Maklumbalas')
            ->assertDontSee('Pending Feedback')
            ->assertDontSee('Other customer feedback.');
        $this->actingAs($this->customerUser)->post(route('customer.feedback.store'), [
            'branch_id' => $this->branch->id,
            'rating' => 5,
            'comment' => 'Customer access feedback is clear.',
        ])->assertRedirect(route('customer.feedback'));

        $this->actingAs($this->customerUser)->get(route('dashboards.business-owner'))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('businesses.show', $this->business))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('dashboards.branch-manager'))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('dashboards.system-admin'))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('dashboards.system-manager'))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('analytics.index'))->assertForbidden();
        $this->actingAs($this->customerUser)->post(route('businesses.branches.check-ins.product-services.store', [
            'business' => $this->business,
            'branch' => $this->branch,
            'checkIn' => $checkIn,
        ]), [
            'product_service_id' => $product->id,
            'quantity' => 1,
            'capture_type' => 'purchase',
        ])->assertForbidden();
        $this->actingAs($this->customerUser)->patch(route('businesses.branches.check-ins.no-purchase', [
            'business' => $this->business,
            'branch' => $this->branch,
            'checkIn' => $checkIn,
        ]))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('customer.feedback'))
            ->assertOk()
            ->assertSee('Customer access feedback is clear.')
            ->assertDontSee('Other customer feedback.');
    }

    public function test_cross_persona_final_access_review_lp_ac_final_01_to_15(): void
    {
        $this->assertDashboardRedirects();
        $this->assertLogoutBlocksProtectedSurfaces();

        $this->actingAs($this->systemManager)->get(route('dashboards.system-admin'))->assertForbidden();
        $this->actingAs($this->systemAdmin)->get(route('dashboards.system-manager'))->assertForbidden();
        $this->actingAs($this->owner)->get(route('businesses.show', $this->otherBusiness))->assertForbidden();
        $this->actingAs($this->branchManager)->get(route('businesses.show', $this->otherBusiness))->assertForbidden();
        $this->actingAs($this->combined)->get(route('businesses.show', $this->otherBusiness))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('analytics.index'))->assertForbidden();

        $checkIn = $this->pendingCheckIn($this->branch);
        $product = $this->product($this->branch);
        foreach ([$this->systemManager, $this->systemAdmin, $this->owner, $this->customerUser] as $blockedUser) {
            $this->actingAs($blockedUser)->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $this->business,
                'branch' => $this->branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
                'capture_reference' => 'blocked-'.$blockedUser->id,
            ])->assertForbidden();
        }

        $this->actingAs($this->branchManager)->post(route('businesses.branches.check-ins.product-services.store', [
            'business' => $this->business,
            'branch' => $this->branch,
            'checkIn' => $checkIn,
        ]), [
            'product_service_id' => $product->id,
            'quantity' => 1,
            'capture_type' => 'purchase',
            'capture_reference' => 'final-allowed-'.$checkIn->id,
        ])->assertRedirect();

        $this->actingAs($this->systemManager)->get(route('analytics.index'))->assertOk()->assertSee('System Manager Analytics');
        $this->actingAs($this->systemAdmin)->get(route('analytics.index'))->assertOk()->assertSee('System Admin Analytics');
        $this->actingAs($this->owner)->get(route('analytics.index'))->assertOk()->assertSee('Business Owner Analytics');
        $this->actingAs($this->branchManager)->get(route('analytics.index'))->assertOk()->assertSee('Branch Manager Analytics');
        $this->actingAs($this->customerUser)->get(route('analytics.index'))->assertForbidden();

        $guard = app(RoleAccessPilotGuard::class);
        $this->assertTrue($guard->validateControlledPilotSetup(
            actor: $this->systemAdmin,
            target: User::factory()->create(['role' => User::ROLE_BRANCH_MANAGER]),
            business: $this->business,
            branchIds: [$this->branch->id],
            primaryRole: User::ROLE_BRANCH_MANAGER,
        )['allowed']);
        $this->assertFalse($guard->validateBusinessOwnerInvite($this->owner, $this->business, User::ROLE_CUSTOMER)['allowed']);
    }

    private function assertDashboardRedirects(): void
    {
        $cases = [
            [$this->systemManager, 'dashboards.system-manager'],
            [$this->systemAdmin, 'dashboards.system-admin'],
            [$this->owner, 'dashboards.business-owner'],
            [$this->branchManager, 'dashboards.branch-manager'],
            [$this->combined, 'dashboards.business-branch-combined'],
            [$this->customerUser, 'customer.portal'],
        ];

        foreach ($cases as [$user, $routeName]) {
            $this->actingAs($user)->get(route('dashboard'))->assertRedirect(route($routeName));
        }
    }

    private function assertLogoutBlocksProtectedSurfaces(): void
    {
        $this->actingAs($this->owner)->post(route('logout'))->assertRedirect('/');

        $this->get(route('dashboards.business-owner'))->assertRedirect(route('login'));
        $this->get(route('customer.portal'))->assertRedirect(route('login'));
        $this->get(route('analytics.index'))->assertRedirect(route('login'));
    }

    private function pendingCheckIn(Branch $branch, ?User $user = null): CustomerCheckIn
    {
        $customer = $user
            ? Customer::query()->where('user_id', $user->id)->where('business_id', $branch->business_id)->firstOrFail()
            : Customer::query()->where('business_id', $branch->business_id)->firstOrFail();

        return CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'user_id' => $user?->id,
            'loyalty_program_id' => $branch->business->loyaltyPrograms()->active()->first()?->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'remaining_access_control_test',
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);
    }

    private function product(Branch $branch): ProductService
    {
        return ProductService::query()
            ->visibleForBranch($branch)
            ->active()
            ->firstOrFail();
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function business(string $slug): Business
    {
        return Business::query()->where('slug', $slug)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business')->where('code', $code)->firstOrFail();
    }
}
