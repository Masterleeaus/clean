<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class LoginLogoutPilotTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_login_page_has_clear_required_fields_and_validation(): void
    {
        $this->get(route('login'))
            ->assertOk()
            ->assertSee('Log in to GOS-F&B')
            ->assertSee('name="email"', false)
            ->assertSee('name="password"', false)
            ->assertSee('Log in');

        $this->post(route('login'), [
            'email' => '',
            'password' => '',
        ])->assertSessionHasErrors(['email', 'password']);

        $this->post(route('login'), [
            'email' => 'manager@gos-fnb.local',
            'password' => 'wrong-local-test-password',
        ])->assertSessionHasErrors('email');

        $this->assertGuest();
    }

    public function test_branch_manager_dashboard_menu_uses_branch_scope_not_owner_scope(): void
    {
        $branchManager = User::query()->where('email', 'branch+wanchu@fbgrowth.local')->firstOrFail();
        $business = Business::query()->where('slug', 'wanchu-corner')->firstOrFail();

        $this->actingAs($branchManager)
            ->get(route('dashboards.branch-manager'))
            ->assertOk()
            ->assertSee('Branch Manager Dashboard')
            ->assertSee('Assigned Branch Overview')
            ->assertSee('Branch Check-ins')
            ->assertDontSee('Business Owner', false)
            ->assertDontSee('Business / QR & Check-in')
            ->assertDontSee('href="'.route('businesses.index').'"', false)
            ->assertDontSee('href="'.route('businesses.show', $business).'"', false);
    }
}
