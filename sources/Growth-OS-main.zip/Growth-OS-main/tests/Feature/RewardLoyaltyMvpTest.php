<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Customer;
use App\Models\CustomerLoyaltyAccount;
use App\Models\ProductService;
use App\Models\RewardRedemption;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class RewardLoyaltyMvpTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_valid_check_in_updates_customer_reward_progress(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->customerCheckIn($customerUser, $branch)->assertOk();
        $this->captureProductForLatestCheckIn($branch);

        $account = CustomerLoyaltyAccount::query()
            ->whereHas('customer', fn ($query) => $query->where('user_id', $customerUser->id))
            ->firstOrFail();

        $this->assertSame(1, $account->current_stamps);
        $this->assertSame(1, $account->total_stamps_earned);
    }

    public function test_duplicate_blocked_check_in_does_not_increase_reward_progress(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->customerCheckIn($customerUser, $branch)->assertOk();
        $this->captureProductForLatestCheckIn($branch);
        $this->travel(30)->minutes();
        $this->customerCheckIn($customerUser, $branch)->assertOk()->assertSee('Cooldown belum selesai');

        $account = CustomerLoyaltyAccount::query()->firstOrFail();

        $this->assertSame(1, $account->current_stamps);
        $this->assertSame(1, $account->total_stamps_earned);
    }

    public function test_customer_can_view_own_reward_status(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->customerCheckIn($customerUser, $branch)->assertOk();
        $this->captureProductForLatestCheckIn($branch);

        $this->actingAs($customerUser)
            ->get(route('customer.rewards'))
            ->assertOk()
            ->assertSee('Reward/Loyalty')
            ->assertSee('WanChu Corner')
            ->assertSee('In progress');
    }

    public function test_customer_cannot_view_other_customer_reward_status(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $otherCustomerUser = User::factory()->create([
            'role' => User::ROLE_CUSTOMER,
            'email' => 'other-customer@example.com',
        ]);
        $branch = $this->branch('WANCHU-MAIN');

        $this->customerCheckIn($customerUser, $branch)->assertOk();
        $this->captureProductForLatestCheckIn($branch);

        $this->actingAs($otherCustomerUser)
            ->get(route('customer.rewards'))
            ->assertOk()
            ->assertDontSee('WanChu Corner');
    }

    public function test_business_owner_can_view_reward_loyalty_for_owned_business(): void
    {
        $owner = $this->user('owner+wanchu@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->customerCheckIn($this->user('customer@fbgrowth.local'), $branch)->assertOk();
        $this->captureProductForLatestCheckIn($branch);

        $this->actingAs($owner)
            ->get(route('businesses.rewards.index', $branch->business))
            ->assertOk()
            ->assertSee('Business Reward/Loyalty')
            ->assertSee('GOS-F&B Demo Customer');
    }

    public function test_branch_manager_can_view_only_assigned_branch_reward_loyalty(): void
    {
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $assignedBranch = $this->branch('WANCHU-MAIN');
        $otherBranch = $this->branch('CHENA-MAIN');

        $this->customerCheckIn($this->user('customer@fbgrowth.local'), $assignedBranch)->assertOk();
        $this->captureProductForLatestCheckIn($assignedBranch);

        $this->actingAs($branchManager)
            ->get(route('businesses.branches.rewards.index', ['business' => $assignedBranch->business, 'branch' => $assignedBranch]))
            ->assertOk()
            ->assertSee('GOS-F&B Demo Customer');

        $this->actingAs($branchManager)
            ->get(route('businesses.branches.rewards.index', ['business' => $otherBranch->business, 'branch' => $otherBranch]))
            ->assertForbidden();
    }

    public function test_redemption_can_be_recorded(): void
    {
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');
        $customer = $this->eligibleCustomer($branch);

        $this->actingAs($branchManager)
            ->post(route('businesses.branches.rewards.redeem', [
                'business' => $branch->business,
                'branch' => $branch,
                'customer' => $customer,
            ]))
            ->assertRedirect(route('businesses.branches.rewards.index', ['business' => $branch->business, 'branch' => $branch]));

        $this->assertDatabaseHas('reward_redemptions', [
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'verified_by_user_id' => $branchManager->id,
        ]);

        $this->assertSame(0, $customer->loyaltyAccounts()->firstOrFail()->current_stamps);
        $this->assertSame(1, RewardRedemption::query()->count());
    }

    public function test_customer_cannot_access_business_admin_reward_surfaces(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($customerUser)
            ->get(route('businesses.rewards.index', $branch->business))
            ->assertForbidden();

        $this->actingAs($customerUser)
            ->get(route('businesses.branches.rewards.index', ['business' => $branch->business, 'branch' => $branch]))
            ->assertForbidden();
    }

    private function eligibleCustomer(Branch $branch): Customer
    {
        $customer = Customer::query()->where('business_id', $branch->business_id)->firstOrFail();
        $program = $branch->business->loyaltyPrograms()->active()->firstOrFail();

        CustomerLoyaltyAccount::query()->updateOrCreate(
            [
                'business_id' => $branch->business_id,
                'customer_id' => $customer->id,
                'loyalty_program_id' => $program->id,
            ],
            [
                'current_stamps' => $program->stamps_required,
                'total_stamps_earned' => $program->stamps_required,
            ],
        );

        return $customer;
    }

    private function customerCheckIn(User $customerUser, Branch $branch)
    {
        return $this->actingAs($customerUser)
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
            ]);
    }

    private function captureProductForLatestCheckIn(Branch $branch): void
    {
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $product = ProductService::query()
            ->where('business_id', $branch->business_id)
            ->where(function ($query) use ($branch): void {
                $query->whereNull('branch_id')->orWhere('branch_id', $branch->id);
            })
            ->firstOrFail();
        $checkIn = $branch->checkIns()->latest()->firstOrFail();

        $this->actingAs($branchManager)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
            ])
            ->assertRedirect();
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business.loyaltyPrograms')->where('code', $code)->firstOrFail();
    }
}
