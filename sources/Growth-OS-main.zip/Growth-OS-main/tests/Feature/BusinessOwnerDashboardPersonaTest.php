<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\User;
use App\Services\RoleAccessPilotGuard;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BusinessOwnerDashboardPersonaTest extends TestCase
{
    use RefreshDatabase;

    private User $owner;

    private Business $business;

    private Business $otherBusiness;

    private Branch $branch;

    private Branch $otherBranch;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);

        $this->owner = User::query()->where('email', 'owner+wanchu@fbgrowth.local')->firstOrFail();
        $this->business = Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
        $this->otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();
        $this->branch = Branch::query()->where('code', 'WANCHU-MAIN')->firstOrFail();
        $this->otherBranch = Branch::query()->where('code', 'CHENA-MAIN')->firstOrFail();
    }

    public function test_business_owner_dashboard_is_business_performance_scoped(): void
    {
        $this->createActivity($this->branch, 'Owner dashboard feedback.');
        $this->createActivity($this->otherBranch, 'Hidden other business feedback.');

        $this->actingAs($this->owner)
            ->get(route('dashboards.business-owner'))
            ->assertOk()
            ->assertSee('Business Owner Dashboard')
            ->assertSee('performance business milik anda')
            ->assertSee('Branches Summary')
            ->assertSee('Product/Service captured')
            ->assertSee('Reward/Loyalty Summary')
            ->assertSee('Recent Feedback')
            ->assertSee($this->branch->name)
            ->assertSee('Owner dashboard feedback.')
            ->assertSee('Business Profile / QR')
            ->assertDontSee($this->otherBranch->name)
            ->assertDontSee($this->otherBusiness->name)
            ->assertDontSee('Hidden other business feedback.')
            ->assertDontSee('Business Owner / Branch Manager')
            ->assertDontSee('Branch Operations')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Mark No Purchase')
            ->assertDontSee('Redeem Reward')
            ->assertDontSee('Customer Portal')
            ->assertDontSee('System Manager Dashboard')
            ->assertDontSee('System Admin Dashboard')
            ->assertDontSee('AI Provider Status');
    }

    public function test_business_owner_analytics_and_ai_are_own_business_only_and_suggestion_only(): void
    {
        $this->createActivity($this->branch, 'Owner analytics feedback.');
        $this->createActivity($this->otherBranch, 'Hidden analytics feedback.');

        $this->actingAs($this->owner)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Business Owner Analytics')
            ->assertSee('AI Insight Engine')
            ->assertSee('AI Action Engine')
            ->assertSee('Human review diperlukan')
            ->assertSee($this->branch->name)
            ->assertDontSee($this->otherBranch->name)
            ->assertDontSee('Hidden analytics feedback.')
            ->assertDontSee('System Manager Analytics')
            ->assertDontSee('System Admin Analytics')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Auto Execute')
            ->assertDontSee('Send Campaign')
            ->assertDontSee('Send Message');
    }

    public function test_business_owner_is_blocked_from_other_persona_and_branch_operation_actions(): void
    {
        $checkIn = $this->pendingCheckIn($this->branch);
        $product = ProductService::query()->where('business_id', $this->business->id)->firstOrFail();

        $this->actingAs($this->owner)->get(route('dashboards.system-manager'))->assertForbidden();
        $this->actingAs($this->owner)->get(route('dashboards.system-admin'))->assertForbidden();
        $this->actingAs($this->owner)->get(route('customer.portal'))->assertForbidden();
        $this->actingAs($this->owner)->get(route('businesses.show', $this->otherBusiness))->assertForbidden();
        $this->actingAs($this->owner)->get(route('businesses.branches.show', [
            'business' => $this->otherBusiness,
            'branch' => $this->otherBranch,
        ]))->assertForbidden();
        $this->actingAs($this->owner)->get(route('businesses.branches.check-ins', [
            'business' => $this->business,
            'branch' => $this->branch,
        ]))->assertForbidden();
        $this->actingAs($this->owner)->post(route('businesses.branches.check-ins.product-services.store', [
            'business' => $this->business,
            'branch' => $this->branch,
            'checkIn' => $checkIn,
        ]), [
            'product_service_id' => $product->id,
            'quantity' => 1,
            'capture_type' => 'purchase',
        ])->assertForbidden();
        $this->actingAs($this->owner)->patch(route('businesses.branches.check-ins.no-purchase', [
            'business' => $this->business,
            'branch' => $this->branch,
            'checkIn' => $checkIn,
        ]))->assertForbidden();
    }

    public function test_business_owner_controlled_pilot_user_setup_rules_are_enforced(): void
    {
        $guard = app(RoleAccessPilotGuard::class);

        $customerInvite = $guard->validateBusinessOwnerInvite($this->owner, $this->business, User::ROLE_CUSTOMER);
        $systemAdminInvite = $guard->validateBusinessOwnerInvite($this->owner, $this->business, User::ROLE_SYSTEM_ADMIN);
        $systemManagerInvite = $guard->validateBusinessOwnerInvite($this->owner, $this->business, User::ROLE_SYSTEM_MANAGER);
        $otherBusinessInvite = $guard->validateBusinessOwnerInvite($this->owner, $this->otherBusiness, User::ROLE_BRANCH_MANAGER);

        $this->assertFalse($customerInvite['allowed']);
        $this->assertFalse($systemAdminInvite['allowed']);
        $this->assertFalse($systemManagerInvite['allowed']);
        $this->assertFalse($otherBusinessInvite['allowed']);
        $this->assertContains('Business Owner cannot create Customer manually. Customer onboarding must be organic.', $customerInvite['errors']);
        $this->assertContains('Business Owner cannot assign System Admin, System Manager, or another Business Owner role.', $systemAdminInvite['errors']);
        $this->assertContains('Business Owner cannot assign System Admin, System Manager, or another Business Owner role.', $systemManagerInvite['errors']);
    }

    private function createActivity(Branch $branch, string $feedbackComment): void
    {
        $business = $branch->business;
        $customer = Customer::query()->create([
            'business_id' => $business->id,
            'name' => 'Owner Persona Customer '.uniqid(),
            'whatsapp_number' => '601'.random_int(100000000, 999999999),
        ]);
        $program = $business->loyaltyPrograms()->active()->firstOrFail();
        $checkIn = CustomerCheckIn::query()->create([
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'stamps_earned' => 0,
            'source' => 'business_owner_persona_review',
            'check_in_type' => 'physical',
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
        ]);
        $product = ProductService::query()->updateOrCreate(
            ['business_id' => $business->id, 'name' => 'Owner Persona Set'],
            ['branch_id' => $branch->id, 'category' => 'food', 'type' => 'product', 'price' => 12.00, 'is_active' => true],
        );

        CustomerFeedback::query()->create([
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'rating' => 4,
            'comment' => $feedbackComment,
            'source' => 'business_owner_persona_review',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'summary_issue_category' => 'positive_feedback',
            'submitted_at' => now(),
        ]);
    }

    private function pendingCheckIn(Branch $branch): CustomerCheckIn
    {
        $customer = Customer::query()->where('business_id', $branch->business_id)->firstOrFail();

        return CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $branch->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'business_owner_persona_review',
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);
    }
}
