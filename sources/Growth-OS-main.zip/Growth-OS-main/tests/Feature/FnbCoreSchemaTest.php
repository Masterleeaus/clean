<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerLoyaltyAccount;
use App\Models\LoyaltyProgram;
use Illuminate\Database\QueryException;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FnbCoreSchemaTest extends TestCase
{
    use RefreshDatabase;

    public function test_same_whatsapp_cannot_register_twice_in_the_same_business(): void
    {
        $business = Business::factory()->create();

        Customer::factory()->create([
            'business_id' => $business->id,
            'whatsapp_number' => '60123456789',
        ]);

        $this->expectException(QueryException::class);

        Customer::factory()->create([
            'business_id' => $business->id,
            'whatsapp_number' => '60123456789',
        ]);
    }

    public function test_same_whatsapp_can_register_in_different_businesses(): void
    {
        $firstBusiness = Business::factory()->create();
        $secondBusiness = Business::factory()->create();

        Customer::factory()->create([
            'business_id' => $firstBusiness->id,
            'whatsapp_number' => '60123456789',
        ]);

        Customer::factory()->create([
            'business_id' => $secondBusiness->id,
            'whatsapp_number' => '60123456789',
        ]);

        $this->assertSame(2, Customer::query()->where('whatsapp_number', '60123456789')->count());
    }

    public function test_business_slug_is_unique(): void
    {
        Business::factory()->create(['slug' => 'wanchu-corner']);

        $this->expectException(QueryException::class);

        Business::factory()->create(['slug' => 'wanchu-corner']);
    }

    public function test_loyalty_account_uniqueness(): void
    {
        [$business, $customer, $program] = $this->businessCustomerAndProgram();

        CustomerLoyaltyAccount::factory()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
        ]);

        $this->expectException(QueryException::class);

        CustomerLoyaltyAccount::factory()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
        ]);
    }

    public function test_one_check_in_per_customer_per_business_per_day_constraint(): void
    {
        [$business, $customer, $program] = $this->businessCustomerAndProgram();

        CustomerCheckIn::factory()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => '2026-06-26',
        ]);

        $this->expectException(QueryException::class);

        CustomerCheckIn::factory()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => '2026-06-26',
        ]);
    }

    private function businessCustomerAndProgram(): array
    {
        $business = Business::factory()->create();
        $customer = Customer::factory()->create(['business_id' => $business->id]);
        $program = LoyaltyProgram::factory()->create(['business_id' => $business->id]);

        return [$business, $customer, $program];
    }
}
