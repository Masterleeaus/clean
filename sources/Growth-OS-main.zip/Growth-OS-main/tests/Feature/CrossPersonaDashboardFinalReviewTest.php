<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CrossPersonaDashboardFinalReviewTest extends TestCase
{
    use RefreshDatabase;

    private User $systemManager;

    private User $systemAdmin;

    private User $owner;

    private User $branchManager;

    private User $combined;

    private User $customerUser;

    private Business $business;

    private Business $otherBusiness;

    private Branch $branch;

    private Branch $otherBranch;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);

        $this->systemManager = $this->user('manager@gos-fnb.local');
        $this->systemAdmin = $this->user('admin@fbgrowth.local');
        $this->owner = $this->user('owner+wanchu@fbgrowth.local');
        $this->branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $this->combined = $this->user('owner-branch+wanchu@fbgrowth.local');
        $this->customerUser = $this->user('customer@fbgrowth.local');
        $this->business = $this->business('wanchu-corner');
        $this->otherBusiness = $this->business('restoran-che-na');
        $this->branch = $this->branch('WANCHU-MAIN');
        $this->otherBranch = $this->branch('CHENA-MAIN');
    }

    public function test_dashboard_entry_points_and_menus_stay_persona_scoped(): void
    {
        foreach ([
            [$this->systemManager, 'dashboards.system-manager'],
            [$this->systemAdmin, 'dashboards.system-admin'],
            [$this->owner, 'dashboards.business-owner'],
            [$this->branchManager, 'dashboards.branch-manager'],
            [$this->combined, 'dashboards.business-branch-combined'],
            [$this->customerUser, 'customer.portal'],
        ] as [$user, $routeName]) {
            $this->actingAs($user)->get(route('dashboard'))->assertRedirect(route($routeName));
        }

        $this->actingAs($this->systemManager)
            ->get(route('dashboards.system-manager'))
            ->assertOk()
            ->assertSee('System Manager Dashboard')
            ->assertSee('Strategic platform performance')
            ->assertSee('Platform Links')
            ->assertDontSee('Businesses')
            ->assertDontSee('Business setup')
            ->assertDontSee('Branch Operations')
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Customer Portal');

        $this->actingAs($this->systemAdmin)
            ->get(route('dashboards.system-admin'))
            ->assertOk()
            ->assertSee('System Admin Dashboard')
            ->assertSee('System setup, admin support')
            ->assertSee('Admin Links')
            ->assertSee('Business setup')
            ->assertSee('AI Provider Status')
            ->assertDontSee('Platform Analytics / AI')
            ->assertDontSee('Business Performance')
            ->assertDontSee('Branch Operations')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Customer Portal');

        $this->actingAs($this->owner)
            ->get(route('dashboards.business-owner'))
            ->assertOk()
            ->assertSee('Business Owner Dashboard')
            ->assertSee('performance business milik anda')
            ->assertSee('Business Profile / QR')
            ->assertSee($this->branch->name)
            ->assertDontSee('Branch Operations')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Mark No Purchase')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Customer Portal');

        $this->actingAs($this->branchManager)
            ->get(route('dashboards.branch-manager'))
            ->assertOk()
            ->assertSee('Branch Manager Dashboard')
            ->assertSee('assigned sahaja')
            ->assertSee('Pending Purchase Capture')
            ->assertSee('Branch Analytics / AI Insight / AI Action')
            ->assertSee($this->branch->name)
            ->assertDontSee('Business Owner cum Branch Manager')
            ->assertDontSee('Business Performance')
            ->assertDontSee('Business Profile / QR')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Customer Portal');

        $this->actingAs($this->combined)
            ->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Business Owner / Branch Manager Dashboard')
            ->assertSee('Business Performance')
            ->assertSee('Branch Operations')
            ->assertSee('Capture Purchase / Mark No Purchase')
            ->assertSee($this->branch->name)
            ->assertDontSee('System Manager Dashboard')
            ->assertDontSee('System Admin Dashboard')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Customer Portal');

        $this->actingAs($this->customerUser)
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Customer Portal')
            ->assertSee('Hantar Maklumbalas')
            ->assertSee('Customer Check-in')
            ->assertSee('bukan POS atau ordering system')
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Mark No Purchase')
            ->assertDontSee('Analytics')
            ->assertDontSee('AI Insight')
            ->assertDontSee('AI Action')
            ->assertDontSee('AI Provider Status');
    }

    public function test_cross_persona_data_isolation_is_preserved(): void
    {
        $unassignedOwnBranch = Branch::factory()->create([
            'business_id' => $this->business->id,
            'name' => 'WanChu Final Review Hidden Ops Branch',
            'code' => 'WANCHU-FINAL-HIDDEN-OPS',
            'is_active' => true,
        ]);

        $this->feedbackForBranch($this->branch, 'Final assigned branch feedback.');
        $this->feedbackForBranch($unassignedOwnBranch, 'Final owner-only branch feedback.');
        $this->feedbackForBranch($this->otherBranch, 'Final other business feedback.');

        $this->actingAs($this->owner)
            ->get(route('dashboards.business-owner'))
            ->assertOk()
            ->assertSee('Final assigned branch feedback.')
            ->assertSee('Final owner-only branch feedback.')
            ->assertDontSee('Final other business feedback.')
            ->assertDontSee($this->otherBusiness->name);

        $this->actingAs($this->branchManager)
            ->get(route('dashboards.branch-manager'))
            ->assertOk()
            ->assertSee('Final assigned branch feedback.')
            ->assertDontSee('Final owner-only branch feedback.')
            ->assertDontSee($unassignedOwnBranch->name)
            ->assertDontSee('Final other business feedback.');

        $combinedResponse = $this->actingAs($this->combined)
            ->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Final assigned branch feedback.')
            ->assertSee('Final owner-only branch feedback.')
            ->assertDontSee('Final other business feedback.');

        $branchOperations = $this->htmlBetween($combinedResponse->getContent(), 'id="branch-operations"', '</section>');
        $this->assertStringContainsString($this->branch->name, $branchOperations);
        $this->assertStringNotContainsString($unassignedOwnBranch->name, $branchOperations);
        $this->assertStringNotContainsString($this->otherBranch->name, $branchOperations);

        $customer = $this->customerForUser($this->customerUser);
        CustomerFeedback::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => $customer->id,
            'comment' => 'Final own customer feedback.',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'submitted_at' => now(),
        ]);
        CustomerFeedback::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => Customer::factory()->create(['business_id' => $this->business->id])->id,
            'comment' => 'Final other customer feedback.',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'submitted_at' => now(),
        ]);

        $this->actingAs($this->customerUser)
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Final own customer feedback.')
            ->assertDontSee('Final other customer feedback.');
    }

    public function test_actions_ai_provider_status_and_customer_flow_are_role_locked(): void
    {
        config(['ai.providers.gemini.api_key' => 'fake-final-review-hidden-key']);

        $pendingForBlockedUsers = $this->pendingCheckIn($this->branch, 'Final Blocked Capture Customer');
        $pendingForBranchManager = $this->pendingCheckIn($this->branch, 'Final BM Capture Customer');
        $pendingNoPurchase = $this->pendingCheckIn($this->branch, 'Final No Purchase Customer');
        $product = $this->product($this->branch);

        foreach ([$this->systemManager, $this->systemAdmin, $this->owner, $this->customerUser] as $blockedUser) {
            $this->actingAs($blockedUser)
                ->post(route('businesses.branches.check-ins.product-services.store', [
                    'business' => $this->business,
                    'branch' => $this->branch,
                    'checkIn' => $pendingForBlockedUsers,
                ]), [
                    'product_service_id' => $product->id,
                    'quantity' => 1,
                    'capture_type' => 'purchase',
                    'capture_reference' => 'final-blocked-'.$blockedUser->id,
                ])
                ->assertForbidden();

            $this->actingAs($blockedUser)
                ->patch(route('businesses.branches.check-ins.no-purchase', [
                    'business' => $this->business,
                    'branch' => $this->branch,
                    'checkIn' => $pendingForBlockedUsers,
                ]))
                ->assertForbidden();
        }

        $this->actingAs($this->branchManager)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $this->business,
                'branch' => $this->branch,
                'checkIn' => $pendingForBranchManager,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
                'capture_reference' => 'final-bm-capture',
            ])
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]));

        $this->actingAs($this->combined)
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $this->business,
                'branch' => $this->branch,
                'checkIn' => $pendingNoPurchase,
            ]), [
                'no_purchase_reason' => 'Final review no purchase.',
            ])
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]));

        $this->assertDatabaseHas('customer_check_ins', [
            'id' => $pendingNoPurchase->id,
            'reward_status' => CustomerCheckIn::REWARD_STATUS_NO_PURCHASE,
            'stamps_earned' => 0,
        ]);

        $this->actingAs($this->systemAdmin)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('System Admin Analytics')
            ->assertSee('AI Provider Status')
            ->assertSee('Suggestion Only')
            ->assertDontSee('fake-final-review-hidden-key');

        foreach ([$this->systemManager, $this->owner, $this->branchManager, $this->combined] as $nonAdmin) {
            $this->actingAs($nonAdmin)
                ->get(route('analytics.index'))
                ->assertOk()
                ->assertSee('AI Action Engine')
                ->assertSee('Suggested action sahaja')
                ->assertDontSee('AI Provider Status')
                ->assertDontSee('fake-final-review-hidden-key')
                ->assertDontSee('Auto Execute');
        }

        $this->actingAs($this->customerUser)
            ->get(route('analytics.index'))
            ->assertForbidden();

        $this->actingAs($this->customerUser)
            ->get(route('customer.feedback'))
            ->assertOk()
            ->assertSee('Hantar Maklumbalas')
            ->assertDontSee('Pending Feedback');

        $this->actingAs($this->customerUser)
            ->post(route('customer.feedback.store'), [
                'branch_id' => $this->branch->id,
                'rating' => 5,
                'comment' => 'Final free feedback without purchase.',
            ])
            ->assertRedirect(route('customer.feedback'));

        $this->assertDatabaseHas('customer_feedback', [
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'comment' => 'Final free feedback without purchase.',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
        ]);
    }

    private function pendingCheckIn(Branch $branch, string $customerName): CustomerCheckIn
    {
        $customer = Customer::query()->create([
            'business_id' => $branch->business_id,
            'name' => $customerName,
            'whatsapp_number' => '601'.random_int(100000000, 999999999),
        ]);

        return CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $branch->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'cross_persona_final_review',
            'check_in_type' => 'physical',
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);
    }

    private function feedbackForBranch(Branch $branch, string $comment): void
    {
        $customer = Customer::query()->create([
            'business_id' => $branch->business_id,
            'name' => 'Final Review Customer '.uniqid(),
            'whatsapp_number' => '601'.random_int(100000000, 999999999),
        ]);

        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'comment' => $comment,
            'source' => 'cross_persona_final_review',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'summary_issue_category' => 'positive_feedback',
            'submitted_at' => now(),
        ]);
    }

    private function product(Branch $branch): ProductService
    {
        return ProductService::query()
            ->visibleForBranch($branch)
            ->active()
            ->firstOrFail();
    }

    private function customerForUser(User $user): Customer
    {
        return Customer::query()
            ->where('business_id', $this->business->id)
            ->where('user_id', $user->id)
            ->firstOrFail();
    }

    private function htmlBetween(string $html, string $start, string $end): string
    {
        $startPosition = strpos($html, $start);
        $this->assertNotFalse($startPosition, "Missing {$start} in dashboard HTML.");
        $endPosition = strpos($html, $end, $startPosition + strlen($start));
        $this->assertNotFalse($endPosition, "Missing {$end} after {$start}.");

        return substr($html, $startPosition, $endPosition - $startPosition);
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function business(string $slug): Business
    {
        return Business::query()->where('slug', $slug)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business')->where('code', $code)->firstOrFail();
    }
}
