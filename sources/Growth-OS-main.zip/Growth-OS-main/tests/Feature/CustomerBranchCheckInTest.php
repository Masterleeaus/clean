<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CustomerCheckIn;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CustomerBranchCheckInTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_customer_can_check_in_to_a_branch(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($customerUser)
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Customer Check-in')
            ->assertSee('WanChu Corner Main Branch');

        $this->actingAs($customerUser)
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
            ])
            ->assertOk()
            ->assertSee('Check-in berjaya direkodkan');
    }

    public function test_check_in_records_customer_business_branch_user_and_timestamp(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($customerUser)
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
            ])
            ->assertOk();

        $checkIn = CustomerCheckIn::query()->firstOrFail();

        $this->assertSame($branch->business_id, $checkIn->business_id);
        $this->assertSame($branch->id, $checkIn->branch_id);
        $this->assertSame($customerUser->id, $checkIn->user_id);
        $this->assertSame('customer_portal', $checkIn->source);
        $this->assertNotNull($checkIn->customer_id);
        $this->assertNotNull($checkIn->check_in_at);
    }

    public function test_duplicate_same_window_branch_check_in_is_blocked(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->customerCheckIn($customerUser, $branch)->assertOk();
        $this->travel(30)->minutes();

        $this->customerCheckIn($customerUser, $branch)
            ->assertOk()
            ->assertSee('Cooldown belum selesai');

        $this->assertSame(1, CustomerCheckIn::query()->where('branch_id', $branch->id)->count());
    }

    public function test_business_owner_can_view_owned_business_check_ins(): void
    {
        $owner = $this->user('owner+wanchu@fbgrowth.local');
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->customerCheckIn($customerUser, $branch)->assertOk();

        $this->actingAs($owner)
            ->get(route('businesses.check-ins', $branch->business))
            ->assertOk()
            ->assertSee('Business Check-ins')
            ->assertSee('WanChu Corner Main Branch')
            ->assertSee('GOS-F&B Demo Customer');
    }

    public function test_branch_manager_can_view_only_assigned_branch_check_ins(): void
    {
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $customerUser = $this->user('customer@fbgrowth.local');
        $assignedBranch = $this->branch('WANCHU-MAIN');
        $otherBranch = Branch::factory()->create([
            'business_id' => $assignedBranch->business_id,
            'name' => 'WanChu Second Branch',
            'code' => 'WANCHU-SECOND',
        ]);

        $this->customerCheckIn($customerUser, $assignedBranch)->assertOk();
        $this->travel(60)->minutes();
        $this->customerCheckIn($customerUser, $otherBranch)->assertOk();

        $this->actingAs($branchManager)
            ->get(route('businesses.check-ins', $assignedBranch->business))
            ->assertOk()
            ->assertSee('WanChu Corner Main Branch')
            ->assertDontSee('WanChu Second Branch');

        $this->actingAs($branchManager)
            ->get(route('businesses.branches.check-ins', ['business' => $assignedBranch->business, 'branch' => $otherBranch]))
            ->assertForbidden();
    }

    public function test_customer_cannot_access_business_admin_check_in_surfaces(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($customerUser)
            ->get(route('businesses.check-ins', $branch->business))
            ->assertForbidden();

        $this->actingAs($customerUser)
            ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
            ->assertForbidden();
    }

    private function customerCheckIn(User $customerUser, Branch $branch)
    {
        return $this->actingAs($customerUser)
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
            ]);
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business')->where('code', $code)->firstOrFail();
    }
}
