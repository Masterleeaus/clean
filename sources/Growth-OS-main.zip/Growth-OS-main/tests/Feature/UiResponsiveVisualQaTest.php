<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UiResponsiveVisualQaTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_global_ui_foundation_has_responsive_overflow_and_focus_safeguards(): void
    {
        $css = file_get_contents(resource_path('css/app.css'));

        $this->assertStringContainsString('overflow-wrap: anywhere;', $css);
        $this->assertStringContainsString('focus-visible', $css);
        $this->assertStringContainsString('#gos-mobile-menu', $css);
        $this->assertStringContainsString('max-height: calc(100vh - 5rem);', $css);
        $this->assertStringContainsString('@media (max-width: 640px)', $css);
        $this->assertStringContainsString('left: 1rem;', $css);
        $this->assertStringContainsString('.gos-action-button', $css);
    }

    public function test_customer_portal_keeps_mobile_friendly_check_in_without_internal_actions(): void
    {
        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Customer Portal')
            ->assertSee('Check-in di Premis')
            ->assertSee('Check-in untuk Order Online')
            ->assertSee('flex min-w-0 cursor-pointer items-start', false)
            ->assertSee('gos-floating-action', false)
            ->assertSee('Hantar Maklumbalas')
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Mark No Purchase')
            ->assertDontSee('AI Provider Status');
    }

    public function test_branch_operation_queue_uses_responsive_columns_and_preserves_actions(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->pendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL, 'UI4 Physical Customer With Long Name');
        $this->pendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_ONLINE, 'UI4 Online Customer With Long Name');

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('Pending Purchase Capture')
            ->assertSee('Physical')
            ->assertSee('Online')
            ->assertSee('lg:grid-cols-[minmax(0,1fr)_minmax(280px,360px)]', false)
            ->assertSee('grid gap-2 sm:grid-cols-2', false)
            ->assertSee('Capture Purchase')
            ->assertSee('Mark No Purchase')
            ->assertSee('Semak pembelian di premis sebelum capture purchase.')
            ->assertSee('Semak order/payment melalui channel luar sebelum capture purchase.');
    }

    public function test_combined_dashboard_tabs_wrap_on_mobile_and_keep_capture_in_branch_operations(): void
    {
        $response = $this->actingAs($this->user('owner-branch+wanchu@fbgrowth.local'))
            ->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Business Performance')
            ->assertSee('Branch Operations')
            ->assertSee('w-full rounded-t-md border border-b-0', false)
            ->assertSee('sm:w-auto', false)
            ->assertSee('Capture Purchase / Mark No Purchase');

        $html = $response->getContent();
        $businessTab = $this->htmlBetween($html, 'id="business-performance"', 'id="branch-operations"');
        $branchTab = $this->htmlBetween($html, 'id="branch-operations"', '</section>');

        $this->assertStringNotContainsString('Capture Purchase / Mark No Purchase', $businessTab);
        $this->assertStringContainsString('Capture Purchase / Mark No Purchase', $branchTab);
    }

    private function pendingCheckIn(Branch $branch, string $type, string $customerName): CustomerCheckIn
    {
        $customer = Customer::query()->create([
            'business_id' => $branch->business_id,
            'name' => $customerName,
            'whatsapp_number' => '601'.random_int(100000000, 999999999),
        ]);

        return CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $branch->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'ui_4_responsive_qa',
            'check_in_type' => $type,
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business')->where('code', $code)->firstOrFail();
    }

    private function htmlBetween(string $html, string $start, string $end): string
    {
        $startPosition = strpos($html, $start);
        $this->assertNotFalse($startPosition, "Missing {$start} in dashboard HTML.");
        $endPosition = strpos($html, $end, $startPosition + strlen($start));
        $this->assertNotFalse($endPosition, "Missing {$end} after {$start}.");

        return substr($html, $startPosition, $endPosition - $startPosition);
    }
}
