<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CustomerCheckIn;
use App\Models\CustomerLoyaltyAccount;
use App\Models\OnlineCheckInReference;
use App\Models\ProductService;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CustomerCheckInLaunchReadinessTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_physical_check_in_without_product_service_does_not_grant_reward(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->physicalCheckIn($branch)->assertOk();

        $checkIn = CustomerCheckIn::query()->firstOrFail();
        $account = CustomerLoyaltyAccount::query()->firstOrFail();

        $this->assertSame('physical', $checkIn->check_in_type);
        $this->assertSame('pending_product', $checkIn->reward_status);
        $this->assertSame(0, $checkIn->stamps_earned);
        $this->assertSame(0, $account->current_stamps);
    }

    public function test_physical_check_in_with_product_service_grants_reward(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->physicalCheckIn($branch)->assertOk();
        $this->captureProductForLatestCheckIn($branch)->assertRedirect();

        $checkIn = CustomerCheckIn::query()->firstOrFail();
        $account = CustomerLoyaltyAccount::query()->firstOrFail();

        $this->assertSame('granted', $checkIn->refresh()->reward_status);
        $this->assertSame(1, $checkIn->refresh()->stamps_earned);
        $this->assertSame(1, $account->refresh()->current_stamps);
    }

    public function test_check_in_blocked_by_cooldown_does_not_grant_reward(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->physicalCheckIn($branch)->assertOk();
        $this->captureProductForLatestCheckIn($branch)->assertRedirect();
        $this->travel(30)->minutes();

        $this->physicalCheckIn($branch)
            ->assertOk()
            ->assertSee('Cooldown belum selesai');

        $account = CustomerLoyaltyAccount::query()->firstOrFail();

        $this->assertSame(1, CustomerCheckIn::query()->count());
        $this->assertSame(1, $account->refresh()->current_stamps);
    }

    public function test_online_check_in_link_can_be_generated(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->createOnlineReference($branch)
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]));

        $reference = OnlineCheckInReference::query()->firstOrFail();

        $this->assertSame($branch->business_id, $reference->business_id);
        $this->assertSame($branch->id, $reference->branch_id);
        $this->assertSame(OnlineCheckInReference::STATUS_PENDING, $reference->status);
        $this->assertNotEmpty($reference->code);
    }

    public function test_valid_online_check_in_records_pending_capture_without_reward(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createOnlineReference($branch);
        $reference = OnlineCheckInReference::query()->firstOrFail();

        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->post(route('customer.online-check-in.store'), ['code' => $reference->code])
            ->assertOk()
            ->assertSee('Check-in order online berjaya direkodkan')
            ->assertSee('Reward akan disahkan selepas pembelian disahkan oleh branch')
            ->assertDontSee('Pending Purchase Capture');

        $checkIn = CustomerCheckIn::query()->firstOrFail();
        $account = CustomerLoyaltyAccount::query()->firstOrFail();

        $this->assertSame('online', $checkIn->check_in_type);
        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $checkIn->reward_status);
        $this->assertSame(0, $checkIn->stamps_earned);
        $this->assertSame(0, $account->current_stamps);
        $this->assertSame(OnlineCheckInReference::STATUS_CLAIMED, $reference->refresh()->status);
        $this->assertDatabaseCount('check_in_product_services', 0);
        $this->assertDatabaseCount('stamp_transactions', 0);
    }

    public function test_online_check_in_cannot_be_claimed_twice(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createOnlineReference($branch);
        $reference = OnlineCheckInReference::query()->firstOrFail();
        $customer = $this->user('customer@fbgrowth.local');

        $this->actingAs($customer)->post(route('customer.online-check-in.store'), ['code' => $reference->code])->assertOk();
        $this->actingAs($customer)
            ->post(route('customer.online-check-in.store'), ['code' => $reference->code])
            ->assertOk()
            ->assertSee('sudah digunakan');

        $this->assertSame(1, CustomerCheckIn::query()->count());
        $this->assertSame(0, CustomerLoyaltyAccount::query()->firstOrFail()->current_stamps);
        $this->assertDatabaseCount('stamp_transactions', 0);
    }

    public function test_invalid_online_check_in_reference_is_rejected(): void
    {
        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->post(route('customer.online-check-in.store'), ['code' => 'NOT-A-CODE'])
            ->assertOk()
            ->assertSee('reference tidak sah');

        $this->assertDatabaseCount('customer_check_ins', 0);
    }

    public function test_customer_cannot_self_claim_online_check_in_without_valid_record(): void
    {
        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->post(route('customer.online-check-in.store'), ['code' => 'SELF-CLAIM'])
            ->assertOk()
            ->assertSee('reference tidak sah');

        $this->assertDatabaseCount('customer_check_ins', 0);
        $this->assertDatabaseCount('stamp_transactions', 0);
    }

    public function test_double_click_network_retry_does_not_create_duplicate_reward(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createOnlineReference($branch);
        $reference = OnlineCheckInReference::query()->firstOrFail();
        $customer = $this->user('customer@fbgrowth.local');

        $this->actingAs($customer)->post(route('customer.online-check-in.store'), ['code' => $reference->code])->assertOk();
        $this->actingAs($customer)->post(route('customer.online-check-in.store'), ['code' => $reference->code])->assertOk();

        $this->assertSame(1, CustomerCheckIn::query()->count());
        $this->assertSame(0, CustomerLoyaltyAccount::query()->firstOrFail()->current_stamps);
        $this->assertDatabaseCount('check_in_product_services', 0);
        $this->assertDatabaseCount('stamp_transactions', 0);
    }

    public function test_branch_manager_can_manage_view_assigned_branch_check_ins_only(): void
    {
        $assignedBranch = $this->branch('WANCHU-MAIN');
        $otherBranch = $this->branch('CHENA-MAIN');
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');

        $this->actingAs($branchManager)
            ->get(route('businesses.branches.check-ins', ['business' => $assignedBranch->business, 'branch' => $assignedBranch]))
            ->assertOk();

        $this->actingAs($branchManager)
            ->get(route('businesses.branches.check-ins', ['business' => $otherBranch->business, 'branch' => $otherBranch]))
            ->assertForbidden();

        $this->actingAs($branchManager)
            ->post(route('businesses.branches.online-check-ins.store', ['business' => $otherBranch->business, 'branch' => $otherBranch]), [
                'customer_id' => $otherBranch->business->customers()->first()?->id ?? 1,
                'product_service_id' => ProductService::query()->where('business_id', $otherBranch->business_id)->firstOrFail()->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
            ])
            ->assertForbidden();
    }

    public function test_business_owner_can_view_owned_business_branch_check_ins(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->physicalCheckIn($branch)->assertOk();

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('businesses.check-ins', $branch->business))
            ->assertOk()
            ->assertSee('WanChu Corner Main Branch')
            ->assertSee('GOS-F&B Demo Customer');
    }

    public function test_customer_cannot_access_internal_admin_check_in_surfaces(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $customer = $this->user('customer@fbgrowth.local');

        $this->actingAs($customer)
            ->get(route('businesses.check-ins', $branch->business))
            ->assertForbidden();

        $this->actingAs($customer)
            ->post(route('businesses.branches.online-check-ins.store', ['business' => $branch->business, 'branch' => $branch]), [
                'customer_id' => $branch->business->customers()->firstOrFail()->id,
                'product_service_id' => $this->product($branch)->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
            ])
            ->assertForbidden();
    }

    private function physicalCheckIn(Branch $branch)
    {
        return $this->actingAs($this->user('customer@fbgrowth.local'))
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
                'check_in_mode' => CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL,
            ]);
    }

    private function captureProductForLatestCheckIn(Branch $branch)
    {
        return $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $branch->checkIns()->latest()->firstOrFail(),
            ]), [
                'product_service_id' => $this->product($branch)->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
            ]);
    }

    private function createOnlineReference(Branch $branch)
    {
        return $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->post(route('businesses.branches.online-check-ins.store', ['business' => $branch->business, 'branch' => $branch]), [
                'customer_id' => $branch->business->customers()->firstOrFail()->id,
                'product_service_id' => $this->product($branch)->id,
                'purchase_reference' => 'ORDER-'.uniqid(),
                'quantity' => 1,
                'capture_type' => 'purchase',
            ]);
    }

    private function product(Branch $branch): ProductService
    {
        return ProductService::query()
            ->where('business_id', $branch->business_id)
            ->where(function ($query) use ($branch): void {
                $query->whereNull('branch_id')->orWhere('branch_id', $branch->id);
            })
            ->firstOrFail();
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business.customers')->where('code', $code)->firstOrFail();
    }
}
