<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CreateOwnerUserCommandTest extends TestCase
{
    use RefreshDatabase;

    public function test_create_owner_command_creates_owner_user(): void
    {
        $this->artisan('users:create-owner', [
            '--name' => 'Pilot Owner',
            '--email' => 'pilot-owner@example.com',
            '--password' => 'pilot-password-123',
        ])
            ->assertSuccessful()
            ->expectsOutput('Owner user created: pilot-owner@example.com');

        $owner = User::query()->where('email', 'pilot-owner@example.com')->firstOrFail();

        $this->assertTrue($owner->isOwner());
        $this->assertNotNull($owner->email_verified_at);
    }

    public function test_create_owner_command_rejects_duplicate_email(): void
    {
        User::factory()->create([
            'email' => 'pilot-owner@example.com',
        ]);

        $this->artisan('users:create-owner', [
            '--name' => 'Pilot Owner',
            '--email' => 'pilot-owner@example.com',
            '--password' => 'pilot-password-123',
        ])
            ->assertFailed()
            ->expectsOutput('The email has already been taken.');
    }
}
