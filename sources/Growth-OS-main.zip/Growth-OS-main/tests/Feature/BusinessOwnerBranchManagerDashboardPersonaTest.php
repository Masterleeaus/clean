<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\User;
use App\Services\RoleAccessPilotGuard;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BusinessOwnerBranchManagerDashboardPersonaTest extends TestCase
{
    use RefreshDatabase;

    private User $combined;

    private Business $business;

    private Branch $assignedBranch;

    private Branch $otherBranch;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);

        $this->combined = User::query()->where('email', 'owner-branch+wanchu@fbgrowth.local')->firstOrFail();
        $this->business = Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
        $this->assignedBranch = Branch::query()->where('code', 'WANCHU-MAIN')->firstOrFail();
        $this->otherBranch = Branch::query()->where('code', 'CHENA-MAIN')->firstOrFail();
    }

    public function test_dual_role_dashboard_has_clear_business_and_branch_tabs(): void
    {
        $unassignedOwnBranch = Branch::factory()->create([
            'business_id' => $this->business->id,
            'name' => 'WanChu Business Performance Branch',
            'code' => 'WANCHU-BP-PERSONA',
            'is_active' => true,
        ]);
        $this->createBranchActivity($this->assignedBranch, 'Assigned dual role feedback.');
        $this->createBranchActivity($unassignedOwnBranch, 'Owner-level branch comparison feedback.');
        $this->createBranchActivity($this->otherBranch, 'Hidden dual role feedback.');

        $response = $this->actingAs($this->combined)
            ->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Business Owner / Branch Manager Dashboard')
            ->assertSee('Business Owner cum Branch Manager')
            ->assertSee('Business Performance')
            ->assertSee('Branch Operations')
            ->assertSee('Owner-level: business overview')
            ->assertSee('Branch-level: assigned/current branch')
            ->assertSee('AI Action suggestion-only')
            ->assertSee($this->business->name)
            ->assertSee($this->assignedBranch->name)
            ->assertSee($unassignedOwnBranch->name)
            ->assertSee('Owner-level branch comparison feedback.')
            ->assertDontSee($this->otherBranch->name)
            ->assertDontSee('Hidden dual role feedback.')
            ->assertDontSee('System Manager Dashboard')
            ->assertDontSee('System Admin Dashboard')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Customer Portal')
            ->assertDontSee('API key')
            ->assertDontSee('secret');

        $html = $response->getContent();
        $businessTab = $this->htmlBetween($html, 'id="business-performance"', 'id="branch-operations"');
        $branchTab = $this->htmlBetween($html, 'id="branch-operations"', '</section>');

        $this->assertStringContainsString('Business Performance', $businessTab);
        $this->assertStringContainsString('Business scope', $businessTab);
        $this->assertStringNotContainsString('Capture Purchase / Mark No Purchase', $businessTab);

        $this->assertStringContainsString('Branch Operations', $branchTab);
        $this->assertStringContainsString('Assigned/current branch', $branchTab);
        $this->assertStringContainsString('Pending Purchase Capture', $branchTab);
        $this->assertStringContainsString('Capture Purchase / Mark No Purchase', $branchTab);
        $this->assertStringContainsString('Branch Analytics / AI', $branchTab);
        $this->assertStringContainsString($this->assignedBranch->name, $branchTab);
        $this->assertStringNotContainsString($unassignedOwnBranch->name, $branchTab);
    }

    public function test_dual_role_capture_and_no_purchase_are_assigned_branch_only(): void
    {
        $unassignedOwnBranch = Branch::factory()->create([
            'business_id' => $this->business->id,
            'name' => 'WanChu Unassigned Operation Branch',
            'code' => 'WANCHU-UNASSIGNED-OPS',
            'is_active' => true,
        ]);
        $assignedCapture = $this->pendingCheckIn($this->assignedBranch, 'Dual Assigned Capture');
        $assignedNoPurchase = $this->pendingCheckIn($this->assignedBranch, 'Dual Assigned No Purchase');
        $unassignedCapture = $this->pendingCheckIn($unassignedOwnBranch, 'Dual Unassigned Capture');
        $unassignedNoPurchase = $this->pendingCheckIn($unassignedOwnBranch, 'Dual Unassigned No Purchase');
        $assignedProduct = ProductService::query()->visibleForBranch($this->assignedBranch)->active()->firstOrFail();
        $unassignedProduct = ProductService::factory()->create([
            'business_id' => $this->business->id,
            'branch_id' => $unassignedOwnBranch->id,
            'name' => 'Unassigned Operation Set',
            'category' => 'food',
            'price' => 11.00,
            'is_active' => true,
        ]);

        $this->actingAs($this->combined)
            ->get(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->assignedBranch]))
            ->assertOk()
            ->assertSee('Capture Purchase')
            ->assertSee('Mark No Purchase')
            ->assertSee('Dual Assigned Capture');

        $this->actingAs($this->combined)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $this->business,
                'branch' => $this->assignedBranch,
                'checkIn' => $assignedCapture,
            ]), [
                'product_service_id' => $assignedProduct->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
                'capture_reference' => 'dual-assigned-capture',
            ])
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->assignedBranch]));

        $this->actingAs($this->combined)
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $this->business,
                'branch' => $this->assignedBranch,
                'checkIn' => $assignedNoPurchase,
            ]), [
                'no_purchase_reason' => 'Dual role no purchase.',
            ])
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->assignedBranch]));

        $this->actingAs($this->combined)
            ->get(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $unassignedOwnBranch]))
            ->assertForbidden();

        $this->actingAs($this->combined)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $this->business,
                'branch' => $unassignedOwnBranch,
                'checkIn' => $unassignedCapture,
            ]), [
                'product_service_id' => $unassignedProduct->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
                'capture_reference' => 'dual-unassigned-capture',
            ])
            ->assertForbidden();

        $this->actingAs($this->combined)
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $this->business,
                'branch' => $unassignedOwnBranch,
                'checkIn' => $unassignedNoPurchase,
            ]), [
                'no_purchase_reason' => 'Blocked unassigned branch.',
            ])
            ->assertForbidden();
    }

    public function test_dual_role_analytics_ai_are_scoped_and_suggestion_only(): void
    {
        $this->createCapturedActivity($this->assignedBranch, 'Dual role AI feedback.', 'Dual Role Set', 2, 9.00);
        $this->createCapturedActivity($this->otherBranch, 'Hidden external AI feedback.', 'Hidden External Set', 1, 99.00);

        $this->actingAs($this->combined)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Business Owner / Branch Manager Analytics')
            ->assertSee('Business-level dan assigned branch-level analytics')
            ->assertSee('AI Insight Engine')
            ->assertSee('AI Action Engine')
            ->assertSee('Suggested action sahaja')
            ->assertSee('Human review diperlukan')
            ->assertSee($this->assignedBranch->name)
            ->assertSee('Dual Role Set')
            ->assertDontSee($this->otherBranch->name)
            ->assertDontSee('Hidden External Set')
            ->assertDontSee('System Manager Analytics')
            ->assertDontSee('System Admin Analytics')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Auto Execute')
            ->assertDontSee('Send Campaign');
    }

    public function test_dual_role_is_blocked_from_other_personas_customer_portal_and_restricted_invites(): void
    {
        $guard = app(RoleAccessPilotGuard::class);

        $this->actingAs($this->combined)->get(route('dashboards.system-manager'))->assertForbidden();
        $this->actingAs($this->combined)->get(route('dashboards.system-admin'))->assertForbidden();
        $this->actingAs($this->combined)->get(route('customer.portal'))->assertForbidden();
        $this->actingAs($this->combined)->get(route('businesses.create'))->assertForbidden();
        $this->actingAs($this->combined)->get(route('businesses.show', $this->otherBranch->business))->assertForbidden();

        $customerInvite = $guard->validateBusinessOwnerInvite($this->combined, $this->business, User::ROLE_CUSTOMER);
        $systemAdminInvite = $guard->validateBusinessOwnerInvite($this->combined, $this->business, User::ROLE_SYSTEM_ADMIN);
        $systemManagerInvite = $guard->validateBusinessOwnerInvite($this->combined, $this->business, User::ROLE_SYSTEM_MANAGER);

        $this->assertFalse($customerInvite['allowed']);
        $this->assertFalse($systemAdminInvite['allowed']);
        $this->assertFalse($systemManagerInvite['allowed']);
        $this->assertContains('Business Owner cannot create Customer manually. Customer onboarding must be organic.', $customerInvite['errors']);
        $this->assertContains('Business Owner cannot assign System Admin, System Manager, or another Business Owner role.', $systemAdminInvite['errors']);
        $this->assertContains('Business Owner cannot assign System Admin, System Manager, or another Business Owner role.', $systemManagerInvite['errors']);
    }

    private function createBranchActivity(Branch $branch, string $feedbackComment): void
    {
        $customer = $this->customerFor($branch, 'Dual Persona Customer '.uniqid());
        $checkIn = $this->pendingCheckIn($branch, $customer->name, $customer);
        $product = ProductService::query()->visibleForBranch($branch)->active()->firstOrFail();

        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'rating' => 4,
            'comment' => $feedbackComment,
            'source' => 'business_owner_branch_manager_persona_review',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'summary_issue_category' => 'positive_feedback',
            'submitted_at' => now(),
        ]);
    }

    private function createCapturedActivity(Branch $branch, string $feedbackComment, string $productName, int $quantity, float $price): void
    {
        $customer = $this->customerFor($branch, 'Dual Analytics Customer '.uniqid());
        $checkIn = $this->pendingCheckIn($branch, $customer->name, $customer);
        $product = ProductService::query()->updateOrCreate(
            ['business_id' => $branch->business_id, 'name' => $productName],
            ['branch_id' => $branch->id, 'category' => 'food', 'type' => 'product', 'price' => $price, 'is_active' => true],
        );
        $capture = CheckInProductService::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'captured_by_user_id' => $this->combined->id,
            'quantity' => $quantity,
            'price_at_capture' => $price,
            'total_amount' => number_format($quantity * $price, 2, '.', ''),
            'capture_type' => 'purchase',
            'capture_source' => 'business_owner_branch_manager_persona_review',
            'capture_reference' => 'dual-persona-'.uniqid(),
        ]);

        $checkIn->forceFill([
            'reward_status' => CustomerCheckIn::REWARD_STATUS_GRANTED,
            'stamps_earned' => 1,
            'reward_granted_at' => now(),
        ])->save();

        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'check_in_product_service_id' => $capture->id,
            'product_service_id' => $product->id,
            'rating' => 4,
            'comment' => $feedbackComment,
            'source' => 'business_owner_branch_manager_persona_review',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'summary_issue_category' => 'general_issue',
            'submitted_at' => now(),
        ]);
    }

    private function pendingCheckIn(Branch $branch, string $customerName, ?Customer $customer = null): CustomerCheckIn
    {
        $customer ??= $this->customerFor($branch, $customerName);

        return CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $branch->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'business_owner_branch_manager_persona_review',
            'check_in_type' => 'physical',
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);
    }

    private function customerFor(Branch $branch, string $name): Customer
    {
        return Customer::query()->create([
            'business_id' => $branch->business_id,
            'name' => $name,
            'whatsapp_number' => '601'.random_int(100000000, 999999999),
        ]);
    }

    private function htmlBetween(string $html, string $start, string $end): string
    {
        $startPosition = strpos($html, $start);
        $this->assertNotFalse($startPosition, "Missing {$start} in dashboard HTML.");
        $endPosition = strpos($html, $end, $startPosition + strlen($start));
        $this->assertNotFalse($endPosition, "Missing {$end} after {$start} in dashboard HTML.");

        return substr($html, $startPosition, $endPosition - $startPosition);
    }
}
