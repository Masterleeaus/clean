<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PersonaAccessTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_dashboard_redirects_by_persona(): void
    {
        $cases = [
            'manager@gos-fnb.local' => 'dashboards.system-manager',
            'admin@fbgrowth.local' => 'dashboards.system-admin',
            'owner+wanchu@fbgrowth.local' => 'dashboards.business-owner',
            'branch+wanchu@fbgrowth.local' => 'dashboards.branch-manager',
            'customer@fbgrowth.local' => 'customer.portal',
            'owner-branch+wanchu@fbgrowth.local' => 'dashboards.business-branch-combined',
            'internal@gos-fnb.local' => 'dashboards.internal-combined',
        ];

        foreach ($cases as $email => $routeName) {
            $this->actingAs($this->user($email))
                ->get(route('dashboard'))
                ->assertRedirect(route($routeName));
        }
    }

    public function test_customer_cannot_access_business_or_platform_dashboards(): void
    {
        $customer = $this->user('customer@fbgrowth.local');

        $this->actingAs($customer)
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Customer Portal');

        $this->actingAs($customer)
            ->get(route('businesses.index'))
            ->assertForbidden();

        $this->actingAs($customer)
            ->get(route('dashboards.system-admin'))
            ->assertForbidden();
    }

    public function test_branch_manager_can_only_access_assigned_business_scope(): void
    {
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $assignedBusiness = Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();

        $this->actingAs($branchManager)
            ->get(route('businesses.show', $assignedBusiness))
            ->assertOk()
            ->assertSee('WanChu Corner');

        $this->actingAs($branchManager)
            ->get(route('businesses.show', $otherBusiness))
            ->assertForbidden();

        $this->actingAs($branchManager)
            ->get(route('businesses.edit', $assignedBusiness))
            ->assertForbidden();
    }

    public function test_branch_manager_without_assigned_scope_sees_no_businesses(): void
    {
        $branchManager = User::factory()->create([
            'role' => User::ROLE_BRANCH_MANAGER,
            'access_scope' => null,
        ]);

        $this->actingAs($branchManager)
            ->get(route('businesses.index'))
            ->assertOk()
            ->assertSee('No businesses available for your account yet.');
    }

    public function test_combined_business_owner_branch_manager_gets_combined_dashboard_and_scope(): void
    {
        $combined = $this->user('owner-branch+wanchu@fbgrowth.local');
        $assignedBusiness = Business::query()->where('slug', 'wanchu-corner')->firstOrFail();

        $this->actingAs($combined)
            ->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Business Owner / Branch Manager Dashboard');

        $this->actingAs($combined)
            ->get(route('businesses.show', $assignedBusiness))
            ->assertOk();
    }

    public function test_internal_combined_user_gets_internal_combined_dashboard(): void
    {
        $this->actingAs($this->user('internal@gos-fnb.local'))
            ->get(route('dashboards.internal-combined'))
            ->assertOk()
            ->assertSee('System Manager / System Admin Dashboard');
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
