<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerLoyaltyAccount;
use App\Models\User;
use Carbon\Carbon;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ManualFollowUpTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_owner_can_view_own_follow_ups_page(): void
    {
        $business = $this->wanChu();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.follow-ups', $business))
            ->assertOk()
            ->assertSee('Manual WhatsApp Follow-ups')
            ->assertSee($business->name);
    }

    public function test_owner_cannot_view_another_business_follow_ups_page(): void
    {
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.follow-ups', $otherBusiness))
            ->assertForbidden();
    }

    public function test_dormant_customers_appear_in_dormant_section(): void
    {
        $business = $this->wanChu();
        $program = $business->loyaltyPrograms()->active()->firstOrFail();
        $customer = $this->createCustomer($business, 'Dormant Dina', '60111111111', now()->subDays(60));

        $this->createAccount($business, $customer, currentStamps: 2);
        CustomerCheckIn::query()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => now()->subDays(45)->toDateString(),
            'stamps_earned' => 1,
        ]);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.follow-ups', $business))
            ->assertOk()
            ->assertSee('Dormant Customers')
            ->assertSee('Dormant Dina')
            ->assertSee('kami rindu nak jumpa anda di '.$business->name);
    }

    public function test_new_customers_appear_in_new_customer_section(): void
    {
        $business = $this->wanChu();
        $customer = $this->createCustomer($business, 'New Nani', '60122222222', now()->subDays(2));

        $this->createAccount($business, $customer, currentStamps: 1);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.follow-ups', $business))
            ->assertOk()
            ->assertSee('New Customers')
            ->assertSee('New Nani')
            ->assertSee('terima kasih kerana singgah di '.$business->name);
    }

    public function test_near_reward_customers_appear_in_near_reward_section(): void
    {
        $business = $this->wanChu();
        $program = $business->loyaltyPrograms()->active()->firstOrFail();
        $customer = $this->createCustomer($business, 'Near Nora', '60133333333', now()->subDays(14));

        $this->createAccount($business, $customer, currentStamps: $program->stamps_required - 1);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.follow-ups', $business))
            ->assertOk()
            ->assertSee('Reward-Near Customers')
            ->assertSee('Near Nora')
            ->assertSee('anda tinggal 1 stamp sahaja lagi untuk claim reward di '.$business->name);
    }

    public function test_eligible_customers_appear_in_eligible_reward_section(): void
    {
        $business = $this->wanChu();
        $program = $business->loyaltyPrograms()->active()->firstOrFail();
        $customer = $this->createCustomer($business, 'Eligible Eli', '60144444444', now()->subDays(14));

        $this->createAccount($business, $customer, currentStamps: $program->stamps_required);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.follow-ups', $business))
            ->assertOk()
            ->assertSee('Eligible Reward Customers')
            ->assertSee('Eligible Eli')
            ->assertSee('sudah layak claim reward '.$program->reward_name.' di '.$business->name);
    }

    public function test_wa_me_link_is_generated_with_normalized_whatsapp_number(): void
    {
        $business = $this->wanChu();
        $customer = $this->createCustomer($business, 'Link Lina', '+60 12-345 6789', now()->subDays(2));

        $this->createAccount($business, $customer, currentStamps: 1);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.follow-ups', $business))
            ->assertOk()
            ->assertSee('https://wa.me/60123456789?text=', false);
    }

    public function test_generated_message_contains_customer_name_and_business_name(): void
    {
        $business = $this->wanChu();
        $customer = $this->createCustomer($business, 'Message Mira', '60155555555', now()->subDays(2));

        $this->createAccount($business, $customer, currentStamps: 1);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.follow-ups', $business))
            ->assertOk()
            ->assertSee('Hi Message Mira')
            ->assertSee($business->name);
    }

    private function createCustomer(Business $business, string $name, string $whatsapp, Carbon $createdAt): Customer
    {
        return Customer::query()->create([
            'business_id' => $business->id,
            'name' => $name,
            'whatsapp_number' => $whatsapp,
            'created_at' => $createdAt,
            'updated_at' => $createdAt,
        ]);
    }

    private function createAccount(Business $business, Customer $customer, int $currentStamps): CustomerLoyaltyAccount
    {
        $program = $business->loyaltyPrograms()->active()->firstOrFail();

        return CustomerLoyaltyAccount::query()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'current_stamps' => $currentStamps,
            'total_stamps_earned' => $currentStamps,
        ]);
    }

    private function wanChu(): Business
    {
        return Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
    }

    private function wanChuOwner(): User
    {
        return User::query()->where('email', 'owner+wanchu@fbgrowth.local')->firstOrFail();
    }
}
