<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerFeedback;
use App\Models\CustomerLoyaltyAccount;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CustomerFeedbackTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_guest_can_view_feedback_form(): void
    {
        $business = $this->wanChu();

        $this->get($this->publicFeedbackRoute($business))
            ->assertOk()
            ->assertSee('Share Feedback')
            ->assertSee($business->name);
    }

    public function test_guest_can_submit_anonymous_feedback(): void
    {
        $business = $this->wanChu();

        $this->post($this->publicFeedbackStoreRoute($business), [
            'food_rating' => 4,
            'service_rating' => 5,
            'price_feedback' => CustomerFeedback::PRICE_OK,
            'comment' => 'Good lunch.',
        ])->assertRedirect($this->publicFeedbackSuccessRoute($business));

        $this->assertDatabaseHas('customer_feedback', [
            'business_id' => $business->id,
            'customer_id' => null,
            'food_rating' => 4,
            'service_rating' => 5,
            'price_feedback' => CustomerFeedback::PRICE_OK,
            'comment' => 'Good lunch.',
        ]);
    }

    public function test_feedback_with_matching_whatsapp_attaches_to_customer(): void
    {
        $business = $this->wanChu();
        $customer = $this->createCustomer($business, 'Aina', '60123456789');

        $this->post($this->publicFeedbackStoreRoute($business), [
            'whatsapp_number' => '+60 12-345 6789',
            'food_rating' => 5,
            'service_rating' => 4,
            'price_feedback' => CustomerFeedback::PRICE_CHEAP,
        ])->assertRedirect($this->publicFeedbackSuccessRoute($business));

        $this->assertDatabaseHas('customer_feedback', [
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'food_rating' => 5,
            'price_feedback' => CustomerFeedback::PRICE_CHEAP,
        ]);
    }

    public function test_feedback_with_non_matching_whatsapp_stays_anonymous(): void
    {
        $business = $this->wanChu();

        $this->post($this->publicFeedbackStoreRoute($business), [
            'whatsapp_number' => '+60 19-999 9999',
            'food_rating' => 3,
            'service_rating' => 3,
            'price_feedback' => CustomerFeedback::PRICE_EXPENSIVE,
        ])->assertRedirect($this->publicFeedbackSuccessRoute($business));

        $this->assertDatabaseHas('customer_feedback', [
            'business_id' => $business->id,
            'customer_id' => null,
            'price_feedback' => CustomerFeedback::PRICE_EXPENSIVE,
        ]);
    }

    public function test_owner_can_view_own_feedback_page(): void
    {
        $business = $this->wanChu();
        $customer = $this->createCustomer($business, 'Aina', '60123456789');

        $this->createFeedback($business, $customer, comment: 'Nice nasi lemak.');

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.feedback', $business))
            ->assertOk()
            ->assertSee('Customer Feedback')
            ->assertSee('Aina')
            ->assertSee('Nice nasi lemak.');
    }

    public function test_owner_cannot_view_another_business_feedback_page(): void
    {
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.feedback', $otherBusiness))
            ->assertForbidden();
    }

    public function test_feedback_summary_shows_average_ratings_and_price_counts(): void
    {
        $business = $this->wanChu();

        $this->createFeedback($business, food: 4, service: 5, price: CustomerFeedback::PRICE_CHEAP);
        $this->createFeedback($business, food: 2, service: 3, price: CustomerFeedback::PRICE_OK);
        $this->createFeedback($business, food: 3, service: 4, price: CustomerFeedback::PRICE_EXPENSIVE);

        $this->actingAs($this->wanChuOwner())
            ->get(route('businesses.feedback', $business))
            ->assertOk()
            ->assertSee('Avg food')
            ->assertSee('3')
            ->assertSee('Avg service')
            ->assertSee('4')
            ->assertSee('Cheap')
            ->assertSee('OK')
            ->assertSee('Expensive');
    }

    public function test_feedback_links_appear_on_public_pages(): void
    {
        $business = $this->wanChu();
        $customer = $this->createCustomer($business, 'Aina', '60123456789');
        $program = $business->loyaltyPrograms()->active()->firstOrFail();

        CustomerLoyaltyAccount::query()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'current_stamps' => 1,
            'total_stamps_earned' => 1,
        ]);

        $this->get(route('public.business.show', ['business' => $business->slug]))
            ->assertOk()
            ->assertSee($this->publicFeedbackRoute($business), false);

        $this->post(route('public.business.check-in', ['business' => $business->slug]), [
            'whatsapp_number' => '60123456789',
        ])
            ->assertOk()
            ->assertSee($this->publicFeedbackRoute($business), false);
    }

    private function createCustomer(Business $business, string $name, string $whatsapp): Customer
    {
        return Customer::query()->create([
            'business_id' => $business->id,
            'name' => $name,
            'whatsapp_number' => $whatsapp,
        ]);
    }

    private function createFeedback(
        Business $business,
        ?Customer $customer = null,
        int $food = 5,
        int $service = 5,
        string $price = CustomerFeedback::PRICE_OK,
        ?string $comment = null,
    ): CustomerFeedback {
        return CustomerFeedback::query()->create([
            'business_id' => $business->id,
            'customer_id' => $customer?->id,
            'food_rating' => $food,
            'service_rating' => $service,
            'price_feedback' => $price,
            'comment' => $comment,
            'submitted_at' => now(),
        ]);
    }

    private function wanChu(): Business
    {
        return Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
    }

    private function wanChuOwner(): User
    {
        return User::query()->where('email', 'owner+wanchu@fbgrowth.local')->firstOrFail();
    }

    private function publicFeedbackRoute(Business $business): string
    {
        return route('public.business.feedback', ['business' => $business->slug]);
    }

    private function publicFeedbackStoreRoute(Business $business): string
    {
        return route('public.business.feedback.store', ['business' => $business->slug]);
    }

    private function publicFeedbackSuccessRoute(Business $business): string
    {
        return route('public.business.feedback.success', ['business' => $business->slug]);
    }
}
