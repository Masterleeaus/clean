<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\LoyaltyProgram;
use App\Models\StampTransaction;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PublicCustomerRegistrationTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_guest_can_view_public_business_qr_page(): void
    {
        $business = $this->wanChu();

        $this->get(route('public.business.show', ['business' => $business->slug]))
            ->assertOk()
            ->assertSee('WanChu Corner')
            ->assertSee('Free drink')
            ->assertSee('Returning customer')
            ->assertSee('Check-in Today')
            ->assertSee('New customer');
    }

    public function test_customer_can_register_through_public_qr_page(): void
    {
        $business = $this->wanChu();

        $this->post(route('public.business.register', ['business' => $business->slug]), [
            'name' => 'Aina',
            'whatsapp_number' => '+60 12-345 6789',
            'birthday' => '1995-01-20',
            'consent_promo' => '1',
        ])
            ->assertOk()
            ->assertSee('Hi, Aina!')
            ->assertSee('1 / 8')
            ->assertSee('Free drink');

        $this->assertDatabaseHas('customers', [
            'business_id' => $business->id,
            'name' => 'Aina',
            'whatsapp_number' => '60123456789',
            'consent_promo' => true,
        ]);
    }

    public function test_registration_creates_customer_loyalty_account_welcome_check_in_and_stamp_transaction(): void
    {
        $business = $this->wanChu();
        $program = $business->loyaltyPrograms()->active()->firstOrFail();

        $this->post(route('public.business.register', ['business' => $business->slug]), [
            'name' => 'Daniel',
            'whatsapp_number' => '60111112222',
        ])->assertOk();

        $customer = Customer::query()->where('whatsapp_number', '60111112222')->firstOrFail();

        $this->assertDatabaseHas('customer_loyalty_accounts', [
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'current_stamps' => 1,
            'total_stamps_earned' => 1,
        ]);

        $this->assertDatabaseHas('customer_check_ins', [
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => now()->startOfDay()->format('Y-m-d H:i:s'),
            'stamps_earned' => 1,
        ]);

        $this->assertDatabaseHas('stamp_transactions', [
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'type' => StampTransaction::TYPE_EARNED,
            'stamps' => 1,
        ]);
    }

    public function test_duplicate_whatsapp_in_same_business_does_not_create_duplicate_customer(): void
    {
        $business = $this->wanChu();

        $this->registerCustomer($business, 'Aina', '60123456789')->assertOk();
        $this->registerCustomer($business, 'Aina Again', '+60 12 345 6789')
            ->assertOk()
            ->assertSee('already registered');

        $this->assertSame(1, Customer::query()
            ->where('business_id', $business->id)
            ->where('whatsapp_number', '60123456789')
            ->count());
    }

    public function test_duplicate_registration_does_not_grant_second_welcome_stamp_on_same_day(): void
    {
        $business = $this->wanChu();

        $this->registerCustomer($business, 'Aina', '60123456789')->assertOk();
        $this->registerCustomer($business, 'Aina Again', '60123456789')->assertOk();

        $customer = Customer::query()->where('whatsapp_number', '60123456789')->firstOrFail();
        $account = $customer->loyaltyAccounts()->firstOrFail();

        $this->assertSame(1, $account->current_stamps);
        $this->assertSame(1, $account->total_stamps_earned);
        $this->assertSame(1, CustomerCheckIn::query()->where('customer_id', $customer->id)->count());
        $this->assertSame(1, StampTransaction::query()->where('customer_id', $customer->id)->count());
    }

    public function test_same_whatsapp_can_register_under_different_businesses(): void
    {
        $wanChu = $this->wanChu();
        $cheNa = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();

        $this->registerCustomer($wanChu, 'Aina', '60123456789')->assertOk();
        $this->registerCustomer($cheNa, 'Aina', '60123456789')->assertOk();

        $this->assertSame(2, Customer::query()->where('whatsapp_number', '60123456789')->count());
    }

    public function test_inactive_or_missing_loyalty_program_is_handled_gracefully(): void
    {
        $business = $this->wanChu();
        LoyaltyProgram::query()->where('business_id', $business->id)->update(['is_active' => false]);

        $this->get(route('public.business.show', ['business' => $business->slug]))
            ->assertOk()
            ->assertSee('not available yet');

        $this->post(route('public.business.register', ['business' => $business->slug]), [
            'name' => 'Aina',
            'whatsapp_number' => '60123456789',
        ])
            ->assertRedirect()
            ->assertSessionHasErrors('loyalty_program');

        $this->assertDatabaseMissing('customers', [
            'business_id' => $business->id,
            'whatsapp_number' => '60123456789',
        ]);
    }

    private function wanChu(): Business
    {
        return Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
    }

    private function registerCustomer(Business $business, string $name, string $whatsappNumber)
    {
        return $this->post(route('public.business.register', ['business' => $business->slug]), [
            'name' => $name,
            'whatsapp_number' => $whatsappNumber,
        ]);
    }
}
