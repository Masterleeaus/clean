<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class BusinessAdminTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_admin_can_see_all_seeded_businesses(): void
    {
        $admin = User::query()->where('email', 'admin@fbgrowth.local')->firstOrFail();

        $this->actingAs($admin)
            ->get(route('businesses.index'))
            ->assertOk()
            ->assertSee('WanChu Corner')
            ->assertSee('Restoran Che Na');
    }

    public function test_owner_can_see_own_business(): void
    {
        [$owner, $business] = $this->wanChuOwnerAndBusiness();

        $this->actingAs($owner)
            ->get(route('businesses.show', $business))
            ->assertOk()
            ->assertSee('WanChu Corner')
            ->assertSee('WanChu Repeat Rewards');
    }

    public function test_owner_cannot_see_another_owners_business(): void
    {
        $owner = User::query()->where('email', 'owner+wanchu@fbgrowth.local')->firstOrFail();
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();

        $this->actingAs($owner)
            ->get(route('businesses.show', $otherBusiness))
            ->assertForbidden();
    }

    public function test_owner_can_update_own_business(): void
    {
        [$owner, $business] = $this->wanChuOwnerAndBusiness();

        $this->actingAs($owner)
            ->patch(route('businesses.update', $business), [
                'name' => 'WanChu Corner Updated',
                'slug' => 'wanchu-corner-updated',
                'owner_name' => 'WanChu Owner',
                'owner_whatsapp' => '60122223333',
                'business_type' => 'cafe',
            ])
            ->assertRedirect(route('businesses.show', $business));

        $this->assertDatabaseHas('businesses', [
            'id' => $business->id,
            'name' => 'WanChu Corner Updated',
            'slug' => 'wanchu-corner-updated',
            'owner_whatsapp' => '60122223333',
            'business_type' => 'cafe',
        ]);
    }

    public function test_owner_cannot_update_another_owners_business(): void
    {
        $owner = User::query()->where('email', 'owner+wanchu@fbgrowth.local')->firstOrFail();
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();

        $this->actingAs($owner)
            ->patch(route('businesses.update', $otherBusiness), [
                'name' => 'Not Allowed',
                'slug' => 'not-allowed',
                'owner_name' => 'Nope',
                'owner_whatsapp' => '60100000000',
                'business_type' => 'restaurant',
            ])
            ->assertForbidden();

        $this->assertDatabaseHas('businesses', [
            'id' => $otherBusiness->id,
            'name' => 'Restoran Che Na',
            'slug' => 'restoran-che-na',
        ]);
    }

    public function test_owner_can_update_own_loyalty_program(): void
    {
        [$owner, $business] = $this->wanChuOwnerAndBusiness();

        $this->actingAs($owner)
            ->patch(route('businesses.loyalty.update', $business), [
                'name' => 'WanChu VIP Stamps',
                'stamps_required' => 9,
                'reward_name' => 'Free nasi lemak',
                'reward_description' => 'Redeem after nine valid visits.',
                'welcome_stamp_enabled' => '1',
                'is_active' => '1',
            ])
            ->assertRedirect(route('businesses.show', $business));

        $this->assertDatabaseHas('loyalty_programs', [
            'business_id' => $business->id,
            'name' => 'WanChu VIP Stamps',
            'stamps_required' => 9,
            'reward_name' => 'Free nasi lemak',
        ]);
    }

    private function wanChuOwnerAndBusiness(): array
    {
        $owner = User::query()->where('email', 'owner+wanchu@fbgrowth.local')->firstOrFail();
        $business = Business::query()->where('slug', 'wanchu-corner')->firstOrFail();

        return [$owner, $business];
    }
}
