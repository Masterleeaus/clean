<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CustomerCheckIn;
use App\Models\CustomerLoyaltyAccount;
use App\Models\StampTransaction;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class GosFnbCorrectionsTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_same_customer_cannot_check_in_again_before_branch_cooldown_expires(): void
    {
        $customer = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');
        $branch->update(['check_in_cooldown_minutes' => 45]);

        $this->customerCheckIn($customer, $branch)->assertOk();
        $this->travel(44)->minutes();

        $this->customerCheckIn($customer, $branch)
            ->assertOk()
            ->assertSee('Cooldown belum selesai. Check-in/reward tidak dikemaskini.');

        $this->assertSame(1, CustomerCheckIn::query()->where('branch_id', $branch->id)->count());
    }

    public function test_same_customer_can_check_in_again_after_branch_cooldown_expires(): void
    {
        $customer = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');
        $branch->update(['check_in_cooldown_minutes' => 30]);

        $this->customerCheckIn($customer, $branch)->assertOk();
        $this->travel(30)->minutes();

        $this->customerCheckIn($customer, $branch)
            ->assertOk()
            ->assertSee('Check-in berjaya direkodkan');

        $this->assertSame(2, CustomerCheckIn::query()->where('branch_id', $branch->id)->count());
    }

    public function test_branch_manager_can_set_cooldown_only_for_assigned_branch(): void
    {
        $manager = $this->user('branch+wanchu@fbgrowth.local');
        $assignedBranch = $this->branch('WANCHU-MAIN');
        $otherBranch = $this->branch('CHENA-MAIN');

        $this->actingAs($manager)
            ->patch(route('businesses.branches.cooldown.update', [$assignedBranch->business, $assignedBranch]), [
                'check_in_cooldown_minutes' => 25,
            ])
            ->assertRedirect(route('businesses.branches.show', [$assignedBranch->business, $assignedBranch]));

        $this->assertDatabaseHas('branches', [
            'id' => $assignedBranch->id,
            'check_in_cooldown_minutes' => 25,
        ]);

        $this->actingAs($manager)
            ->patch(route('businesses.branches.cooldown.update', [$otherBranch->business, $otherBranch]), [
                'check_in_cooldown_minutes' => 25,
            ])
            ->assertForbidden();
    }

    public function test_business_owner_can_set_and_view_cooldown_for_owned_branch(): void
    {
        $owner = $this->user('owner+wanchu@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($owner)
            ->patch(route('businesses.branches.cooldown.update', [$branch->business, $branch]), [
                'check_in_cooldown_minutes' => 35,
            ])
            ->assertRedirect(route('businesses.branches.show', [$branch->business, $branch]));

        $this->actingAs($owner)
            ->get(route('businesses.branches.show', [$branch->business, $branch]))
            ->assertOk()
            ->assertSee('Check-in cooldown')
            ->assertSee('35 minutes');
    }

    public function test_customer_cannot_manage_branch_cooldown(): void
    {
        $customer = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($customer)
            ->patch(route('businesses.branches.cooldown.update', [$branch->business, $branch]), [
                'check_in_cooldown_minutes' => 20,
            ])
            ->assertForbidden();
    }

    public function test_blocked_check_in_does_not_increase_reward_or_stamp(): void
    {
        $customer = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');
        $branch->update(['check_in_cooldown_minutes' => 60]);

        $this->customerCheckIn($customer, $branch)->assertOk();
        $this->travel(10)->minutes();
        $this->customerCheckIn($customer, $branch)->assertOk();

        $account = CustomerLoyaltyAccount::query()
            ->whereHas('customer', fn ($query) => $query->where('user_id', $customer->id))
            ->firstOrFail();

        $this->assertSame(0, $account->current_stamps);
        $this->assertSame(1, CustomerCheckIn::query()->where('branch_id', $branch->id)->count());
        $this->assertSame(0, StampTransaction::query()->where('branch_id', $branch->id)->count());
    }

    public function test_customer_does_not_see_analytics_or_ai_insight(): void
    {
        $customer = $this->user('customer@fbgrowth.local');

        $this->actingAs($customer)
            ->get(route('analytics.index'))
            ->assertForbidden();

        $this->actingAs($customer)
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Check-in saya')
            ->assertSee('Reward/Loyalty Status')
            ->assertSee('Submitted Feedback')
            ->assertDontSee('Analytics Saya')
            ->assertDontSee('AI Insight Engine');
    }

    private function customerCheckIn(User $customer, Branch $branch)
    {
        return $this->actingAs($customer)
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
            ]);
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business')->where('code', $code)->firstOrFail();
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
