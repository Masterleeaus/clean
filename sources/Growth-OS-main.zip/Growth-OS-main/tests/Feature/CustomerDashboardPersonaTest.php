<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\CustomerLoyaltyAccount;
use App\Models\ProductService;
use App\Models\RewardRedemption;
use App\Models\StampTransaction;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CustomerDashboardPersonaTest extends TestCase
{
    use RefreshDatabase;

    private User $customerUser;

    private Business $business;

    private Branch $branch;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);

        $this->customerUser = User::query()->where('email', 'customer@fbgrowth.local')->firstOrFail();
        $this->business = Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
        $this->branch = Branch::query()->where('code', 'WANCHU-MAIN')->firstOrFail();
    }

    public function test_customer_portal_is_customer_only_and_confirmed_reward_scoped(): void
    {
        $customer = $this->customerForUser($this->customerUser);
        $this->confirmedRewardActivity($customer);
        CustomerFeedback::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => $customer->id,
            'comment' => 'My customer portal feedback.',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'source' => 'customer_dashboard_persona_review',
            'submitted_at' => now(),
        ]);
        CustomerFeedback::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => Customer::factory()->create(['business_id' => $this->business->id])->id,
            'comment' => 'Other customer hidden feedback.',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'submitted_at' => now(),
        ]);

        $this->actingAs($this->customerUser)
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Customer Portal')
            ->assertSee('Customer account hanya boleh akses portal pelanggan')
            ->assertSee('reward/stamp hanya confirmed selepas Branch Manager capture Product/Service purchase yang sah')
            ->assertSee('Confirmed stamps sahaja')
            ->assertSee('Confirmed Reward')
            ->assertSee('Reward/Loyalty Status')
            ->assertSee('Hantar Maklumbalas')
            ->assertSee('Customer Check-in')
            ->assertSee('Check-in di Premis')
            ->assertSee('Gunakan jika anda berada di kedai.')
            ->assertSee('Check-in untuk Order Online')
            ->assertSee('Gunakan jika anda membuat order melalui WhatsApp, delivery, pickup atau channel luar.')
            ->assertSee('bukan POS atau ordering system')
            ->assertSee('My customer portal feedback.')
            ->assertDontSee('Other customer hidden feedback.')
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Mark No Purchase')
            ->assertDontSee('Redeem Reward')
            ->assertDontSee('Analytics')
            ->assertDontSee('AI Insight')
            ->assertDontSee('AI Action')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('API key')
            ->assertDontSee('secret');
    }

    public function test_customer_reward_page_shows_own_confirmed_stamp_and_reward_history(): void
    {
        $customer = $this->customerForUser($this->customerUser);
        $this->confirmedRewardActivity($customer);
        $otherCustomer = Customer::factory()->create(['business_id' => $this->business->id]);
        StampTransaction::factory()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => $otherCustomer->id,
            'loyalty_program_id' => $this->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'stamps' => 4,
            'description' => 'Other customer stamp history.',
        ]);

        $this->actingAs($this->customerUser)
            ->get(route('customer.rewards'))
            ->assertOk()
            ->assertSee('Confirmed Reward/Stamp Status')
            ->assertSee('Reward/Stamp History')
            ->assertSee('Reward Redemption History')
            ->assertSee('Current stamps')
            ->assertSee('earned')
            ->assertSee('Free drink')
            ->assertSee('Customer tidak boleh self-claim purchase')
            ->assertDontSee('Other customer stamp history.')
            ->assertDontSee('Redeem Reward')
            ->assertDontSee('Self-Claim Purchase');
    }

    public function test_customer_can_check_in_and_submit_free_feedback_without_completed_purchase(): void
    {
        $this->actingAs($this->customerUser)
            ->post(route('customer.check-in.store'), [
                'branch_id' => $this->branch->id,
                'whatsapp_number' => '60111112222',
            ])
            ->assertOk()
            ->assertSee('Check-in berjaya direkodkan.')
            ->assertSee('Reward/stamp hanya confirmed selepas Branch Manager capture Product/Service purchase yang sah')
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Confirmed Reward');

        $this->assertDatabaseHas('customer_check_ins', [
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'user_id' => $this->customerUser->id,
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);

        $this->actingAs($this->customerUser)
            ->get(route('customer.feedback'))
            ->assertOk()
            ->assertSee('Hantar Maklumbalas')
            ->assertDontSee('Pending Feedback');

        $this->actingAs($this->customerUser)
            ->post(route('customer.feedback.store'), [
                'branch_id' => $this->branch->id,
                'rating' => 5,
                'comment' => 'Free feedback without completed purchase.',
            ])
            ->assertRedirect(route('customer.feedback'));

        $this->assertDatabaseHas('customer_feedback', [
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'comment' => 'Free feedback without completed purchase.',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
        ]);
    }

    public function test_customer_is_blocked_from_internal_dashboards_and_operation_routes(): void
    {
        $checkIn = $this->pendingCheckInForCustomer();
        $product = ProductService::query()->visibleForBranch($this->branch)->active()->firstOrFail();

        $this->actingAs($this->customerUser)->get(route('dashboards.system-manager'))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('dashboards.system-admin'))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('dashboards.business-owner'))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('dashboards.branch-manager'))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('dashboards.business-branch-combined'))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('analytics.index'))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('businesses.show', $this->business))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('businesses.customers.index', $this->business))->assertForbidden();
        $this->actingAs($this->customerUser)->get(route('businesses.branches.check-ins', ['business' => $this->business, 'branch' => $this->branch]))->assertForbidden();

        $this->actingAs($this->customerUser)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $this->business,
                'branch' => $this->branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
            ])
            ->assertForbidden();

        $this->actingAs($this->customerUser)
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $this->business,
                'branch' => $this->branch,
                'checkIn' => $checkIn,
            ]))
            ->assertForbidden();

        $this->actingAs($this->customerUser)
            ->post(route('businesses.branches.rewards.redeem', [
                'business' => $this->business,
                'branch' => $this->branch,
                'customer' => $this->customerForUser($this->customerUser),
            ]))
            ->assertForbidden();
    }

    private function confirmedRewardActivity(Customer $customer): void
    {
        $program = $this->business->loyaltyPrograms()->active()->firstOrFail();
        $product = ProductService::query()->visibleForBranch($this->branch)->active()->firstOrFail();
        $checkIn = CustomerCheckIn::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => $customer->id,
            'user_id' => $this->customerUser->id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'customer_dashboard_persona_review',
            'reward_status' => CustomerCheckIn::REWARD_STATUS_GRANTED,
            'stamps_earned' => 1,
            'reward_granted_at' => now(),
        ]);

        CheckInProductService::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'captured_by_user_id' => User::query()->where('email', 'branch+wanchu@fbgrowth.local')->firstOrFail()->id,
            'quantity' => 1,
            'price_at_capture' => $product->price,
            'total_amount' => $product->price,
            'capture_type' => 'purchase',
            'capture_source' => 'staff_manual',
        ]);

        CustomerLoyaltyAccount::query()->updateOrCreate(
            [
                'business_id' => $this->business->id,
                'customer_id' => $customer->id,
                'loyalty_program_id' => $program->id,
            ],
            [
                'current_stamps' => 8,
                'total_stamps_earned' => 8,
                'total_rewards_redeemed' => 1,
            ],
        );

        StampTransaction::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'type' => StampTransaction::TYPE_EARNED,
            'stamps' => 1,
            'description' => 'Confirmed customer persona stamp.',
        ]);

        RewardRedemption::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'reward_name' => 'Free drink',
            'stamps_spent' => 8,
            'verified_by_user_id' => User::query()->where('email', 'branch+wanchu@fbgrowth.local')->firstOrFail()->id,
            'redeemed_at' => now(),
        ]);
    }

    private function pendingCheckInForCustomer(): CustomerCheckIn
    {
        $customer = $this->customerForUser($this->customerUser);

        return CustomerCheckIn::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => $customer->id,
            'user_id' => $this->customerUser->id,
            'loyalty_program_id' => $this->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'customer_dashboard_persona_review',
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);
    }

    private function customerForUser(User $user): Customer
    {
        return Customer::query()
            ->where('business_id', $this->business->id)
            ->where('user_id', $user->id)
            ->firstOrFail();
    }
}
