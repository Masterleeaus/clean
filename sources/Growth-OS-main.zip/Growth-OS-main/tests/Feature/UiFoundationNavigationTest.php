<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UiFoundationNavigationTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_customer_navigation_stays_portal_scoped_with_check_in_fab(): void
    {
        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Customer Portal')
            ->assertSee('Customer Check-in')
            ->assertSee('href="#customer-check-in"', false)
            ->assertSee('gos-floating-action', false)
            ->assertSee('Rewards')
            ->assertSee('Feedback')
            ->assertDontSee('Analytics')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Business setup');
    }

    public function test_system_admin_navigation_stays_admin_support_scoped(): void
    {
        $this->actingAs($this->user('admin@fbgrowth.local'))
            ->get(route('dashboards.system-admin'))
            ->assertOk()
            ->assertSee('System Admin')
            ->assertSee('Admin Support')
            ->assertSee('Admin Analytics')
            ->assertSee('Business setup')
            ->assertSee('Create business')
            ->assertSee('AI Provider Status')
            ->assertDontSee('Platform Analytics / AI')
            ->assertDontSee('Business Performance')
            ->assertDontSee('Branch Operations')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Customer Portal');
    }

    public function test_system_manager_navigation_stays_platform_scoped(): void
    {
        $this->actingAs($this->user('manager@gos-fnb.local'))
            ->get(route('dashboards.system-manager'))
            ->assertOk()
            ->assertSee('System Manager')
            ->assertSee('Platform Analytics / AI')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Business setup')
            ->assertDontSee('Businesses')
            ->assertDontSee('Branch Operations')
            ->assertDontSee('Customer Portal');
    }

    public function test_business_owner_navigation_has_business_scope_without_capture_actions(): void
    {
        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('dashboards.business-owner'))
            ->assertOk()
            ->assertSee('Business Owner')
            ->assertSee('Business Performance')
            ->assertSee('Analytics / AI')
            ->assertSee('Businesses')
            ->assertDontSee('Branch Operations')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Customer Portal');
    }

    public function test_branch_manager_navigation_has_branch_operation_scope_only(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('dashboards.branch-manager'))
            ->assertOk()
            ->assertSee('Branch Manager')
            ->assertSee('Branch Operation')
            ->assertSee('Pending Capture')
            ->assertSee('Capture Purchase')
            ->assertSee(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]), false)
            ->assertSee('Branch Analytics / AI')
            ->assertDontSee('Business Performance')
            ->assertDontSee('Businesses')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Customer Portal');
    }

    public function test_combined_business_branch_navigation_keeps_both_scopes_without_admin_status(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->actingAs($this->user('owner-branch+wanchu@fbgrowth.local'))
            ->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Business Owner / Branch Manager')
            ->assertSee('Business Performance')
            ->assertSee('Branch Operations')
            ->assertSee('Capture Purchase')
            ->assertSee(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]), false)
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Customer Portal');
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business')->where('code', $code)->firstOrFail();
    }
}
