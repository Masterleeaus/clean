<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\ProductService;
use App\Models\ProductServiceReviewAlert;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Route;
use Tests\TestCase;

class CheNaPilotCatalogManagementTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_pilot_login_accounts_use_gos_fnb_pilot_domain_and_password(): void
    {
        $accounts = [
            'manager@gos-fnb.pilot' => ['GOS-F&B System Manager', User::ROLE_SYSTEM_MANAGER, null],
            'admin@gos-fnb.pilot' => ['GOS-F&B System Admin', User::ROLE_SYSTEM_ADMIN, null],
            'owner+wanchu@gos-fnb.pilot' => ['WanChu Corner Owner', User::ROLE_BUSINESS_OWNER, null],
            'branch+wanchu@gos-fnb.pilot' => ['WanChu Branch Manager', User::ROLE_BRANCH_MANAGER, null],
            'owner-branch+wanchu@gos-fnb.pilot' => ['WanChu Owner Branch Combined', User::ROLE_BUSINESS_OWNER, User::ROLE_BRANCH_MANAGER],
            'customer@gos-fnb.pilot' => ['GOS-F&B Demo Customer', User::ROLE_CUSTOMER, null],
            'owner+chena@gos-fnb.pilot' => ['Restoran Che Na Owner', User::ROLE_BUSINESS_OWNER, null],
            'branch+chena@gos-fnb.pilot' => ['Restoran Che Na Branch Manager', User::ROLE_BRANCH_MANAGER, null],
            'owner-branch+chena@gos-fnb.pilot' => ['Restoran Che Na Owner Branch Combined', User::ROLE_BUSINESS_OWNER, User::ROLE_BRANCH_MANAGER],
        ];

        foreach ($accounts as $email => [$name, $role, $secondaryRole]) {
            $user = $this->user($email);

            $this->assertStringEndsWith('@gos-fnb.pilot', $user->email);
            $this->assertSame($name, $user->name);
            $this->assertSame($role, $user->role);
            $this->assertSame($secondaryRole, $user->secondary_role);
            $this->assertTrue(Hash::check('password', $user->password));
        }
    }

    public function test_che_na_business_branch_personas_and_catalog_are_seeded(): void
    {
        $business = $this->business('restoran-che-na');
        $branch = $this->branch('CHENA-MAIN');
        $owner = $this->user('owner+chena@gos-fnb.pilot');
        $branchManager = $this->user('branch+chena@gos-fnb.pilot');
        $combined = $this->user('owner-branch+chena@gos-fnb.pilot');

        $this->assertSame('Restoran Che Na', $business->name);
        $this->assertSame('Restoran Che Na - Main Branch', $branch->name);
        $this->assertTrue($owner->canAccessBusiness($business));
        $this->assertTrue($owner->canAccessBranch($branch));
        $this->assertTrue($branchManager->canAccessBranch($branch));
        $this->assertTrue($combined->hasBusinessCombinedAccess());
        $this->assertContains($business->id, $combined->scopedBusinessIds());
        $this->assertContains($branch->id, $combined->scopedBranchIds());

        $this->assertGreaterThanOrEqual(
            35,
            ProductService::query()->where('business_id', $business->id)->where('branch_id', $branch->id)->count(),
        );

        foreach (['Nasi Lemak Biasa', 'Teh Ais Special', 'Set Premium Dinner', 'Nasi Campur Ayam Large'] as $name) {
            $this->assertDatabaseHas('product_services', [
                'business_id' => $business->id,
                'branch_id' => $branch->id,
                'name' => $name,
            ]);
        }

        foreach ([
            'Nasi Lemak Biasa' => 'Makanan',
            'Teh Ais' => 'Minuman',
            'Set Family Dinner' => 'Set Kombo',
            'Telur Dadar' => 'Add-on',
        ] as $name => $category) {
            $this->assertDatabaseHas('product_services', [
                'business_id' => $business->id,
                'branch_id' => $branch->id,
                'name' => $name,
                'category' => $category,
            ]);
        }

        $this->assertTrue(ProductServiceReviewAlert::query()
            ->where('business_id', $business->id)
            ->whereIn('issue_type', ['similar_name', 'suspicious_low_price', 'suspicious_high_price'])
            ->exists());
    }

    public function test_product_service_list_is_grouped_by_category_and_sorted_alphabetically(): void
    {
        $manager = $this->user('branch+chena@gos-fnb.pilot');
        $business = $this->business('restoran-che-na');

        $this->assertSame(['Makanan', 'Minuman', 'Set Kombo', 'Add-on'], ProductService::DEFAULT_CATEGORIES);
        $this->assertNotContains('Lain-lain', ProductService::DEFAULT_CATEGORIES);

        $response = $this->actingAs($manager)
            ->get(route('businesses.product-services.index', $business))
            ->assertOk()
            ->assertSee('Semua')
            ->assertSee('Makanan')
            ->assertSee('Minuman')
            ->assertSee('Set Kombo')
            ->assertSee('Add-on')
            ->assertDontSee('Lain-lain');

        $html = $response->getContent();
        $this->assertOrderedIn($html, [
            'data-category-tab="Semua"',
            'data-category-tab="Makanan"',
            'data-category-tab="Minuman"',
            'data-category-tab="Set Kombo"',
            'data-category-tab="Add-on"',
        ]);
        $this->assertOrderedIn($html, [
            'data-category="Makanan"',
            'data-category="Minuman"',
            'data-category="Set Kombo"',
            'data-category="Add-on"',
        ]);
        $this->assertOrderedIn($html, [
            'data-product-name="Bihun Goreng"',
            'data-product-name="Kailan Ikan Masin"',
            'data-product-name="Lontong"',
            'data-product-name="Mee Goreng Mamak"',
        ]);
        $this->assertOrderedIn($html, [
            'data-product-name="Kopi Ais"',
            'data-product-name="Kopi Ice"',
            'data-product-name="Kopi O Panas"',
            'data-product-name="Milo Ais"',
        ]);

        $this->actingAs($manager)
            ->get(route('businesses.product-services.index', ['business' => $business, 'category' => 'Minuman']))
            ->assertOk()
            ->assertSee('data-category-tab="Minuman"', false)
            ->assertSee('Kopi Ais')
            ->assertSee('Teh Ais')
            ->assertDontSee('Nasi Lemak Biasa');
    }

    public function test_category_dropdown_supports_default_existing_and_new_categories(): void
    {
        $manager = $this->user('branch+chena@gos-fnb.pilot');
        $business = $this->business('restoran-che-na');
        $branch = $this->branch('CHENA-MAIN');

        $this->actingAs($manager)
            ->get(route('businesses.product-services.create', $business))
            ->assertOk()
            ->assertSee('Makanan')
            ->assertSee('Minuman')
            ->assertSee('Set Kombo')
            ->assertSee('Add-on')
            ->assertDontSee('Lain-lain')
            ->assertSee('+ Tambah kategori baharu');

        $this->actingAs($manager)
            ->post(route('businesses.product-services.store', $business), [
                'branch_id' => $branch->id,
                'name' => 'Kuih Keria',
                'category' => 'makanan',
                'type' => 'product',
                'price' => '2.80',
                'is_active' => '1',
            ])
            ->assertRedirect(route('businesses.product-services.index', $business));

        $this->assertDatabaseHas('product_services', [
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'name' => 'Kuih Keria',
            'category' => 'Makanan',
        ]);

        $this->actingAs($manager)
            ->post(route('businesses.product-services.store', $business), [
                'branch_id' => $branch->id,
                'name' => 'Katering Mini',
                'category' => '__new',
                'category_new' => ' Catering ',
                'type' => 'service',
                'price' => '80.00',
                'is_active' => '1',
            ])
            ->assertRedirect(route('businesses.product-services.index', $business))
            ->assertSessionHas('review_warnings');

        $this->assertDatabaseHas('product_services', [
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'name' => 'Katering Mini',
            'category' => 'Catering',
        ]);
        $this->assertDatabaseHas('product_service_review_alerts', [
            'business_id' => $business->id,
            'issue_type' => 'new_category_created',
        ]);

        $this->actingAs($manager)
            ->get(route('businesses.product-services.create', $business))
            ->assertOk()
            ->assertSee('Catering');

        $this->actingAs($manager)
            ->get(route('businesses.product-services.index', ['business' => $business, 'category' => 'Catering']))
            ->assertOk()
            ->assertSee('data-category-tab="Catering"', false)
            ->assertSee('Katering Mini')
            ->assertDontSee('Nasi Lemak Biasa');
    }

    public function test_branch_manager_and_bo_cum_bm_can_edit_product_category(): void
    {
        $manager = $this->user('branch+chena@gos-fnb.pilot');
        $combined = $this->user('owner-branch+chena@gos-fnb.pilot');
        $business = $this->business('restoran-che-na');
        $branch = $this->branch('CHENA-MAIN');
        $product = ProductService::query()
            ->where('business_id', $business->id)
            ->where('branch_id', $branch->id)
            ->where('name', 'Nasi Lemak Biasa')
            ->firstOrFail();

        $this->actingAs($manager)
            ->patch(route('businesses.product-services.update', ['business' => $business, 'productService' => $product]), [
                'branch_id' => $branch->id,
                'name' => 'Nasi Lemak Biasa',
                'category' => '__new',
                'category_new' => 'Sarapan',
                'type' => 'product',
                'price' => '4.50',
                'is_active' => '1',
            ])
            ->assertRedirect(route('businesses.product-services.index', $business));

        $this->assertSame('Sarapan', $product->refresh()->category);

        $this->actingAs($combined)
            ->get(route('businesses.product-services.index', ['business' => $business, 'category' => 'Sarapan']))
            ->assertOk()
            ->assertSee('data-category-tab="Sarapan"', false)
            ->assertSee('Nasi Lemak Biasa');

        $this->actingAs($combined)
            ->patch(route('businesses.product-services.update', ['business' => $business, 'productService' => $product]), [
                'branch_id' => $branch->id,
                'name' => 'Nasi Lemak Biasa',
                'category' => 'Makanan',
                'type' => 'product',
                'price' => '4.50',
                'is_active' => '1',
            ])
            ->assertRedirect(route('businesses.product-services.index', $business));

        $this->assertSame('Makanan', $product->refresh()->category);
    }

    public function test_che_na_personas_access_dashboards_with_correct_scope(): void
    {
        $this->actingAs($this->user('owner+chena@gos-fnb.pilot'))
            ->get(route('dashboards.business-owner'))
            ->assertOk()
            ->assertSee('Restoran Che Na')
            ->assertSee('Product/Service Review Alerts')
            ->assertDontSee('WanChu Corner');

        $this->actingAs($this->user('branch+chena@gos-fnb.pilot'))
            ->get(route('dashboards.branch-manager'))
            ->assertOk()
            ->assertSee('Branch Manager Dashboard')
            ->assertSee('Restoran Che Na - Main Branch')
            ->assertSee('Product/Service Management')
            ->assertDontSee('WanChu Corner');

        $this->actingAs($this->user('owner-branch+chena@gos-fnb.pilot'))
            ->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Business Performance')
            ->assertSee('Branch Operations')
            ->assertSee('Restoran Che Na')
            ->assertDontSee('WanChu Corner');
    }

    public function test_branch_manager_can_manage_che_na_product_services_and_is_scoped_to_assigned_branch(): void
    {
        $manager = $this->user('branch+chena@gos-fnb.pilot');
        $business = $this->business('restoran-che-na');
        $branch = $this->branch('CHENA-MAIN');
        $wanChu = $this->business('wanchu-corner');
        $wanChuBranch = $this->branch('WANCHU-MAIN');

        $this->actingAs($manager)
            ->get(route('businesses.product-services.index', $business))
            ->assertOk()
            ->assertSee('Nasi Lemak Biasa');

        $this->actingAs($manager)
            ->get(route('businesses.product-services.create', $business))
            ->assertOk()
            ->assertSee('Restoran Che Na - Main Branch')
            ->assertDontSee('All branches');

        $this->actingAs($manager)
            ->post(route('businesses.product-services.store', $business), [
                'branch_id' => $branch->id,
                'name' => 'Kuih Seri Muka',
                'category' => 'Makanan',
                'type' => 'product',
                'price' => '3.20',
                'is_active' => '1',
            ])
            ->assertRedirect(route('businesses.product-services.index', $business));

        $product = ProductService::query()
            ->where('business_id', $business->id)
            ->where('name', 'Kuih Seri Muka')
            ->firstOrFail();

        $this->actingAs($manager)
            ->patch(route('businesses.product-services.update', ['business' => $business, 'productService' => $product]), [
                'branch_id' => $branch->id,
                'name' => 'Kuih Seri Muka Premium',
                'category' => 'Makanan',
                'type' => 'product',
                'price' => '4.20',
                'is_active' => '1',
            ])
            ->assertRedirect(route('businesses.product-services.index', $business));

        $this->assertDatabaseHas('product_services', [
            'id' => $product->id,
            'name' => 'Kuih Seri Muka Premium',
            'price' => 4.20,
            'is_active' => true,
        ]);

        $this->actingAs($manager)
            ->delete(route('businesses.product-services.destroy', ['business' => $business, 'productService' => $product]))
            ->assertRedirect(route('businesses.product-services.index', $business));

        $this->assertDatabaseMissing('product_services', ['id' => $product->id]);

        $this->actingAs($manager)
            ->get(route('businesses.product-services.index', $wanChu))
            ->assertForbidden();

        $this->actingAs($manager)
            ->post(route('businesses.product-services.store', $wanChu), [
                'branch_id' => $wanChuBranch->id,
                'name' => 'Blocked Outside Scope',
                'category' => 'Makanan',
                'type' => 'product',
                'price' => '9.00',
                'is_active' => '1',
            ])
            ->assertForbidden();
    }

    public function test_used_product_service_is_archived_instead_of_hard_deleted_and_capture_rules_still_work(): void
    {
        $manager = $this->user('branch+chena@gos-fnb.pilot');
        $business = $this->business('restoran-che-na');
        $branch = $this->branch('CHENA-MAIN');
        $product = ProductService::query()
            ->where('business_id', $business->id)
            ->where('branch_id', $branch->id)
            ->where('name', 'Nasi Lemak Biasa')
            ->firstOrFail();
        $checkIn = $this->pendingCheckIn($branch);

        $this->actingAs($manager)
            ->get(route('businesses.branches.check-ins', ['business' => $business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('Makanan - Nasi Lemak Biasa');

        $this->actingAs($manager)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 2,
                'capture_type' => 'purchase',
                'capture_reference' => 'che-na-used-product-capture',
            ])
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $business, 'branch' => $branch]));

        $this->assertDatabaseHas('check_in_product_services', [
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'quantity' => 2,
            'capture_type' => 'purchase',
        ]);
        $this->assertSame(CustomerCheckIn::REWARD_STATUS_GRANTED, $checkIn->refresh()->reward_status);

        $this->actingAs($manager)
            ->delete(route('businesses.product-services.destroy', ['business' => $business, 'productService' => $product]))
            ->assertRedirect(route('businesses.product-services.index', $business));

        $product->refresh();

        $this->assertFalse($product->is_active);
        $this->assertSame('archived', $product->review_status);
        $this->assertNotNull($product->archived_at);
        $this->assertDatabaseHas('product_service_review_alerts', [
            'business_id' => $business->id,
            'product_service_id' => $product->id,
            'issue_type' => 'archive_used_item',
        ]);
    }

    public function test_bo_receives_product_service_review_alerts_scoped_to_own_business(): void
    {
        $manager = $this->user('branch+chena@gos-fnb.pilot');
        $business = $this->business('restoran-che-na');
        $branch = $this->branch('CHENA-MAIN');

        $this->actingAs($manager)
            ->post(route('businesses.product-services.store', $business), [
                'branch_id' => $branch->id,
                'name' => 'Teh Ais',
                'category' => 'Minuman',
                'type' => 'product',
                'price' => '0.10',
                'is_active' => '1',
            ])
            ->assertRedirect(route('businesses.product-services.index', $business))
            ->assertSessionHas('review_warnings');

        foreach (['duplicate_name', 'suspicious_low_price'] as $issueType) {
            $this->assertDatabaseHas('product_service_review_alerts', [
                'business_id' => $business->id,
                'issue_type' => $issueType,
            ]);
        }

        $this->actingAs($this->user('owner+chena@gos-fnb.pilot'))
            ->get(route('dashboards.business-owner'))
            ->assertOk()
            ->assertSee('Product/Service Review Alerts')
            ->assertSee('Teh Ais')
            ->assertSee('suspicious low price')
            ->assertSee('Restoran Che Na Branch Manager');

        $this->actingAs($this->user('owner+wanchu@gos-fnb.pilot'))
            ->get(route('dashboards.business-owner'))
            ->assertOk()
            ->assertDontSee('Product/Service Review Alerts')
            ->assertDontSee('Restoran Che Na Branch Manager');
    }

    public function test_review_checks_detect_similarity_price_anomalies_and_large_price_change(): void
    {
        $manager = $this->user('branch+chena@gos-fnb.pilot');
        $business = $this->business('restoran-che-na');
        $branch = $this->branch('CHENA-MAIN');

        $this->createProductAs($manager, $business, $branch, 'Kopi Icee', '2.80');
        $this->createProductAs($manager, $business, $branch, 'Low Price Test', '0.10');
        $this->createProductAs($manager, $business, $branch, 'High Price Test', '199.90');
        $this->createProductAs($manager, $business, $branch, 'Price Jump Test', '10.00');

        $jumpProduct = ProductService::query()
            ->where('business_id', $business->id)
            ->where('name', 'Price Jump Test')
            ->firstOrFail();

        $this->actingAs($manager)
            ->patch(route('businesses.product-services.update', ['business' => $business, 'productService' => $jumpProduct]), [
                'branch_id' => $branch->id,
                'name' => 'Price Jump Test',
                'category' => 'Makanan',
                'type' => 'product',
                'price' => '40.00',
                'is_active' => '1',
            ])
            ->assertRedirect(route('businesses.product-services.index', $business));

        foreach (['similar_name', 'suspicious_low_price', 'suspicious_high_price', 'large_price_change'] as $issueType) {
            $this->assertDatabaseHas('product_service_review_alerts', [
                'business_id' => $business->id,
                'issue_type' => $issueType,
            ]);
        }
    }

    public function test_customer_cannot_manage_catalog_self_claim_purchase_or_access_pos_surfaces(): void
    {
        $customer = $this->user('customer@gos-fnb.pilot');
        $business = $this->business('restoran-che-na');
        $branch = $this->branch('CHENA-MAIN');
        $product = ProductService::query()->where('business_id', $business->id)->where('branch_id', $branch->id)->firstOrFail();
        $checkIn = $this->pendingCheckIn($branch);

        $this->actingAs($customer)
            ->get(route('businesses.product-services.index', $business))
            ->assertForbidden();

        $this->actingAs($customer)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
                'capture_reference' => 'customer-self-claim-blocked',
            ])
            ->assertForbidden();

        $this->actingAs($customer)
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertDontSee('Pending Purchase Capture');

        $uris = collect(Route::getRoutes())->map(fn ($route): string => $route->uri())->join(' ');

        foreach (['cart', 'payment', 'payments', 'pos', 'orders'] as $forbiddenUriPart) {
            $this->assertStringNotContainsString($forbiddenUriPart, $uris);
        }

        $this->assertSame(0, CheckInProductService::query()->where('capture_reference', 'customer-self-claim-blocked')->count());
    }

    private function createProductAs(User $manager, Business $business, Branch $branch, string $name, string $price): void
    {
        $this->actingAs($manager)
            ->post(route('businesses.product-services.store', $business), [
                'branch_id' => $branch->id,
                'name' => $name,
                'category' => 'Makanan',
                'type' => 'product',
                'price' => $price,
                'is_active' => '1',
            ])
            ->assertRedirect(route('businesses.product-services.index', $business));
    }

    private function pendingCheckIn(Branch $branch): CustomerCheckIn
    {
        $customer = Customer::query()->create([
            'business_id' => $branch->business_id,
            'name' => 'Che Na Test Customer',
            'whatsapp_number' => '601'.random_int(100000000, 999999999),
        ]);

        return CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $branch->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'che_na_pilot_catalog_management_test',
            'check_in_type' => CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL,
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function business(string $slug): Business
    {
        return Business::query()->where('slug', $slug)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business.loyaltyPrograms')->where('code', $code)->firstOrFail();
    }

    /**
     * @param  array<int, string>  $needles
     */
    private function assertOrderedIn(string $haystack, array $needles): void
    {
        $lastPosition = -1;

        foreach ($needles as $needle) {
            $position = strpos($haystack, $needle);
            $this->assertNotFalse($position, "Missing {$needle}.");
            $this->assertGreaterThan($lastPosition, $position, "{$needle} is not in the expected order.");
            $lastPosition = $position;
        }
    }
}
