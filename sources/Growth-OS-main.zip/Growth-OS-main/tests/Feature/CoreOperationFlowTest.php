<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\CustomerLoyaltyAccount;
use App\Models\LoyaltyProgram;
use App\Models\ProductService;
use App\Models\StampTransaction;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Routing\Middleware\ThrottleRequests;
use Tests\TestCase;

class CoreOperationFlowTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->withoutMiddleware(ThrottleRequests::class);
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_dummy_master_data_is_ready_for_core_operation_flow(): void
    {
        $branch = $this->branch();

        $this->assertNotNull($branch->business);
        $this->assertTrue($branch->business->loyaltyPrograms()->active()->exists());
        $this->assertTrue($branch->business->productServices()->visibleForBranch($branch)->active()->exists());
        $this->assertNotNull($this->user('owner+wanchu@fbgrowth.local'));
        $this->assertNotNull($this->user('branch+wanchu@fbgrowth.local'));
        $this->assertNotNull($this->user('owner-branch+wanchu@fbgrowth.local'));
        $this->assertNotNull($this->user('customer@fbgrowth.local'));
        $this->assertTrue($this->user('branch+wanchu@fbgrowth.local')->canAccessBranch($branch));
    }

    public function test_customer_check_in_creates_pending_purchase_without_confirming_reward(): void
    {
        $branch = $this->branch();

        $this->actingAs($this->customerUser())
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Customer Portal')
            ->assertDontSee('Business Performance')
            ->assertDontSee('Capture Purchase');

        $this->customerCheckIn($branch)
            ->assertOk()
            ->assertSee('Check-in berjaya direkodkan.')
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Reward will be confirmed after purchase is verified');

        $checkIn = CustomerCheckIn::query()->firstOrFail();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $checkIn->reward_status);
        $this->assertSame(CustomerCheckIn::PURCHASE_STATUS_PENDING, $checkIn->purchaseCaptureStatus());
        $this->assertSame(0, $checkIn->stamps_earned);
        $this->assertNull($checkIn->reward_granted_at);
        $this->assertDatabaseCount('stamp_transactions', 0);

        $this->actingAs($this->customerUser())
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Reward will be confirmed after purchase is verified')
            ->assertDontSee('Confirmed Reward');

        $this->actingAs($this->branchManager())
            ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('GOS-F&B Demo Customer')
            ->assertSee('Pending Purchase Capture');

        $this->travel(30)->minutes();

        $this->customerCheckIn($branch)
            ->assertOk()
            ->assertSee('Cooldown belum selesai');

        $this->assertSame(1, CustomerCheckIn::query()->count());
        $this->assertSame(1, CustomerCheckIn::query()->where('reward_status', CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT)->count());
        $this->assertDatabaseCount('stamp_transactions', 0);

        $this->actingAs($this->customerUser())
            ->from(route('customer.portal'))
            ->post(route('customer.check-in.store'), [
                'branch_id' => 999999,
                'whatsapp_number' => '60111112222',
            ])
            ->assertRedirect(route('customer.portal'))
            ->assertSessionHasErrors('branch_id');

        $this->actingAs($this->customerUser())
            ->get(route('dashboards.business-owner'))
            ->assertForbidden();
    }

    public function test_pending_purchase_capture_visibility_and_actions_are_scoped(): void
    {
        $branch = $this->branch();
        $pending = $this->createPendingCheckIn($branch);
        $otherBranch = $this->otherBranch();
        $otherPending = $this->createDirectPendingCheckIn($otherBranch, 'Other Branch Customer', '60122223333');

        $this->actingAs($this->branchManager())
            ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('GOS-F&B Demo Customer')
            ->assertSee($branch->name)
            ->assertSee('Pending Purchase Capture')
            ->assertSee('Capture Purchase')
            ->assertSee('Mark No Purchase')
            ->assertDontSee('Other Branch Customer');

        $this->actingAs($this->branchManager())
            ->get(route('businesses.branches.check-ins', ['business' => $otherBranch->business, 'branch' => $otherBranch]))
            ->assertForbidden();

        $otherCustomer = $this->createDirectPendingCheckIn($branch, 'Other Same Branch Customer', '60122224444');

        $this->actingAs($this->customerUser())
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('GOS-F&B Demo Customer')
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Other Same Branch Customer');

        $this->actingAs($this->businessOwner())
            ->get(route('businesses.check-ins', $branch->business))
            ->assertOk()
            ->assertSee('Pending Purchase Capture')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Mark No Purchase');

        $this->captureProduct($this->businessOwner(), $branch, $pending, $this->product($branch))
            ->assertForbidden();

        $this->actingAs($this->businessOwnerBranchManager())
            ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('Pending Purchase Capture')
            ->assertSee('Capture Purchase')
            ->assertSee('Mark No Purchase');

        $pending->forceFill(['check_in_at' => now()->subHours(CustomerCheckIn::OVERDUE_PURCHASE_CAPTURE_HOURS + 1)])->save();
        $this->assertSame(CustomerCheckIn::PURCHASE_STATUS_OVERDUE, $pending->refresh()->purchaseCaptureStatus());

        $otherPending->forceFill(['check_in_at' => now()->subHours(CustomerCheckIn::MANUAL_REVIEW_HOURS + 1)])->save();
        $this->assertSame(CustomerCheckIn::PURCHASE_STATUS_MANUAL_REVIEW, $otherPending->refresh()->purchaseCaptureStatus());
        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $otherPending->reward_status);
        $this->assertNotSame(CustomerCheckIn::REWARD_STATUS_NO_PURCHASE, $otherPending->reward_status);

        $this->actingAs($this->customerUser())
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertDontSee('Overdue Purchase Capture')
            ->assertDontSee('Manual Review Required')
            ->assertDontSee('Confirmed Reward')
            ->assertDontSee('Capture Purchase');

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $otherCustomer->refresh()->reward_status);
    }

    public function test_capture_purchase_validation_duplicate_and_repeated_purchase_rules(): void
    {
        $branch = $this->branch();
        $product = $this->product($branch);
        $pending = $this->createPendingCheckIn($branch);

        $this->actingAs($this->branchManager())
            ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee($product->name);

        $this->captureProduct($this->branchManager(), $branch, $pending, $product, quantity: 1, reference: 'core-capture-1')
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]));

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_GRANTED, $pending->refresh()->reward_status);
        $this->assertSame(CustomerCheckIn::PURCHASE_STATUS_CONFIRMED, $pending->purchaseCaptureStatus());
        $this->assertSame(1, $pending->stamps_earned);
        $this->assertDatabaseHas('check_in_product_services', [
            'customer_check_in_id' => $pending->id,
            'quantity' => 1,
            'price_at_capture' => $product->price,
            'capture_reference' => 'core-capture-1',
        ]);

        $this->captureProduct($this->branchManager(), $branch, $pending, $product, quantity: 2, reference: 'core-same-visit-repeat')
            ->assertRedirect();

        $this->assertSame(2, CheckInProductService::query()->where('customer_check_in_id', $pending->id)->count());
        $this->assertSame(1, StampTransaction::query()->count());

        $this->captureProduct($this->branchManager(), $branch, $pending, $product, quantity: 2, reference: 'core-same-visit-repeat')
            ->assertRedirect();

        $this->assertSame(1, CheckInProductService::query()->where('capture_reference', 'core-same-visit-repeat')->count());
        $this->assertSame(1, StampTransaction::query()->count());

        $this->captureProduct($this->branchManager(), $branch, $pending, $product, quantity: 0, reference: 'bad-qty')
            ->assertSessionHasErrors('quantity');

        $inactiveProduct = ProductService::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'name' => 'Inactive Pilot Item',
            'category' => 'food',
            'type' => 'product',
            'price' => 5.00,
            'is_active' => false,
        ]);

        $inactivePending = $this->createDirectPendingCheckIn($branch, 'Inactive Product Customer', '60155550000');

        $this->captureProduct($this->branchManager(), $branch, $inactivePending, $inactiveProduct, reference: 'inactive-product')
            ->assertStatus(422);

        $this->actingAs($this->branchManager())
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => 999999,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
                'capture_reference' => 'missing-check-in',
            ])
            ->assertNotFound();

        $otherBranch = $this->otherBranch();
        $otherPending = $this->createDirectPendingCheckIn($otherBranch, 'Other Capture Customer', '60155551111');

        $this->captureProduct($this->branchManager(), $otherBranch, $otherPending, $this->product($otherBranch), reference: 'other-branch-blocked')
            ->assertForbidden();

        $this->captureProduct($this->customerUser(), $branch, $inactivePending, $product, reference: 'customer-self-claim')
            ->assertForbidden();

        $this->travel(61)->minutes();
        $secondPending = $this->createPendingCheckIn($branch);

        $this->captureProduct($this->branchManager(), $branch, $secondPending, $product, quantity: 3, reference: 'core-capture-2')
            ->assertRedirect();

        $secondCapture = CheckInProductService::query()->where('capture_reference', 'core-capture-2')->firstOrFail();

        $this->assertSame(3, $secondCapture->quantity);
        $this->assertSame(number_format((float) $product->price * 3, 2, '.', ''), $secondCapture->total_amount);
        $this->assertSame(2, StampTransaction::query()->count());
        $this->assertSame(2, CustomerLoyaltyAccount::query()->where('customer_id', $secondPending->customer_id)->firstOrFail()->current_stamps);
    }

    public function test_mark_no_purchase_sets_no_reward_without_stamp_or_feedback(): void
    {
        $branch = $this->branch();
        $pending = $this->createPendingCheckIn($branch);

        $this->markNoPurchase($this->branchManager(), $branch, $pending)
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]));

        $pending->refresh();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_NO_PURCHASE, $pending->reward_status);
        $this->assertSame(CustomerCheckIn::PURCHASE_STATUS_NO_PURCHASE, $pending->purchaseCaptureStatus());
        $this->assertSame(0, $pending->stamps_earned);
        $this->assertDatabaseCount('stamp_transactions', 0);
        $this->assertDatabaseCount('customer_feedback', 0);

        $this->actingAs($this->customerUser())
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertDontSee('No Reward - No Purchase')
            ->assertDontSee('Pending Feedback');

        $secondPending = $this->createDirectPendingCheckIn($branch, 'No Purchase Unauthorized Customer', '60166660000');

        $this->markNoPurchase($this->businessOwner(), $branch, $secondPending)
            ->assertForbidden();

        $this->markNoPurchase($this->customerUser(), $branch, $secondPending)
            ->assertForbidden();
    }

    public function test_reward_updates_only_after_valid_purchase_capture(): void
    {
        $branch = $this->branch();
        $pending = $this->createPendingCheckIn($branch);

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $pending->reward_status);
        $this->assertDatabaseCount('stamp_transactions', 0);

        $this->captureProduct($this->branchManager(), $branch, $pending, $this->product($branch), reference: 'reward-valid-capture')
            ->assertRedirect();

        $pending->refresh();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_GRANTED, $pending->reward_status);
        $this->assertSame(1, $pending->stamps_earned);
        $this->assertDatabaseCount('stamp_transactions', 1);

        $this->actingAs($this->customerUser())
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Confirmed Reward');

        $this->actingAs($this->branchManager())
            ->get(route('businesses.branches.rewards.index', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('GOS-F&B Demo Customer');

        $this->actingAs($this->businessOwner())
            ->get(route('businesses.rewards.index', $branch->business))
            ->assertOk()
            ->assertSee('GOS-F&B Demo Customer');

        $noPurchase = $this->createDirectPendingCheckIn($branch, 'Reward No Purchase Customer', '60177770000');
        $this->markNoPurchase($this->branchManager(), $branch, $noPurchase)->assertRedirect();
        $this->assertSame(0, $noPurchase->refresh()->stamps_earned);

        $this->travel(30)->minutes();
        $this->customerCheckIn($branch)->assertOk()->assertSee('Cooldown belum selesai');

        $this->assertSame(1, CustomerCheckIn::query()->where('user_id', $this->customerUser()->id)->count());

        $this->captureProduct($this->branchManager(), $branch, $pending, $this->product($branch), reference: 'reward-valid-capture')
            ->assertRedirect();

        $this->assertDatabaseCount('stamp_transactions', 1);

        $quantityPending = $this->createDirectPendingCheckIn($branch, 'Reward Quantity Customer', '60177771111');
        $this->captureProduct($this->branchManager(), $branch, $quantityPending, $this->product($branch), quantity: 4, reference: 'reward-quantity')
            ->assertRedirect();

        $this->assertSame(1, $quantityPending->refresh()->stamps_earned);

        $this->actingAs($this->customerUser())
            ->post(route('businesses.branches.rewards.redeem', [
                'business' => $branch->business,
                'branch' => $branch,
                'customer' => $pending->customer,
            ]))
            ->assertForbidden();
    }

    public function test_general_feedback_submission_history_and_reward_independence(): void
    {
        $branch = $this->branch();
        $pending = $this->createPendingCheckIn($branch);
        $product = $this->product($branch);

        $this->captureProduct($this->branchManager(), $branch, $pending, $product, reference: 'feedback-capture')
            ->assertRedirect();

        $this->assertDatabaseMissing('customer_feedback', [
            'customer_check_in_id' => $pending->id,
            'status' => CustomerFeedback::STATUS_PENDING,
        ]);
        $this->assertDatabaseCount('customer_feedback', 0);

        $this->actingAs($this->customerUser())
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertDontSee('Pending Feedback')
            ->assertDontSee('feedback belum dihantar');

        $this->actingAs($this->customerUser())
            ->get(route('customer.feedback'))
            ->assertOk()
            ->assertSee('Hantar Maklumbalas')
            ->assertDontSee('Hantar Maklumbalas Lain')
            ->assertDontSee('Pending Feedback');

        $this->actingAs($this->customerUser())
            ->from(route('customer.feedback'))
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'rating' => 6,
                'comment' => 'Rating invalid.',
            ])
            ->assertRedirect(route('customer.feedback'))
            ->assertSessionHasErrors('rating');

        $this->actingAs($this->customerUser())
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'product_service_id' => $product->id,
                'rating' => 5,
                'comment' => $product->name.' sedap dan service cepat.',
            ])
            ->assertRedirect(route('customer.feedback'))
            ->assertSessionHas('status', 'Feedback berjaya dihantar.');

        $feedback = CustomerFeedback::query()->firstOrFail();

        $this->assertSame(CustomerFeedback::STATUS_SUBMITTED, $feedback->status);
        $this->assertNotNull($feedback->submitted_at);
        $this->assertSame($pending->customer_id, $feedback->customer_id);
        $this->assertSame($branch->business_id, $feedback->business_id);
        $this->assertSame($branch->id, $feedback->branch_id);
        $this->assertNull($feedback->customer_check_in_id);
        $this->assertNull($feedback->check_in_product_service_id);
        $this->assertSame('service', $feedback->summary_issue_category);
        $this->assertSame($product->name, $feedback->summary_product_service_mentioned);

        $this->actingAs($this->customerUser())
            ->get(route('customer.feedback'))
            ->assertOk()
            ->assertSee($product->name.' sedap dan service cepat.')
            ->assertDontSee('feedback belum dihantar')
            ->assertDontSee('Pending Feedback');

        $this->actingAs($this->branchManager())
            ->get(route('businesses.branches.feedback', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee($product->name.' sedap dan service cepat.');

        $this->actingAs($this->businessOwner())
            ->get(route('businesses.feedback', $branch->business))
            ->assertOk()
            ->assertSee($product->name.' sedap dan service cepat.');

        $this->actingAs($this->customerUser())
            ->from(route('customer.feedback'))
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'rating' => 5,
                'comment' => '',
            ])
            ->assertRedirect(route('customer.feedback'))
            ->assertSessionHasErrors('feedback');

        $noPurchase = $this->createDirectPendingCheckIn($branch, 'Feedback No Purchase Customer', '60188880000');
        $this->markNoPurchase($this->branchManager(), $branch, $noPurchase)->assertRedirect();
        $this->assertDatabaseMissing('customer_feedback', ['customer_check_in_id' => $noPurchase->id]);

        $this->travel(30)->minutes();
        $this->customerCheckIn($branch)->assertOk()->assertSee('Cooldown belum selesai');
        $this->assertSame(1, CustomerFeedback::query()->where('customer_id', $pending->customer_id)->count());
        $this->assertSame(1, StampTransaction::query()->count());
    }

    private function createPendingCheckIn(Branch $branch): CustomerCheckIn
    {
        $this->customerCheckIn($branch)->assertOk();

        return CustomerCheckIn::query()
            ->where('branch_id', $branch->id)
            ->where('user_id', $this->customerUser()->id)
            ->latest('check_in_at')
            ->firstOrFail();
    }

    private function createDirectPendingCheckIn(Branch $branch, string $customerName, string $whatsapp): CustomerCheckIn
    {
        $user = User::factory()->create([
            'name' => $customerName,
            'email' => str($customerName)->slug().'-'.uniqid().'@example.test',
            'role' => User::ROLE_CUSTOMER,
        ]);

        $customer = Customer::query()->create([
            'business_id' => $branch->business_id,
            'user_id' => $user->id,
            'name' => $customerName,
            'whatsapp_number' => $whatsapp,
            'consent_promo' => false,
        ]);

        return CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'user_id' => $user->id,
            'loyalty_program_id' => $this->loyaltyProgram($branch->business)->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'stamps_earned' => 0,
            'source' => 'customer_portal',
            'check_in_type' => 'physical',
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
        ]);
    }

    private function customerCheckIn(Branch $branch)
    {
        return $this->actingAs($this->customerUser())
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
            ]);
    }

    private function captureProduct(User $actor, Branch $branch, CustomerCheckIn $checkIn, ProductService $product, int $quantity = 1, string $reference = 'core-capture')
    {
        return $this->actingAs($actor)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => $quantity,
                'capture_type' => 'purchase',
                'capture_reference' => $reference,
            ]);
    }

    private function markNoPurchase(User $actor, Branch $branch, CustomerCheckIn $checkIn)
    {
        return $this->actingAs($actor)
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'no_purchase_reason' => 'Customer did not buy.',
            ]);
    }

    private function product(Branch $branch): ProductService
    {
        return ProductService::query()
            ->visibleForBranch($branch)
            ->active()
            ->orderBy('name')
            ->firstOrFail();
    }

    private function loyaltyProgram(Business $business): LoyaltyProgram
    {
        return $business->loyaltyPrograms()->active()->firstOrFail();
    }

    private function branch(): Branch
    {
        return Branch::query()->with('business')->where('code', 'WANCHU-MAIN')->firstOrFail();
    }

    private function otherBranch(): Branch
    {
        return Branch::query()->with('business')->where('code', 'CHENA-MAIN')->firstOrFail();
    }

    private function customerUser(): User
    {
        return $this->user('customer@fbgrowth.local');
    }

    private function branchManager(): User
    {
        return $this->user('branch+wanchu@fbgrowth.local');
    }

    private function businessOwner(): User
    {
        return $this->user('owner+wanchu@fbgrowth.local');
    }

    private function businessOwnerBranchManager(): User
    {
        return $this->user('owner-branch+wanchu@fbgrowth.local');
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
