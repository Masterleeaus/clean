<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class FeedbackMvpTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_customer_can_submit_free_text_feedback(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->wanChuBranch();

        $this->createCustomerCheckIn($customerUser, $branch);

        $this->actingAs($customerUser)
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'comment' => 'Sedap dan servis cepat.',
            ])
            ->assertRedirect(route('customer.feedback'));

        $this->assertDatabaseHas('customer_feedback', [
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'comment' => 'Sedap dan servis cepat.',
            'source' => 'customer_portal',
        ]);
    }

    public function test_feedback_records_customer_business_and_branch_without_requiring_check_in_link(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->wanChuBranch();
        $this->createCustomerCheckIn($customerUser, $branch);

        $this->actingAs($customerUser)
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'rating' => 5,
                'comment' => 'Akan datang lagi.',
            ])
            ->assertRedirect(route('customer.feedback'));

        $customer = Customer::query()->where('user_id', $customerUser->id)->firstOrFail();

        $this->assertDatabaseHas('customer_feedback', [
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => null,
            'rating' => 5,
        ]);
    }

    public function test_feedback_can_reference_product_service_where_available(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->wanChuBranch();
        $productService = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        $this->createCustomerCheckIn($customerUser, $branch);

        $this->actingAs($customerUser)
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'product_service_id' => $productService->id,
                'comment' => 'Teh ais cukup kaw.',
            ])
            ->assertRedirect(route('customer.feedback'));

        $this->assertDatabaseHas('customer_feedback', [
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'product_service_id' => $productService->id,
            'comment' => 'Teh ais cukup kaw.',
        ]);
    }

    public function test_business_owner_can_view_feedback_for_owned_business(): void
    {
        $branch = $this->wanChuBranch();
        $feedback = $this->feedbackFor($branch, 'Owner boleh nampak feedback ini.');

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('businesses.feedback', $branch->business))
            ->assertOk()
            ->assertSee($feedback->comment)
            ->assertSee($branch->name);
    }

    public function test_branch_manager_can_view_only_assigned_branch_feedback(): void
    {
        $branch = $this->wanChuBranch();
        $otherBranch = Branch::query()->create([
            'business_id' => $branch->business_id,
            'name' => 'WanChu Side Branch',
            'code' => 'WANCHU-SIDE',
            'is_active' => true,
        ]);

        $assignedFeedback = $this->feedbackFor($branch, 'Assigned branch feedback.');
        $otherFeedback = $this->feedbackFor($otherBranch, 'Other branch feedback.');

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('businesses.feedback', $branch->business))
            ->assertOk()
            ->assertSee($assignedFeedback->comment)
            ->assertDontSee($otherFeedback->comment);
    }

    public function test_branch_manager_cannot_view_other_branch_feedback_page(): void
    {
        $business = $this->wanChu();
        $otherBranch = Branch::query()->create([
            'business_id' => $business->id,
            'name' => 'WanChu Side Branch',
            'code' => 'WANCHU-SIDE',
            'is_active' => true,
        ]);

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('businesses.branches.feedback', [$business, $otherBranch]))
            ->assertForbidden();
    }

    public function test_customer_cannot_access_business_feedback_surfaces(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->wanChuBranch();

        $this->actingAs($customerUser)
            ->get(route('businesses.feedback', $branch->business))
            ->assertForbidden();

        $this->actingAs($customerUser)
            ->get(route('businesses.branches.feedback', [$branch->business, $branch]))
            ->assertForbidden();
    }

    public function test_customer_feedback_history_only_shows_own_feedback(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->wanChuBranch();
        $ownCustomer = Customer::query()->where('user_id', $customerUser->id)->firstOrFail();
        $otherCustomer = Customer::query()->create([
            'business_id' => $branch->business_id,
            'name' => 'Other Customer',
            'whatsapp_number' => '60199990000',
        ]);

        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $ownCustomer->id,
            'comment' => 'Feedback milik saya.',
            'submitted_at' => now(),
        ]);

        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $otherCustomer->id,
            'comment' => 'Feedback pelanggan lain.',
            'submitted_at' => now(),
        ]);

        $this->actingAs($customerUser)
            ->get(route('customer.feedback'))
            ->assertOk()
            ->assertSee('Feedback milik saya.')
            ->assertDontSee('Feedback pelanggan lain.');
    }

    private function createCustomerCheckIn(User $user, Branch $branch): CustomerCheckIn
    {
        $this->actingAs($user)
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
            ])
            ->assertOk();

        return CustomerCheckIn::query()
            ->where('user_id', $user->id)
            ->where('branch_id', $branch->id)
            ->latest()
            ->firstOrFail();
    }

    private function feedbackFor(Branch $branch, string $comment): CustomerFeedback
    {
        return CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'comment' => $comment,
            'submitted_at' => now(),
        ]);
    }

    private function wanChu(): Business
    {
        return Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
    }

    private function wanChuBranch(): Branch
    {
        return Branch::query()->where('code', 'WANCHU-MAIN')->firstOrFail();
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
