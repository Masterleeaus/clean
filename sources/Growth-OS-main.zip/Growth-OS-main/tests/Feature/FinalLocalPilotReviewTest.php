<?php

namespace Tests\Feature;

use Tests\TestCase;

class FinalLocalPilotReviewTest extends TestCase
{
    public function test_lp_final_01_to_20_local_pilot_review_document_and_safety_rules_are_ready(): void
    {
        $document = file_get_contents(base_path('docs/local-pilot-test-step-2.md'));

        foreach ([
            'Bahagian 1',
            'Bahagian 2',
            'Bahagian 3.0',
            'Bahagian 4',
            'Bahagian 5',
            'Bahagian 6',
            'Bahagian 7',
            'Bahagian 8',
            'Bahagian 9',
            'Bahagian 10',
            'Bahagian 11',
            'Bahagian 12',
            'Bahagian 13',
        ] as $section) {
            $this->assertStringContainsString($section, $document);
        }

        foreach ([
            'Customer hanya check-in',
            'Purchase berlaku di luar platform',
            'Customer tidak nampak Pending Purchase Capture',
            'Customer hanya nampak confirmed reward/stamp',
            'Hantar Maklumbalas bebas',
            'Feedback tidak trigger reward/stamp',
            'Branch Manager assigned branch sahaja',
            'Business Owner / BO cum BM',
            'System Manager / System Admin',
            'internal rule-based',
            'Tiada external AI/API key dependency',
            'READY FOR CONTROLLED PILOT PREPARATION',
        ] as $requirement) {
            $this->assertStringContainsString($requirement, $document);
        }

        foreach ([
            'LP-FINAL-01',
            'LP-FINAL-05',
            'LP-FINAL-10',
            'LP-FINAL-15',
            'LP-FINAL-20',
        ] as $testId) {
            $this->assertStringContainsString($testId, $document);
        }

        $source = file_get_contents(app_path('Services/AiInsightService.php'))
            .file_get_contents(app_path('Services/AiActionService.php'))
            .file_get_contents(app_path('Http/Controllers/AnalyticsController.php'));

        $this->assertStringNotContainsString('OpenAI', $source);
        $this->assertStringNotContainsString('Gemini', $source);
        $this->assertStringNotContainsString('OPENAI_API_KEY', $source);
        $this->assertStringNotContainsString('Http::post', $source);
    }
}
