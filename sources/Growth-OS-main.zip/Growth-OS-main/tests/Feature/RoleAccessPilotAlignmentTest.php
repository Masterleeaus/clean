<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\User;
use App\Services\RoleAccessPilotGuard;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class RoleAccessPilotAlignmentTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_business_owner_cum_branch_manager_sees_business_performance_and_branch_operations_tabs(): void
    {
        $combined = $this->user('owner-branch+wanchu@fbgrowth.local');

        $this->actingAs($combined)
            ->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Business Performance')
            ->assertSee('Branch Operations')
            ->assertSee('Assigned/current branch')
            ->assertSee('Pending Purchase Capture')
            ->assertSee('Capture Purchase')
            ->assertDontSee('System Admin Dashboard')
            ->assertDontSee('System Manager Dashboard');
    }

    public function test_pure_business_owner_does_not_get_branch_manager_only_operations_tab(): void
    {
        $owner = $this->user('owner+wanchu@fbgrowth.local');

        $this->actingAs($owner)
            ->get(route('dashboards.business-owner'))
            ->assertOk()
            ->assertSee('Business Owner Dashboard')
            ->assertDontSee('Branch Operations')
            ->assertDontSee('Assigned/current branch');
    }

    public function test_pure_branch_manager_does_not_get_business_performance_tab(): void
    {
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');

        $this->actingAs($branchManager)
            ->get(route('dashboards.branch-manager'))
            ->assertOk()
            ->assertSee('Branch Manager Dashboard')
            ->assertSee('Pending Purchase Capture')
            ->assertDontSee('Business Performance');
    }

    public function test_business_owner_cum_branch_manager_access_stays_within_assigned_business_and_branch(): void
    {
        $combined = $this->user('owner-branch+wanchu@fbgrowth.local');
        $assignedBusiness = $this->business('wanchu-corner');
        $assignedBranch = $this->branch('WANCHU-MAIN');
        $otherBusiness = $this->business('restoran-che-na');
        $otherBranch = $this->branch('CHENA-MAIN');

        $this->actingAs($combined)
            ->get(route('businesses.branches.show', ['business' => $assignedBusiness, 'branch' => $assignedBranch]))
            ->assertOk();

        $this->actingAs($combined)
            ->get(route('businesses.branches.show', ['business' => $otherBusiness, 'branch' => $otherBranch]))
            ->assertForbidden();
    }

    public function test_system_admin_can_intentionally_validate_business_owner_branch_manager_dual_role(): void
    {
        $guard = app(RoleAccessPilotGuard::class);
        $admin = $this->user('admin@fbgrowth.local');
        $owner = $this->user('owner+wanchu@fbgrowth.local');
        $business = $this->business('wanchu-corner');
        $branch = $this->branch('WANCHU-MAIN');

        $withoutConfirmation = $guard->validateControlledPilotSetup(
            actor: $admin,
            target: $owner,
            business: $business,
            branchIds: [$branch->id],
            primaryRole: User::ROLE_BUSINESS_OWNER,
            secondaryRole: User::ROLE_BRANCH_MANAGER,
        );

        $withConfirmation = $guard->validateControlledPilotSetup(
            actor: $admin,
            target: $owner,
            business: $business,
            branchIds: [$branch->id],
            primaryRole: User::ROLE_BUSINESS_OWNER,
            secondaryRole: User::ROLE_BRANCH_MANAGER,
            intentionalDualRole: true,
        );

        $this->assertFalse($withoutConfirmation['allowed']);
        $this->assertContains('Business Owner / Branch Manager dual role requires intentional confirmation.', $withoutConfirmation['errors']);
        $this->assertTrue($withConfirmation['allowed']);
        $this->assertTrue($withConfirmation['intentional_dual_role']);
    }

    public function test_one_branch_can_have_multiple_branch_managers_by_scope(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $existingManager = $this->user('branch+wanchu@fbgrowth.local');
        $secondManager = User::factory()->create([
            'role' => User::ROLE_BRANCH_MANAGER,
            'access_scope' => ['branch_ids' => [$branch->id]],
        ]);

        $this->assertTrue($existingManager->fresh()->canAccessBranch($branch));
        $this->assertTrue($secondManager->fresh()->canAccessBranch($branch));

        $this->actingAs($secondManager)
            ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk();
    }

    public function test_guard_rejects_branch_manager_assignment_outside_selected_business(): void
    {
        $guard = app(RoleAccessPilotGuard::class);
        $admin = $this->user('admin@fbgrowth.local');
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $business = $this->business('wanchu-corner');
        $otherBranch = $this->branch('CHENA-MAIN');

        $result = $guard->validateControlledPilotSetup(
            actor: $admin,
            target: $branchManager,
            business: $business,
            branchIds: [$otherBranch->id],
            primaryRole: User::ROLE_BRANCH_MANAGER,
        );

        $this->assertFalse($result['allowed']);
        $this->assertContains('Branch Manager cannot be assigned to branch outside the selected business.', $result['errors']);
    }

    public function test_business_owner_invite_is_restricted_during_controlled_pilot(): void
    {
        $guard = app(RoleAccessPilotGuard::class);
        $owner = $this->user('owner+wanchu@fbgrowth.local');
        $ownBusiness = $this->business('wanchu-corner');
        $otherBusiness = $this->business('restoran-che-na');

        $customerInvite = $guard->validateBusinessOwnerInvite($owner, $ownBusiness, User::ROLE_CUSTOMER);
        $systemAdminInvite = $guard->validateBusinessOwnerInvite($owner, $ownBusiness, User::ROLE_SYSTEM_ADMIN);
        $otherBusinessInvite = $guard->validateBusinessOwnerInvite($owner, $otherBusiness, User::ROLE_BRANCH_MANAGER);

        $this->assertFalse($customerInvite['allowed']);
        $this->assertContains('Business Owner cannot create Customer manually. Customer onboarding must be organic.', $customerInvite['errors']);

        $this->assertFalse($systemAdminInvite['allowed']);
        $this->assertContains('Business Owner cannot assign System Admin, System Manager, or another Business Owner role.', $systemAdminInvite['errors']);

        $this->assertFalse($otherBusinessInvite['allowed']);
        $this->assertContains('Business Owner can only invite users within own business.', $otherBusinessInvite['errors']);
    }

    public function test_branch_manager_picker_rejects_non_branch_manager_user(): void
    {
        $admin = $this->user('admin@fbgrowth.local');
        $customer = $this->user('customer@fbgrowth.local');
        $business = $this->business('wanchu-corner');

        $this->actingAs($admin)
            ->post(route('businesses.branches.store', $business), [
                'name' => 'Invalid Manager Branch',
                'code' => 'INVALID-MANAGER',
                'manager_user_id' => $customer->id,
                'is_active' => '1',
            ])
            ->assertSessionHasErrors('manager_user_id');
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function business(string $slug): Business
    {
        return Business::query()->where('slug', $slug)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business')->where('code', $code)->firstOrFail();
    }
}
