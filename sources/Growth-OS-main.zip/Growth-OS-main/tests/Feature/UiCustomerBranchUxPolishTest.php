<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UiCustomerBranchUxPolishTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_customer_portal_keeps_safe_check_in_reward_and_feedback_ux(): void
    {
        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Selamat datang')
            ->assertSee('Reward akan disahkan selepas pembelian disahkan oleh branch.')
            ->assertSee('Check-in di Premis')
            ->assertSee('Gunakan jika anda berada di kedai.')
            ->assertSee('Check-in untuk Order Online')
            ->assertSee('Gunakan jika anda membuat order melalui WhatsApp, delivery, pickup atau channel luar.')
            ->assertSee('Hantar Maklumbalas')
            ->assertSee('Maklumbalas bebas/general')
            ->assertSee('gos-floating-action', false)
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Mark No Purchase');
    }

    public function test_branch_operation_queue_highlights_physical_online_pending_capture_and_actions(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->pendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL, 'UI3 Physical Customer');
        $this->pendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_ONLINE, 'UI3 Online Customer');

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('Branch Check-ins')
            ->assertSee('Physical check-ins')
            ->assertSee('Online check-ins')
            ->assertSee('Pending Purchase Capture — Physical')
            ->assertSee('Pending Purchase Capture — Online')
            ->assertSee('Sahkan pembelian hanya selepas transaksi sebenar berlaku di luar sistem.')
            ->assertSee('Semak pembelian di premis sebelum capture purchase.')
            ->assertSee('Semak order/payment melalui channel luar sebelum capture purchase.')
            ->assertSee('UI3 Physical Customer')
            ->assertSee('UI3 Online Customer')
            ->assertSee('Capture Purchase')
            ->assertSee('Mark No Purchase');
    }

    public function test_combined_role_keeps_capture_actions_inside_branch_operations_only(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->pendingCheckIn($branch, CustomerCheckIn::CHECK_IN_TYPE_ONLINE, 'UI3 Combined Online Customer');

        $response = $this->actingAs($this->user('owner-branch+wanchu@fbgrowth.local'))
            ->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Business Performance')
            ->assertSee('Branch Operations')
            ->assertSee('Pending Purchase Capture — Physical')
            ->assertSee('Pending Purchase Capture — Online')
            ->assertSee('Capture Purchase / Mark No Purchase');

        $html = $response->getContent();
        $businessTab = $this->htmlBetween($html, 'id="business-performance"', 'id="branch-operations"');
        $branchTab = $this->htmlBetween($html, 'id="branch-operations"', '</section>');

        $this->assertStringNotContainsString('Capture Purchase / Mark No Purchase', $businessTab);
        $this->assertStringContainsString('Capture Purchase / Mark No Purchase', $branchTab);
        $this->assertStringContainsString('Semak order/payment melalui channel luar sebelum capture purchase.', $branchTab);
    }

    private function pendingCheckIn(Branch $branch, string $type, string $customerName): CustomerCheckIn
    {
        $customer = Customer::query()->create([
            'business_id' => $branch->business_id,
            'name' => $customerName,
            'whatsapp_number' => '601'.random_int(100000000, 999999999),
        ]);

        return CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $branch->business->loyaltyPrograms()->active()->firstOrFail()->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'ui_3_ux_polish',
            'check_in_type' => $type,
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business')->where('code', $code)->firstOrFail();
    }

    private function htmlBetween(string $html, string $start, string $end): string
    {
        $startPosition = strpos($html, $start);
        $this->assertNotFalse($startPosition, "Missing {$start} in dashboard HTML.");
        $endPosition = strpos($html, $end, $startPosition + strlen($start));
        $this->assertNotFalse($endPosition, "Missing {$end} after {$start}.");

        return substr($html, $startPosition, $endPosition - $startPosition);
    }
}
