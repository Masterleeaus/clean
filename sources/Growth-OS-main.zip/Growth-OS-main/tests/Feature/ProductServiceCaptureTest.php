<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CheckInProductService;
use App\Models\CustomerCheckIn;
use App\Models\CustomerLoyaltyAccount;
use App\Models\ProductService;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class ProductServiceCaptureTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_business_owner_can_create_and_view_product_service_for_owned_business(): void
    {
        $owner = $this->user('owner+wanchu@fbgrowth.local');
        $business = $this->branch('WANCHU-MAIN')->business;

        $this->actingAs($owner)
            ->post(route('businesses.product-services.store', $business), [
                'name' => 'Kopi O',
                'category' => 'drink',
                'type' => 'product',
                'price' => '2.80',
                'is_active' => '1',
            ])
            ->assertRedirect(route('businesses.product-services.index', $business));

        $this->assertDatabaseHas('product_services', [
            'business_id' => $business->id,
            'name' => 'Kopi O',
            'category' => 'drink',
            'type' => 'product',
            'price' => 2.80,
            'is_active' => true,
        ]);

        $this->actingAs($owner)
            ->get(route('businesses.product-services.index', $business))
            ->assertOk()
            ->assertSee('Kopi O');
    }

    public function test_business_owner_can_update_product_service_price_and_active_status(): void
    {
        $owner = $this->user('owner+wanchu@fbgrowth.local');
        $business = $this->branch('WANCHU-MAIN')->business;
        $product = ProductService::query()->where('name', 'Nasi Lemak Ayam')->firstOrFail();

        $this->actingAs($owner)
            ->patch(route('businesses.product-services.update', ['business' => $business, 'productService' => $product]), [
                'name' => 'Nasi Lemak Ayam Special',
                'category' => 'food',
                'type' => 'product',
                'price' => '14.50',
            ])
            ->assertRedirect(route('businesses.product-services.index', $business));

        $product->refresh();

        $this->assertSame('Nasi Lemak Ayam Special', $product->name);
        $this->assertSame('14.50', $product->price);
        $this->assertFalse($product->is_active);
    }

    public function test_product_service_requires_price(): void
    {
        $owner = $this->user('owner+wanchu@fbgrowth.local');
        $business = $this->branch('WANCHU-MAIN')->business;

        $this->actingAs($owner)
            ->post(route('businesses.product-services.store', $business), [
                'name' => 'Missing Price Item',
                'category' => 'food',
                'type' => 'product',
                'is_active' => '1',
            ])
            ->assertSessionHasErrors('price');
    }

    public function test_product_service_branch_availability_works(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $otherBranch = Branch::factory()->create([
            'business_id' => $branch->business_id,
            'name' => 'WanChu Third Branch',
            'code' => 'WANCHU-THIRD',
        ]);
        $branchOnlyProduct = ProductService::factory()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'name' => 'Branch Only Roti',
            'price' => 4.20,
        ]);

        $this->assertTrue(ProductService::query()->visibleForBranch($branch)->whereKey($branchOnlyProduct)->exists());
        $this->assertFalse(ProductService::query()->visibleForBranch($otherBranch)->whereKey($branchOnlyProduct)->exists());
    }

    public function test_branch_manager_can_capture_product_service_usage_for_assigned_branch(): void
    {
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');
        $checkIn = $this->checkInForBranch($branch);
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        $this->actingAs($branchManager)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 2,
                'capture_type' => 'purchase',
            ])
            ->assertRedirect(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]));

        $this->assertDatabaseHas('check_in_product_services', [
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $checkIn->customer_id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'captured_by_user_id' => $branchManager->id,
            'quantity' => 2,
            'price_at_capture' => 3.50,
            'total_amount' => 7.00,
            'capture_type' => 'purchase',
            'capture_source' => 'staff_manual',
        ]);
    }

    public function test_branch_manager_cannot_capture_for_other_branch(): void
    {
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $otherBranch = $this->branch('CHENA-MAIN');
        $checkIn = $this->checkInForBranch($otherBranch, '60199990000');
        $product = ProductService::query()->where('name', 'Lunch Set')->firstOrFail();

        $this->actingAs($branchManager)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $otherBranch->business,
                'branch' => $otherBranch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
            ])
            ->assertForbidden();

        $this->assertDatabaseCount('check_in_product_services', 0);
    }

    public function test_customer_check_in_can_be_linked_to_product_service_capture(): void
    {
        $branchManager = $this->user('branch+wanchu@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');
        $checkIn = $this->checkInForBranch($branch);
        $product = ProductService::query()->where('name', 'Nasi Lemak Ayam')->firstOrFail();

        $this->actingAs($branchManager)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'subscription',
                'notes' => 'MVP capture',
            ])
            ->assertRedirect();

        $capture = CheckInProductService::query()->firstOrFail();

        $this->assertSame($checkIn->id, $capture->customer_check_in_id);
        $this->assertSame($product->id, $capture->product_service_id);
        $this->assertSame('subscription', $capture->capture_type);
    }

    public function test_capture_stores_price_snapshot_and_total_amount(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $checkIn = $this->checkInForBranch($branch);
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        $this->captureProduct($branch, $checkIn, $product, quantity: 3)->assertRedirect();

        $capture = CheckInProductService::query()->firstOrFail();

        $this->assertSame(3, $capture->quantity);
        $this->assertSame('3.50', $capture->price_at_capture);
        $this->assertSame('10.50', $capture->total_amount);
    }

    public function test_old_capture_price_does_not_change_when_product_price_changes_later(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $checkIn = $this->checkInForBranch($branch);
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        $this->captureProduct($branch, $checkIn, $product)->assertRedirect();
        $product->update(['price' => 4.90]);

        $capture = CheckInProductService::query()->firstOrFail();

        $this->assertSame('3.50', $capture->refresh()->price_at_capture);
        $this->assertSame('3.50', $capture->refresh()->total_amount);
    }

    public function test_same_product_quantity_greater_than_one_is_valid(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $checkIn = $this->checkInForBranch($branch);
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        $this->captureProduct($branch, $checkIn, $product, quantity: 4)->assertRedirect();

        $this->assertDatabaseHas('check_in_product_services', [
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'quantity' => 4,
            'total_amount' => 14.00,
        ]);
    }

    public function test_same_product_can_be_captured_again_in_same_visit_as_separate_purchase(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $checkIn = $this->checkInForBranch($branch);
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        $this->captureProduct($branch, $checkIn, $product, reference: 'valid-repeat-1')->assertRedirect();
        $this->captureProduct($branch, $checkIn, $product, reference: 'valid-repeat-2')->assertRedirect();

        $this->assertSame(2, CheckInProductService::query()->where('product_service_id', $product->id)->count());
    }

    public function test_false_duplicate_capture_is_prevented_by_capture_reference(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $checkIn = $this->checkInForBranch($branch);
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        $this->captureProduct($branch, $checkIn, $product, reference: 'retry-token-1')->assertRedirect();
        $this->captureProduct($branch, $checkIn, $product, reference: 'retry-token-1')->assertRedirect();

        $this->assertSame(1, CheckInProductService::query()->where('capture_reference', 'retry-token-1')->count());
    }

    public function test_valid_product_service_capture_linked_to_check_in_grants_reward(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $checkIn = $this->checkInForBranch($branch);
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        $this->captureProduct($branch, $checkIn, $product)->assertRedirect();

        $account = CustomerLoyaltyAccount::query()->firstOrFail();

        $this->assertSame(1, $account->current_stamps);
        $this->assertSame('granted', $checkIn->refresh()->reward_status);
    }

    public function test_check_in_without_product_service_capture_does_not_grant_reward(): void
    {
        $branch = $this->branch('WANCHU-MAIN');

        $this->checkInForBranch($branch);

        $account = CustomerLoyaltyAccount::query()->firstOrFail();

        $this->assertSame(0, $account->current_stamps);
    }

    public function test_customer_can_see_own_recorded_product_service_activity(): void
    {
        $customer = $this->user('customer@fbgrowth.local');
        $branch = $this->branch('WANCHU-MAIN');
        $checkIn = $this->checkInForBranch($branch);
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        $this->captureProduct($branch, $checkIn, $product)->assertRedirect();

        $this->actingAs($customer)
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Teh Ais')
            ->assertSee('RM 3.50');
    }

    public function test_customer_cannot_access_product_service_admin_surfaces(): void
    {
        $customer = $this->user('customer@fbgrowth.local');
        $business = $this->branch('WANCHU-MAIN')->business;

        $this->actingAs($customer)
            ->get(route('businesses.product-services.index', $business))
            ->assertForbidden();
    }

    public function test_system_manager_can_view_and_system_admin_can_manage_product_services(): void
    {
        $systemManager = $this->user('manager@gos-fnb.local');
        $systemAdmin = $this->user('admin@fbgrowth.local');
        $business = $this->branch('WANCHU-MAIN')->business;

        $this->actingAs($systemManager)
            ->get(route('businesses.product-services.index', $business))
            ->assertOk()
            ->assertSee('Nasi Lemak Ayam');

        $this->actingAs($systemManager)
            ->get(route('businesses.product-services.create', $business))
            ->assertForbidden();

        $this->actingAs($systemAdmin)
            ->get(route('businesses.product-services.create', $business))
            ->assertOk();
    }

    private function checkInForBranch(Branch $branch, string $whatsapp = '60111112222'): CustomerCheckIn
    {
        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => $whatsapp,
            ])
            ->assertOk();

        return CustomerCheckIn::query()
            ->where('branch_id', $branch->id)
            ->latest()
            ->firstOrFail();
    }

    private function captureProduct(Branch $branch, CustomerCheckIn $checkIn, ProductService $product, int $quantity = 1, ?string $reference = null)
    {
        return $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => $quantity,
                'capture_type' => 'purchase',
                'capture_reference' => $reference ?? 'capture-'.uniqid(),
            ]);
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business')->where('code', $code)->firstOrFail();
    }
}
