<?php

namespace Tests\Feature;

use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class UiDashboardPresentationPolishTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_system_manager_dashboard_has_platform_strategy_presentation_only(): void
    {
        $this->actingAs($this->user('manager@gos-fnb.local'))
            ->get(route('dashboards.system-manager'))
            ->assertOk()
            ->assertSee('Platform overview')
            ->assertSee('GOS/F&amp;B vertical effectiveness', false)
            ->assertSee('Adoption/usage signals')
            ->assertSee('Strategic AI Insight')
            ->assertSee('Strategic AI Action')
            ->assertSee('High-level risk/opportunity')
            ->assertSee('gos-metric-card', false)
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Branch Operations');
    }

    public function test_system_admin_dashboard_has_admin_support_presentation_and_provider_status(): void
    {
        $this->actingAs($this->user('admin@fbgrowth.local'))
            ->get(route('dashboards.system-admin'))
            ->assertOk()
            ->assertSee('Admin Support')
            ->assertSee('System overview')
            ->assertSee('Setup/configuration support')
            ->assertSee('Admin/support AI Insight')
            ->assertSee('Admin/support AI Action')
            ->assertSee('AI Provider Status')
            ->assertSee('Priority chain')
            ->assertDontSee('Business Performance')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Customer Portal');
    }

    public function test_business_owner_dashboard_has_business_data_presentation_without_capture_actions(): void
    {
        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('dashboards.business-owner'))
            ->assertOk()
            ->assertSee('Business performance dashboard')
            ->assertSee('Business overview')
            ->assertSee('Branch performance summary')
            ->assertSee('Product/Service captured')
            ->assertSee('Reward/Loyalty Summary')
            ->assertSee('Business growth AI Insight')
            ->assertSee('Business Profile / QR')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Mark No Purchase')
            ->assertDontSee('AI Provider Status');
    }

    public function test_branch_manager_dashboard_has_assigned_branch_operation_presentation(): void
    {
        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('dashboards.branch-manager'))
            ->assertOk()
            ->assertSee('Branch operation dashboard')
            ->assertSee('Assigned branch identity')
            ->assertSee('Pending Purchase Capture by mode')
            ->assertSee('Physical')
            ->assertSee('Online')
            ->assertSee('Capture Purchase / Mark No Purchase action area')
            ->assertSee('Branch Analytics / AI Insight / AI Action')
            ->assertSee('Branch Check-ins')
            ->assertDontSee('Business Performance')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Customer Portal');
    }

    public function test_customer_portal_has_customer_data_presentation_without_internal_data(): void
    {
        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Customer dashboard')
            ->assertSee('Check-in di Premis')
            ->assertSee('Check-in untuk Order Online')
            ->assertSee('Confirmed stamps sahaja')
            ->assertSee('Reward/Loyalty Status')
            ->assertSee('Hantar Maklumbalas')
            ->assertSee('gos-floating-action', false)
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Analytics')
            ->assertDontSee('AI Provider Status')
            ->assertDontSee('Capture Purchase');
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
