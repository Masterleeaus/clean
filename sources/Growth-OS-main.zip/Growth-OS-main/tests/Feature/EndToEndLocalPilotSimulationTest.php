<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CheckInProductService;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\StampTransaction;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Routing\Middleware\ThrottleRequests;
use Tests\TestCase;

class EndToEndLocalPilotSimulationTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->withoutMiddleware(ThrottleRequests::class);
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_lp_e2e_01_to_15_full_local_pilot_simulation(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $product = $this->product($branch);

        $this->actingAs($this->user('admin@fbgrowth.local'))
            ->get(route('dashboards.system-admin'))
            ->assertOk()
            ->assertSee('System Admin Dashboard')
            ->assertSee('Businesses configured')
            ->assertSee('Branches configured');

        $this->actingAs($this->customer())
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Customer Portal')
            ->assertSee('Check-in untuk Order Online')
            ->assertDontSee('Create Order')
            ->assertDontSee('Pay Now')
            ->assertDontSee('Payment Form');

        $this->customerCheckIn($branch)->assertOk()->assertSee('Check-in berjaya direkodkan.');
        $firstCheckIn = CustomerCheckIn::query()->where('branch_id', $branch->id)->latest('check_in_at')->firstOrFail();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT, $firstCheckIn->reward_status);
        $this->assertSame(0, StampTransaction::query()->count());

        $this->actingAs($this->branchManager())
            ->get(route('businesses.branches.check-ins', ['business' => $branch->business, 'branch' => $branch]))
            ->assertOk()
            ->assertSee('Pending Purchase Capture')
            ->assertSee('Capture Purchase');

        $this->actingAs($this->customer())
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertDontSee('Pending Purchase Capture')
            ->assertDontSee('Reward will be confirmed after purchase is verified');

        $this->captureProduct($branch, $firstCheckIn, $product, 'e2e-purchase-1')->assertRedirect();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_GRANTED, $firstCheckIn->refresh()->reward_status);
        $this->assertSame(1, StampTransaction::query()->count());
        $this->assertSame(1, CheckInProductService::query()->where('capture_reference', 'e2e-purchase-1')->count());

        $this->actingAs($this->customer())
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Confirmed Reward');

        $this->actingAs($this->customer())
            ->post(route('customer.feedback.store'), [
                'branch_id' => $branch->id,
                'product_service_id' => $product->id,
                'rating' => 5,
                'comment' => 'Hantar Maklumbalas bebas selepas beli di luar platform.',
            ])
            ->assertRedirect(route('customer.feedback'));

        $this->assertSame(1, CustomerFeedback::query()->count());

        $this->travel(61)->minutes();
        $this->customerCheckIn($branch)->assertOk();
        $noPurchase = CustomerCheckIn::query()->where('branch_id', $branch->id)->latest('check_in_at')->firstOrFail();
        $this->markNoPurchase($branch, $noPurchase)->assertRedirect();

        $this->assertSame(CustomerCheckIn::REWARD_STATUS_NO_PURCHASE, $noPurchase->refresh()->reward_status);
        $this->assertSame(1, StampTransaction::query()->count());

        $this->travel(30)->minutes();
        $this->customerCheckIn($branch)->assertOk()->assertSee('Cooldown belum selesai');
        $this->assertSame(2, CustomerCheckIn::query()->where('user_id', $this->customer()->id)->count());
        $this->assertSame(1, StampTransaction::query()->count());

        $this->actingAs($this->owner())
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Core Operation Analytics')
            ->assertSee('AI Insight Engine')
            ->assertSee('AI Action Engine')
            ->assertSee('No purchase / check-in without purchase')
            ->assertSee('Reward/stamp issued')
            ->assertSee('Feedback Analytics')
            ->assertSee('Human review diperlukan');

        $this->actingAs($this->customer())->get(route('analytics.index'))->assertForbidden();
        $this->actingAs($this->branchManager())
            ->get(route('businesses.branches.check-ins', ['business' => $this->branch('CHENA-MAIN')->business, 'branch' => $this->branch('CHENA-MAIN')]))
            ->assertForbidden();

        $this->actingAs($this->customer())->post(route('logout'))->assertRedirect('/');
        $this->get(route('customer.portal'))->assertRedirect(route('login'));
    }

    private function customerCheckIn(Branch $branch)
    {
        return $this->actingAs($this->customer())
            ->post(route('customer.check-in.store'), [
                'branch_id' => $branch->id,
                'whatsapp_number' => '60111112222',
            ]);
    }

    private function captureProduct(Branch $branch, CustomerCheckIn $checkIn, ProductService $product, string $reference)
    {
        return $this->actingAs($this->branchManager())
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
                'capture_reference' => $reference,
            ]);
    }

    private function markNoPurchase(Branch $branch, CustomerCheckIn $checkIn)
    {
        return $this->actingAs($this->branchManager())
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $branch->business,
                'branch' => $branch,
                'checkIn' => $checkIn,
            ]), [
                'no_purchase_reason' => 'E2E no-purchase scenario.',
            ]);
    }

    private function product(Branch $branch): ProductService
    {
        return ProductService::query()
            ->where('business_id', $branch->business_id)
            ->where(function ($query) use ($branch): void {
                $query->whereNull('branch_id')->orWhere('branch_id', $branch->id);
            })
            ->active()
            ->firstOrFail();
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business')->where('code', $code)->firstOrFail();
    }

    private function owner(): User
    {
        return $this->user('owner+wanchu@fbgrowth.local');
    }

    private function branchManager(): User
    {
        return $this->user('branch+wanchu@fbgrowth.local');
    }

    private function customer(): User
    {
        return $this->user('customer@fbgrowth.local');
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
