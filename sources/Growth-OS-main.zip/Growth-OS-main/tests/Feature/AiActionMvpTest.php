<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\StampTransaction;
use App\Models\User;
use App\Services\AiActionService;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AiActionMvpTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_business_owner_sees_ai_action_for_owned_business_only(): void
    {
        $ownedBranch = $this->branch('WANCHU-MAIN');
        $otherBranch = $this->branch('CHENA-MAIN');

        $this->createActionActivity($ownedBranch, productName: 'Owner Action Set', quantity: 6, price: 12.00);
        $this->createActionActivity($otherBranch, productName: 'Hidden Other Action Set', quantity: 6, price: 18.00);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Action Engine')
            ->assertSee('Increase sales for high-potential Product/Service')
            ->assertSee('Owner Action Set')
            ->assertDontSee('Hidden Other Action Set')
            ->assertDontSee($otherBranch->name);
    }

    public function test_branch_manager_sees_ai_action_for_assigned_branch_only(): void
    {
        $assignedBranch = $this->branch('WANCHU-MAIN');
        $otherBranch = Branch::query()->create([
            'business_id' => $assignedBranch->business_id,
            'name' => 'WanChu Action Hidden',
            'code' => 'WANCHU-ACTION-HIDDEN',
            'is_active' => true,
        ]);

        $this->createActionActivity($assignedBranch, productName: 'Assigned Action Set', quantity: 6, price: 8.00);
        $this->createActionActivity($otherBranch, productName: 'Hidden Branch Action Set', quantity: 6, price: 8.00);

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Action Engine')
            ->assertSee('Assigned Action Set')
            ->assertSee($assignedBranch->name)
            ->assertDontSee('Hidden Branch Action Set')
            ->assertDontSee($otherBranch->name);
    }

    public function test_customer_cannot_access_ai_action(): void
    {
        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertForbidden();

        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertDontSee('AI Action Engine');
    }

    public function test_system_admin_can_access_admin_support_ai_action_without_commercial_strategy(): void
    {
        $this->actingAs($this->user('admin@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Action Engine')
            ->assertSee('Complete branch manager assignment')
            ->assertSee('System Admin')
            ->assertSee('System/admin/support')
            ->assertDontSee('vertical expansion')
            ->assertDontSee('revenue strategy')
            ->assertDontSee('subscriber revenue optimization');
    }

    public function test_system_manager_can_access_gos_platform_business_performance_ai_action(): void
    {
        $this->createActionActivity($this->branch('WANCHU-MAIN'), productName: 'Platform Action Set', quantity: 3, price: 9.00);

        $this->actingAs($this->user('manager@gos-fnb.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Action Engine')
            ->assertSee('Complete GOS revenue/subscription data gap')
            ->assertSee('GOS platform/business performance monitoring')
            ->assertSee('Subscription revenue')
            ->assertSee('Data belum tersedia');
    }

    public function test_ai_action_is_generated_from_ai_insight_and_analytics_data(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createActionActivity($branch, productName: 'Signature Action Laksa', quantity: 6, price: 11.50);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Linked Insight')
            ->assertSee('Product/Service performance insight')
            ->assertSee('Supporting data/evidence')
            ->assertSee('Signature Action Laksa')
            ->assertSee('Quantity sold/subscribed');
    }

    public function test_each_ai_action_includes_required_launch_ready_fields(): void
    {
        $this->createActionActivity($this->branch('WANCHU-MAIN'), productName: 'Required Fields Set', quantity: 2, price: 10.00);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Recommended Action')
            ->assertSee('Reason / Why It Matters')
            ->assertSee('Linked Insight')
            ->assertSee('Evidence')
            ->assertSee('Target')
            ->assertSee('Owner / Person In Charge')
            ->assertSee('Priority')
            ->assertSee('Confidence')
            ->assertSee('Success Metric')
            ->assertSee('Suggested Period')
            ->assertSee('Data Gap');
    }

    public function test_ai_action_supports_required_statuses(): void
    {
        $this->assertSame([
            'Suggested',
            'Planned',
            'In Progress',
            'Done',
            'Dismissed',
        ], AiActionService::statuses());

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Statuses')
            ->assertSee('Suggested')
            ->assertSee('Planned')
            ->assertSee('In Progress')
            ->assertSee('Done')
            ->assertSee('Dismissed');
    }

    public function test_low_data_state_generates_cautious_data_completion_action(): void
    {
        $owner = User::factory()->create([
            'role' => User::ROLE_BUSINESS_OWNER,
            'access_scope' => null,
        ]);

        $this->actingAs($owner)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Complete missing or weak data')
            ->assertSee('Data gap insight')
            ->assertSee('low')
            ->assertDontSee('high');
    }

    public function test_ai_action_does_not_auto_execute_campaign_messages_or_data_changes(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createActionActivity($branch, productName: 'No Execute Set', quantity: 4, price: 9.00);
        $checkIns = CustomerCheckIn::query()->count();
        $captures = CheckInProductService::query()->count();
        $feedback = CustomerFeedback::query()->count();

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Human review diperlukan')
            ->assertDontSee('Auto Execute')
            ->assertDontSee('Send Campaign')
            ->assertDontSee('Send Message');

        $this->assertSame($checkIns, CustomerCheckIn::query()->count());
        $this->assertSame($captures, CheckInProductService::query()->count());
        $this->assertSame($feedback, CustomerFeedback::query()->count());
    }

    public function test_combined_business_owner_branch_manager_ai_action_works(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createActionActivity($branch, productName: 'Combined Action Set', quantity: 3, price: 10.00);

        $this->actingAs($this->user('owner-branch+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Business Owner / Branch Manager Analytics')
            ->assertSee('AI Action Engine')
            ->assertSee('Combined Action Set');
    }

    private function createActionActivity(
        Branch $branch,
        string $productName,
        int $quantity,
        float $price,
        int $rating = 5,
        string $summaryCategory = 'positive_feedback',
    ): void {
        $business = $branch->business;
        $customer = Customer::query()->create([
            'business_id' => $business->id,
            'name' => 'Action Customer '.uniqid(),
            'whatsapp_number' => '601'.random_int(100000000, 999999999),
        ]);
        $program = $business->loyaltyPrograms()->active()->firstOrFail();
        $checkIn = CustomerCheckIn::query()->create([
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'stamps_earned' => 1,
            'source' => 'ai_action_test',
            'check_in_type' => 'physical',
            'reward_status' => 'granted',
            'reward_granted_at' => now(),
        ]);
        StampTransaction::query()->create([
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'type' => StampTransaction::TYPE_EARNED,
            'stamps' => 1,
        ]);
        $product = ProductService::query()->updateOrCreate(
            ['business_id' => $business->id, 'name' => $productName],
            ['branch_id' => $branch->id, 'category' => 'food', 'type' => 'product', 'price' => $price, 'is_active' => true],
        );
        $capture = CheckInProductService::query()->create([
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'captured_by_user_id' => $this->user('owner+wanchu@fbgrowth.local')->id,
            'quantity' => $quantity,
            'price_at_capture' => $price,
            'total_amount' => $quantity * $price,
            'capture_type' => 'purchase',
            'capture_source' => 'ai_action_test',
            'capture_reference' => 'action-'.uniqid(),
        ]);

        CustomerFeedback::query()->create([
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'check_in_product_service_id' => $capture->id,
            'rating' => $rating,
            'comment' => 'AI Action feedback for '.$productName,
            'source' => 'ai_action_test',
            'status' => $rating <= 2 ? CustomerFeedback::STATUS_ACTION_NEEDED : CustomerFeedback::STATUS_SUBMITTED,
            'summary_issue_category' => $summaryCategory,
            'submitted_at' => now(),
        ]);
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business.loyaltyPrograms')->where('code', $code)->firstOrFail();
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
