<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class DashboardScoreboardTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_each_persona_lands_on_correct_dashboard(): void
    {
        $cases = [
            'manager@gos-fnb.local' => 'dashboards.system-manager',
            'admin@fbgrowth.local' => 'dashboards.system-admin',
            'owner+wanchu@fbgrowth.local' => 'dashboards.business-owner',
            'branch+wanchu@fbgrowth.local' => 'dashboards.branch-manager',
            'customer@fbgrowth.local' => 'customer.portal',
            'owner-branch+wanchu@fbgrowth.local' => 'dashboards.business-branch-combined',
        ];

        foreach ($cases as $email => $routeName) {
            $this->actingAs($this->user($email))
                ->get(route('dashboard'))
                ->assertRedirect(route($routeName));
        }
    }

    public function test_system_manager_and_admin_dashboards_show_overview_scoreboards(): void
    {
        $this->actingAs($this->user('manager@gos-fnb.local'))
            ->get(route('dashboards.system-manager'))
            ->assertOk()
            ->assertSee('System Manager Dashboard')
            ->assertSee('Total businesses')
            ->assertSee('Total branches')
            ->assertSee('Total feedback');

        $this->actingAs($this->user('admin@fbgrowth.local'))
            ->get(route('dashboards.system-admin'))
            ->assertOk()
            ->assertSee('System Admin Dashboard')
            ->assertSee('Businesses configured')
            ->assertSee('Users configured')
            ->assertSee('Business setup');
    }

    public function test_business_owner_sees_business_level_scoreboard(): void
    {
        $branch = $this->wanChuBranch();
        $this->createBranchActivity($branch, 'Owner dashboard feedback.');

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('dashboards.business-owner'))
            ->assertOk()
            ->assertSee('Business Owner Dashboard')
            ->assertSee('Branches Summary')
            ->assertSee($branch->name)
            ->assertSee('Product/Service captured')
            ->assertSee('Reward/Loyalty Summary')
            ->assertSee('Owner dashboard feedback.');
    }

    public function test_branch_manager_sees_only_assigned_branch_scoreboard_data(): void
    {
        $assignedBranch = $this->wanChuBranch();
        $otherBranch = Branch::query()->create([
            'business_id' => $assignedBranch->business_id,
            'name' => 'WanChu Hidden Branch',
            'code' => 'WANCHU-HIDDEN',
            'is_active' => true,
        ]);

        $this->createBranchActivity($assignedBranch, 'Assigned branch scoreboard feedback.');
        $this->createBranchActivity($otherBranch, 'Hidden branch scoreboard feedback.');

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('dashboards.branch-manager'))
            ->assertOk()
            ->assertSee('Branch Manager Dashboard')
            ->assertSee($assignedBranch->name)
            ->assertSee('Assigned branch scoreboard feedback.')
            ->assertDontSee($otherBranch->name)
            ->assertDontSee('Hidden branch scoreboard feedback.');
    }

    public function test_combined_business_owner_branch_manager_dashboard_works(): void
    {
        $branch = $this->wanChuBranch();

        $this->actingAs($this->user('owner-branch+wanchu@fbgrowth.local'))
            ->get(route('dashboards.business-branch-combined'))
            ->assertOk()
            ->assertSee('Business Owner / Branch Manager Dashboard')
            ->assertSee('Business Owner cum Branch Manager')
            ->assertSee('Business Performance')
            ->assertSee('Branch Operations')
            ->assertSee($branch->name);
    }

    public function test_customer_sees_only_customer_portal_dashboard(): void
    {
        $customerUser = $this->user('customer@fbgrowth.local');
        $branch = $this->wanChuBranch();
        $this->createBranchActivity($branch, 'Customer own feedback.', $customerUser);

        $this->actingAs($customerUser)
            ->get(route('customer.portal'))
            ->assertOk()
            ->assertSee('Customer Portal')
            ->assertSee('Check-in saya')
            ->assertSee('Reward/Loyalty Status')
            ->assertSee('Submitted Feedback')
            ->assertSee('Customer own feedback.');

        $this->actingAs($customerUser)
            ->get(route('dashboards.business-owner'))
            ->assertForbidden();

        $this->actingAs($customerUser)
            ->get(route('businesses.feedback', $branch->business))
            ->assertForbidden();

        $this->actingAs($customerUser)
            ->get(route('dashboards.system-manager'))
            ->assertForbidden();
    }

    private function createBranchActivity(Branch $branch, string $feedbackComment, ?User $customerUser = null): void
    {
        $business = $branch->business;
        $customer = Customer::query()->where('business_id', $business->id)->first()
            ?? Customer::query()->create([
                'business_id' => $business->id,
                'name' => 'Dashboard Customer',
                'whatsapp_number' => '60122223333',
            ]);

        if ($customerUser) {
            $customer->forceFill(['user_id' => $customerUser->id])->save();
        }

        $checkIn = CustomerCheckIn::query()->create([
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'user_id' => $customerUser?->id,
            'loyalty_program_id' => $business->loyaltyPrograms()->active()->first()?->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'stamps_earned' => 1,
            'source' => 'dashboard_test',
        ]);

        $productService = ProductService::query()
            ->visibleForBranch($branch)
            ->first();

        if ($productService) {
            CheckInProductService::query()->create([
                'customer_check_in_id' => $checkIn->id,
                'product_service_id' => $productService->id,
                'captured_by_user_id' => $this->user('owner+wanchu@fbgrowth.local')->id,
                'quantity' => 1,
                'capture_type' => 'purchased',
            ]);
        }

        CustomerFeedback::query()->create([
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $productService?->id,
            'rating' => 5,
            'comment' => $feedbackComment,
            'source' => 'dashboard_test',
            'submitted_at' => now(),
        ]);
    }

    private function wanChuBranch(): Branch
    {
        return Branch::query()->where('code', 'WANCHU-MAIN')->firstOrFail();
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
