<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\ProductService;
use App\Models\RewardRedemption;
use App\Models\StampTransaction;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AnalyticsMvpTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_business_owner_sees_analytics_for_owned_business_only(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $otherBranch = $this->branch('CHENA-MAIN');
        $this->createAnalyticsActivity($branch, productName: 'Teh Ais', quantity: 2, price: 3.50, comment: 'Teh Ais sedap dan service cepat.');
        $this->createAnalyticsActivity($otherBranch, productName: 'Lunch Set', quantity: 1, price: 20.00, comment: 'Hidden owner analytics.');

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Business Owner Analytics')
            ->assertSee('WanChu Corner Main Branch')
            ->assertSee('RM 7.00')
            ->assertDontSee('Restoran Che Na Main Branch')
            ->assertDontSee('RM 20.00');
    }

    public function test_branch_manager_sees_analytics_for_assigned_branch_only(): void
    {
        $assignedBranch = $this->branch('WANCHU-MAIN');
        $otherBranch = Branch::factory()->create([
            'business_id' => $assignedBranch->business_id,
            'name' => 'WanChu Hidden Analytics',
            'code' => 'WANCHU-HIDDEN-ANALYTICS',
        ]);

        $this->createAnalyticsActivity($assignedBranch, productName: 'Teh Ais', quantity: 2, price: 3.50);
        $this->createAnalyticsActivity($otherBranch, productName: 'Hidden Item', quantity: 1, price: 99.00);

        $this->actingAs($this->user('branch+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Branch Manager Analytics')
            ->assertSee('WanChu Corner Main Branch')
            ->assertSee('RM 7.00')
            ->assertDontSee('WanChu Hidden Analytics')
            ->assertDontSee('RM 99.00');
    }

    public function test_customer_cannot_access_internal_analytics(): void
    {
        $this->actingAs($this->user('customer@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertForbidden();
    }

    public function test_system_admin_can_access_admin_support_analytics(): void
    {
        $this->actingAs($this->user('admin@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('System Admin Analytics')
            ->assertSee('System &amp; Access Support Analytics', false)
            ->assertSee('System Admin Support Analytics')
            ->assertSee('Total users')
            ->assertSee('Branch without assigned manager')
            ->assertSee('Product/Service configuration missing')
            ->assertDontSee('Sales by Product/Service')
            ->assertDontSee('GOS revenue/subscription data gap insight');
    }

    public function test_system_manager_can_view_high_level_platform_analytics(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createAnalyticsActivity($branch, productName: 'Teh Ais', quantity: 1, price: 3.50);

        $this->actingAs($this->user('manager@gos-fnb.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('System Manager Analytics')
            ->assertSee('GOS platform/business analytics')
            ->assertSee('GOS Platform / Business Performance')
            ->assertSee('Business category/vertical performance')
            ->assertSee('Revenue/subscription data gap')
            ->assertSee('Total sales/value')
            ->assertSee('Branch Performance Analytics');
    }

    public function test_sales_and_average_transaction_value_are_calculated_from_valid_captures(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createAnalyticsActivity($branch, productName: 'Teh Ais', quantity: 2, price: 3.50);
        $this->createAnalyticsActivity($branch, productName: 'Nasi Lemak Ayam', quantity: 1, price: 12.90);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('RM 19.90')
            ->assertSee('RM 9.95');
    }

    public function test_sales_by_branch_and_product_service_work(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createAnalyticsActivity($branch, productName: 'Teh Ais', quantity: 3, price: 3.50);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Sales by branch')
            ->assertSee('WanChu Corner Main Branch')
            ->assertSee('Sales by Product/Service')
            ->assertSee('Teh Ais')
            ->assertSee('Qty: 3');
    }

    public function test_customer_analytics_calculates_total_new_repeat_active_purchase_and_value(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $customer = $this->createAnalyticsActivity($branch, productName: 'Teh Ais', quantity: 1, price: 3.50);
        $this->createCheckIn($branch, $customer);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Customer Analytics')
            ->assertSee('Repeat customers')
            ->assertSee('Active customers')
            ->assertSee('Purchase count')
            ->assertSee('Customer value');
    }

    public function test_product_service_analytics_identifies_popular_highest_sales_and_low_activity_products(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        ProductService::factory()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'name' => 'Low Activity Soup',
            'category' => 'food',
            'price' => 8.00,
        ]);
        $this->createAnalyticsActivity($branch, productName: 'Teh Ais', quantity: 5, price: 3.50);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Popular Product/Service')
            ->assertSee('Highest sales Product/Service')
            ->assertSee('Most purchased Product/Service')
            ->assertSee('Weak/low activity Product/Service')
            ->assertSee('Low Activity Soup');
    }

    public function test_branch_analytics_calculates_sales_check_ins_customers_repeat_and_feedback_status(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $customer = $this->createAnalyticsActivity($branch, productName: 'Teh Ais', quantity: 1, price: 3.50);
        $this->createCheckIn($branch, $customer);

        CustomerFeedback::query()->where('branch_id', $branch->id)->firstOrFail()->update([
            'status' => CustomerFeedback::STATUS_ACTION_NEEDED,
        ]);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Branch Performance Analytics')
            ->assertSee('Check-ins')
            ->assertSee('Customers')
            ->assertSee('Repeat')
            ->assertSee('1 action');
    }

    public function test_reward_analytics_counts_issued_redeemed_and_pending(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $customer = $this->createAnalyticsActivity($branch, productName: 'Teh Ais', quantity: 1, price: 3.50);
        $program = $branch->business->loyaltyPrograms()->active()->firstOrFail();

        RewardRedemption::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'reward_name' => 'Free drink',
            'stamps_spent' => 8,
            'redeemed_at' => now(),
        ]);
        RewardRedemption::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'reward_name' => 'Free drink',
            'stamps_spent' => 8,
        ]);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Reward/stamp issued')
            ->assertSee('Reward redeemed')
            ->assertSee('Reward pending');
    }

    public function test_feedback_analytics_counts_statuses_and_summary_categories(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createAnalyticsActivity($branch, productName: 'Teh Ais', quantity: 1, price: 3.50, comment: 'Teh Ais sedap dan service cepat.');
        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => Customer::query()->where('business_id', $branch->business_id)->firstOrFail()->id,
            'status' => CustomerFeedback::STATUS_REVIEWED,
            'summary_issue_category' => 'unclear',
            'summary_needs_review' => true,
            'submitted_at' => now(),
        ]);
        CustomerFeedback::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => Customer::query()->where('business_id', $branch->business_id)->firstOrFail()->id,
            'status' => CustomerFeedback::STATUS_RESOLVED,
            'summary_issue_category' => 'positive_feedback',
            'submitted_at' => now(),
        ]);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Pending feedback')
            ->assertSee('Submitted feedback')
            ->assertSee('Reviewed feedback')
            ->assertSee('Action needed feedback')
            ->assertSee('Resolved feedback')
            ->assertSee('Positive summary')
            ->assertSee('Unclear summary');
    }

    public function test_time_filters_work_for_today_this_week_and_this_month(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $this->createAnalyticsActivity($branch, productName: 'Teh Ais', quantity: 1, price: 3.50, createdAt: now());
        $this->createAnalyticsActivity($branch, productName: 'Old Item', quantity: 1, price: 99.00, createdAt: now()->subMonths(2));

        $owner = $this->user('owner+wanchu@fbgrowth.local');

        $this->actingAs($owner)->get(route('analytics.index', ['period' => 'today']))->assertOk()->assertSee('RM 3.50')->assertDontSee('RM 102.50');
        $this->actingAs($owner)->get(route('analytics.index', ['period' => 'week']))->assertOk()->assertSee('RM 3.50');
        $this->actingAs($owner)->get(route('analytics.index', ['period' => 'month']))->assertOk()->assertSee('RM 3.50');
    }

    public function test_incomplete_activity_is_not_counted_as_valid_revenue(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $customer = Customer::query()->where('business_id', $branch->business_id)->firstOrFail();
        $checkIn = $this->createCheckIn($branch, $customer);
        $product = ProductService::query()->where('business_id', $branch->business_id)->firstOrFail();

        CheckInProductService::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'quantity' => 1,
            'price_at_capture' => 0,
            'total_amount' => 0,
            'capture_type' => 'purchase',
            'capture_source' => 'test',
        ]);

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('RM 0.00');
    }

    public function test_duplicate_captures_are_not_double_counted_when_duplicate_is_prevented(): void
    {
        $branch = $this->branch('WANCHU-MAIN');
        $customer = $this->createAnalyticsActivity($branch, productName: 'Teh Ais', quantity: 1, price: 3.50, reference: 'same-ref');
        $checkIn = CustomerCheckIn::query()->where('customer_id', $customer->id)->firstOrFail();
        $product = ProductService::query()->where('name', 'Teh Ais')->firstOrFail();

        try {
            $this->createCapture($branch, $checkIn, $customer, $product, 1, 3.50, 'same-ref');
        } catch (\Throwable) {
            // Unique capture reference blocks retry-style duplicates.
        }

        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('RM 3.50')
            ->assertDontSee('RM 7.00');
    }

    public function test_data_completeness_detects_weak_data_with_recommendation_and_reason(): void
    {
        $this->actingAs($this->user('owner+wanchu@fbgrowth.local'))
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('Analytics Data Completeness')
            ->assertSee('Insufficient check-in data')
            ->assertSee('Check-in masih rendah')
            ->assertSee('aktifkan QR check-in di branch')
            ->assertSee('Data belum cukup untuk analytics yang tepat.');
    }

    private function createAnalyticsActivity(
        Branch $branch,
        string $productName,
        int $quantity,
        float $price,
        string $comment = 'Analytics feedback.',
        ?User $customerUser = null,
        ?\DateTimeInterface $createdAt = null,
        ?string $reference = null,
    ): Customer {
        $createdAt ??= now();
        $business = $branch->business;
        $customer = Customer::query()->create([
            'business_id' => $business->id,
            'user_id' => $customerUser?->id,
            'name' => $customerUser?->name ?? 'Analytics Customer '.uniqid(),
            'whatsapp_number' => '601'.random_int(100000000, 999999999),
            'created_at' => $createdAt,
            'updated_at' => $createdAt,
        ]);
        $checkIn = $this->createCheckIn($branch, $customer, $createdAt);
        $product = ProductService::query()->updateOrCreate(
            ['business_id' => $business->id, 'name' => $productName],
            ['branch_id' => $branch->id, 'category' => 'drink', 'type' => 'product', 'price' => $price, 'is_active' => true],
        );
        $capture = $this->createCapture(
            branch: $branch,
            checkIn: $checkIn,
            customer: $customer,
            product: $product,
            quantity: $quantity,
            price: $price,
            reference: $reference,
            createdAt: $createdAt,
        );

        CustomerFeedback::query()->create([
            'business_id' => $business->id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'check_in_product_service_id' => $capture->id,
            'rating' => 4,
            'comment' => $comment,
            'source' => 'analytics_test',
            'status' => CustomerFeedback::STATUS_SUBMITTED,
            'summary_issue_category' => str_contains(strtolower($comment), 'sedap') ? 'positive_feedback' : 'general_issue',
            'submitted_at' => $createdAt,
            'created_at' => $createdAt,
            'updated_at' => $createdAt,
        ]);

        return $customer;
    }

    private function createCheckIn(Branch $branch, Customer $customer, ?\DateTimeInterface $createdAt = null): CustomerCheckIn
    {
        $createdAt ??= now();
        $program = $branch->business->loyaltyPrograms()->active()->firstOrFail();

        $checkIn = CustomerCheckIn::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'user_id' => $customer->user_id,
            'loyalty_program_id' => $program->id,
            'check_in_date' => $createdAt->format('Y-m-d'),
            'check_in_at' => $createdAt,
            'stamps_earned' => 1,
            'source' => 'analytics_test',
            'check_in_type' => 'physical',
            'reward_status' => 'granted',
            'reward_granted_at' => $createdAt,
            'created_at' => $createdAt,
            'updated_at' => $createdAt,
        ]);

        StampTransaction::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'type' => StampTransaction::TYPE_EARNED,
            'stamps' => 1,
            'created_at' => $createdAt,
            'updated_at' => $createdAt,
        ]);

        return $checkIn;
    }

    private function createCapture(
        Branch $branch,
        CustomerCheckIn $checkIn,
        Customer $customer,
        ProductService $product,
        int $quantity,
        float $price,
        ?string $reference = null,
        ?\DateTimeInterface $createdAt = null,
    ): CheckInProductService {
        $createdAt ??= now();

        $capture = CheckInProductService::query()->create([
            'business_id' => $branch->business_id,
            'branch_id' => $branch->id,
            'customer_id' => $customer->id,
            'customer_check_in_id' => $checkIn->id,
            'product_service_id' => $product->id,
            'captured_by_user_id' => $this->user('owner+wanchu@fbgrowth.local')->id,
            'quantity' => $quantity,
            'price_at_capture' => $price,
            'total_amount' => $quantity * $price,
            'capture_type' => 'purchase',
            'capture_source' => 'analytics_test',
            'capture_reference' => $reference ?? 'analytics-'.uniqid(),
        ]);

        $capture->forceFill([
            'created_at' => $createdAt,
            'updated_at' => $createdAt,
        ])->save();

        return $capture;
    }

    private function branch(string $code): Branch
    {
        return Branch::query()->with('business.loyaltyPrograms')->where('code', $code)->firstOrFail();
    }

    private function user(string $email): User
    {
        return User::query()->where('email', $email)->firstOrFail();
    }
}
