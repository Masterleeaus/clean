<?php

namespace Tests\Feature;

use App\Models\Branch;
use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\ProductService;
use App\Models\User;
use App\Services\RoleAccessPilotGuard;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class SystemAdminAccessControlTest extends TestCase
{
    use RefreshDatabase;

    private User $systemAdmin;

    private Business $business;

    private Branch $branch;

    private CustomerCheckIn $checkIn;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);

        $this->systemAdmin = User::query()->where('email', 'admin@fbgrowth.local')->firstOrFail();
        $this->business = Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
        $this->branch = Branch::query()->where('code', 'WANCHU-MAIN')->firstOrFail();

        $customer = Customer::query()->where('business_id', $this->business->id)->firstOrFail();

        $this->checkIn = CustomerCheckIn::query()->create([
            'business_id' => $this->business->id,
            'branch_id' => $this->branch->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $this->business->loyaltyPrograms()->active()->first()?->id,
            'check_in_date' => now()->toDateString(),
            'check_in_at' => now(),
            'source' => 'system_admin_access_test',
            'reward_status' => CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT,
            'stamps_earned' => 0,
        ]);
    }

    public function test_lp_ac_sa_01_system_admin_dashboard_is_allowed(): void
    {
        $this->actingAs($this->systemAdmin)
            ->get(route('dashboards.system-admin'))
            ->assertOk()
            ->assertSee('System Admin Dashboard')
            ->assertSee('System/admin/support operation')
            ->assertSee('System setup, admin support, access support, dan AI provider visibility');
    }

    public function test_lp_ac_sa_02_user_account_admin_support_area_is_allowed(): void
    {
        $this->actingAs($this->systemAdmin)
            ->get(route('dashboards.system-admin'))
            ->assertOk()
            ->assertSee('Users configured')
            ->assertSee('Branches without manager');
    }

    public function test_lp_ac_sa_03_role_access_assignment_check_and_balance_is_allowed(): void
    {
        $guard = app(RoleAccessPilotGuard::class);
        $target = User::factory()->create([
            'role' => User::ROLE_BRANCH_MANAGER,
            'secondary_role' => null,
            'access_scope' => null,
        ]);

        $result = $guard->validateControlledPilotSetup(
            actor: $this->systemAdmin,
            target: $target,
            business: $this->business,
            branchIds: [$this->branch->id],
            primaryRole: User::ROLE_BRANCH_MANAGER,
        );

        $this->assertTrue($result['allowed']);
        $this->assertNotContains('Controlled Pilot user setup must be completed by System Admin.', $result['errors']);
    }

    public function test_lp_ac_sa_04_business_branch_setup_area_is_allowed(): void
    {
        $this->actingAs($this->systemAdmin)
            ->get(route('businesses.create'))
            ->assertOk();

        $this->actingAs($this->systemAdmin)
            ->get(route('businesses.branches.create', $this->business))
            ->assertOk();

        $this->actingAs($this->systemAdmin)
            ->get(route('businesses.branches.edit', [
                'business' => $this->business,
                'branch' => $this->branch,
            ]))
            ->assertOk();
    }

    public function test_lp_ac_sa_05_platform_usage_support_analytics_is_allowed(): void
    {
        $this->actingAs($this->systemAdmin)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('System Admin Analytics')
            ->assertSee('System &amp; Access Support Analytics', false)
            ->assertSee('System Admin Support Analytics')
            ->assertDontSee('GOS Platform / Business Performance');
    }

    public function test_lp_ac_sa_06_admin_support_ai_insight_is_allowed(): void
    {
        $this->actingAs($this->systemAdmin)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Insight Engine')
            ->assertSee('System setup/access insight')
            ->assertSee('Platform usage support insight')
            ->assertDontSee('GOS revenue/subscription data gap insight');
    }

    public function test_lp_ac_sa_07_admin_support_ai_action_is_allowed(): void
    {
        $this->actingAs($this->systemAdmin)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('AI Action Engine')
            ->assertSee('System/admin/support')
            ->assertSee('System Admin')
            ->assertSee('Human review diperlukan')
            ->assertDontSee('Auto Execute')
            ->assertDontSee('Send Campaign')
            ->assertDontSee('Send Message')
            ->assertDontSee('subscriber revenue optimization');
    }

    public function test_lp_ac_sa_08_system_manager_strategy_area_is_blocked(): void
    {
        $this->actingAs($this->systemAdmin)
            ->get(route('dashboards.system-manager'))
            ->assertForbidden();

        $this->actingAs($this->systemAdmin)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertDontSee('System Manager Analytics')
            ->assertDontSee('GOS Platform / Business Performance');
    }

    public function test_lp_ac_sa_09_customer_portal_is_blocked(): void
    {
        $this->actingAs($this->systemAdmin)
            ->get(route('customer.portal'))
            ->assertForbidden();
    }

    public function test_lp_ac_sa_10_customer_only_check_in_action_is_blocked(): void
    {
        $this->actingAs($this->systemAdmin)
            ->post(route('customer.check-in.store'))
            ->assertForbidden();
    }

    public function test_lp_ac_sa_11_owner_dashboard_and_strategy_pages_are_blocked(): void
    {
        $this->actingAs($this->systemAdmin)
            ->get(route('dashboards.business-owner'))
            ->assertForbidden();

        $this->actingAs($this->systemAdmin)
            ->get(route('businesses.dashboard', $this->business))
            ->assertForbidden();
    }

    public function test_lp_ac_sa_12_branch_manager_operation_dashboard_and_capture_purchase_are_blocked(): void
    {
        $product = ProductService::query()->where('business_id', $this->business->id)->firstOrFail();

        $this->actingAs($this->systemAdmin)
            ->get(route('dashboards.branch-manager'))
            ->assertForbidden();

        $this->actingAs($this->systemAdmin)
            ->get(route('businesses.branches.check-ins', [
                'business' => $this->business,
                'branch' => $this->branch,
            ]))
            ->assertForbidden();

        $this->actingAs($this->systemAdmin)
            ->post(route('businesses.branches.check-ins.product-services.store', [
                'business' => $this->business,
                'branch' => $this->branch,
                'checkIn' => $this->checkIn,
            ]), [
                'product_service_id' => $product->id,
                'quantity' => 1,
                'capture_type' => 'purchase',
            ])
            ->assertForbidden();
    }

    public function test_lp_ac_sa_13_mark_no_purchase_is_blocked(): void
    {
        $this->actingAs($this->systemAdmin)
            ->patch(route('businesses.branches.check-ins.no-purchase', [
                'business' => $this->business,
                'branch' => $this->branch,
                'checkIn' => $this->checkIn,
            ]))
            ->assertForbidden();
    }

    public function test_lp_ac_sa_14_system_admin_navigation_stays_admin_support_scoped(): void
    {
        $this->actingAs($this->systemAdmin)
            ->get(route('dashboards.system-admin'))
            ->assertOk()
            ->assertSee('System Admin Dashboard')
            ->assertSee('Admin Links')
            ->assertSee('Analytics')
            ->assertSee('Business setup')
            ->assertSee('Create business')
            ->assertSee('Users configured')
            ->assertSee('AI Provider Status')
            ->assertSee('Active/default provider')
            ->assertSee('Gemini')
            ->assertSee('Priority chain')
            ->assertSee('OpenAI: Disabled')
            ->assertSee('Rule-based: Available')
            ->assertSee('Last used provider')
            ->assertSee('External AI')
            ->assertSee('Suggestion Only')
            ->assertDontSee('Customer Portal')
            ->assertDontSee('Customer Check-in')
            ->assertDontSee('Business Performance')
            ->assertDontSee('Branch Operations')
            ->assertDontSee('Capture Purchase')
            ->assertDontSee('Mark No Purchase')
            ->assertDontSee('System Manager Dashboard')
            ->assertDontSee('Platform Analytics / AI');
    }

    public function test_system_admin_ai_provider_status_is_visible_without_secret_values(): void
    {
        config(['ai.providers.gemini.api_key' => 'fake-system-admin-hidden-key']);

        $this->actingAs($this->systemAdmin)
            ->get(route('dashboards.system-admin'))
            ->assertOk()
            ->assertSee('AI Provider Status')
            ->assertSee('Active/default provider')
            ->assertSee('Gemini')
            ->assertSee('OpenAI: Disabled')
            ->assertSee('Gemini: Configured')
            ->assertSee('Groq: Missing key')
            ->assertSee('OpenRouter: Missing key')
            ->assertSee('Rule-based: Available')
            ->assertSee('External AI')
            ->assertSee('Last used provider')
            ->assertSee('No fallback recorded')
            ->assertSee('Suggestion Only')
            ->assertDontSee('fake-system-admin-hidden-key');
    }

    public function test_system_admin_analytics_keeps_admin_support_ai_scope_and_safe_provider_status(): void
    {
        config([
            'ai.external_enabled' => false,
            'ai.providers.gemini.api_key' => 'fake-system-admin-analytics-hidden-key',
        ]);

        $this->actingAs($this->systemAdmin)
            ->get(route('analytics.index'))
            ->assertOk()
            ->assertSee('System Admin Analytics')
            ->assertSee('System Admin Support Analytics')
            ->assertSee('System setup/access insight')
            ->assertSee('AI Provider Status')
            ->assertSee('Suggestion Only')
            ->assertDontSee('GOS Platform / Business Performance')
            ->assertDontSee('GOS revenue/subscription data gap insight')
            ->assertDontSee('fake-system-admin-analytics-hidden-key');
    }
}
