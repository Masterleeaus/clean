<?php

namespace Tests\Feature;

use App\Models\Business;
use App\Models\Customer;
use App\Models\CustomerLoyaltyAccount;
use App\Models\RewardRedemption;
use App\Models\StampTransaction;
use App\Models\User;
use Database\Seeders\FnbCoreSeeder;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class RewardRedemptionTest extends TestCase
{
    use RefreshDatabase;

    protected function setUp(): void
    {
        parent::setUp();

        $this->withoutVite();
        $this->seed(FnbCoreSeeder::class);
    }

    public function test_owner_can_redeem_eligible_customer_reward_for_own_business(): void
    {
        [$business, $customer] = $this->eligibleCustomer();
        $owner = $this->wanChuOwner();

        $this->actingAs($owner)
            ->post($this->redeemRoute($business, $customer))
            ->assertRedirect($this->businessShowRoute($business))
            ->assertSessionHas('status', 'Reward redemption verified.');
    }

    public function test_redemption_creates_reward_redemptions_record(): void
    {
        [$business, $customer, $program] = $this->eligibleCustomer();
        $owner = $this->wanChuOwner();

        $this->actingAs($owner)->post($this->redeemRoute($business, $customer));

        $this->assertDatabaseHas('reward_redemptions', [
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'reward_name' => $program->reward_name,
            'stamps_spent' => $program->stamps_required,
            'verified_by_user_id' => $owner->id,
        ]);

        $this->assertNotNull(RewardRedemption::query()->firstOrFail()->redeemed_at);
    }

    public function test_redemption_resets_current_stamps_to_zero(): void
    {
        [$business, $customer] = $this->eligibleCustomer(currentStamps: 10);

        $this->actingAs($this->wanChuOwner())->post($this->redeemRoute($business, $customer));

        $this->assertSame(0, $customer->loyaltyAccounts()->firstOrFail()->current_stamps);
    }

    public function test_redemption_increments_total_rewards_redeemed(): void
    {
        [$business, $customer] = $this->eligibleCustomer();

        $this->actingAs($this->wanChuOwner())->post($this->redeemRoute($business, $customer));

        $this->assertSame(1, $customer->loyaltyAccounts()->firstOrFail()->total_rewards_redeemed);
    }

    public function test_total_stamps_earned_does_not_reset(): void
    {
        [$business, $customer] = $this->eligibleCustomer(currentStamps: 8, totalEarned: 21);

        $this->actingAs($this->wanChuOwner())->post($this->redeemRoute($business, $customer));

        $this->assertSame(21, $customer->loyaltyAccounts()->firstOrFail()->total_stamps_earned);
    }

    public function test_stamp_transaction_is_recorded_for_redemption_reset(): void
    {
        [$business, $customer, $program] = $this->eligibleCustomer();

        $this->actingAs($this->wanChuOwner())->post($this->redeemRoute($business, $customer));

        $this->assertDatabaseHas('stamp_transactions', [
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'type' => StampTransaction::TYPE_REDEEMED_RESET,
            'stamps' => -$program->stamps_required,
        ]);
    }

    public function test_owner_cannot_redeem_another_business_customer(): void
    {
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();
        $customer = $this->eligibleCustomerFor($otherBusiness)[1];

        $this->actingAs($this->wanChuOwner())
            ->post($this->redeemRoute($otherBusiness, $customer))
            ->assertForbidden();

        $this->assertDatabaseCount('reward_redemptions', 0);
    }

    public function test_admin_can_redeem_any_business_customer(): void
    {
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();
        $customer = $this->eligibleCustomerFor($otherBusiness)[1];
        $admin = User::query()->where('email', 'admin@fbgrowth.local')->firstOrFail();

        $this->actingAs($admin)
            ->post($this->redeemRoute($otherBusiness, $customer))
            ->assertRedirect($this->businessShowRoute($otherBusiness));

        $redemption = RewardRedemption::query()->firstOrFail();

        $this->assertSame($otherBusiness->id, $redemption->business_id);
        $this->assertSame($customer->id, $redemption->customer_id);
        $this->assertSame($admin->id, $redemption->verified_by_user_id);
    }

    public function test_ineligible_customer_cannot_be_redeemed(): void
    {
        [$business, $customer] = $this->eligibleCustomer(currentStamps: 3, totalEarned: 3);

        $this->actingAs($this->wanChuOwner())
            ->post($this->redeemRoute($business, $customer))
            ->assertSessionHasErrors('redemption');

        $this->assertDatabaseCount('reward_redemptions', 0);
        $this->assertSame(3, $customer->loyaltyAccounts()->firstOrFail()->current_stamps);
    }

    public function test_customer_belonging_to_another_business_cannot_be_redeemed_through_wrong_business_route(): void
    {
        $wanChu = $this->wanChu();
        $otherBusiness = Business::query()->where('slug', 'restoran-che-na')->firstOrFail();
        $otherCustomer = $this->eligibleCustomerFor($otherBusiness)[1];
        $admin = User::query()->where('email', 'admin@fbgrowth.local')->firstOrFail();

        $this->actingAs($admin)
            ->post($this->redeemRoute($wanChu, $otherCustomer))
            ->assertSessionHasErrors('customer');

        $this->assertDatabaseCount('reward_redemptions', 0);
    }

    private function eligibleCustomer(?int $currentStamps = null, ?int $totalEarned = null): array
    {
        return $this->eligibleCustomerFor($this->wanChu(), $currentStamps, $totalEarned);
    }

    private function eligibleCustomerFor(Business $business, ?int $currentStamps = null, ?int $totalEarned = null): array
    {
        $program = $business->loyaltyPrograms()->active()->firstOrFail();
        $currentStamps ??= $program->stamps_required;
        $totalEarned ??= $currentStamps;
        $customer = Customer::query()->create([
            'business_id' => $business->id,
            'name' => 'Aina',
            'whatsapp_number' => '60123456789'.$business->id,
        ]);
        CustomerLoyaltyAccount::query()->create([
            'business_id' => $business->id,
            'customer_id' => $customer->id,
            'loyalty_program_id' => $program->id,
            'current_stamps' => $currentStamps,
            'total_stamps_earned' => $totalEarned,
        ]);

        return [$business, $customer, $program];
    }

    private function wanChu(): Business
    {
        return Business::query()->where('slug', 'wanchu-corner')->firstOrFail();
    }

    private function wanChuOwner(): User
    {
        return User::query()->where('email', 'owner+wanchu@fbgrowth.local')->firstOrFail();
    }

    private function redeemRoute(Business $business, Customer $customer): string
    {
        return route('businesses.customers.redeem', [
            'business' => $business,
            'customer' => $customer,
        ]);
    }

    private function businessShowRoute(Business $business): string
    {
        return route('businesses.show', [
            'business' => $business,
        ]);
    }
}
