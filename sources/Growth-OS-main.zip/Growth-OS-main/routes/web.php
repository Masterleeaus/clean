<?php

use App\Http\Controllers\BusinessController;
use App\Http\Controllers\AnalyticsController;
use App\Http\Controllers\BranchController;
use App\Http\Controllers\CheckInProductServiceController;
use App\Http\Controllers\CustomerCheckInController;
use App\Http\Controllers\CustomerFeedbackController;
use App\Http\Controllers\CustomerPortalController;
use App\Http\Controllers\ProductServiceController;
use App\Http\Controllers\RewardLoyaltyController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\PublicBusinessRegistrationController;
use App\Http\Controllers\WeeklyGrowthReportController;
use App\Models\Branch;
use App\Models\Business;
use App\Models\CheckInProductService;
use App\Models\Customer;
use App\Models\CustomerCheckIn;
use App\Models\CustomerFeedback;
use App\Models\CustomerLoyaltyAccount;
use App\Models\ProductServiceReviewAlert;
use App\Models\RewardRedemption;
use App\Models\User;
use App\Services\Ai\AiProviderManager;
use App\Services\WeeklyGrowthReportService;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return auth()->check()
        ? redirect()->route('dashboard')
        : redirect()->route('login');
});

$businessDashboard = function (Request $request, WeeklyGrowthReportService $reports) {
    $routeName = (string) $request->route()?->getName();
    $user = $request->user();

    abort_if($routeName === 'dashboards.business-owner' && ! $user->isOwner(), 403);
    abort_if($routeName === 'dashboards.branch-manager' && ! $user->isBranchManager(), 403);
    abort_if($routeName === 'dashboards.business-branch-combined' && ! $user->hasBusinessCombinedAccess(), 403);

    $businesses = Business::query()
        ->accessibleTo($user)
        ->orderBy('name')
        ->get();

    $businessIds = $businesses->pluck('id');
    $primaryBusiness = $businesses->first();
    $branches = Branch::query()
        ->accessibleTo($user)
        ->with('business')
        ->orderBy('name')
        ->get();
    $branchIds = $branches->pluck('id');
    $operationBranchIds = $user->isBranchManager()
        ? collect($user->scopedBranchIds())
        : $branchIds;
    $assignedBranches = $user->isBranchManager()
        ? Branch::query()
            ->whereIn('id', $user->scopedBranchIds())
            ->with('business')
            ->orderBy('name')
            ->get()
        : collect();

    $scopedCheckIns = fn () => CustomerCheckIn::query()
        ->whereIn('business_id', $businessIds)
        ->when($branchIds->isNotEmpty(), fn (Builder $query) => $query->whereIn('branch_id', $branchIds));

    $scopedFeedback = fn () => CustomerFeedback::query()
        ->whereIn('business_id', $businessIds)
        ->when($branchIds->isNotEmpty(), fn (Builder $query) => $query->whereIn('branch_id', $branchIds));

    $scopedRedemptions = fn () => RewardRedemption::query()
        ->whereIn('business_id', $businessIds)
        ->when($branchIds->isNotEmpty(), fn (Builder $query) => $query->whereIn('branch_id', $branchIds));

    $scopedOperationCheckIns = fn () => $scopedCheckIns()
        ->when(
            $user->isBranchManager(),
            fn (Builder $query) => $operationBranchIds->isEmpty()
                ? $query->whereRaw('1 = 0')
                : $query->whereIn('branch_id', $operationBranchIds),
        );

    return view('dashboard', [
        'dashboardTitle' => match ($routeName) {
            'dashboards.branch-manager' => 'Branch Manager Dashboard',
            'dashboards.business-branch-combined' => 'Business Owner / Branch Manager Dashboard',
            default => 'Business Owner Dashboard',
        },
        'businesses' => $businesses,
        'branches' => $branches,
        'assignedBranches' => $assignedBranches,
        'primaryBusiness' => $primaryBusiness,
        'todayRegistrations' => $businessIds->isEmpty()
            ? 0
            : Customer::query()
                ->whereIn('business_id', $businessIds)
                ->whereDate('created_at', now()->toDateString())
                ->count(),
        'todayCheckIns' => $businessIds->isEmpty()
            ? 0
            : $scopedCheckIns()
                ->whereDate('check_in_date', now()->toDateString())
                ->count(),
        'repeatCustomers' => $businessIds->isEmpty()
            ? 0
            : $scopedCheckIns()
                ->select('business_id', 'customer_id')
                ->groupBy('business_id', 'customer_id')
                ->havingRaw('COUNT(*) > 1')
                ->get()
                ->count(),
        'rewardsRedeemed' => $businessIds->isEmpty()
            ? 0
            : $scopedRedemptions()
                ->count(),
        'productCaptures' => $businessIds->isEmpty()
            ? 0
            : CheckInProductService::query()
                ->whereHas('checkIn', fn (Builder $query) => $query
                    ->whereIn('business_id', $businessIds)
                    ->when($branchIds->isNotEmpty(), fn (Builder $query) => $query->whereIn('branch_id', $branchIds)))
                ->count(),
        'feedbackSubmitted' => $businessIds->isEmpty() ? 0 : $scopedFeedback()->count(),
        'pendingPurchaseCaptures' => $businessIds->isEmpty()
            ? 0
            : $scopedOperationCheckIns()
                ->where('reward_status', CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT)
                ->where('check_in_at', '>', now()->subHours(CustomerCheckIn::OVERDUE_PURCHASE_CAPTURE_HOURS))
                ->count(),
        'overduePurchaseCaptures' => $businessIds->isEmpty()
            ? 0
            : $scopedOperationCheckIns()
                ->where('reward_status', CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT)
                ->where('check_in_at', '<=', now()->subHours(CustomerCheckIn::OVERDUE_PURCHASE_CAPTURE_HOURS))
                ->where('check_in_at', '>', now()->subHours(CustomerCheckIn::MANUAL_REVIEW_HOURS))
                ->count(),
        'manualReviewPurchaseCaptures' => $businessIds->isEmpty()
            ? 0
            : $scopedOperationCheckIns()
                ->where('reward_status', CustomerCheckIn::REWARD_STATUS_PENDING_PRODUCT)
                ->where('check_in_at', '<=', now()->subHours(CustomerCheckIn::MANUAL_REVIEW_HOURS))
                ->count(),
        'loyaltyAccounts' => $businessIds->isEmpty()
            ? 0
            : CustomerLoyaltyAccount::query()
                ->whereIn('business_id', $businessIds)
                ->count(),
        'recentCheckIns' => $businessIds->isEmpty()
            ? collect()
            : $scopedCheckIns()
                ->with(['business', 'branch', 'customer'])
                ->latest('check_in_at')
                ->limit(5)
                ->get(),
        'recentFeedback' => $businessIds->isEmpty()
            ? collect()
            : $scopedFeedback()
                ->with(['business', 'branch', 'customer'])
                ->latest('submitted_at')
                ->limit(5)
                ->get(),
        'weeklyReport' => ($primaryBusiness && ! ($user->isBranchManager() && ! $user->isOwner()))
            ? $reports->reportFor($primaryBusiness)
            : null,
        'productServiceReviewAlerts' => $businessIds->isEmpty()
            ? collect()
            : ProductServiceReviewAlert::query()
                ->with(['branch', 'productService', 'actor'])
                ->whereIn('business_id', $businessIds)
                ->where('status', ProductServiceReviewAlert::STATUS_OPEN)
                ->latest()
                ->limit(8)
                ->get(),
    ]);
};

Route::get('/dashboard', function (Request $request) {
    return redirect()->route($request->user()->dashboardRouteName());
})->middleware(['auth', 'verified'])->name('dashboard');

Route::get('/analytics', AnalyticsController::class)
    ->middleware(['auth', 'verified'])
    ->name('analytics.index');

Route::get('/dashboards/system-manager', function () {
    abort_unless(request()->user()->isSystemManager(), 403);

    return view('dashboards.persona', [
        'title' => 'System Manager Dashboard',
        'subtitle' => 'GOS Sdn Bhd platform/business performance, vertical health, dan adoption signals.',
        'scope' => 'Strategic platform performance dan F&B vertical effectiveness',
        'stats' => [
            'Total businesses' => Business::query()->count(),
            'Total branches' => Branch::query()->count(),
            'Total customers' => Customer::query()->count(),
            'Total check-ins' => CustomerCheckIn::query()->count(),
            'Total feedback' => CustomerFeedback::query()->count(),
        ],
        'links' => [
            'Platform Analytics / AI' => route('analytics.index'),
        ],
        'linksTitle' => 'Platform Links',
    ]);
})->middleware(['auth', 'verified'])->name('dashboards.system-manager');

Route::get('/dashboards/system-admin', function () {
    abort_unless(request()->user()->isSystemAdmin(), 403);

    return view('dashboards.persona', [
        'title' => 'System Admin Dashboard',
        'subtitle' => 'System/admin/support operation untuk setup, access, configuration, dan provider visibility.',
        'scope' => 'System setup, admin support, access support, dan AI provider visibility',
        'stats' => [
            'Businesses configured' => Business::query()->count(),
            'Branches configured' => Branch::query()->count(),
            'Users configured' => User::query()->count(),
            'Branches without manager' => Branch::query()->whereNull('manager_user_id')->count(),
        ],
        'links' => [
            'Business setup' => route('businesses.index'),
            'Create business' => route('businesses.create'),
        ],
        'linksTitle' => 'Admin Links',
        'aiProviderStatus' => app(AiProviderManager::class)->status(),
    ]);
})->middleware(['auth', 'verified'])->name('dashboards.system-admin');

Route::get('/dashboards/internal', function () {
    abort_unless(request()->user()->hasInternalCombinedAccess(), 403);

    return view('dashboards.persona', [
        'title' => 'System Manager / System Admin Dashboard',
        'subtitle' => 'Combined internal dashboard untuk pengguna GOS sahaja.',
        'scope' => 'Platform overview dan system/admin operation',
        'stats' => [
            'Total businesses' => Business::query()->count(),
            'Total branches' => Branch::query()->count(),
            'Users configured' => User::query()->count(),
            'Total check-ins' => CustomerCheckIn::query()->count(),
            'Total feedback' => CustomerFeedback::query()->count(),
        ],
        'links' => [
            'Business setup' => route('businesses.index'),
            'Create business' => route('businesses.create'),
        ],
        'linksTitle' => 'Internal Links',
        'aiProviderStatus' => app(AiProviderManager::class)->status(),
    ]);
})->middleware(['auth', 'verified'])->name('dashboards.internal-combined');

Route::get('/dashboards/business-owner', $businessDashboard)
    ->middleware(['auth', 'verified', 'can:viewAny,'.Business::class])
    ->name('dashboards.business-owner');

Route::get('/dashboards/branch-manager', $businessDashboard)
    ->middleware(['auth', 'verified', 'can:viewAny,'.Business::class])
    ->name('dashboards.branch-manager');

Route::get('/dashboards/business-branch', $businessDashboard)
    ->middleware(['auth', 'verified', 'can:viewAny,'.Business::class])
    ->name('dashboards.business-branch-combined');

Route::get('/customer/portal', [CustomerPortalController::class, 'show'])
    ->middleware(['auth', 'verified'])
    ->name('customer.portal');
Route::post('/customer/check-in', [CustomerPortalController::class, 'checkIn'])
    ->middleware(['auth', 'verified', 'throttle:10,1'])
    ->name('customer.check-in.store');
Route::post('/customer/online-check-in', [CustomerPortalController::class, 'onlineCheckIn'])
    ->middleware(['auth', 'verified', 'throttle:10,1'])
    ->name('customer.online-check-in.store');
Route::get('/customer/rewards', [RewardLoyaltyController::class, 'customerStatus'])
    ->middleware(['auth', 'verified'])
    ->name('customer.rewards');
Route::get('/customer/feedback', [CustomerFeedbackController::class, 'customerIndex'])
    ->middleware(['auth', 'verified'])
    ->name('customer.feedback');
Route::post('/customer/feedback', [CustomerFeedbackController::class, 'customerStore'])
    ->middleware(['auth', 'verified', 'throttle:10,1'])
    ->name('customer.feedback.store');

Route::get('/b/{business:slug}', [PublicBusinessRegistrationController::class, 'show'])->name('public.business.show');
Route::get('/b/{business:slug}/feedback', [CustomerFeedbackController::class, 'show'])->name('public.business.feedback');
Route::post('/b/{business:slug}/feedback', [CustomerFeedbackController::class, 'store'])
    ->middleware('throttle:10,1')
    ->name('public.business.feedback.store');
Route::get('/b/{business:slug}/feedback/thanks', [CustomerFeedbackController::class, 'success'])->name('public.business.feedback.success');
Route::post('/b/{business:slug}/register', [PublicBusinessRegistrationController::class, 'store'])
    ->middleware('throttle:10,1')
    ->name('public.business.register');
Route::post('/b/{business:slug}/check-in', [PublicBusinessRegistrationController::class, 'checkIn'])
    ->middleware('throttle:10,1')
    ->name('public.business.check-in');

Route::middleware('auth')->group(function () {
    Route::get('/businesses', [BusinessController::class, 'index'])->name('businesses.index');
    Route::get('/businesses/create', [BusinessController::class, 'create'])->name('businesses.create');
    Route::post('/businesses', [BusinessController::class, 'store'])->name('businesses.store');
    Route::get('/businesses/{business}/dashboard', [BusinessController::class, 'dashboard'])->name('businesses.dashboard');
    Route::get('/businesses/{business}/product-services', [ProductServiceController::class, 'index'])->name('businesses.product-services.index');
    Route::get('/businesses/{business}/product-services/create', [ProductServiceController::class, 'create'])->name('businesses.product-services.create');
    Route::post('/businesses/{business}/product-services', [ProductServiceController::class, 'store'])->name('businesses.product-services.store');
    Route::get('/businesses/{business}/product-services/{productService}/edit', [ProductServiceController::class, 'edit'])->name('businesses.product-services.edit');
    Route::patch('/businesses/{business}/product-services/{productService}', [ProductServiceController::class, 'update'])->name('businesses.product-services.update');
    Route::delete('/businesses/{business}/product-services/{productService}', [ProductServiceController::class, 'destroy'])->name('businesses.product-services.destroy');
    Route::get('/businesses/{business}/branches/create', [BranchController::class, 'create'])->name('businesses.branches.create');
    Route::post('/businesses/{business}/branches', [BranchController::class, 'store'])->name('businesses.branches.store');
    Route::get('/businesses/{business}/branches/{branch}', [BranchController::class, 'show'])->name('businesses.branches.show');
    Route::patch('/businesses/{business}/branches/{branch}/check-in-cooldown', [BranchController::class, 'updateCooldown'])->name('businesses.branches.cooldown.update');
    Route::get('/businesses/{business}/branches/{branch}/check-ins', [CustomerCheckInController::class, 'branchIndex'])->name('businesses.branches.check-ins');
    Route::post('/businesses/{business}/branches/{branch}/online-check-ins', [CustomerCheckInController::class, 'storeOnlineReference'])->name('businesses.branches.online-check-ins.store');
    Route::post('/businesses/{business}/branches/{branch}/check-ins/{checkIn}/product-services', [CheckInProductServiceController::class, 'store'])->name('businesses.branches.check-ins.product-services.store');
    Route::patch('/businesses/{business}/branches/{branch}/check-ins/{checkIn}/no-purchase', [CheckInProductServiceController::class, 'noPurchase'])->name('businesses.branches.check-ins.no-purchase');
    Route::get('/businesses/{business}/branches/{branch}/feedback', [CustomerFeedbackController::class, 'branchIndex'])->name('businesses.branches.feedback');
    Route::patch('/businesses/{business}/branches/{branch}/feedback/{feedback}/status', [CustomerFeedbackController::class, 'updateStatus'])->name('businesses.branches.feedback.status.update');
    Route::get('/businesses/{business}/branches/{branch}/rewards', [RewardLoyaltyController::class, 'branchIndex'])->name('businesses.branches.rewards.index');
    Route::post('/businesses/{business}/branches/{branch}/rewards/{customer}/redeem', [RewardLoyaltyController::class, 'redeem'])->name('businesses.branches.rewards.redeem');
    Route::get('/businesses/{business}/branches/{branch}/edit', [BranchController::class, 'edit'])->name('businesses.branches.edit');
    Route::patch('/businesses/{business}/branches/{branch}', [BranchController::class, 'update'])->name('businesses.branches.update');
    Route::get('/businesses/{business}/check-ins', [CustomerCheckInController::class, 'businessIndex'])->name('businesses.check-ins');
    Route::get('/businesses/{business}/rewards', [RewardLoyaltyController::class, 'businessIndex'])->name('businesses.rewards.index');
    Route::get('/businesses/{business}/follow-ups', [BusinessController::class, 'followUps'])->name('businesses.follow-ups');
    Route::get('/businesses/{business}/feedback', [CustomerFeedbackController::class, 'index'])->name('businesses.feedback');
    Route::get('/businesses/{business}/reports/weekly', [WeeklyGrowthReportController::class, 'show'])->name('businesses.reports.weekly');
    Route::get('/businesses/{business}/customers', [BusinessController::class, 'customers'])->name('businesses.customers.index');
    Route::get('/businesses/{business}/customers/{customer}', [BusinessController::class, 'customerShow'])->name('businesses.customers.show');
    Route::get('/businesses/{business}', [BusinessController::class, 'show'])->name('businesses.show');
    Route::get('/businesses/{business}/edit', [BusinessController::class, 'edit'])->name('businesses.edit');
    Route::patch('/businesses/{business}', [BusinessController::class, 'update'])->name('businesses.update');
    Route::get('/businesses/{business}/loyalty', [BusinessController::class, 'editLoyalty'])->name('businesses.loyalty.edit');
    Route::patch('/businesses/{business}/loyalty', [BusinessController::class, 'updateLoyalty'])->name('businesses.loyalty.update');
    Route::post('/businesses/{business}/customers/{customer}/redeem', [BusinessController::class, 'redeem'])->name('businesses.customers.redeem');

    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
});

require __DIR__.'/auth.php';
