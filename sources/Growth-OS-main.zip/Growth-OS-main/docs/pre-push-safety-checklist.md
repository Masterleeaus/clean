# Pre-Push Safety Checklist

Run this before pushing F&B Growth Core to a private GitHub repository.

## Required Commands

```bash
php artisan test
php vendor/bin/pint
npm run build
php artisan route:list
php artisan migrate:status
```

On Windows from this project path:

```powershell
php vendor\bin\pint
```

## Git Safety Checks

Confirm `.env` is ignored:

```bash
git check-ignore -v .env
git ls-files .env
```

Expected:

- `git check-ignore` shows the ignore rule.
- `git ls-files .env` prints nothing.

Confirm SQLite database is ignored:

```bash
git check-ignore -v database/database.sqlite
git ls-files database/database.sqlite
```

Expected:

- SQLite database is ignored.
- `git ls-files database/database.sqlite` prints nothing.

Review staged files:

```bash
git status --short
git diff --cached --name-only
```

## Must Not Be Staged

- `.env`
- `database/*.sqlite`
- `storage/logs/*.log`
- `storage/app/backups/*`
- `vendor/`
- `node_modules/`
- `public/build/`
- API keys.
- Mailtrap credentials.
- Database passwords.
- App keys.
- Real customer data exports.

## Auth Safeguard Checks

Public owner registration must stay disabled:

```bash
php artisan route:list --path=register
```

Expected: only public customer route:

```text
POST b/{business:slug}/register
```

Profile self-deletion must stay disabled:

```bash
php artisan route:list --path=profile
```

Expected:

```text
GET profile
PATCH profile
```

No `DELETE profile`.

## Demo Password Warning

Seeded accounts use demo password:

```text
password
```

Before real FAP pilot data:

- Create supervised owner with `php artisan users:create-owner`.
- Change demo passwords.
- Do not share seeded demo credentials externally.

## Final Push Check

Run:

```bash
git status --short
git diff --cached --name-only
```

Only push when no secrets, database files, logs, generated dependencies, or backups are staged.

