# Skrip Ujian Customer Lokal Growth OS-F&B

Dokumen ini untuk menguji pengalaman customer dari public QR link secara lokal. Web server dan database adalah KIV. Ujian ini tidak memerlukan login owner kecuali untuk semakan hasil di dashboard.

## Persediaan Lokal

Jalankan dari folder F&B Growth:

```powershell
composer install
npm install
Copy-Item .env.example .env -Force
php artisan key:generate
New-Item -ItemType File -Force .\database\database.sqlite
php artisan migrate:fresh --seed
```

Jalankan server:

```powershell
php artisan serve
```

Jalankan Vite:

```powershell
npm run dev
```

URL customer:

```text
http://127.0.0.1:8000/b/wanchu-corner
http://127.0.0.1:8000/b/wanchu-corner/feedback
http://127.0.0.1:8000/b/restoran-che-na
http://127.0.0.1:8000/b/restoran-che-na/feedback
```

## 1. Buka Public QR Link

Langkah:

1. Buka browser private/incognito.
2. Pergi ke `http://127.0.0.1:8000/b/wanchu-corner`.

Keputusan dijangka:

- Halaman public WanChu Corner dibuka tanpa login.
- Reward offer dipaparkan.
- Borang Returning customer dan New customer dipaparkan.
- Link `Share Feedback` dipaparkan.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 2. Customer Registration

Langkah:

1. Pada borang New customer, isi:
   - Name: `Aina Test`
   - WhatsApp Number: `60111110001`
   - Birthday: `1995-01-15`
   - Tick consent promo
2. Klik `Register`.

Keputusan dijangka:

- Halaman status dipaparkan.
- Paparan `Hi, Aina Test!`.
- Stamps menunjukkan `1 / 8`.
- Reward menunjukkan `Free drink`.
- Mesej welcome stamp dipaparkan.
- Link `Share Feedback` dan `Back` dipaparkan.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 3. Registration Customer Sama

Langkah:

1. Klik `Back`.
2. Isi borang New customer sekali lagi:
   - Name: `Aina Test Duplicate`
   - WhatsApp Number: `60111110001`
3. Klik `Register`.

Keputusan dijangka:

- Sistem mengenal pasti customer sudah berdaftar.
- Tiada welcome stamp tambahan diberikan.
- Stamp tidak bertambah secara tidak sah.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 4. Returning Customer Check-In

Langkah:

1. Buka `http://127.0.0.1:8000/b/wanchu-corner`.
2. Pada Returning customer, masukkan:
   - WhatsApp Number: `60111110001`
3. Klik `Check-in Today`.

Keputusan dijangka:

- Jika customer sudah mendapat welcome/check-in pada hari yang sama, sistem tidak menambah stamp kedua.
- Mesej already checked-in atau already registered dipaparkan.
- Stamp kekal pada nilai yang betul.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 5. Check-In Dengan Nombor Tidak Berdaftar

Langkah:

1. Buka `http://127.0.0.1:8000/b/wanchu-corner`.
2. Pada Returning customer, masukkan:
   - WhatsApp Number: `60111119999`
3. Klik `Check-in Today`.

Keputusan dijangka:

- Sistem memaparkan validation error.
- Customer diminta daftar dahulu.
- Tiada customer atau stamp palsu diwujudkan.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 6. Customer Feedback

Langkah:

1. Buka `http://127.0.0.1:8000/b/wanchu-corner/feedback`.
2. Isi:
   - WhatsApp Number: `60111110001`
   - Food Rating: `5`
   - Service Rating: `4`
   - Price Feedback: `OK`
   - Comment: `Makanan sedap, servis laju.`
3. Klik `Submit Feedback`.

Keputusan dijangka:

- Halaman terima kasih dipaparkan.
- Customer boleh kembali ke public page.
- Feedback boleh dilihat oleh owner pada halaman Feedback.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 7. Feedback Tanpa WhatsApp

Langkah:

1. Buka `http://127.0.0.1:8000/b/wanchu-corner/feedback`.
2. Biarkan WhatsApp kosong.
3. Isi:
   - Food Rating: `3`
   - Service Rating: `3`
   - Price Feedback: `Expensive`
   - Comment: `Portion boleh diperbaiki.`
4. Klik `Submit Feedback`.

Keputusan dijangka:

- Feedback anonymous diterima.
- Owner view memaparkan customer sebagai Anonymous.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 8. Reward Eligibility Customer View

Nota lokal: Seeded WanChu memerlukan 8 stamps. Untuk demo cepat, owner boleh guna UI `Edit Loyalty` dan set `Stamps Required` kepada `1` secara lokal sahaja.

Langkah selepas owner set threshold kepada `1`:

1. Buka `http://127.0.0.1:8000/b/wanchu-corner`.
2. Daftar customer baru:
   - Name: `Eligible Customer`
   - WhatsApp Number: `60111110008`
   - Tick consent promo
3. Klik `Register`.

Keputusan dijangka:

- Halaman status menunjukkan `1 / 1`.
- Mesej eligible reward dipaparkan.
- Arahan show screen to staff/owner dipaparkan.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 9. Selepas Reward Redemption

Prasyarat:

- Owner redeem reward untuk `Eligible Customer`.

Langkah:

1. Customer buka semula `http://127.0.0.1:8000/b/wanchu-corner`.
2. Masukkan WhatsApp `60111110008` pada Returning customer.
3. Klik `Check-in Today`.

Keputusan dijangka:

- Jika redemption sudah dibuat, current stamps customer telah reset ke `0`.
- Same-day duplicate check-in masih dikawal.
- Untuk ujian hari lain, stamp baharu hanya patut bertambah sekali sehari.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## Verification

Jalankan selepas sesi customer test:

```powershell
php artisan test
npm run build
php artisan route:list
```

Keputusan dijangka:

- Test suite lulus.
- Build berjaya.
- Route list keluar tanpa error.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

