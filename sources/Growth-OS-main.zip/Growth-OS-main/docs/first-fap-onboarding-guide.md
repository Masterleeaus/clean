# First FAP Onboarding Guide

This guide is for onboarding the first Founding Advisory Partner into the supervised staging pilot.

## Pilot Positioning

Explain clearly:

- This is a controlled staging pilot.
- The goal is to test loyalty, check-in, feedback, and owner workflow.
- WhatsApp follow-up is manual only.
- QR is currently a public link, not a generated QR image.
- No payment, POS, inventory, staff roles, AI, or automated messaging is included yet.

## Before The Session

- Confirm the business name, owner name, and owner WhatsApp number.
- Confirm the reward offer and stamps required.
- Create or update the owner account.
- Change any seeded demo passwords.
- Prepare the public QR URL:

```text
/b/{business-slug}
```

- Open the owner dashboard on a laptop.
- Open the public customer page on a phone.

## Creating The Owner Account

Use the supervised artisan command:

```bash
php artisan users:create-owner --name="Owner Name" --email="owner@example.com" --password="temporary-strong-password"
```

Then ask the owner to log in and change the password from Profile.

Do not enable public owner registration.

## Owner Walkthrough

1. Log in.
2. Open Businesses.
3. Open the business dashboard.
4. Show the public QR link.
5. Open Customers.
6. Open Follow-ups.
7. Open Feedback.
8. Open Weekly Report.
9. Open Business Detail.
10. Show where eligible rewards are verified.

## Customer Walkthrough

1. Customer opens the public QR link.
2. Customer registers with name and WhatsApp number.
3. Customer sees stamp status.
4. Customer submits feedback.
5. Returning customer enters WhatsApp number to check in.
6. Returning customer sees updated stamp status.
7. If eligible, customer shows screen to owner/staff.
8. Owner verifies redemption from authenticated area.

## What To Ask FAP To Test

- Is the QR link easy to explain to customers?
- Do customers understand registration versus check-in?
- Is the reward offer clear?
- Is one check-in per day acceptable?
- Does the owner understand reward verification?
- Are WhatsApp follow-up message templates useful?
- Is feedback form short enough?
- Does the weekly report help decide what to do next?

## What Not To Promise

- Automated WhatsApp messages.
- AI recommendations.
- Email reports.
- QR image generation.
- Staff accounts.
- POS/payment/inventory integration.
- Self-service business signup.
- Production analytics.

## Support Notes

- Record any confusing customer wording.
- Record any owner workflow friction.
- Record reward rules that differ by business.
- Record requests, but avoid changing scope during the first pilot.
- Keep pilot data small and supervised.

