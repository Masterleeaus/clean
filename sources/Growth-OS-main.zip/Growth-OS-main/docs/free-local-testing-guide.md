# Free Local Testing Guide

Use this guide for RM0 testing on a local machine before any cloud staging pilot.

## Requirements

- PHP 8.3+ compatible with this Laravel install.
- Composer.
- Node.js and npm.
- SQLite PHP extension.
- A browser and phone browser for customer-flow checks.

## Initial Setup

From the F&B Growth project directory:

```bash
composer install
npm install
copy .env.example .env
php artisan key:generate
```

On PowerShell, use:

```powershell
Copy-Item .env.example .env
```

## SQLite Setup

Keep local testing simple with SQLite:

```dotenv
DB_CONNECTION=sqlite
DB_DATABASE=database/database.sqlite
QUEUE_CONNECTION=database
SESSION_DRIVER=database
CACHE_STORE=database
```

Create the SQLite file if needed:

```powershell
New-Item -ItemType File -Force .\database\database.sqlite
```

Then migrate and seed:

```bash
php artisan migrate:fresh --seed
```

The seeder prints a warning because demo accounts use the password `password`. Do not use demo passwords with real pilot data.

## Run The App Locally

Start Laravel:

```bash
php artisan serve
```

Default local URL:

```text
http://127.0.0.1:8000
```

## Frontend Assets

For a quick built-asset check:

```bash
npm run build
```

For local development with live rebuild:

```bash
npm run dev
```

If using `npm run dev`, keep the Vite terminal running while browsing the app.

## Mailtrap Or Log Mail

Mail is foundation-ready but not used by current core pilot flows.

For Mailtrap local testing, set:

```dotenv
MAIL_MAILER=smtp
MAIL_HOST=sandbox.smtp.mailtrap.io
MAIL_PORT=2525
MAIL_USERNAME=your_mailtrap_username
MAIL_PASSWORD=your_mailtrap_password
MAIL_FROM_ADDRESS="hello@fbgrowth.local"
MAIL_FROM_NAME="${APP_NAME}"
```

For RM0 local testing without Mailtrap, use log mail:

```dotenv
MAIL_MAILER=log
```

Then inspect `storage/logs/laravel.log` if a mail flow is tested later.

## Owner Login

Seeded local accounts:

```text
admin@fbgrowth.local
owner+wanchu@fbgrowth.local
owner+restoran-che-na@fbgrowth.local
```

Seeded password:

```text
password
```

Change these before entering real pilot data.

## Create A Local Owner Safely

Public owner registration is disabled. Use:

```bash
php artisan users:create-owner --name="Pilot Owner" --email="owner@example.com" --password="temporary-strong-password"
```

## Test Commands

Run:

```bash
php artisan test
php vendor/bin/pint
npm run build
php artisan route:list
php artisan migrate:status
```

On Windows from this project path:

```powershell
php vendor\bin\pint
```

## Local Smoke Test Flow

1. Run `php artisan migrate:fresh --seed`.
2. Run `php artisan serve`.
3. Open `/login`.
4. Log in as `owner+wanchu@fbgrowth.local`.
5. Open `/businesses`.
6. Open WanChu Corner dashboard.
7. Copy the public QR link.
8. Open `/b/wanchu-corner` in another browser or private window.
9. Register a test customer.
10. Confirm stamp status page appears.
11. Return to `/b/wanchu-corner`.
12. Try returning customer check-in with the same WhatsApp number.
13. Confirm duplicate same-day check-in is blocked.
14. Submit feedback at `/b/wanchu-corner/feedback`.
15. In owner area, open Feedback, Follow-ups, and Weekly Report.
16. If using a prepared eligible customer, test reward redemption.

## Local Data Reset

To reset local test data:

```bash
php artisan migrate:fresh --seed
```

Do not run this against staging or real pilot data unless data loss is intended and backups are confirmed.

