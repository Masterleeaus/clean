# FAP Restoran Che Na Pilot Access

Purpose: provide Restoran Che Na with controlled pilot access to review BO, BM, and BO cum BM views, test Product/Service management, and share feedback before a wider controlled pilot.

For Render Free + external MySQL Pre-Test Pilot setup, use `docs/render-free-external-mysql-deployment.md`. Recommended database setup is a clean empty external MySQL database followed by:

```bash
php artisan migrate --force
php artisan db:seed --class=FnbCoreSeeder --force
```

Do not use a local DB clone unless the pilot intentionally needs every local/test row.

## Business And Branch

| Item | Value |
| --- | --- |
| FAP business | Restoran Che Na |
| Main branch | Restoran Che Na - Main Branch |
| Branch code | CHENA-MAIN |
| Pilot password | `password` |
| Access note | Demo/pilot access only for FAP feedback. Change credentials before real customer data is used. |

## Login Table

| Persona | Name | Email/Login ID | Password test | Dashboard/Portal URL | Scope |
| --- | --- | --- | --- | --- | --- |
| System Manager | GOS-F&B System Manager | `manager@gos-fnb.pilot` | `password` | `/dashboards/system-manager` | Platform/GOS strategy, analytics, AI platform |
| System Admin | GOS-F&B System Admin | `admin@gos-fnb.pilot` | `password` | `/dashboards/system-admin` | Admin/support setup/config, AI Provider Status |
| Business Owner | WanChu Corner Owner | `owner+wanchu@gos-fnb.pilot` | `password` | `/dashboards/business-owner` | WanChu owner performance |
| Branch Manager | WanChu Branch Manager | `branch+wanchu@gos-fnb.pilot` | `password` | `/dashboards/branch-manager` | WanChu assigned branch operation |
| BO cum BM | WanChu Owner Branch Combined | `owner-branch+wanchu@gos-fnb.pilot` | `password` | `/dashboards/business-branch` | Business Performance + Branch Operations |
| Customer | GOS-F&B Demo Customer | `customer@gos-fnb.pilot` | `password` | `/customer/portal` | Customer portal, check-in, rewards, feedback |
| Business Owner | Restoran Che Na Owner | `owner+chena@gos-fnb.pilot` | `password` | `/dashboards/business-owner` | Che Na business and branch performance |
| Branch Manager | Restoran Che Na Branch Manager | `branch+chena@gos-fnb.pilot` | `password` | `/dashboards/branch-manager` | Che Na assigned branch operation and Product/Service management |
| BO cum BM | Restoran Che Na Owner Branch Combined | `owner-branch+chena@gos-fnb.pilot` | `password` | `/dashboards/business-branch` | Business Performance + Branch Operations |

Legacy local accounts are kept for regression tests, but pilot-facing docs and handover should use the `gos-fnb.pilot` accounts above.

## Product/Service Dummy Data

Restoran Che Na is seeded with 35 branch-scoped Product/Service records. The catalog is grouped into BM-friendly categories:

| Default Category | Example Items |
| --- | --- |
| Makanan | Nasi Lemak Biasa, Mee Goreng Mamak, Tomyam Ayam |
| Minuman | Teh Ais, Kopi Ais, Milo Ais |
| Set Kombo | Set Lunch Ayam + Air, Set Family Dinner |
| Add-on | Telur Dadar, Ayam Goreng Berempah |

`Lain-lain` is no longer a default category because BM can add a custom category when needed.

Product/Service list pages use category tabs: Semua, Makanan, Minuman, Set Kombo, Add-on, and any custom categories. Each tab shows item counts, and Product/Service items are sorted alphabetically within the selected category. A few intentional review examples are included:

| Review Example | Purpose |
| --- | --- |
| Nasi Lemak Aym | Similar/typo name test |
| Kopi Ice | Similar name test |
| Teh Ais Special at RM0.10 | Suspicious low price test |
| Set Premium Dinner at RM199.90 | Suspicious high price test |
| Nasi Campur Ayam Large | Similar/price review scenario |

## BM Product/Service Management

Branch Manager can view, add, edit, delete, or archive Product/Service records for the assigned branch. Pure BM must select the assigned branch and cannot manage another business or branch. BM can choose an existing category or add a new category when the current options are not enough. Edit Product/Service also allows category changes. If an item has purchase capture history, delete is converted to archive so historical capture data is preserved.

BO cum BM can access Product/Service Management from Branch Operations. Pure BO currently receives review alerts and business performance context; operational clutter is kept out of the BO-only view.

Customer cannot access Product/Service management and cannot self-claim purchase.

## BO Review Alerts

Dashboard section: `Product/Service Review Alerts`.

Alerts are created for duplicate/similar names, suspicious low/high price, large price changes, and archive of an item already used in purchase capture history. Alerts are scoped to the BO's own business and show item name, issue type, actor, suggested review, and created time.

When BM creates a new custom category, a `new_category_created` alert is recorded so BO can confirm whether the category should remain part of branch capture and analytics grouping.

## POS Scope Note

GOS-F&B is not a POS/order/cart/payment system in this step.

For FAPs with an existing POS, use GOS-F&B as the growth, check-in, purchase capture, analytics, AI Insight, and AI Action layer. For FAPs still using manual sales flow, a future GOS POS module can be planned separately; it is not part of this implementation.
