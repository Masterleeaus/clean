# Render Free + External MySQL Deployment

Purpose: prepare GOS-F&B for a controlled Pre-Test Pilot on Render Free with an external managed MySQL database. This is not final production infrastructure.

## Architecture

- Render Web Service using Docker runtime on branch `main`.
- Nginx + PHP-FPM from the repo Docker image.
- External managed MySQL for pilot data.
- Render dashboard environment variables for all secrets and runtime settings.
- Manual migration and seeding after first deploy. No boot-time migration, no auto-seeding, and no `migrate:fresh` deployment flow.

Current project facts:

- Laravel requirement: `laravel/framework` `^13.8`.
- PHP requirement: `^8.3`; Docker runtime uses PHP 8.4 FPM.
- Frontend build: `npm ci` then `npm run build`.
- Docker image includes MySQL support through `pdo_mysql`, plus `mbstring`, `bcmath`, `zip`, `intl`, and `opcache`.
- `FnbCoreSeeder` recreates the pilot accounts, WanChu data, Restoran Che Na FAP data, 35 Che Na Product/Service rows, category tabs, and Product/Service review alerts.

## Render Setup

1. Connect the GitHub repo to Render.
2. Create a new Web Service.
3. Select branch `main`.
4. Set Runtime to Docker.
5. Use instance type Free for this Pre-Test Pilot only.
6. Keep Dockerfile path as `./Dockerfile` and Docker context as `.`.
7. Set health check path to `/up`.
8. Add the environment variables below in Render.
9. Deploy the web service.

Do not create a database from Codex and do not commit `.env`.

## External MySQL Setup

1. Create an empty managed MySQL database with the chosen provider.
2. Save host, port, database name, username, and password privately.
3. Allow trusted access from the machine that will run migrations.
4. Add the MySQL values only in Render environment variables.
5. Use `migrate + seed semula` as the primary Pre-Test Pilot setup.

If the provider requires SSL, keep certificates outside the repo. This Laravel config already supports optional MySQL CA path through `MYSQL_ATTR_SSL_CA`. Set it only if the provider gives a CA file/path and Render has that file available at runtime.

## Render Environment Variables

Use placeholders only until the actual values are added in Render.

```env
APP_NAME=GOS-FNB
APP_ENV=production
APP_KEY=<generate-with-php-artisan-key-generate-show>
APP_DEBUG=false
APP_URL=<render-service-url>

LOG_CHANNEL=stderr
LOG_LEVEL=info

DB_CONNECTION=mysql
DB_HOST=<external-mysql-host>
DB_PORT=3306
DB_DATABASE=<external-mysql-database>
DB_USERNAME=<external-mysql-username>
DB_PASSWORD=<external-mysql-password>
MYSQL_ATTR_SSL_CA=<optional-provider-ca-path-if-required>

CACHE_STORE=file
SESSION_DRIVER=file
QUEUE_CONNECTION=sync

MAIL_MAILER=log
AI_EXTERNAL_ENABLED=false
AI_DEFAULT_PROVIDER=rule_based
AI_FALLBACK_PROVIDER=rule_based
AI_ACTION_MODE=suggestion_only
```

Generate `APP_KEY` locally and paste only the generated value into Render:

```bash
php artisan key:generate --show
```

## Migration And Seed

Render Free web services may not provide shell or one-off jobs. For the Pre-Test Pilot, run these commands from a trusted local/admin terminal that is temporarily configured with the same external MySQL environment values:

```bash
php artisan migrate --force
php artisan db:seed --class=FnbCoreSeeder --force
php artisan optimize:clear
```

Do not run `migrate:fresh` against the external pilot database. Use a clean empty database, then migrate and seed.

## Login Verification

| Persona | Email/Login ID | Password | URL |
| --- | --- | --- | --- |
| System Manager | `manager@gos-fnb.pilot` | `password` | `/dashboards/system-manager` |
| System Admin | `admin@gos-fnb.pilot` | `password` | `/dashboards/system-admin` |
| WanChu BO | `owner+wanchu@gos-fnb.pilot` | `password` | `/dashboards/business-owner` |
| WanChu BM | `branch+wanchu@gos-fnb.pilot` | `password` | `/dashboards/branch-manager` |
| WanChu BO cum BM | `owner-branch+wanchu@gos-fnb.pilot` | `password` | `/dashboards/business-branch` |
| Customer | `customer@gos-fnb.pilot` | `password` | `/customer/portal` |
| Che Na BO | `owner+chena@gos-fnb.pilot` | `password` | `/dashboards/business-owner` |
| Che Na BM | `branch+chena@gos-fnb.pilot` | `password` | `/dashboards/branch-manager` |
| Che Na BO cum BM | `owner-branch+chena@gos-fnb.pilot` | `password` | `/dashboards/business-branch` |

The demo password is pilot-only. Replace it before any real public launch or real customer data use.

## Pre-Test Pilot Checklist

- App opens and `/up` is healthy.
- Login/logout works for all personas.
- System Manager dashboard opens.
- System Admin dashboard opens.
- BO dashboard opens.
- BM branch operation opens.
- BO cum BM has `Business Performance` and `Branch Operations` tabs.
- Customer portal opens.
- Physical Check-in works.
- Online Check-in works.
- Pending Purchase Capture is visible only to BM or BO cum BM.
- Capture Purchase works.
- Mark No Purchase works.
- Reward/stamp appears after valid capture.
- No reward appears after no-purchase flow.
- Product/Service category tabs work.
- BM can add, edit, delete, and archive Product/Service rows.
- BM can add a custom category.
- BO Product/Service Review Alerts appear.
- Customer feedback works.
- AI Provider Status is visible only to System Admin.
- AI Action remains suggestion-only.

## Known Limitations

- Render Free may sleep, restart, or limit resources.
- Local storage is ephemeral and should not hold pilot data.
- Render Free is not a production SLA.
- Queue worker and scheduler are not configured for production.
- Email should remain `log` or sandbox-only for pilot.
- External MySQL free tiers are not production infrastructure.
- Demo password `password` is pilot-only.

## Troubleshooting

- `APP_KEY` missing: generate with `php artisan key:generate --show` and add it to Render.
- DB connection failed: confirm host, port, database, username, password, provider firewall, and SSL requirement.
- Migration failed: confirm the database is empty, reachable, and uses a compatible MySQL version/collation.
- Asset/build issue: confirm Docker build completed `npm ci` and `npm run build`.
- File permission issue: confirm `storage` and `bootstrap/cache` are writable in the container.
- 500 with `APP_DEBUG=false`: review Render logs without printing secrets.
- Session/CSRF issue: confirm `APP_URL`, `SESSION_DRIVER=file`, and browser cookies for the Render domain.

## Optional Local MySQL Clone

Primary pilot setup is still `migrate + seed semula`. Use dump/import only if the goal is to clone every local row, including local/test/dirty data.

```bash
mysqldump --host=<local-mysql-host> --port=<local-mysql-port> --user=<local-mysql-username> --password <local-mysql-database> > gos-fnb-local.sql
mysql --host=<external-mysql-host> --port=3306 --user=<external-mysql-username> --password <external-mysql-database> < gos-fnb-local.sql
```

Keep dump files private, delete them after verified import, and never commit them.
