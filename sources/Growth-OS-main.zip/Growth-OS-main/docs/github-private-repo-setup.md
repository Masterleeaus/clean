# GitHub Private Repository Setup

Use this guide to push the standalone F&B Growth Core Laravel app to a private GitHub repository for Laravel Cloud deployment.

## 1. Create Private GitHub Repository

1. Open GitHub.
2. Create a new repository.
3. Repository visibility: **Private**.
4. Recommended repository name: `fbgrowth-core` or `fbgrowth-os`.
5. Do not initialize with README, `.gitignore`, or license if this local project already contains those files.
6. Copy the GitHub remote URL.

## 2. Confirm Project Folder

Run commands from the standalone F&B Growth directory only.

```powershell
pwd
```

Confirm you are not inside NUSA KING.

## 3. Initialize Git If Missing

Check whether Git is already initialized:

```bash
git status
```

If Git says it is not a repository:

```bash
git init
git branch -M main
```

Branch recommendation: use `main`.

## 4. Confirm Ignore Rules

Before staging files:

```bash
git status --short --ignored
```

Must be ignored:

- `.env`
- `database/*.sqlite`
- `vendor/`
- `node_modules/`
- `public/build/`
- storage logs/cache/generated files
- local editor folders
- backups
- secrets

Confirm `.env` is ignored:

```bash
git check-ignore -v .env
```

Confirm local SQLite is ignored:

```bash
git check-ignore -v database/database.sqlite
```

## 5. Run Pre-Push Safety Checks

```bash
php artisan test
php vendor/bin/pint
npm run build
php artisan route:list
php artisan migrate:status
```

On Windows from this path:

```powershell
php vendor\bin\pint
```

## 6. First Commit

Review files:

```bash
git status --short
```

Stage source files:

```bash
git add .
```

Before committing, confirm no secrets are staged:

```bash
git status --short
git diff --cached --name-only
```

If `.env`, SQLite databases, logs, backups, `vendor`, or `node_modules` appear, stop and fix `.gitignore`.

Commit:

```bash
git commit -m "Prepare F&B Growth Core for staging pilot"
```

## 7. Push To GitHub

Add remote:

```bash
git remote add origin https://github.com/YOUR_ORG_OR_USER/YOUR_PRIVATE_REPO.git
```

Push:

```bash
git push -u origin main
```

## What Must Never Be Committed

- `.env`
- Real Mailtrap credentials.
- Database passwords.
- App keys.
- API keys.
- Production/staging database dumps.
- `database/*.sqlite`
- `storage/app/backups/*`
- `storage/logs/*.log`
- `vendor/`
- `node_modules/`
- Personal notes containing credentials.

## How To Confirm `.env` Is Not Committed

Before push:

```bash
git ls-files .env
```

Expected output: nothing.

Also check:

```bash
git status --short
git check-ignore -v .env
```

If `.env` was accidentally committed, stop and remove it from Git history before pushing.

## Founder Next Commands

```bash
git init
git branch -M main
git status --short --ignored
git check-ignore -v .env
git check-ignore -v database/database.sqlite
php artisan test
php vendor/bin/pint
npm run build
git add .
git diff --cached --name-only
git commit -m "Prepare F&B Growth Core for staging pilot"
git remote add origin https://github.com/YOUR_ORG_OR_USER/YOUR_PRIVATE_REPO.git
git push -u origin main
```

