# Senarai Semak Validasi Pilot Lokal Growth OS-F&B

Dokumen ini untuk mengesahkan aplikasi Growth OS-F&B secara lokal sebelum keputusan akhir web server dan database. Web server dan database adalah KIV. Untuk ujian lokal sahaja, gunakan `php artisan serve`, Vite dev server, dan SQLite lokal.

## Skop

- Aplikasi standalone Laravel dalam folder F&B Growth sahaja.
- Jangan sentuh NUSA KING.
- Dokumentasi dan validasi sahaja.
- Tiada perubahan fitur, business logic, auth safeguards, migrations, atau integrasi luar.

## Akaun Seeded

Semua akaun demo seeded menggunakan password:

```text
password
```

| Peranan | Email | Akses |
|---|---|---|
| Admin | `admin@fbgrowth.local` | Semua bisnes |
| Owner | `owner+wanchu@fbgrowth.local` | WanChu Corner |
| Owner | `owner+restoran-che-na@fbgrowth.local` | Restoran Che Na |

Nota keselamatan: Jangan guna password demo atau data pelanggan sebenar untuk pilot live.

## Setup Lokal Bersih

Jalankan dari folder projek F&B Growth:

```powershell
composer install
npm install
Copy-Item .env.example .env -Force
php artisan key:generate
New-Item -ItemType File -Force .\database\database.sqlite
php artisan migrate:fresh --seed
```

Pastikan `.env` lokal menggunakan SQLite:

```dotenv
DB_CONNECTION=sqlite
DB_DATABASE=database/database.sqlite
SESSION_DRIVER=database
QUEUE_CONNECTION=database
CACHE_STORE=database
```

Keputusan dijangka:

- Dependencies PHP dan npm tersedia.
- `.env` wujud.
- `APP_KEY` dijana.
- Database SQLite lokal wujud.
- Seeder selesai dan memaparkan amaran password demo.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Jalankan Aplikasi Lokal

Terminal 1:

```powershell
php artisan serve
```

Terminal 2:

```powershell
npm run dev
```

URL lokal utama:

```text
http://127.0.0.1:8000
http://127.0.0.1:8000/login
http://127.0.0.1:8000/businesses
http://127.0.0.1:8000/b/wanchu-corner
http://127.0.0.1:8000/b/wanchu-corner/feedback
http://127.0.0.1:8000/b/restoran-che-na
http://127.0.0.1:8000/b/restoran-che-na/feedback
```

Keputusan dijangka:

- `php artisan serve` menunjukkan server berjalan pada `http://127.0.0.1:8000`.
- `npm run dev` menunjukkan Vite berjalan.
- `/login` boleh dibuka.
- Public customer page boleh dibuka tanpa login.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Owner/Admin Login Flow

1. Buka `http://127.0.0.1:8000/login`.
2. Login sebagai `owner+wanchu@fbgrowth.local` dengan password `password`.
3. Buka `http://127.0.0.1:8000/businesses`.
4. Pastikan hanya WanChu Corner muncul untuk owner WanChu.
5. Logout.
6. Login sebagai `admin@fbgrowth.local` dengan password `password`.
7. Buka `http://127.0.0.1:8000/businesses`.
8. Pastikan WanChu Corner dan Restoran Che Na muncul untuk admin.

Keputusan dijangka:

- Owner hanya nampak bisnes sendiri.
- Admin nampak semua bisnes.
- Auth safeguard kekal aktif.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Business Dashboard Flow

1. Login sebagai `owner+wanchu@fbgrowth.local`.
2. Buka `http://127.0.0.1:8000/businesses`.
3. Klik WanChu Corner.
4. Klik `Dashboard`.
5. Semak metrik: Total customers, New customers today, Check-ins today, Repeat customers, Eligible rewards, Rewards redeemed.
6. Salin Public QR Link.

Keputusan dijangka:

- Dashboard WanChu Corner dipaparkan.
- Public QR Link menunjuk kepada `http://127.0.0.1:8000/b/wanchu-corner`.
- Tiada data pelanggan pada database fresh kecuali selepas ujian customer dibuat.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Public QR/Customer Registration Flow

Gunakan browser private/incognito atau browser berbeza.

1. Buka `http://127.0.0.1:8000/b/wanchu-corner`.
2. Isi borang New customer:
   - Name: `Aina Test`
   - WhatsApp Number: `60111110001`
   - Birthday: pilihan
   - Consent promo: tick untuk ujian follow-up
3. Klik `Register`.

Keputusan dijangka:

- Halaman status pelanggan dipaparkan.
- Nama pelanggan dipaparkan.
- Stamp status menjadi `1 / 8`.
- Mesej welcome stamp dipaparkan.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Repeat Check-In Flow

1. Buka semula `http://127.0.0.1:8000/b/wanchu-corner`.
2. Pada Returning customer, masukkan `60111110001`.
3. Klik `Check-in Today`.
4. Ulang langkah yang sama sekali lagi pada hari yang sama.

Keputusan dijangka:

- Untuk pelanggan yang sudah daftar hari ini, sistem tidak memberi stamp tambahan pada hari yang sama.
- Mesej `Your check-in for today has already been recorded.` atau mesej already registered dipaparkan.
- Stamp kekal terkawal dan tidak bertambah berulang kali pada hari yang sama.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Reward Eligibility Flow

Nota lokal: Program seeded WanChu memerlukan 8 stamps. Oleh sebab check-in hari yang sama disekat, untuk demo cepat lokal gunakan UI sedia ada sahaja:

1. Login sebagai `owner+wanchu@fbgrowth.local`.
2. Buka WanChu Corner.
3. Klik `Edit Loyalty`.
4. Catat nilai asal:
   - Program: WanChu Repeat Rewards
   - Stamps Required: `8`
   - Reward: Free drink
5. Tukar `Stamps Required` kepada `1`.
6. Simpan.
7. Buka `http://127.0.0.1:8000/b/wanchu-corner` dalam browser customer.
8. Daftar customer baru:
   - Name: `Eligible Test`
   - WhatsApp Number: `60111110008`
   - Consent promo: tick
9. Semak halaman status.

Keputusan dijangka:

- Pelanggan mendapat `1 / 1`.
- Mesej eligible reward dipaparkan.
- Owner boleh nampak pelanggan dalam senarai Eligible Customers.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Reward Redemption Flow

1. Login sebagai `owner+wanchu@fbgrowth.local`.
2. Buka `http://127.0.0.1:8000/businesses`.
3. Buka WanChu Corner.
4. Pada bahagian Eligible Customers, cari `Eligible Test`.
5. Klik `Redeem`.

Keputusan dijangka:

- Mesej `Reward redemption verified.` dipaparkan.
- Pelanggan masuk ke Redemption History.
- Current stamps pelanggan reset kepada `0`.
- Rewards redeemed bertambah.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Customer Feedback Flow

1. Buka `http://127.0.0.1:8000/b/wanchu-corner/feedback`.
2. Isi:
   - WhatsApp Number: `60111110001`
   - Food Rating: `5`
   - Service Rating: `5`
   - Price Feedback: `OK`
   - Comment: `Sedap dan servis cepat.`
3. Klik `Submit Feedback`.
4. Login owner dan buka Feedback.

Keputusan dijangka:

- Customer melihat halaman terima kasih.
- Owner melihat feedback terkini dan ringkasan rating.
- Feedback dipadankan kepada customer jika nombor WhatsApp sepadan.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Weekly Report Flow

1. Login owner.
2. Buka WanChu Corner.
3. Klik `Weekly Report`.
4. Semak metrik mingguan.
5. Klik `Copy Summary`.

Keputusan dijangka:

- Weekly Growth Report dipaparkan.
- Metrik customer, check-in, redemption, dan feedback dikira.
- Copy Summary tersedia untuk disalin manual.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Manual WhatsApp Follow-Up Flow

1. Login owner.
2. Buka WanChu Corner.
3. Klik `Follow-ups`.
4. Semak kumpulan Dormant Customers, New Customers, Reward-Near Customers, Eligible Reward Customers.
5. Klik `Copy Message` pada salah satu customer jika ada.
6. Klik `Open WhatsApp` hanya untuk semakan URL. Jangan hantar mesej sebenar semasa ujian tanpa kebenaran.

Keputusan dijangka:

- Halaman menyatakan follow-up adalah manual sahaja.
- Tiada mesej dihantar automatik.
- Message template boleh disalin.
- WhatsApp URL dibuka secara manual jika nombor valid.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Reset Data Lokal

Untuk ulang ujian dari kosong:

```powershell
php artisan migrate:fresh --seed
```

Keputusan dijangka:

- Semua data ujian lokal dipadam.
- Data seeded admin, owner, business, dan loyalty program diwujudkan semula.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

## Verification Commands

Jalankan sebelum menutup sesi validasi:

```powershell
php artisan test
npm run build
php artisan route:list
```

Keputusan dijangka:

- Test suite lulus.
- Build assets berjaya.
- Route list keluar tanpa error.

Status:

- [ ] Pass
- [ ] Fail

Catatan isu:

```text

```

