# AI Provider Architecture

GOS-F&B MVP uses a free-tier/free-model external AI provider chain with internal rule-based AI as the safety fallback.

## Priority Chain

1. OpenAI - future provider, disabled by default.
2. Gemini - default external provider for MVP when configured.
3. Groq - external fallback.
4. OpenRouter - external fallback.
5. Rule-based AI - internal safety fallback.

The provider manager reads `config/ai.php` and environment placeholders from `.env.example`. No API key is committed.

## Failure Handling

External providers can fail because an API key is missing, the provider is disabled, quota is exhausted, a timeout happens, the provider returns an error, or the response is invalid. The manager skips unavailable providers, tries the next provider in order, and falls back to rule-based AI if needed.

In local testing without API keys, AI Insight and AI Action still return meaningful rule-based output.

## System Admin Visibility

System Admin can see provider status without secrets:

- Configured priority chain.
- Active/default provider.
- Last used provider.
- Fallback used or not.
- External AI enabled/disabled.
- Provider status such as `Configured`, `Missing key`, or `Disabled`.
- AI Action mode: `Suggestion Only`.

API keys, tokens, prompts, and sensitive customer data are not displayed.

## AI Action Safety

AI Action remains suggestion-only. The system does not auto-send messages, auto-execute campaigns, or auto-change reward/stamp/data.

## Tests

Tests use Laravel HTTP fake/mock responses and do not call real external APIs.
