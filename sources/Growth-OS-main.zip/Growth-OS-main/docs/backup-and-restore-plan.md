# Backup And Restore Plan

This plan covers the first supervised FAP staging pilot.

## Backup Goals

- Prevent loss of pilot customer, stamp, redemption, feedback, and business data.
- Keep backups simple enough to run manually before and after pilot sessions.
- Avoid adding new infrastructure before the first supervised pilot.

## SQLite Backup

If staging uses SQLite, back up the database file before and after every pilot session.

Default local database path:

```text
database/database.sqlite
```

Manual backup example:

```powershell
Copy-Item .\database\database.sqlite .\storage\app\backups\database-YYYY-MM-DD-HHMM.sqlite
```

Create the backup directory first if needed:

```powershell
New-Item -ItemType Directory -Force .\storage\app\backups
```

Restore example:

```powershell
Copy-Item .\storage\app\backups\database-YYYY-MM-DD-HHMM.sqlite .\database\database.sqlite
php artisan migrate:status
```

## MySQL Backup

If staging uses MySQL, take a dump before and after pilot sessions.

Backup example:

```bash
mysqldump -u DB_USERNAME -p DB_DATABASE > storage/app/backups/fbgrowth-YYYY-MM-DD-HHMM.sql
```

Restore example:

```bash
mysql -u DB_USERNAME -p DB_DATABASE < storage/app/backups/fbgrowth-YYYY-MM-DD-HHMM.sql
php artisan migrate:status
```

## Backup Timing

- Before `migrate:fresh --seed`.
- Immediately before FAP testing starts.
- Immediately after FAP testing ends.
- Before any manual database edits.
- Before deployment changes.

## What To Back Up

- Database.
- `.env` values stored securely outside the repository.
- Any uploaded files if file uploads are added later.

Current MVP has no customer-uploaded files.

## What Not To Do

- Do not run `php artisan migrate:fresh --seed` after real pilot data exists unless data loss is intentional and a backup has been confirmed.
- Do not store backups in public web directories.
- Do not commit backups to Git.
- Do not share backups over public links.

## Restore Validation

After restoring:

```bash
php artisan migrate:status
php artisan test
php artisan route:list
```

Then manually confirm:

- Owner can log in.
- Businesses are present.
- Customers are present.
- Loyalty accounts and stamp balances are present.
- Check-ins are present.
- Reward redemptions are present.
- Feedback is present.

## Staging Blockers

Before real pilot data, resolve:

- No backup location chosen.
- No responsible person assigned to run backups.
- Seeded demo passwords still active.
- Staging database location unknown.
- `.env` not backed up securely.

