# FAP Pilot Test Checklist

Use this checklist for a controlled pilot walkthrough with one business at a time.

## Pre-Pilot Setup

- Confirm `.env` is not committed or shared publicly.
- Confirm `APP_ENV` and database connection are correct for the pilot environment.
- Confirm Mailtrap placeholders are set if password reset or future email testing is needed.
- Run `php artisan migrate:fresh --seed`.
- Confirm seeded/admin-provided owner accounts can log in.
- Change seeded demo passwords before using real pilot customer data.
- Confirm public owner registration is disabled at `/register`.
- Confirm account deletion is not visible on `/profile`.
- Confirm the public QR URL opens on a mobile phone.

## Owner Flow

- Log in as a WanChu Corner owner.
- Open `/businesses`.
- Confirm only WanChu Corner is visible to that owner.
- Open business dashboard.
- Confirm totals, QR link, recent check-ins, and recent redemptions load.
- Open business detail.
- Confirm business profile, loyalty program, activity summary, eligible customers, and redemption history.
- Edit business profile.
- Confirm required validation works for name, slug, owner name, WhatsApp, and business type.
- Edit loyalty program.
- Confirm stamps required and reward name validation works.

## Customer Registration Flow

- Open the public QR URL `/b/wanchu-corner`.
- Register a new customer with name and WhatsApp number.
- Confirm success/status page appears.
- Confirm welcome stamp is granted when enabled.
- Register the same WhatsApp number again.
- Confirm no duplicate customer is created and no second welcome stamp is added.
- Register the same WhatsApp number under another business.
- Confirm it is allowed.

## Customer Check-In Flow

- Open `/b/wanchu-corner`.
- Enter an existing customer WhatsApp number in returning customer check-in.
- Confirm one stamp is added.
- Try checking in the same customer again on the same day.
- Confirm no second stamp is added.
- Try checking in a WhatsApp number that does not exist.
- Confirm the customer is asked to register first.

## Reward Redemption Flow

- Create or use a customer with enough stamps for reward eligibility.
- Confirm public status page says the customer is eligible.
- Log in as the business owner.
- Open business detail.
- Find eligible customer.
- Click Redeem.
- Confirm redemption history is created.
- Confirm current stamps reset to 0.
- Confirm total stamps earned does not reset.
- Confirm total rewards redeemed increments.

## Manual WhatsApp Follow-Up Flow

- Open business dashboard.
- Click Follow-ups.
- Confirm dormant customers section loads.
- Confirm new customers section loads.
- Confirm near-reward customers section loads.
- Confirm eligible reward customers section loads.
- Confirm Open WhatsApp uses a `wa.me` link.
- Confirm Copy Message copies or exposes the generated message for manual copy.

## Feedback Flow

- Open `/b/wanchu-corner/feedback`.
- Submit anonymous feedback.
- Confirm thank-you page appears.
- Submit feedback with an existing WhatsApp number.
- Confirm owner feedback page shows matched customer name.
- Submit feedback with a non-matching WhatsApp number.
- Confirm it remains anonymous.
- Open owner feedback page.
- Confirm latest feedback and summary counts/averages are visible.

## Weekly Report Flow

- Open business dashboard.
- Click Weekly Report.
- Confirm weekly metrics load.
- Confirm feedback summary loads.
- Confirm suggestions load.
- Confirm Copy Summary block is present.
- Confirm report is scoped to the selected business.

## Access Control Checks

- Log in as WanChu owner.
- Try opening Restoran Che Na dashboard.
- Confirm access is forbidden.
- Try opening Restoran Che Na customers page.
- Confirm access is forbidden.
- Try opening Restoran Che Na feedback/follow-up/report pages.
- Confirm access is forbidden.
- Log in as admin.
- Confirm admin can view both businesses.

## Do Not Test Or Promise Yet

- Automated WhatsApp sending.
- AI-generated recommendations.
- Scheduled weekly emails.
- QR image generation.
- Staff accounts.
- POS/payment/inventory.
- Production analytics dashboards.

## Pass Criteria

- Owner can complete login, dashboard review, customer lookup, redemption, feedback review, follow-up review, and weekly report review.
- Customer can complete registration, check-in, duplicate check-in handling, and feedback submission on mobile.
- Owner cannot access another owner business.
- Public owner self-registration remains disabled.
- Account self-deletion remains disabled.
- Full test suite passes.

