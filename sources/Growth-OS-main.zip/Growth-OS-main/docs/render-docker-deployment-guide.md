# Render Docker Deployment Guide

Use `docs/render-free-external-mysql-deployment.md` as the authoritative guide for the current Pre-Test Pilot deployment.

Current decision:

- Runtime: Render Docker Web Service.
- Instance: Free for controlled Pre-Test Pilot only.
- Database: external managed MySQL, not SQLite/local DB.
- Data setup: manual `php artisan migrate --force` then `php artisan db:seed --class=FnbCoreSeeder --force`.
- No `.env` commit, no hardcoded database credentials, no boot-time migrations, no auto-seeding.

Docker files in this repo:

- `Dockerfile`
- `.dockerignore`
- `docker/render-start.sh`
- `docker/nginx.conf.template`
- `docker/supervisord.conf`
- `docker/php/opcache.ini`
- optional `render.yaml`

The Docker image builds Composer dependencies and Vite assets, serves Laravel through Nginx/PHP-FPM, binds Nginx to Render `$PORT`, and keeps `storage` plus `bootstrap/cache` writable.

For full Render setup, external MySQL variables, migration/seed guidance, pilot login table, checklist, limitations, troubleshooting, and optional MySQL dump/import fallback, see:

```text
docs/render-free-external-mysql-deployment.md
```
