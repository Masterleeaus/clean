# Skrip Ujian Owner Lokal Growth OS-F&B

Dokumen ini ialah skrip langkah demi langkah untuk founder atau owner menguji bahagian admin/owner secara lokal. Web server dan database masih KIV. Ujian lokal menggunakan `php artisan serve`, `npm run dev`, dan SQLite lokal sementara.

## Persediaan

Jalankan dari folder F&B Growth:

```powershell
composer install
npm install
Copy-Item .env.example .env -Force
php artisan key:generate
New-Item -ItemType File -Force .\database\database.sqlite
php artisan migrate:fresh --seed
```

Pastikan `.env`:

```dotenv
DB_CONNECTION=sqlite
DB_DATABASE=database/database.sqlite
SESSION_DRIVER=database
QUEUE_CONNECTION=database
CACHE_STORE=database
```

Jalankan app:

```powershell
php artisan serve
```

Dalam terminal lain:

```powershell
npm run dev
```

URL:

```text
http://127.0.0.1:8000/login
http://127.0.0.1:8000/businesses
```

## Akaun Login

```text
Owner WanChu: owner+wanchu@fbgrowth.local
Owner Che Na: owner+restoran-che-na@fbgrowth.local
Admin: admin@fbgrowth.local
Password semua: password
```

## 1. Login Owner

Langkah:

1. Buka `http://127.0.0.1:8000/login`.
2. Masukkan email `owner+wanchu@fbgrowth.local`.
3. Masukkan password `password`.
4. Klik `Log in`.
5. Buka `http://127.0.0.1:8000/businesses`.

Keputusan dijangka:

- Login berjaya.
- Senarai bisnes dipaparkan.
- Owner WanChu hanya nampak WanChu Corner.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 2. Semak Business Overview

Langkah:

1. Klik WanChu Corner.
2. Semak Business Profile.
3. Semak QR Check-in Placeholder.
4. Semak Active Loyalty Program.
5. Semak Activity Summary.

Keputusan dijangka:

- Owner, WhatsApp, Type, dan Slug dipaparkan.
- QR link menunjukkan `http://127.0.0.1:8000/b/wanchu-corner`.
- Loyalty Program: `WanChu Repeat Rewards`.
- Reward: `Free drink`.
- Stamps Required: `8`.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 3. Semak Dashboard Operasi

Langkah:

1. Klik `Dashboard`.
2. Semak metrik:
   - Total customers
   - New customers today
   - Check-ins today
   - Repeat customers
   - Eligible rewards
   - Rewards redeemed
3. Salin Public QR Link.

Keputusan dijangka:

- Dashboard boleh dibuka.
- Metrik dipaparkan sebagai nombor.
- Public QR Link boleh digunakan oleh customer tanpa login.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 4. Semak Customer Selepas Registration

Prasyarat:

- Jalankan skrip customer di `docs/local-customer-test-script.md` untuk daftar `Aina Test` dengan WhatsApp `60111110001`.

Langkah:

1. Login sebagai owner.
2. Buka WanChu Corner.
3. Klik `Customers`.
4. Cari `Aina Test` atau `60111110001`.
5. Klik rekod customer.

Keputusan dijangka:

- Customer muncul dalam senarai.
- Profil customer memaparkan WhatsApp, birthday jika diisi, dan consent promo.
- Stamp Progress menunjukkan `1 / 8` untuk program seeded asal.
- Check-in History dan Stamp Transactions memaparkan rekod welcome/check-in yang sesuai.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 5. Semak Feedback Owner View

Prasyarat:

- Customer sudah submit feedback di `http://127.0.0.1:8000/b/wanchu-corner/feedback`.

Langkah:

1. Buka WanChu Corner.
2. Klik `Feedback`.
3. Semak Avg food, Avg service, Cheap, OK, Expensive.
4. Semak Latest Feedback.

Keputusan dijangka:

- Feedback terkini dipaparkan.
- Jika WhatsApp customer sepadan, nama customer muncul.
- Rating dan comment dipaparkan.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 6. Semak Weekly Report

Langkah:

1. Buka WanChu Corner.
2. Klik `Weekly Report`.
3. Semak semua metrik mingguan.
4. Semak bahagian `What should I do next?`.
5. Klik `Copy Summary`.

Keputusan dijangka:

- Report dipaparkan untuk minggu semasa.
- Metrik customer, check-in, feedback, dan redemption berubah mengikut data ujian.
- Summary boleh disalin untuk laporan manual.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 7. Semak Manual WhatsApp Follow-Ups

Langkah:

1. Buka WanChu Corner.
2. Klik `Follow-ups`.
3. Semak mesej amaran manual sahaja.
4. Semak kumpulan:
   - Dormant Customers
   - New Customers
   - Reward-Near Customers
   - Eligible Reward Customers
5. Klik `Copy Message` untuk customer yang wujud.
6. Klik `Open WhatsApp` jika ingin mengesahkan URL.

Keputusan dijangka:

- Tiada mesej dihantar automatik.
- Template mesej boleh disalin.
- Butang WhatsApp hanya membuka URL secara manual.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 8. Semak Reward Redemption

Prasyarat lokal cepat:

1. Pada WanChu Corner, klik `Edit Loyalty`.
2. Catat nilai asal `Stamps Required = 8`.
3. Tukar `Stamps Required` kepada `1`.
4. Simpan.
5. Daftar customer baru melalui `http://127.0.0.1:8000/b/wanchu-corner`:
   - Name: `Eligible Test`
   - WhatsApp: `60111110008`

Langkah redemption:

1. Login sebagai owner.
2. Buka WanChu Corner overview.
3. Semak bahagian Eligible Customers.
4. Klik `Redeem` untuk `Eligible Test`.

Keputusan dijangka:

- Mesej `Reward redemption verified.` dipaparkan.
- Customer berpindah ke Redemption History.
- Current stamps customer reset kepada `0`.
- Rewards redeemed bertambah.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## 9. Semak Admin Boundary

Langkah:

1. Logout.
2. Login sebagai `admin@fbgrowth.local`.
3. Buka `http://127.0.0.1:8000/businesses`.
4. Semak WanChu Corner dan Restoran Che Na.

Keputusan dijangka:

- Admin nampak semua bisnes seeded.
- Ini hanya untuk validasi akses admin lokal.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

## Verification

Jalankan:

```powershell
php artisan test
npm run build
php artisan route:list
```

Keputusan dijangka:

- Semua test lulus.
- Build berjaya.
- Route list keluar tanpa error.

Status:

- [ ] Pass
- [ ] Fail

Bug/catatan:

```text

```

