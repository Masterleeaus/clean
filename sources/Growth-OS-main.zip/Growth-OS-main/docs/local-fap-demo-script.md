# Skrip Demo Lokal Untuk FAP Growth OS-F&B

Dokumen ini ialah skrip demo lokal untuk menunjukkan perjalanan founder/owner dan customer kepada FAP. Web server dan database masih KIV. Demo ini menggunakan setup lokal sahaja dan tidak menghantar WhatsApp automatik.

## Setup Sebelum Demo

Dari folder F&B Growth:

```powershell
composer install
npm install
Copy-Item .env.example .env -Force
php artisan key:generate
New-Item -ItemType File -Force .\database\database.sqlite
php artisan migrate:fresh --seed
```

Jalankan dua terminal:

```powershell
php artisan serve
```

```powershell
npm run dev
```

URL demo:

```text
Owner login: http://127.0.0.1:8000/login
Owner area: http://127.0.0.1:8000/businesses
Customer QR WanChu: http://127.0.0.1:8000/b/wanchu-corner
Feedback WanChu: http://127.0.0.1:8000/b/wanchu-corner/feedback
```

Akaun demo:

```text
owner+wanchu@fbgrowth.local / password
admin@fbgrowth.local / password
```

## Pembukaan Demo

Skrip cakap:

```text
Ini ialah demo lokal Growth OS-F&B. Fokusnya ialah validasi end-to-end sebelum keputusan hosting dan database dibuat. Web server dan database masih KIV, jadi hari ini kita guna Laravel local server dan SQLite lokal.
```

Keputusan dijangka:

- FAP faham ini bukan production/staging final.
- Tiada janji integrasi luar dibuat.

Status:

- [ ] Pass
- [ ] Fail

Catatan:

```text

```

## 1. Owner Login Dan Business List

Langkah demo:

1. Buka `http://127.0.0.1:8000/login`.
2. Login `owner+wanchu@fbgrowth.local` / `password`.
3. Buka `http://127.0.0.1:8000/businesses`.

Skrip cakap:

```text
Owner login masuk ke workspace bisnes sendiri. Dalam demo seeded ini, owner WanChu hanya nampak WanChu Corner.
```

Keputusan dijangka:

- Login berjaya.
- Owner nampak WanChu Corner sahaja.

Status:

- [ ] Pass
- [ ] Fail

Catatan:

```text

```

## 2. Business Dashboard

Langkah demo:

1. Klik WanChu Corner.
2. Klik `Dashboard`.
3. Tunjuk metrik dashboard.
4. Tunjuk Public QR Link.

Skrip cakap:

```text
Dashboard memberi snapshot operasi: customer baru, check-in hari ini, repeat customer, reward eligible, dan redemption. Public QR Link inilah link yang boleh ditukar menjadi QR untuk pelanggan daftar dan check-in.
```

Keputusan dijangka:

- Dashboard dan Public QR Link dipaparkan.
- Link ialah `http://127.0.0.1:8000/b/wanchu-corner`.

Status:

- [ ] Pass
- [ ] Fail

Catatan:

```text

```

## 3. Customer Registration Dari QR

Langkah demo:

1. Buka browser private/incognito.
2. Buka `http://127.0.0.1:8000/b/wanchu-corner`.
3. Isi:
   - Name: `FAP Demo Customer`
   - WhatsApp Number: `60111112222`
   - Consent promo: tick
4. Klik `Register`.

Skrip cakap:

```text
Customer tidak perlu install app. Mereka daftar dari QR link, masukkan nama dan WhatsApp, kemudian terus dapat stamp pertama jika welcome stamp aktif.
```

Keputusan dijangka:

- Customer status page dipaparkan.
- Stamp `1 / 8` dipaparkan untuk WanChu default.
- Reward `Free drink` dipaparkan.

Status:

- [ ] Pass
- [ ] Fail

Catatan:

```text

```

## 4. Repeat Check-In Guard

Langkah demo:

1. Buka semula `http://127.0.0.1:8000/b/wanchu-corner`.
2. Pada Returning customer, masukkan `60111112222`.
3. Klik `Check-in Today`.

Skrip cakap:

```text
Sistem kawal supaya customer tidak boleh spam check-in pada hari yang sama. Ini penting untuk jaga fairness reward.
```

Keputusan dijangka:

- Same-day duplicate tidak menambah stamp berulang.
- Mesej already checked-in/already registered dipaparkan.

Status:

- [ ] Pass
- [ ] Fail

Catatan:

```text

```

## 5. Feedback Customer

Langkah demo:

1. Buka `http://127.0.0.1:8000/b/wanchu-corner/feedback`.
2. Isi:
   - WhatsApp Number: `60111112222`
   - Food Rating: `5`
   - Service Rating: `5`
   - Price Feedback: `OK`
   - Comment: `Demo feedback FAP.`
3. Klik `Submit Feedback`.

Skrip cakap:

```text
Feedback customer dikumpul terus daripada public page. Jika nombor WhatsApp sepadan, owner boleh kaitkan feedback kepada customer loyalty record.
```

Keputusan dijangka:

- Feedback success page dipaparkan.
- Owner boleh lihat feedback dalam owner area.

Status:

- [ ] Pass
- [ ] Fail

Catatan:

```text

```

## 6. Owner Semak Customer Dan Feedback

Langkah demo:

1. Kembali ke browser owner.
2. Buka WanChu Corner.
3. Klik `Customers`.
4. Cari `FAP Demo Customer`.
5. Klik customer.
6. Buka `Feedback`.

Skrip cakap:

```text
Owner boleh lihat customer, stamp progress, history, dan feedback. Ini membantu kedai kecil faham siapa pelanggan repeat dan apa pengalaman mereka.
```

Keputusan dijangka:

- Customer muncul dalam senarai.
- Stamp progress dan feedback boleh disemak.

Status:

- [ ] Pass
- [ ] Fail

Catatan:

```text

```

## 7. Reward Eligibility Dan Redemption Demo Cepat

Nota demo lokal:

WanChu default memerlukan 8 stamps. Untuk demo cepat, gunakan UI owner untuk set threshold kepada `1` secara lokal sahaja. Ini perubahan data demo, bukan perubahan code atau business logic.

Langkah demo:

1. Owner buka WanChu Corner.
2. Klik `Edit Loyalty`.
3. Catat nilai asal `Stamps Required = 8`.
4. Tukar kepada `1`.
5. Simpan.
6. Dalam browser customer, buka `http://127.0.0.1:8000/b/wanchu-corner`.
7. Daftar:
   - Name: `FAP Reward Demo`
   - WhatsApp Number: `60111113333`
   - Consent promo: tick
8. Tunjuk status eligible pada customer screen.
9. Owner buka WanChu Corner overview.
10. Pada Eligible Customers, klik `Redeem`.

Skrip cakap:

```text
Untuk demo masa pendek, kita turunkan threshold reward kepada satu stamp. Dalam operasi sebenar, threshold ikut setup kedai, contohnya 8 stamps untuk WanChu. Redemption hanya dibuat oleh owner/admin selepas customer tunjuk skrin eligible.
```

Keputusan dijangka:

- Customer melihat eligible reward.
- Owner melihat customer dalam Eligible Customers.
- Selepas `Redeem`, redemption direkod dan current stamps reset kepada `0`.

Status:

- [ ] Pass
- [ ] Fail

Catatan:

```text

```

## 8. Weekly Report

Langkah demo:

1. Owner buka WanChu Corner.
2. Klik `Weekly Report`.
3. Tunjuk metrik dan suggestions.
4. Klik `Copy Summary`.

Skrip cakap:

```text
Weekly report membantu owner lihat growth signals setiap minggu: customer baru, check-in, feedback, dormant customer, dan cadangan tindakan.
```

Keputusan dijangka:

- Weekly report dipaparkan.
- Copy summary tersedia untuk laporan manual.

Status:

- [ ] Pass
- [ ] Fail

Catatan:

```text

```

## 9. Manual WhatsApp Follow-Up

Langkah demo:

1. Owner klik `Follow-ups`.
2. Tunjuk mesej manual only.
3. Tunjuk group customer dan template mesej.
4. Klik `Copy Message`.
5. Tunjuk `Open WhatsApp` tanpa menghantar mesej sebenar.

Skrip cakap:

```text
Buat masa ini follow-up adalah manual. Sistem bantu cadangkan group dan mesej, tetapi tiada mesej dihantar automatik. Ini mengurangkan risiko integrasi sebelum pilot live.
```

Keputusan dijangka:

- Follow-up groups dipaparkan.
- Copy Message berfungsi.
- Tiada auto-send berlaku.

Status:

- [ ] Pass
- [ ] Fail

Catatan:

```text

```

## Penutup Demo

Skrip cakap:

```text
Validasi lokal ini membuktikan flow asas boleh diuji end-to-end: owner login, dashboard, QR registration, check-in guard, reward, redemption, feedback, weekly report, dan manual WhatsApp follow-up. Keputusan hosting dan database masih KIV sebelum pilot sebenar.
```

## Verification Selepas Demo

Jalankan:

```powershell
php artisan test
npm run build
php artisan route:list
```

Keputusan dijangka:

- Test lulus.
- Build berjaya.
- Routes boleh disenaraikan.

Catatan keputusan:

```text

```

