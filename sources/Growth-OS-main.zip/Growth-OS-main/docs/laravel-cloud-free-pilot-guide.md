# Laravel Cloud Free/Credit Pilot Guide

Use this guide for a first 1-2 FAP controlled pilot on Laravel Cloud using free trial or credit-based usage where available.

Current public Laravel Cloud materials describe a Starter plan with a first month free, included monthly usage credits, spending limits, and scale-to-zero behavior. Verify current terms on Laravel Cloud before launch:

- Pricing: https://laravel.com/cloud/pricing
- Scale-to-zero and spending limits: https://laravel.com/blog/your-laravel-cloud-stack-now-scales-to-zero
- Cost controls: https://laravel.com/blog/5-tips-to-save-money-on-laravel-cloud

## Pilot Positioning

Use Laravel Cloud only for a controlled staging pilot, not a public production launch.

Good fit:

- 1-2 FAP businesses.
- Low traffic.
- Supervised testing.
- Manual backups.
- Clear spending limit.

Not suitable yet:

- Open signup.
- High traffic.
- Production SLA promises.
- Automated WhatsApp, AI, email report, POS, or payment expectations.

## GitHub Repo Preparation

Before connecting to Laravel Cloud:

- Push only the standalone F&B Growth Laravel app.
- Do not include NUSA KING.
- Confirm `.env` is not committed.
- Confirm `vendor/`, `node_modules/`, `public/build`, and local database backups are ignored.
- Confirm latest tests pass locally:

```bash
php artisan test
php vendor/bin/pint
npm run build
```

- Confirm public owner registration remains disabled:

```bash
php artisan route:list --path=register
```

Expected: only `POST b/{business:slug}/register`.

## Laravel Cloud Starter / Free Trial Setup

1. Create or log in to Laravel Cloud.
2. Create an organization for the pilot.
3. Select Starter/free trial if available.
4. Set a hard spending limit before provisioning resources.
5. Enable billing/spending alerts.
6. Create a new application from the GitHub repository.
7. Choose a staging environment name such as `staging`.
8. Choose the smallest suitable compute option for the pilot.
9. Enable scale-to-zero if available and appropriate.

## Spending Limit Reminder

Before sharing any FAP link:

- Set a hard monthly spending limit.
- Check included credits and trial expiry date.
- Check whether storage is excluded from the spending cap.
- Review the usage page daily during pilot.
- Stop the pilot or pause access if credits are close to the limit.

Free credits are not a backup plan. They are a short pilot runway.

## Managed Database Setup

For staging, prefer a managed database over SQLite on ephemeral cloud storage.

Recommended:

- Managed MySQL or MariaDB if available.
- Persistent database resource attached to the staging environment.
- Daily manual export during the pilot.

Confirm:

- Database credentials are injected into environment variables.
- Database does not scale down or disappear unexpectedly.
- Backups or exports are available.
- Restore process is known.

## Environment Variables

Set these in Laravel Cloud environment variables:

```dotenv
APP_NAME="F&B Growth"
APP_ENV=staging
APP_DEBUG=false
APP_URL=https://your-laravel-cloud-domain.example

SESSION_DRIVER=database
CACHE_STORE=database
QUEUE_CONNECTION=database

DB_CONNECTION=mysql
DB_HOST=provided-by-laravel-cloud
DB_PORT=3306
DB_DATABASE=provided-by-laravel-cloud
DB_USERNAME=provided-by-laravel-cloud
DB_PASSWORD=<DB_PASSWORD>
```

Use the actual values provided by Laravel Cloud. Do not paste real secrets into docs or chat.

## Mailtrap SMTP Setup

Use Mailtrap sandbox values:

```dotenv
MAIL_MAILER=smtp
MAIL_SCHEME=null
MAIL_HOST=sandbox.smtp.mailtrap.io
MAIL_PORT=2525
MAIL_USERNAME=your_mailtrap_username
MAIL_PASSWORD=<MAIL_PASSWORD>
MAIL_FROM_ADDRESS="hello@fbgrowth.local"
MAIL_FROM_NAME="${APP_NAME}"
```

Current MVP does not send scheduled emails, but password reset/mail foundation should not use real customer email infrastructure during staging.

## Migration Steps

Before real pilot data:

```bash
php artisan migrate:fresh --seed
```

After real pilot data exists:

```bash
php artisan migrate --force
```

Do not run `migrate:fresh --seed` after FAP data exists unless a backup is verified and data loss is intentional.

## Owner Creation Command

Public owner registration is disabled. Create supervised owners with:

```bash
php artisan users:create-owner --name="Owner Name" --email="owner@example.com" --password="temporary-strong-password"
```

Then:

- Ask the owner to log in.
- Ask the owner to change the temporary password.
- Confirm the business belongs to the correct owner.

## Queue Worker Setup

Current MVP does not depend on queued jobs for the main flows, but staging is queue-ready.

If Laravel Cloud managed queues are available, prefer managed queues for cost control and idle scaling.

If using a worker process:

```bash
php artisan queue:work database --queue=default --tries=3 --timeout=90
```

## Scheduler Setup

No scheduled product jobs are currently enabled, but staging should be scheduler-ready.

Configure Laravel Cloud scheduler/cron equivalent for:

```bash
php artisan schedule:run
```

Run every minute if the platform supports it.

## Asset Build

Use the platform build step or deploy prebuilt assets:

```bash
npm ci
npm run build
```

Confirm `public/build/manifest.json` exists after deployment.

## QR Link Testing

Open the public QR route:

```text
https://your-staging-domain/b/wanchu-corner
```

Confirm:

- Business name appears.
- Registration form appears.
- Returning check-in form appears.
- Feedback link appears.
- Form submission works on mobile.

## First FAP Smoke Test

Run:

- Owner login.
- Business dashboard.
- QR customer registration.
- Repeat check-in.
- Reward eligibility.
- Reward redemption.
- Feedback submit.
- Follow-up page.
- Weekly report.

Use `docs/first-fap-smoke-test.md` for exact steps.

## Backup Routine During Free Pilot

Before sharing with FAP:

- Export database.
- Save export outside Laravel Cloud.
- Record timestamp and app version.

After each FAP session:

- Export database again.
- Verify file exists and is downloadable.
- Do not store backups in public web directories.

## Warnings About Free Credits And Scale-To-Zero

- Free/trial credits can expire or be consumed.
- Scale-to-zero can introduce first-request wake behavior.
- A sleeping app should wake on request, but always test before live FAP sessions.
- Queue and scheduler behavior should be confirmed after scale-to-zero is enabled.
- Spending limits protect budget but may stop provisioning or scaling.
- Manual backups are still required.

## Go/No-Go

Go only when:

- Spending limit is set.
- Database is persistent and backed up.
- `APP_DEBUG=false`.
- Owner account is created.
- Demo passwords are changed.
- Public QR link works on phone.
- Smoke test passes.

