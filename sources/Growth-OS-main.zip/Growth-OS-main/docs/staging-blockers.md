# Staging Blockers

These items must be completed before using real FAP pilot data.

## Required Before Real Pilot

- Choose staging host. Paid hosting is not required for a 1-2 FAP controlled pilot if a free/credit-based host is monitored closely.
- If using Render Free, deploy with Docker and confirm the service wakes reliably before live sessions.
- Configure HTTPS.
- Set `APP_ENV=staging`.
- Set `APP_DEBUG=false`.
- Set real `APP_URL`.
- Generate and secure `APP_KEY`.
- Choose database:
  - SQLite only for very small supervised staging.
  - MySQL/MariaDB preferred for production-like staging.
  - Render Postgres Free or another managed database is preferred for Render web pilot if available.
  - SQLite on Render must be treated as temporary throwaway testing only.
- Configure database backups.
- Confirm backup restore process.
- If using free credits, set a spending limit and monitor credits/usage daily.
- If using free credits, export database backups manually before and after each pilot session.
- If using Render Free, confirm database retention, backup/export, and expiry limits before real FAP data.
- Set Mailtrap sandbox credentials.
- Change seeded demo passwords.
- Create supervised owner account with `php artisan users:create-owner`.
- Confirm business owner assignment.
- Confirm active loyalty program.
- Run first FAP smoke test.

## Security Blockers

- Public owner registration must remain disabled.
- Account self-deletion must remain disabled.
- `.env` must not be committed or shared.
- Debug mode must not be enabled for FAP users.
- Staging must not expose database files or backups.
- Public QR links must only be shared with intended pilot testers.

## Operational Blockers

- No named person responsible for backups.
- No named person responsible for monitoring free credits or spending limit usage.
- No confirmed Docker deployment owner for Render build/runtime failures.
- No rollback process agreed.
- No staging database location documented.
- No owner temporary password handoff process.
- No clear pilot support contact.

## Product Scope Blockers

These are not blockers for staging, but must not be promised as available:

- WhatsApp API.
- AI suggestions.
- Scheduled email reports.
- QR image generator.
- Staff roles.
- POS/payment/inventory integration.
- Self-service owner signup.

## Recommended Host And Database Notes

- Use a staging host that supports PHP 8.3+, Composer, Node build or deployed built assets, cron, and background workers.
- Paid hosting is optional for the first controlled 1-2 FAP pilot if the free/credit-based option supports HTTPS, persistent database, env vars, logs, and backups.
- For Render, use Docker runtime and a managed database for any web pilot with real FAP data.
- Use persistent storage for SQLite if SQLite is selected.
- Prefer MySQL or MariaDB when more than one device/person will test at the same time.
- Use a host that allows access to logs and database backups without exposing them publicly.
- Avoid hardcoded provider-specific paths in docs or code; keep deployment variables in `.env`.
