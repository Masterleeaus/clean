# Staging Launch Runbook

This runbook prepares F&B Growth Core for the first supervised FAP staging pilot. It is provider-neutral and assumes SSH or equivalent terminal access.

## 1. Upload Or Deploy Code

- Deploy the standalone F&B Growth project only.
- Do not deploy or modify NUSA KING.
- Ensure the web root points to Laravel's `public` directory.
- Confirm `.env` is not committed with source code.

## 2. Install Dependencies

```bash
composer install --no-dev --optimize-autoloader
npm ci
```

If staging is a temporary low-risk server that still uses dev dependencies for diagnostics, document that exception before deployment.

## 3. Create `.env`

- Copy `.env.example` to `.env`.
- Use `docs/staging-env-template.md` as the staging reference.
- Set `APP_ENV=staging`.
- Set `APP_DEBUG=false`.
- Set `APP_URL` to the real HTTPS staging URL.
- Configure database credentials.
- Configure Mailtrap sandbox credentials.
- Keep `QUEUE_CONNECTION=database`.

## 4. Generate App Key

If `APP_KEY` is empty:

```bash
php artisan key:generate
```

Do not regenerate `APP_KEY` after real pilot data exists unless you understand the impact on encrypted values and sessions.

## 5. Prepare Storage And Permissions

```bash
mkdir -p storage/app/backups
php artisan storage:link
```

Ensure the web server can write to:

- `storage`
- `bootstrap/cache`
- SQLite database file directory, if using SQLite

## 6. Run Migrations

Before pilot data exists:

```bash
php artisan migrate:fresh --seed
```

After pilot data exists:

```bash
php artisan migrate --force
```

Never run `migrate:fresh --seed` after real pilot data exists unless a verified backup exists and data loss is intentional.

## 7. Build Assets

```bash
npm run build
```

Confirm `public/build/manifest.json` exists after the build.

## 8. Optimize Laravel

```bash
php artisan config:clear
php artisan route:clear
php artisan view:clear
php artisan config:cache
php artisan route:cache
```

If route caching reveals a problem, clear route cache and resolve it before pilot.

## 9. Queue Worker Setup

Current MVP does not depend on queued jobs, but staging is configured for database queues.

If queue processing is needed:

```bash
php artisan queue:work database --queue=default --tries=3 --timeout=90
```

Use the hosting platform's process manager, supervisor, or background worker feature to keep it running.

## 10. Scheduler Setup

No scheduled product jobs are enabled yet, but staging should be scheduler-ready.

Add one cron entry on the server:

```bash
* * * * * cd /path/to/fbgrowth && php artisan schedule:run >> /dev/null 2>&1
```

## 11. Create Owner User

Public owner registration is disabled. Create supervised owner accounts with:

```bash
php artisan users:create-owner --name="Owner Name" --email="owner@example.com" --password="temporary-strong-password"
```

Then ask the owner to change the temporary password from Profile.

## 12. Create Or Update Business

For the first staging pilot, use the seeded businesses or update records carefully through the owner UI or controlled database changes.

Confirm:

- Owner user exists.
- Business belongs to the correct owner.
- Business slug is correct.
- Active loyalty program exists.
- Reward name and stamps required are correct.

## 13. Confirm Public QR Link

Open:

```text
https://staging.example.com/b/{business-slug}
```

Confirm the page shows:

- Business name.
- Reward offer.
- Returning customer check-in form.
- New customer registration form.
- Feedback link.

## 14. Run Smoke Test

Use `docs/first-fap-smoke-test.md`.

At minimum confirm:

- Owner login.
- Business dashboard.
- Customer registration.
- Repeat check-in.
- Feedback submission.
- Reward redemption.
- Follow-up page.
- Weekly report.

## 15. Final Verification Commands

```bash
php artisan test
php artisan route:list
php artisan migrate:status
```

For code quality and assets:

```bash
php vendor/bin/pint
npm run build
```

On Windows from this project path:

```powershell
php vendor\bin\pint
```

## Rollback

- Restore the latest database backup.
- Redeploy the previous known-good code bundle.
- Run `php artisan config:clear`.
- Run `php artisan migrate:status`.
- Perform owner login and public QR smoke checks.

