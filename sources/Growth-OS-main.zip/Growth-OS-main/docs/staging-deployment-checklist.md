# Staging Deployment Checklist

Use this checklist before the first supervised FAP staging pilot.

## Environment

- Set `APP_ENV=staging`.
- Set `APP_DEBUG=false`.
- Set `APP_URL` to the real staging URL, including `https://`.
- Set `APP_KEY` with `php artisan key:generate` if missing.
- Confirm `.env` is not committed.
- Confirm `SESSION_DRIVER=database`.
- Confirm `QUEUE_CONNECTION=database`.
- Confirm `MAIL_MAILER=smtp` and Mailtrap sandbox values are set.
- Confirm no production or personal email credentials are used.

## Database

- Choose the staging database intentionally:
  - SQLite is acceptable only for a very small supervised pilot.
  - MySQL is preferred if multiple staff/devices will test at the same time.
- Run `php artisan migrate:fresh --seed` only before pilot data is collected.
- After pilot data exists, use `php artisan migrate --force` only.
- Confirm `php artisan migrate:status` shows all migrations as ran.
- Change seeded demo passwords before entering real customer data.

## Owner Account Creation

Public owner registration is disabled and must stay disabled.

Create supervised owner accounts with:

```bash
php artisan users:create-owner --name="Owner Name" --email="owner@example.com" --password="temporary-strong-password"
```

Then:

- Ask the owner to change the temporary password after first login.
- Assign businesses manually through seed/data setup for this pilot.
- Do not share seeded demo credentials with real FAP users.

## Build And Cache

- Run `composer install --no-dev --optimize-autoloader` for staging deployment.
- Run `npm ci`.
- Run `npm run build`.
- Run `php artisan config:clear`.
- Run `php artisan route:clear`.
- Run `php artisan view:clear`.
- Optionally run `php artisan config:cache` after `.env` is final.

## Queue And Scheduler

- Database queue tables exist.
- Current MVP does not require queued jobs for core flows.
- If queued jobs are later added, run:

```bash
php artisan queue:work --queue=default --tries=3
```

- Laravel scheduler is available, but no scheduled report/email jobs are enabled yet.

## Security Checks

- Confirm `/register` returns 404.
- Confirm `DELETE /profile` is not listed in `php artisan route:list`.
- Confirm owner cannot open another owner's business dashboard.
- Confirm public POST routes are throttled.
- Confirm `.env` and database files are not publicly served.
- Confirm staging uses HTTPS before sharing links externally.

## Required Verification

Run these before inviting FAP testers:

```bash
php artisan test
php vendor/bin/pint
npm run build
php artisan route:list
php artisan migrate:status
```

On Windows from this project path, use:

```powershell
php vendor\bin\pint
```

## Go/No-Go

Go only when:

- All verification commands pass.
- Owner accounts and passwords are prepared.
- Backups are configured or manually scheduled.
- Pilot limitations have been communicated.
- FAP knows this is supervised staging, not production launch.

