# Log Isu Diketahui Validasi Lokal Growth OS-F&B

Dokumen ini digunakan untuk merekod isu semasa founder menjalankan local pilot validation. Web server dan database masih KIV. Isu dalam dokumen ini tidak semestinya blocker untuk hosting, tetapi perlu dinilai sebelum pilot sebenar.

## Cara Guna Log Ini

Untuk setiap isu, rekod:

- Tarikh dan masa.
- Tester.
- Flow yang diuji.
- Langkah untuk ulang isu.
- Expected result.
- Actual result.
- Screenshot atau nota tambahan jika ada.
- Severity.
- Status.

Severity:

| Severity | Maksud |
|---|---|
| P0 | Blocker, flow utama tidak boleh diuji |
| P1 | Bug serius, flow utama rosak sebahagian |
| P2 | Bug sederhana, ada workaround |
| P3 | Cosmetic, copywriting, atau UX kecil |

Status:

| Status | Maksud |
|---|---|
| Open | Baru direkod |
| Investigating | Sedang disemak |
| Fixed Locally | Sudah dibaiki lokal |
| Deferred | Ditangguh |
| Not A Bug | Tingkah laku dijangka |

## Known Notes Setakat Dokumen Ini

| ID | Nota | Status |
|---|---|---|
| KIV-001 | Web server production belum dipilih. Ujian lokal guna `php artisan serve`. | Deferred |
| KIV-002 | Database production belum dipilih. Ujian lokal guna SQLite. | Deferred |
| KIV-003 | QR image generation belum menjadi skop validasi ini; owner guna public URL sebagai QR placeholder. | Deferred |
| KIV-004 | WhatsApp follow-up adalah manual sahaja; tiada mesej dihantar automatik. | Not A Bug |
| KIV-005 | Same-day repeat check-in disekat. Untuk reward demo cepat lokal, threshold loyalty boleh diturunkan melalui UI owner. | Not A Bug |

## Setup Dan Verification Commands

Setup lokal:

```powershell
composer install
npm install
Copy-Item .env.example .env -Force
php artisan key:generate
New-Item -ItemType File -Force .\database\database.sqlite
php artisan migrate:fresh --seed
php artisan serve
npm run dev
```

Verification:

```powershell
php artisan test
npm run build
php artisan route:list
```

URL utama:

```text
http://127.0.0.1:8000/login
http://127.0.0.1:8000/businesses
http://127.0.0.1:8000/b/wanchu-corner
http://127.0.0.1:8000/b/wanchu-corner/feedback
```

Akaun seeded:

```text
admin@fbgrowth.local / password
owner+wanchu@fbgrowth.local / password
owner+restoran-che-na@fbgrowth.local / password
```

## Template Isu

```text
ID:
Tarikh/Masa:
Tester:
Environment:
Browser/Device:
Flow:
Severity:
Status:

Langkah untuk ulang:
1.
2.
3.

Expected result:

Actual result:

Screenshot/link/log:

Workaround:

Owner:

Catatan keputusan:
```

## Issue Log

### ISSUE-001

```text
ID:
Tarikh/Masa:
Tester:
Environment:
Browser/Device:
Flow:
Severity:
Status:

Langkah untuk ulang:
1.
2.
3.

Expected result:

Actual result:

Screenshot/link/log:

Workaround:

Owner:

Catatan keputusan:
```

### ISSUE-002

```text
ID:
Tarikh/Masa:
Tester:
Environment:
Browser/Device:
Flow:
Severity:
Status:

Langkah untuk ulang:
1.
2.
3.

Expected result:

Actual result:

Screenshot/link/log:

Workaround:

Owner:

Catatan keputusan:
```

### ISSUE-003

```text
ID:
Tarikh/Masa:
Tester:
Environment:
Browser/Device:
Flow:
Severity:
Status:

Langkah untuk ulang:
1.
2.
3.

Expected result:

Actual result:

Screenshot/link/log:

Workaround:

Owner:

Catatan keputusan:
```

## Ringkasan Sesi Validasi

```text
Tarikh sesi:
Tester:
Data reset dengan migrate:fresh --seed: Ya / Tidak
php artisan test: Pass / Fail
npm run build: Pass / Fail
php artisan route:list: Pass / Fail

Flow owner/admin login: Pass / Fail
Flow business dashboard: Pass / Fail
Flow QR/customer registration: Pass / Fail
Flow repeat check-in: Pass / Fail
Flow reward eligibility: Pass / Fail
Flow reward redemption: Pass / Fail
Flow customer feedback: Pass / Fail
Flow weekly report: Pass / Fail
Flow manual WhatsApp follow-up: Pass / Fail

Keputusan:
Blocker sebelum pilot:
Next action:
```

