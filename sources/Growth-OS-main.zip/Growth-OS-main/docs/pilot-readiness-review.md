# F&B Growth Core MVP Pilot Readiness Review

Review date: 2026-06-27

## Readiness Decision

READY FOR CONTROLLED FAP PILOT

The app is ready for a small, supervised Founding Advisory Partner pilot using seeded/admin-created owner accounts, local SQLite or a managed pilot database, Mailtrap for email testing, and manual WhatsApp follow-up only.

## What Is Ready

- Laravel Breeze login and password flows.
- Admin and owner roles using `users.role`.
- Owner/admin business isolation through `BusinessPolicy`.
- Authenticated business pages for dashboard, customers, feedback, follow-ups, loyalty settings, reward redemption, and weekly reports.
- Public QR customer registration and check-in routes.
- Public customer feedback form.
- Stamp tracking with one check-in per customer per business per day.
- Reward redemption verification by authenticated owner/admin.
- Manual WhatsApp follow-up links using `wa.me`.
- Weekly growth report with rule-based suggestions.
- Mailtrap-ready `.env.example` placeholders.
- Database queue driver configured.
- SQLite local development support.
- Automated feature tests for core access control, public flows, loyalty rules, feedback, reports, and registration-disabled hardening.

## Critical Issues Found And Fixed

1. Public Breeze user registration was enabled.

Risk: anyone could create an owner-role account because `users.role` defaults to `owner`.

Fix: removed public `/register` auth routes and updated tests to assert owner account self-registration is disabled.

2. Breeze profile self-deletion was enabled.

Risk: an owner deleting their account would cascade-delete owned businesses and pilot data.

Fix: removed the `DELETE /profile` route, removed the delete-account UI from the profile page, and updated tests to assert deletion is disabled.

## Review Findings

### Auth And Access Control

- Admin can view/manage all businesses.
- Owners can view/manage only businesses where `businesses.owner_user_id = users.id`.
- Owner dashboard, detail, customer, follow-up, feedback, report, loyalty, and redemption routes are behind `auth`.
- Customer detail and redemption actions validate customer/business ownership.
- Public owner self-registration is disabled for pilot.
- Account self-deletion is disabled for pilot data protection.

### Public Route Safety

- Public routes are limited to QR registration/check-in and feedback.
- Public POST routes are throttled with `throttle:10,1`.
- Customer registration normalizes WhatsApp numbers.
- Duplicate customer prevention is enforced by validation flow plus database unique constraint.
- Existing customers see status and do not receive duplicate welcome stamps.
- Feedback can be anonymous or attached to a matching WhatsApp number.

### Data Integrity

- `customers` enforces unique `business_id + whatsapp_number`.
- `customer_loyalty_accounts` enforces unique `business_id + customer_id + loyalty_program_id`.
- `customer_check_ins` enforces unique `business_id + customer_id + check_in_date`.
- Valid check-ins increment `current_stamps` and `total_stamps_earned`.
- Reward redemption resets `current_stamps` to 0 and does not reset `total_stamps_earned`.
- Reward redemption increments `total_rewards_redeemed`.
- Reward redemption creates a negative `redeemed_reset` stamp transaction.
- Business/customer mismatch is rejected during redemption and customer detail access.

### UX Readiness

- Public QR page supports registration, returning-customer check-in, and feedback link.
- Public status page shows stamp progress and reward eligibility.
- Owner pages have simple cards, empty states, and direct navigation.
- Follow-up page uses generated WhatsApp messages and copy/open controls.
- Weekly report answers what happened this week and what to do next.

### Foundation Readiness

- `.env.example` uses SQLite, database sessions, database queue, and Mailtrap placeholders.
- `.env` is ignored by `.gitignore`.
- No WhatsApp API, AI API, payment, POS, or inventory integration is present.
- Scheduler is available through Laravel, but no scheduled jobs are configured yet.
- Queue-ready structure exists, but no queued jobs are required for current MVP flows.

## What FAP Can Test

- Login as seeded/admin-provided owner accounts.
- View own business dashboard and business detail.
- Share the public QR link as a text URL.
- Register customers from public QR page.
- Check in returning customers once per day.
- Confirm duplicate customer/check-in behavior.
- Redeem eligible customer rewards from owner/admin area.
- View customer lists and customer detail histories.
- Use manual WhatsApp follow-up groups and copy/open messages.
- Submit customer feedback publicly.
- View feedback summaries as owner/admin.
- View weekly growth report and rule-based suggestions.

## What Should Not Be Promised Yet

- Automated WhatsApp sending.
- WhatsApp Business API integration.
- AI-generated insights.
- Scheduled email reports.
- QR image generation.
- Staff roles or staff permissions.
- Multi-owner business management.
- POS, payment, inventory, or receipt integrations.
- Production-grade analytics dashboards or charts.
- Self-service business onboarding.

## Remaining Risks And Blockers

- Seeded pilot credentials use simple demo passwords and must be changed before real pilot usage.
- Public QR link uses business slug; QR token routing is not implemented yet.
- Public feedback allows anonymous submissions, which may include noise.
- Public routes are throttled but do not include CAPTCHA or abuse detection.
- Concurrent duplicate registration/check-in relies on database constraints; users may see a generic error under rare race conditions.
- No automated backups are configured.
- No production deployment, HTTPS, domain, or monitoring setup is documented here.
- Email sending is Mailtrap-ready only and not used by current flows.

