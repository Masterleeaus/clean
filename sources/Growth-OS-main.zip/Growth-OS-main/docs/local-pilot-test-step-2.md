# Step 2: GOS-F&B Local Pilot Test

Tarikh semakan: 2026-07-05

Render Free external MySQL note: this file records local pilot validation only. For the Render Pre-Test Pilot, use `docs/render-free-external-mysql-deployment.md` and recreate clean pilot data through `php artisan migrate --force` plus `php artisan db:seed --class=FnbCoreSeeder --force`; keep local DB dump/import as fallback only.

## Bahagian 1: Persediaan Test & Template Rekod Result

Tujuan bahagian ini ialah memastikan local environment dan akaun test persona sedia sebelum mula Bahagian 2 Login/Logout Test.

Label status yang digunakan:
- PASS
- ISSUE
- BLOCKER
- UI CONFUSING
- NEED FIX

## Checklist Environment

| Item | Expected Result | Actual Result | Status |
| --- | --- | --- | --- |
| Laravel app bootstrap | App boleh bootstrap melalui Artisan | `php artisan about` berjaya. App name GOS-F&B, environment local, URL 127.0.0.1:8000 | PASS |
| Database connection | `.env` menggunakan MySQL local | DB_CONNECTION=mysql, DB_HOST=127.0.0.1, DB_PORT=3306, DB_DATABASE=gos_fnb_local | PASS |
| Database password | Password wujud tetapi tidak dipaparkan | DB_PASSWORD disahkan set dan direkod sebagai redacted | PASS |
| Migration status | Semua migration perlu `Ran` | `php artisan migrate:status` menunjukkan semua migration `Ran` | PASS |
| Local app URL | App boleh digunakan di local URL | URL local: http://127.0.0.1:8000 | PASS |

## Senarai Persona Test Account

Nota: Akaun seed demo/pilot menggunakan password test `password` untuk kegunaan local/pilot sahaja. Tukar credential sebelum guna data pelanggan sebenar.

| Persona | Test Account | Role | Assignment / Context | Status |
| --- | --- | --- | --- | --- |
| System Manager | manager@gos-fnb.pilot | system_manager | Platform/GOS-level scope | PASS |
| System Admin | admin@gos-fnb.pilot | system_admin | System/admin support scope | PASS |
| Business Owner | owner+wanchu@gos-fnb.pilot | business_owner | Owner scope untuk business `wanchu-corner` | PASS |
| Branch Manager | branch+wanchu@gos-fnb.pilot | branch_manager | Manager scope untuk branch `WANCHU-MAIN` | PASS |
| Customer | customer@gos-fnb.pilot | customer | Customer profile wujud untuk GOS-F&B Demo Customer | PASS |
| Business Owner | owner+chena@gos-fnb.pilot | business_owner | FAP BO scope untuk business `restoran-che-na` | PASS |
| Branch Manager | branch+chena@gos-fnb.pilot | branch_manager | FAP BM scope untuk branch `CHENA-MAIN` | PASS |

## Combined Role Demo Account

| Use Case | Test Account | Role | Scope | Status |
| --- | --- | --- | --- | --- |
| Business Owner / Branch Manager | owner-branch+wanchu@gos-fnb.pilot | business_owner + branch_manager | Business `wanchu-corner`, branch `WANCHU-MAIN` | PASS |
| Business Owner / Branch Manager | owner-branch+chena@gos-fnb.pilot | business_owner + branch_manager | Business `restoran-che-na`, branch `CHENA-MAIN` | PASS |
| System Manager / System Admin | internal@gos-fnb.local | system_manager + system_admin | Internal GOS combined scope | PASS |

## Template Catatan Issue

Gunakan format ini untuk Bahagian 2 dan seterusnya.

| Field | Catatan |
| --- | --- |
| Tarikh/Masa |  |
| Tester |  |
| Persona |  |
| Page / Flow |  |
| Expected Result |  |
| Actual Result |  |
| Status | PASS / ISSUE / BLOCKER / UI CONFUSING / NEED FIX |
| Screenshot / Evidence |  |
| Cadangan Fix Ringkas |  |
| Owner |  |
| Retest Status |  |

## Keputusan Akhir Bahagian 1

| Area | Result | Catatan |
| --- | --- | --- |
| Environment local | PASS | Laravel bootstrap, MySQL `.env`, migration status, dan local URL sedia |
| Persona test accounts | PASS | Semua persona locked mempunyai akaun test dan context asas |
| Documentation | PASS | Template rekod result telah disediakan |

Keputusan: BOLEH TERUS KE BAHAGIAN 2 Login/Logout Test.

## Bahagian 2: Login / Logout Test Semua Persona

Tarikh semakan: 2026-07-05

Kaedah test: HTTP session/manual-equivalent check menggunakan local app `http://127.0.0.1:8000`. Browser automation visual tidak tersedia dalam tool semasa, jadi UI visual penuh masih perlu human confirmation jika diperlukan.

### 2.1 Login Page

| Test ID | Step | Expected Result | Actual Result | Status |
| --- | --- | --- | --- | --- |
| LP-LOGIN-01 | Buka `/login` | Login page muncul | Page `/login` return 200 | PASS |
| LP-LOGIN-02 | Semak field login | Email/username dan password jelas | RESOLVED 2A: heading, email field, password field, placeholder, dan button dikesan jelas melalui HTML/manual-equivalent check | PASS |
| LP-LOGIN-03 | Submit form kosong | Validation error muncul | Redirect balik `/login` dengan validation | PASS |
| LP-LOGIN-04 | Login credential salah | Login ditolak dengan mesej sesuai | Redirect balik `/login`, login tidak diterima | PASS |

### 2.2 System Manager Login/Logout

| Test ID | Step | Expected Result | Actual Result | Status |
| --- | --- | --- | --- | --- |
| LP-SM-LOGIN-01 | Login sebagai System Manager | Login berjaya | Login berjaya | PASS |
| LP-SM-LOGIN-02 | Semak landing page | Dashboard System Manager | Masuk `/dashboards/system-manager` | PASS |
| LP-SM-LOGIN-03 | Semak menu utama | Menu GOS/platform performance wujud | Keyword GOS/platform/System Manager dikesan | PASS |
| LP-SM-LOGIN-04 | Tiada customer-only area | Tidak masuk customer-only area | Tiada customer portal pada landing/menu utama | PASS |
| LP-SM-LOGIN-05 | Logout | Logout berjaya | Logout redirect ke `/login` | PASS |
| LP-SM-LOGIN-06 | Akses dashboard selepas logout | Tidak boleh akses tanpa login | Dashboard redirect/blocked selepas logout | PASS |

### 2.3 System Admin Login/Logout

| Test ID | Step | Expected Result | Actual Result | Status |
| --- | --- | --- | --- | --- |
| LP-SA-LOGIN-01 | Login sebagai System Admin | Login berjaya | Login berjaya | PASS |
| LP-SA-LOGIN-02 | Semak landing page | Dashboard System Admin | Masuk `/dashboards/system-admin` | PASS |
| LP-SA-LOGIN-03 | Semak menu utama | Menu admin/support/system usage wujud | Keyword admin/setup/support dikesan | PASS |
| LP-SA-LOGIN-04 | Scope bukan commercial strategy | Tiada strategi business GOS seperti System Manager | Tiada keyword commercial strategy/vertical expansion dikesan | PASS |
| LP-SA-LOGIN-05 | Logout | Logout berjaya | Logout redirect ke `/login` | PASS |
| LP-SA-LOGIN-06 | Akses dashboard selepas logout | Tidak boleh akses tanpa login | Dashboard redirect/blocked selepas logout | PASS |

### 2.4 Business Owner Login/Logout

| Test ID | Step | Expected Result | Actual Result | Status |
| --- | --- | --- | --- | --- |
| LP-BO-LOGIN-01 | Login sebagai Business Owner | Login berjaya | Login berjaya | PASS |
| LP-BO-LOGIN-02 | Semak landing page | Dashboard Business Owner | Masuk `/dashboards/business-owner` | PASS |
| LP-BO-LOGIN-03 | Semak ownership | Hanya business/branch milik dia | WanChu dikesan, Che Na tidak dikesan | PASS |
| LP-BO-LOGIN-04 | Semak menu utama | Menu business performance/branch/analytics/AI wujud jika scope | Business/performance context dikesan | PASS |
| LP-BO-LOGIN-05 | Tiada System Admin/System Manager menu | Tiada platform-wide/admin-only menu | Tiada System Admin/System Manager dikesan | PASS |
| LP-BO-LOGIN-06 | Logout | Logout berjaya | Logout redirect ke `/login` | PASS |
| LP-BO-LOGIN-07 | Akses dashboard selepas logout | Tidak boleh akses tanpa login | Dashboard redirect/blocked selepas logout | PASS |

### 2.5 Branch Manager Login/Logout

| Test ID | Step | Expected Result | Actual Result | Status |
| --- | --- | --- | --- | --- |
| LP-BM-LOGIN-01 | Login sebagai Branch Manager | Login berjaya | Login berjaya | PASS |
| LP-BM-LOGIN-02 | Semak landing page | Dashboard Branch Manager | Masuk `/dashboards/branch-manager` | PASS |
| LP-BM-LOGIN-03 | Semak branch assignment | Hanya assigned branch sahaja | Branch Manager/WanChu branch context dikesan | PASS |
| LP-BM-LOGIN-04 | Semak menu utama | Menu operasi branch/capture/feedback/analytics branch wujud jika scope | Branch/analytics/business operation links dikesan | PASS |
| LP-BM-LOGIN-05 | Tiada owner/admin/platform menu | Tiada akses/menu luar branch assigned | RESOLVED 2A: tiada teks `Business Owner`, tiada nav `Businesses`, dan quick actions ditukar kepada branch-level | PASS |
| LP-BM-LOGIN-06 | Logout | Logout berjaya | Logout redirect ke `/login` | PASS |
| LP-BM-LOGIN-07 | Akses dashboard selepas logout | Tidak boleh akses tanpa login | Dashboard redirect/blocked selepas logout | PASS |

### 2.6 Customer Login/Logout

| Test ID | Step | Expected Result | Actual Result | Status |
| --- | --- | --- | --- | --- |
| LP-CUST-LOGIN-01 | Login sebagai Customer | Login berjaya | Login berjaya | PASS |
| LP-CUST-LOGIN-02 | Semak landing page | Customer Portal | Masuk `/customer/portal` | PASS |
| LP-CUST-LOGIN-03 | Semak menu customer | Hanya menu customer muncul | Check-in/reward/feedback context dikesan | PASS |
| LP-CUST-LOGIN-04 | Tiada internal dashboard/menu | Tiada akses admin/business/branch dashboard | Tiada internal dashboard/menu dikesan pada portal | PASS |
| LP-CUST-LOGIN-05 | Logout | Logout berjaya | Logout redirect ke `/login` | PASS |
| LP-CUST-LOGIN-06 | Akses portal selepas logout | Tidak boleh akses tanpa login | Customer portal redirect/blocked selepas logout | PASS |

### 2.7 Ringkasan Result Bahagian 2

| Area | Result | Catatan |
| --- | --- | --- |
| Login page | PASS | Page, field, validation, dan wrong credential rejection OK |
| System Manager login/logout | PASS | Login, landing, logout, post-logout block OK |
| System Admin login/logout | PASS | Login, landing, logout, post-logout block OK |
| Business Owner login/logout | PASS | Login, ownership view, logout, post-logout block OK |
| Branch Manager login/logout | PASS | Issue menu/scope clarity diselesaikan dalam Bahagian 2A |
| Customer login/logout | PASS | Login ke Customer Portal, logout, post-logout block OK |
| Session security selepas logout | PASS | Semua persona tidak boleh akses semula landing selepas logout |
| UI login/logout jelas | PASS | Login heading, email field, password field, placeholder, button, validation, dan wrong credential rejection dikesan melalui HTML/manual-equivalent check |

### Issue Table Bahagian 2

| Test ID | Persona | Page / Module | Expected Result | Actual Result | Status | Screenshot Taken? | Nota Fix |
| --- | --- | --- | --- | --- | --- | --- | --- |
| LP-BM-LOGIN-05 | Branch Manager | Branch Manager dashboard/menu | Tiada owner/admin/platform menu atau link luar branch assigned | RESOLVED 2A: Branch Manager dashboard/menu kini branch-scoped | RESOLVED | Tidak | Tiada fix lanjut untuk Bahagian 2 |
| LP-LOGIN-02 | Login Page | Login form UI | Email/username dan password jelas | RESOLVED 2A: heading, field, placeholder, button, dan validation dikesan jelas | RESOLVED | Tidak | Tiada fix lanjut untuk Bahagian 2 |

### Keputusan Akhir Bahagian 2

| Item | Result |
| --- | --- |
| Semua persona boleh login | PASS |
| Semua persona masuk dashboard/portal betul | PASS |
| Semua persona boleh logout | PASS |
| Tiada akses selepas logout | PASS |
| Boleh terus ke Bahagian 3 Access Control Test | YA, dengan 1 ISSUE menu/scope Branch Manager dibawa ke Bahagian 3 |

Keputusan: BOLEH TERUS KE BAHAGIAN 3 Access Control Test.

## Bahagian 2A: Resolve & Retest Login/Logout Issues

Tarikh semakan: 2026-07-05

### Issue Asal & Tindakan Fix

| Test ID | Issue Asal | Tindakan Fix | Status Akhir |
| --- | --- | --- | --- |
| LP-BM-LOGIN-05 | Branch Manager nampak teks `Business Owner` dan link business-level yang mengelirukan | Navigation `Businesses` disembunyikan untuk pure Branch Manager. Dashboard Branch Manager ditukar kepada copy dan quick actions branch-level: Assigned Branch Overview, Branch Check-ins, Branch Feedback, Branch Rewards | RESOLVED |
| LP-LOGIN-02 | Field login hanya disahkan melalui HTML check dan visual clarity belum cukup kuat | Login page ditambah heading `Log in to GOS-F&B`, helper text, placeholder email, dan placeholder password | RESOLVED |

### Command / Check Dijalankan

| Command / Check | Tujuan | Result |
| --- | --- | --- |
| `php -l` fail disentuh | Syntax check | PASS |
| `php artisan test tests/Feature/LoginLogoutPilotTest.php` | Focused coverage untuk login page dan Branch Manager menu | PASS, 2 tests |
| `php artisan test tests/Feature/Auth/AuthenticationTest.php tests/Feature/LoginLogoutPilotTest.php tests/Feature/PersonaAccessTest.php` | Auth/persona smoke regression | PASS, 12 tests |
| HTTP session retest | Retest LP-LOGIN, LP-BM, dan smoke persona lain | PASS |
| `php artisan view:clear` | Pastikan running local guna view terkini | PASS |

### Retest Result LP-LOGIN

| Test ID | Retest Result | Status Akhir |
| --- | --- | --- |
| LP-LOGIN-01 | `/login` return 200 | PASS |
| LP-LOGIN-02 | Heading, email field, password field, placeholder, dan button dikesan | PASS |
| LP-LOGIN-03 | Submit kosong redirect balik `/login` dengan validation | PASS |
| LP-LOGIN-04 | Credential salah ditolak dan kekal di `/login` | PASS |

### Retest Result Branch Manager

| Test ID | Retest Result | Status Akhir |
| --- | --- | --- |
| LP-BM-LOGIN-01 | Login berjaya | PASS |
| LP-BM-LOGIN-02 | Masuk `/dashboards/branch-manager` | PASS |
| LP-BM-LOGIN-03 | Assigned branch context dikesan | PASS |
| LP-BM-LOGIN-04 | Branch operation menu/context dikesan | PASS |
| LP-BM-LOGIN-05 | Tiada `Business Owner`, tiada nav `Businesses`, quick actions branch-level sahaja | PASS |
| LP-BM-LOGIN-06 | Logout redirect ke `/login` | PASS |
| LP-BM-LOGIN-07 | Dashboard blocked selepas logout | PASS |

### Smoke Check Persona Lain

| Persona | Result | Catatan |
| --- | --- | --- |
| System Manager | PASS | Login, landing, logout, post-logout block OK |
| System Admin | PASS | Login, landing, logout, post-logout block OK |
| Business Owner | PASS | Login, landing owner, logout, post-logout block OK |
| Customer | PASS | Login Customer Portal, logout, post-logout block OK |

### Keputusan Akhir Selepas 2A

| Item | Result |
| --- | --- |
| Semua issue Bahagian 2 selesai | PASS |
| Semua persona boleh login/logout | PASS |
| Semua persona masuk dashboard/portal betul | PASS |
| Session security selepas logout | PASS |
| Boleh terus ke Bahagian 3 Access Control Test | YA |

Keputusan 2A: BOLEH TERUS KE BAHAGIAN 3 Access Control Test.

## Bahagian 2B: Capture Purchase & Pending Purchase Capture Alignment

Tarikh semakan: 2026-07-06

### Requirement Dikunci

| Requirement | Status |
| --- | --- |
| Customer tidak buat order/purchase dalam GOS-F&B | PASS |
| Purchase berlaku luar platform; GOS-F&B hanya capture purchase untuk reward, analytics, AI Insight, dan AI Action | PASS |
| Valid check-in sahaja tidak confirm reward | PASS |
| Valid check-in mesti jadi Pending Purchase Capture untuk Branch Manager / BO cum BM sahaja | PASS |
| Reward hanya confirm selepas valid check-in + valid Product/Service purchase capture | PASS |
| Cooldown-blocked check-in tidak create pending reward/stamp | PASS |
| Branch Manager boleh capture purchase atau mark No Purchase | PASS |
| No Purchase tidak auto berlaku hanya kerana lewat diproses | PASS |
| Product sama boleh dicapture semula jika separate valid purchase | PASS |
| Quantity lebih daripada 1 valid | PASS |
| Duplicate palsu dicegah melalui capture reference | PASS |

### Status Flow Dikunci

| Flow | Result |
| --- | --- |
| Valid Check-in | Pending Purchase Capture untuk Branch Manager / BO cum BM assigned branch |
| Purchase Captured | Confirmed Reward |
| No Purchase confirmed | No Reward - No Purchase |
| Unprocessed selepas threshold | Overdue Purchase Capture / Manual Review Required |
| Cooldown / invalid / duplicate | Blocked / No reward update |
| Customer feedback | Feedback bebas melalui `Hantar Maklumbalas`, bukan wajib selepas purchase |

### Dummy / Master Data Readiness

| Data | Result | Catatan |
| --- | --- | --- |
| Business | PASS | 2 business tersedia |
| Branch | PASS | 2 branch tersedia |
| Persona users | PASS | System Manager, System Admin, Business Owner, Branch Manager, Customer tersedia |
| Product/Service | PASS | Product/Service tersedia dan list boleh digroup mengikut kategori |
| Reward rule | PASS | 2 loyalty/reward rules tersedia |
| Branch assignment | PASS | Branch Manager assigned ke `WANCHU-MAIN` |

### Product/Service Category Management

| Requirement | Status |
| --- | --- |
| Default category tersedia: Makanan, Minuman, Set Kombo, Add-on | PASS |
| `Lain-lain` tidak lagi menjadi default category kerana BM boleh tambah kategori sendiri | PASS |
| Product/Service list guna category tabs termasuk `Semua` dan custom category | PASS |
| Item dalam kategori sorted alphabetical by name | PASS |
| BM boleh pilih existing category atau tambah kategori baharu | PASS |
| BM/BO cum BM boleh tukar kategori semasa edit Product/Service | PASS |
| BO alert wujud untuk suspicious Product/Service dan kategori custom baharu | PASS |
| Capture Purchase masih guna Product/Service list; GOS-F&B kekal bukan POS/order/cart/payment | PASS |

### Issue / Fix

| Area | Gap Sebelum Fix | Fix Dibuat | Status |
| --- | --- | --- | --- |
| Customer check-in status | Rule lama pernah memaparkan pending purchase kepada customer | Customer message diselaraskan kepada check-in berjaya direkod sahaja | RESOLVED |
| Customer portal | Rule lama pernah memaparkan Pending Purchase Capture kepada customer | Customer portal diselaraskan: hanya confirmed reward/stamp dan feedback bebas | RESOLVED |
| Branch Manager check-ins | Pending/Overdue/Manual/No Purchase tidak cukup jelas | Tambah status label, Capture Purchase form, dan Mark No Purchase action | RESOLVED |
| Branch Manager dashboard | Pending/Overdue/Manual Review belum dibezakan | Tambah count/status untuk Pending Purchase Capture, Overdue Purchase Capture, Manual Review Required | RESOLVED |
| Reward flow | No Purchase action belum jelas | Tambah `No Reward - No Purchase`; tiada stamp dan tiada feedback wajib | RESOLVED |

### Command / Check Dijalankan

| Command / Check | Tujuan | Result |
| --- | --- | --- |
| `php artisan about --only=environment` | Semak app bootstrap | PASS |
| `php artisan migrate:status` | Semak migration | PASS |
| `php -l` fail PHP disentuh | Syntax check | PASS |
| `php artisan test tests/Feature/PurchaseCaptureAlignmentTest.php` | Focused 2B tests | PASS, 9 tests |
| `php artisan test` focused check-in/product/reward/feedback/auth/persona | Regression berkaitan | PASS, 59 tests |
| `php artisan view:clear` | Refresh view selepas perubahan UI | PASS |

### Focused Test Result

| Test Scope | Result |
| --- | --- |
| Valid check-in creates Pending Purchase Capture | PASS |
| Pending Purchase Capture not visible to Customer | PASS |
| Pending Purchase Capture visible to Branch Manager | PASS |
| Valid check-in does not create Confirmed Reward immediately | PASS |
| Cooldown-blocked check-in does not create pending reward/stamp | PASS |
| Branch Manager capture purchase converts pending to confirmed reward | PASS |
| Capture purchase does not create mandatory pending feedback | PASS |
| Branch Manager mark No Purchase creates No Reward - No Purchase | PASS |
| Delayed/unprocessed pending does not auto-cancel reward as No Reward | PASS |
| Product same can be captured again as separate valid purchase | PASS |
| Quantity > 1 accepted | PASS |
| Fake duplicate purchase capture blocked | PASS |

### Keputusan Akhir Bahagian 2B

| Item | Result |
| --- | --- |
| Capture Purchase Alignment | PASS |
| Pending Purchase Capture clarity | PASS |
| Pending Reward clarity | PASS |
| Dummy/master data readiness | PASS |
| Issue/BLOCKER tinggal | Tiada |
| Boleh terus ke Bahagian 3 Access Control Test | YA |

Keputusan 2B: CAPTURE PURCHASE ALIGNMENT PASS. BOLEH TERUS KE BAHAGIAN 3 Access Control Test.

## Bahagian 2C: Role/Access & Business Owner cum Branch Manager Alignment

Tarikh semakan: 2026-07-06

### Requirement Dikunci

| Requirement | Status |
| --- | --- |
| Business Owner cum Branch Manager dibenarkan jika intentional | PASS |
| UI combined role mesti ada tab `Business Performance` dan `Branch Operations` | PASS |
| Business Performance ialah owner-level scope | PASS |
| Branch Operations ialah branch daily operation scope | PASS |
| Multi-branch Branch Manager mesti nampak branch context jelas | PASS |
| System Admin setup semua user untuk Controlled Pilot | PASS |
| Business Owner invite/user creation ditangguh selepas Controlled Pilot | PASS |
| Business Owner tidak boleh create Customer manual | PASS |
| Customer onboarding mesti organik melalui QR/check-in/customer portal | PASS |
| Satu branch boleh ada lebih daripada satu Branch Manager | PASS |

### Business Owner cum Branch Manager UI Rule

| Tab | Scope | Kandungan Minimum |
| --- | --- | --- |
| Business Performance | Owner-level | Business overview, branch comparison, Product/Service performance, reward summary, feedback summary, analytics, AI Insight, AI Action, alerts |
| Branch Operations | Assigned branch-level | Assigned/current branch, pending purchase capture, overdue purchase capture, manual review, capture purchase, today check-ins, branch rewards, branch feedback |

### Check-and-Balance Role/Access Rules

| Rule | Status |
| --- | --- |
| Detect existing role/access sebelum save | PASS |
| Dual-role Business Owner / Branch Manager perlu intentional confirmation | PASS |
| Customer role tidak boleh digabung dengan internal/business/branch role | PASS |
| Customer profile conflict perlu review | PASS |
| Branch scope mesti guna Branch Manager role | PASS |
| Branch Manager tidak boleh assigned ke branch luar selected business | PASS |
| Business Owner tidak boleh assigned business yang bukan milik/approved scope | PASS |
| Non-admin tidak boleh buat controlled pilot user setup | PASS |
| Business Owner invite disabled untuk Controlled Pilot | PASS |

### Controlled Pilot User Setup Rule

Untuk Controlled Pilot, semua user/role/access setup dibuat oleh System Admin dahulu. Business Owner invite/tambah user adalah later-phase sahaja dan mesti limited kepada Branch Manager atau branch staff yang approved, dalam business sendiri sahaja. Business Owner tidak boleh invite Customer, System Admin, System Manager, atau Business Owner lain.

### Implementation Summary

| Area | Perubahan |
| --- | --- |
| Combined dashboard | Tambah tab jelas `Business Performance` dan `Branch Operations` |
| Branch Manager picker | Hanya user dengan role/secondary role Branch Manager boleh dipilih sebagai branch manager |
| Role/access guard | Tambah guard service untuk Controlled Pilot role/access validation |
| Multiple Branch Manager | Disokong melalui branch scope pada user; lebih daripada satu Branch Manager boleh akses branch sama |
| Documentation | Rule pilot dan restriction direkod dalam dokumen Step 2 |

### Command / Check Dijalankan

| Command / Check | Tujuan | Result |
| --- | --- | --- |
| `php artisan about --only=environment` | Semak app bootstrap | PASS |
| `php artisan migrate:status` | Semak migration | PASS |
| `php -l` fail disentuh | Syntax check | PASS |
| Focused 2C tests | Role/access + dual persona UI | PASS |
| Regression tests berkaitan | Auth/persona/dashboard/branch/check-in/purchase | PASS |
| `php artisan view:clear` | Refresh view | PASS |

### Focused Test Result

| Test Scope | Result |
| --- | --- |
| Business Owner cum Branch Manager sees `Business Performance` tab | PASS |
| Business Owner cum Branch Manager sees `Branch Operations` tab | PASS |
| Pure Business Owner does not get misleading Branch Manager-only operations | PASS |
| Pure Branch Manager does not see Business Owner performance tab | PASS |
| Combined role remains within own business/assigned branch scope | PASS |
| System Admin can validate intentional dual role | PASS |
| Dual-role requires explicit intentional confirmation | PASS |
| One branch can have multiple Branch Managers | PASS |
| Branch Manager outside selected business validation error | PASS |
| Business Owner cannot invite/create Customer manually | PASS |
| Business Owner cannot assign System Admin/System Manager | PASS |
| Business Owner cannot assign user to another business | PASS |

### Keputusan Akhir Bahagian 2C

| Item | Result |
| --- | --- |
| Role/access alignment | PASS |
| Business Owner cum Branch Manager UI | PASS |
| Controlled Pilot user setup rule | PASS |
| Issue/BLOCKER tinggal | Tiada |
| Boleh terus ke Bahagian 3 Access Control Test | YA, selepas commit 2C |

Keputusan 2C: STEP 2C ROLE/ACCESS ALIGNMENT PASS.

## Bahagian 3.0: Access Control Scope & Matrix

Tarikh semakan: 2026-07-06

Tujuan Bahagian 3.0 ialah mengunci scope access sebelum Bahagian 3.1 full Access Control Test. Bahagian ini hanya scope dan matrix; belum menjalankan full route-by-route access test.

### Persona Scope Dikunci

| Persona | Fokus | Boleh Akses | Tidak Boleh Akses |
| --- | --- | --- | --- |
| System Manager | GOS Sdn Bhd / platform business performance | Platform performance, platform/business revenue jika data wujud, vertical/category analytics, platform AI Insight, platform AI Action | Customer Portal, branch operation harian, manual customer action, user setup/admin support harian |
| System Admin | System setup, support, correction, check-and-balance | User setup, role/access assignment, business/branch setup, platform usage support, admin/support analytics, admin/support AI Insight/Action | Commercial strategy view System Manager, Customer Portal, owner business strategy sebagai dirinya sendiri |
| Business Owner | Business sendiri sahaja | Own business dashboard, own branch list, own business analytics, own business AI Insight/Action, Business Performance tab | Business orang lain, System Admin area, System Manager area, Customer Portal, manual create Customer |
| Branch Manager | Assigned branch sahaja | Assigned branch dashboard, Branch Operations tab, pending purchase capture, overdue/manual review, capture purchase, mark no purchase, branch feedback/reward | Business Performance tab, business-level owner dashboard, branch lain, System Admin area, System Manager area, Customer Portal |
| Business Owner cum Branch Manager | Owner-level dan branch operation dengan UI jelas | Own business performance, assigned/current branch operations, capture purchase untuk assigned branch, pending/overdue/manual review untuk assigned branch | Business lain, branch luar assignment, System Admin area, System Manager area, Customer Portal |
| Customer | Customer portal sendiri sahaja | Check-in, pending purchase capture status sendiri, confirmed reward sendiri, pending feedback sendiri, feedback history sendiri | Internal dashboard, business analytics, branch dashboard, internal AI Insight/Action, admin/user setup |

### Access Matrix Untuk Bahagian 3.1

Legend: `ALLOW` = boleh akses, `DENY` = tidak boleh akses.

| Surface / Function | System Manager | System Admin | Business Owner | Branch Manager | BO cum BM | Customer |
| --- | --- | --- | --- | --- | --- | --- |
| System Manager dashboard | ALLOW | DENY | DENY | DENY | DENY | DENY |
| System Admin dashboard | DENY | ALLOW | DENY | DENY | DENY | DENY |
| Business Owner dashboard | DENY | DENY | ALLOW own business | DENY | ALLOW own business | DENY |
| Branch Manager dashboard | DENY | DENY | DENY unless assigned | ALLOW assigned branch | ALLOW assigned branch | DENY |
| Business Performance tab | DENY | DENY | ALLOW own business | DENY | ALLOW own business | DENY |
| Branch Operations tab | DENY | DENY | DENY unless assigned | ALLOW assigned branch | ALLOW assigned branch | DENY |
| Customer Portal | DENY | DENY | DENY | DENY | DENY | ALLOW own data |
| Platform analytics | ALLOW | DENY except admin/support view | DENY | DENY | DENY | DENY |
| Admin/support analytics | DENY | ALLOW | DENY | DENY | DENY | DENY |
| Own business analytics | DENY | DENY | ALLOW own business | DENY | ALLOW own business | DENY |
| Assigned branch analytics | DENY | DENY | DENY unless assigned | ALLOW assigned branch | ALLOW assigned branch | DENY |
| Platform AI Insight / AI Action | ALLOW | DENY commercial strategy | DENY | DENY | DENY | DENY |
| Admin/support AI Insight / AI Action | DENY | ALLOW support only | DENY | DENY | DENY | DENY |
| Own business AI Insight / AI Action | DENY | DENY | ALLOW own business | DENY | ALLOW own business | DENY |
| Assigned branch AI Insight / AI Action | DENY | DENY | DENY unless assigned | ALLOW assigned branch | ALLOW assigned branch | DENY |
| Capture Purchase | DENY | DENY except support correction if required | DENY unless assigned | ALLOW assigned branch | ALLOW assigned branch | DENY |
| Mark No Purchase | DENY | DENY except support correction if required | DENY unless assigned | ALLOW assigned branch | ALLOW assigned branch | DENY |
| Pending Purchase Capture list | DENY | DENY except support correction if required | DENY unless assigned | ALLOW assigned branch | ALLOW assigned branch | DENY |
| User/role setup | DENY | ALLOW | DENY for Controlled Pilot | DENY | DENY | DENY |

### Rules Untuk Full Access Control Test

| Rule | Status |
| --- | --- |
| Business Owner cum Branch Manager mesti nampak dua tab: `Business Performance` dan `Branch Operations` | LOCKED |
| Business Owner cum Branch Manager tidak boleh campur data business lain atau branch luar assignment | LOCKED |
| Customer hanya customer portal dan own data sahaja | LOCKED |
| System Admin ialah admin/support, bukan commercial strategy | LOCKED |
| System Manager ialah GOS platform/business strategy, bukan branch operation atau admin support harian | LOCKED |
| Business Owner tidak boleh manual create Customer untuk manipulate analytics/reward | LOCKED |
| User/role setup Controlled Pilot dibuat oleh System Admin sahaja | LOCKED |

### Lightweight Scope Check

| Check | Result |
| --- | --- |
| App bootstrap environment | PASS |
| Route/menu/dashboard scan ringan | PASS |
| Combined-role tab wording wujud | PASS |
| Customer Portal wording wujud | PASS |
| Capture Purchase / Mark No Purchase wording wujud | PASS |
| Full route-by-route access test | Belum dijalankan, masuk Bahagian 3.1 |

### Gap / Issue Awal

Tiada BLOCKER untuk memulakan Bahagian 3.1. Bahagian 3.1 perlu validate actual route access mengikut matrix ini, termasuk `DENY` cases untuk Customer, Branch Manager branch lain, Business Owner business lain, System Admin commercial strategy, dan System Manager admin/support harian.

### Keputusan Bahagian 3.0

| Item | Result |
| --- | --- |
| Access scope dikunci | PASS |
| Access matrix lengkap untuk persona wajib | PASS |
| Gap/BLOCKER awal | Tiada BLOCKER |
| Boleh terus ke Bahagian 3.1 full Access Control Test | YA |

Keputusan 3.0: BAHAGIAN 3.0 ACCESS MATRIX PASS.

## Bahagian 3.1: System Manager Access Control Test

Tarikh semakan: 2026-07-06

Scope Bahagian 3.1 hanya persona System Manager. System Manager fokus kepada GOS Sdn Bhd / platform business performance dan bukan customer portal, branch operation harian, owner operation, atau admin support harian.

### Result Test

| Test ID | Step | Expected Result | Actual Result | Status |
| --- | --- | --- | --- | --- |
| LP-AC-SM-01 | Login sebagai System Manager dan akses System Manager dashboard | Allowed | System Manager dashboard boleh diakses | PASS |
| LP-AC-SM-02 | Akses platform/GOS business analytics/performance | Allowed | System Manager Analytics boleh diakses | PASS |
| LP-AC-SM-03 | Akses platform/GOS AI Insight | Allowed | AI Insight Engine untuk platform boleh dilihat | PASS |
| LP-AC-SM-04 | Akses platform/GOS AI Action | Allowed | AI Action Engine untuk platform boleh dilihat | PASS |
| LP-AC-SM-05 | Cuba akses Customer Portal | Blocked / forbidden | Forbidden | PASS |
| LP-AC-SM-06 | Cuba akses customer-only check-in action | Blocked | Forbidden | PASS |
| LP-AC-SM-07 | Cuba akses Branch Operations / Capture Purchase | Blocked / forbidden / not shown in menu | Forbidden | PASS |
| LP-AC-SM-08 | Cuba akses Mark No Purchase | Blocked | Forbidden | PASS |
| LP-AC-SM-09 | Cuba akses Business Owner dashboard/business-level owner page | Blocked / redirected / not shown in menu | Forbidden | PASS |
| LP-AC-SM-10 | Cuba akses Branch Manager dashboard/branch-level operation page | Blocked / redirected / not shown in menu | Forbidden | PASS |
| LP-AC-SM-11 | Cuba akses System Admin user setup/admin support area | Blocked jika admin-only | Forbidden | PASS |
| LP-AC-SM-12 | Semak navigation/menu System Manager | Platform/GOS analytics link wujud; customer/branch/owner/admin operation menu tiada | Platform Links dan Analytics wujud; menu luar scope tidak dipaparkan | PASS |

### Fix / Alignment Dibuat

| Area | Fix |
| --- | --- |
| System Manager dashboard links | Tukar kepada platform-scoped link `Platform Analytics / AI`; buang business setup link daripada dashboard System Manager |
| Dashboard link label | Link section boleh guna label sesuai persona, contoh `Platform Links` |
| Branch operation endpoints | Pure System Manager diblock daripada check-in operation, online reference creation, capture purchase, dan mark no purchase |
| Business owner operation endpoints | Pure System Manager diblock daripada business dashboard, customer list/detail, follow-up, loyalty setup, dan redeem action |

### Command / Check Dijalankan

| Command / Check | Tujuan | Result |
| --- | --- | --- |
| Route/menu/controller scan ringan | Kenal pasti surface System Manager | PASS |
| `php artisan test tests/Feature/SystemManagerAccessControlTest.php` | Focused Bahagian 3.1 access test | PASS: 12 tests, 35 assertions |
| `php artisan about --only=environment` | Semak app bootstrap | PASS |
| `php artisan migrate:status` | Semak migration status | PASS |
| `php -l` touched PHP files | Syntax check | PASS |
| Focused regression auth/persona/dashboard/menu | Pastikan route dashboard dan persona utama tidak regress | PASS |
| `php artisan view:clear` | Clear compiled views selepas view change | PASS |
| `git diff --check` | Whitespace check | PASS |

### Issue / Blocker

Tiada ISSUE/BLOCKER tinggal untuk Bahagian 3.1.

### Keputusan Bahagian 3.1

| Item | Result |
| --- | --- |
| System Manager allowed platform/dashboard/analytics/AI scope | PASS |
| System Manager blocked daripada Customer Portal dan customer action | PASS |
| System Manager blocked daripada branch operations/capture/no purchase | PASS |
| System Manager blocked daripada owner/branch/admin dashboard luar scope | PASS |
| Navigation System Manager jelas platform-scoped | PASS |
| Boleh terus ke Bahagian 3.2 System Admin Access Control Test | YA, selepas commit 3.1 |

Keputusan 3.1: BAHAGIAN 3.1 SYSTEM MANAGER ACCESS CONTROL PASS.

## Bahagian 3.2: System Admin Access Control Test

Tarikh semakan: 2026-07-06

Pre-check: commit Bahagian 3.1 `b0cd2ae2d69448ae593fa74a6a3fc27412367828` sudah pushed ke `origin/main`. `main` dan `origin/main` selari sebelum Bahagian 3.2 dimulakan.

Scope Bahagian 3.2 hanya persona System Admin. System Admin fokus kepada system setup, admin/support, correction, role/access check-and-balance, dan platform usage support. System Admin bukan System Manager commercial strategy, bukan Business Owner persona, bukan Branch Manager operation persona, dan bukan Customer Portal user.

### Result Test

| Test ID | Step | Expected Result | Actual Result | Status |
| --- | --- | --- | --- | --- |
| LP-AC-SA-01 | Login sebagai System Admin dan akses System Admin dashboard | Allowed | System Admin dashboard boleh diakses | PASS |
| LP-AC-SA-02 | Akses user/account/admin support area | Allowed | Dashboard admin menunjukkan user/support setup status | PASS |
| LP-AC-SA-03 | Akses role/access assignment atau setup area | Allowed dengan check-and-balance jika flow tersedia | Guard role/access Controlled Pilot membenarkan System Admin setup dengan validation | PASS |
| LP-AC-SA-04 | Akses business/branch setup area | Allowed | Business create, branch create, branch edit boleh diakses | PASS |
| LP-AC-SA-05 | Akses platform usage/support analytics | Allowed untuk admin/support purpose sahaja | System Admin Analytics boleh diakses, bukan strategy platform | PASS |
| LP-AC-SA-06 | Akses admin/support AI Insight | Allowed untuk support/admin purpose sahaja | AI Insight admin/support boleh dilihat | PASS |
| LP-AC-SA-07 | Akses admin/support AI Action | Allowed untuk support/admin purpose sahaja | AI Action admin/support boleh dilihat | PASS |
| LP-AC-SA-08 | Cuba akses System Manager commercial strategy/platform business strategy area | Blocked / redirected / not shown | System Manager dashboard forbidden; analytics tidak tunjuk System Manager scope | PASS |
| LP-AC-SA-09 | Cuba akses Customer Portal | Blocked / forbidden | Forbidden | PASS |
| LP-AC-SA-10 | Cuba akses customer-only check-in action | Blocked | Forbidden | PASS |
| LP-AC-SA-11 | Cuba akses Business Owner dashboard/business strategy page sebagai owner | Blocked kecuali support/admin route explicit | Forbidden | PASS |
| LP-AC-SA-12 | Cuba akses Branch Manager operation dashboard / Capture Purchase | Blocked kecuali support/correction route explicit | Forbidden | PASS |
| LP-AC-SA-13 | Cuba akses Mark No Purchase sebagai Branch Manager operation user | Blocked kecuali support/correction route explicit | Forbidden | PASS |
| LP-AC-SA-14 | Semak navigation/menu System Admin | Admin/support links wujud; customer/owner/branch/system-manager strategy menu tiada | Admin Links, Analytics, Business setup, Create business wujud; menu luar scope tiada | PASS |

### Fix / Alignment Dibuat

| Area | Fix |
| --- | --- |
| System Admin operation boundary | System Admin diblock daripada branch operation endpoints: branch check-ins, online reference operation, capture purchase, dan mark no purchase |
| System Admin owner/persona boundary | System Admin diblock daripada business owner strategy dashboard, customer list/detail operation, follow-up, loyalty setup, dan redeem action sebagai owner persona |
| Dashboard label | System Admin dashboard link section dilabel `Admin Links` untuk lebih jelas |
| Internal combined label | Internal combined dashboard link section dilabel `Internal Links` |

### Command / Check Dijalankan

| Command / Check | Tujuan | Result |
| --- | --- | --- |
| `git status -sb` | Pre-check 3.1 pushed | PASS |
| `git log --oneline origin/main..HEAD` | Pre-check commit pending | PASS, kosong |
| Route/menu/controller scan ringan | Kenal pasti surface System Admin | PASS |
| `php artisan test tests/Feature/SystemAdminAccessControlTest.php` | Focused Bahagian 3.2 access test | PASS: 14 tests, 50 assertions |
| `php artisan about --only=environment` | Semak app bootstrap | PASS |
| `php artisan migrate:status` | Semak migration status | PASS |
| `php -l` touched PHP files | Syntax check | PASS |
| Focused regression auth/persona/dashboard/menu | Pastikan persona/dashboard utama tidak regress | PASS |
| `php artisan view:clear` | Clear compiled views selepas view change | PASS |
| `git diff --check` | Whitespace check | PASS |

### Issue / Blocker

Tiada ISSUE/BLOCKER tinggal untuk Bahagian 3.2.

### Keputusan Bahagian 3.2

| Item | Result |
| --- | --- |
| System Admin allowed admin/support dashboard, setup, analytics, AI scope | PASS |
| System Admin blocked daripada System Manager commercial strategy scope | PASS |
| System Admin blocked daripada Customer Portal dan customer check-in action | PASS |
| System Admin blocked daripada owner dashboard dan branch operation/capture/no purchase | PASS |
| Navigation System Admin jelas admin/support-scoped | PASS |
| Boleh terus ke Bahagian 3.3 Business Owner Access Control Test | YA, selepas commit 3.2 |

Keputusan 3.2: BAHAGIAN 3.2 SYSTEM ADMIN ACCESS CONTROL PASS.

## Bahagian 3.3: Business Owner Access Control Test

Tarikh semakan: 2026-07-06

Scope Business Owner ialah business sendiri sahaja. Business Owner boleh lihat business performance, business page, own branch page, analytics, AI Insight, dan AI Action untuk business sendiri. Business Owner tidak boleh masuk branch operation/capture/no purchase jika tidak ada Branch Manager assignment.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-AC-BO-01 | Business Owner dashboard allowed | Allowed | PASS |
| LP-AC-BO-02 | Own business page allowed | Allowed | PASS |
| LP-AC-BO-03 | Own branch page allowed | Allowed | PASS |
| LP-AC-BO-04 | Own business analytics/performance allowed | Allowed | PASS |
| LP-AC-BO-05 | Own business AI Insight allowed jika tersedia | Allowed | PASS |
| LP-AC-BO-06 | Own business AI Action allowed jika tersedia | Allowed | PASS |
| LP-AC-BO-07 | Business orang lain blocked | Forbidden | PASS |
| LP-AC-BO-08 | Branch business lain blocked | Forbidden | PASS |
| LP-AC-BO-09 | System Admin area blocked | Forbidden | PASS |
| LP-AC-BO-10 | System Manager area blocked | Forbidden | PASS |
| LP-AC-BO-11 | Customer Portal blocked | Forbidden | PASS |
| LP-AC-BO-12 | Branch Operations / Capture Purchase tanpa BM assignment blocked/not shown | Forbidden / not shown | PASS |
| LP-AC-BO-13 | Mark No Purchase tanpa BM assignment blocked | Forbidden | PASS |
| LP-AC-BO-14 | Create/invite Customer manual blocked/not available | Blocked by Controlled Pilot guard | PASS |
| LP-AC-BO-15 | Menu Business Owner tidak bercampur scope | Own business scope sahaja | PASS |

Keputusan 3.3: BUSINESS OWNER ACCESS CONTROL PASS.

## Bahagian 3.4: Branch Manager Access Control Test

Tarikh semakan: 2026-07-06

Scope Branch Manager ialah assigned branch sahaja. Branch Manager boleh masuk branch operation, pending purchase capture, capture purchase, mark no purchase, branch feedback, branch reward, dan assigned branch analytics jika tersedia. Branch Manager tidak boleh masuk owner/system/admin/customer scope atau branch lain.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-AC-BM-01 | Branch Manager dashboard allowed | Allowed | PASS |
| LP-AC-BM-02 | Assigned branch page allowed | Allowed | PASS |
| LP-AC-BM-03 | Assigned branch operation/capture area allowed | Allowed | PASS |
| LP-AC-BM-04 | Assigned branch Pending Purchase Capture list allowed | Allowed | PASS |
| LP-AC-BM-05 | Capture Purchase assigned branch allowed | Allowed | PASS |
| LP-AC-BM-06 | Mark No Purchase assigned branch allowed | Allowed | PASS |
| LP-AC-BM-07 | Assigned branch feedback/reward allowed | Allowed | PASS |
| LP-AC-BM-08 | Business Performance tab blocked/not shown | Not shown | PASS |
| LP-AC-BM-09 | Business Owner dashboard/business-level owner page blocked | Forbidden | PASS |
| LP-AC-BM-10 | Branch lain blocked | Forbidden | PASS |
| LP-AC-BM-11 | Business lain blocked | Forbidden | PASS |
| LP-AC-BM-12 | System Admin area blocked | Forbidden | PASS |
| LP-AC-BM-13 | System Manager area blocked | Forbidden | PASS |
| LP-AC-BM-14 | Customer Portal blocked | Forbidden | PASS |
| LP-AC-BM-15 | Menu Branch Manager assigned branch sahaja | PASS | PASS |

Keputusan 3.4: BRANCH MANAGER ACCESS CONTROL PASS.

## Bahagian 3.5: Business Owner cum Branch Manager Access Control Test

Tarikh semakan: 2026-07-06

Scope Business Owner cum Branch Manager ialah gabungan intentional: owner/business performance + assigned branch operations. UI mesti memisahkan `Business Performance` dan `Branch Operations`.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-AC-BOBM-01 | Login allowed dan masuk combined dashboard | Allowed | PASS |
| LP-AC-BOBM-02 | Business Performance tab visible/allowed | Visible | PASS |
| LP-AC-BOBM-03 | Branch Operations tab visible/allowed | Visible | PASS |
| LP-AC-BOBM-04 | Own business performance/analytics allowed | Allowed | PASS |
| LP-AC-BOBM-05 | Own business AI Insight/AI Action allowed jika tersedia | Allowed | PASS |
| LP-AC-BOBM-06 | Assigned/current branch operations allowed | Allowed | PASS |
| LP-AC-BOBM-07 | Capture Purchase assigned branch allowed | Allowed | PASS |
| LP-AC-BOBM-08 | Mark No Purchase assigned branch allowed | Allowed | PASS |
| LP-AC-BOBM-09 | Business lain blocked | Forbidden | PASS |
| LP-AC-BOBM-10 | Branch luar assignment blocked | Forbidden | PASS |
| LP-AC-BOBM-11 | System Admin area blocked | Forbidden | PASS |
| LP-AC-BOBM-12 | System Manager area blocked | Forbidden | PASS |
| LP-AC-BOBM-13 | Customer Portal blocked | Forbidden | PASS |
| LP-AC-BOBM-14 | Create/invite Customer manual blocked/not available | Blocked by Controlled Pilot guard | PASS |
| LP-AC-BOBM-15 | Menu/tabs combined jelas dan tidak bercampur admin/system/customer scope | PASS | PASS |

Keputusan 3.5: BUSINESS OWNER CUM BRANCH MANAGER ACCESS CONTROL PASS.

## Bahagian 3.6: Customer Access Control Test

Tarikh semakan: 2026-07-06

Scope Customer ialah Customer Portal dan own data sahaja. Customer tidak boleh masuk internal dashboard, analytics, AI Insight, AI Action, business/branch/admin pages, Capture Purchase, atau Mark No Purchase.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-AC-CUST-01 | Customer Portal allowed | Allowed | PASS |
| LP-AC-CUST-02 | Own check-in/status allowed | Allowed | PASS |
| LP-AC-CUST-03 | Pending Purchase Capture status tidak dipaparkan kepada Customer | Not shown | PASS |
| LP-AC-CUST-04 | Own confirmed reward/history allowed | Allowed | PASS |
| LP-AC-CUST-05 | Customer feedback bebas sendiri allowed | Allowed | PASS |
| LP-AC-CUST-06 | Submit feedback tanpa pending purchase/feedback allowed | Allowed | PASS |
| LP-AC-CUST-07 | Internal dashboard blocked | Forbidden / redirect to login if unauthenticated | PASS |
| LP-AC-CUST-08 | Business Owner dashboard/business page blocked | Forbidden | PASS |
| LP-AC-CUST-09 | Branch Manager dashboard/branch operations blocked | Forbidden | PASS |
| LP-AC-CUST-10 | System Admin area blocked | Forbidden | PASS |
| LP-AC-CUST-11 | System Manager area blocked | Forbidden | PASS |
| LP-AC-CUST-12 | Internal analytics blocked | Forbidden | PASS |
| LP-AC-CUST-13 | Internal AI Insight / AI Action blocked | Forbidden via analytics route | PASS |
| LP-AC-CUST-14 | Capture Purchase blocked | Forbidden | PASS |
| LP-AC-CUST-15 | Mark No Purchase blocked | Forbidden | PASS |
| LP-AC-CUST-16 | Customer lain reward/feedback/status blocked jika route ada ID | Not found / blocked | PASS |
| LP-AC-CUST-17 | Menu Customer customer-only sahaja | PASS | PASS |

Keputusan 3.6: CUSTOMER ACCESS CONTROL PASS.

## Bahagian 3.7: Cross-Persona Regression / Final Access Review

Tarikh semakan: 2026-07-06

Cross-persona regression dibuat selepas 3.3 hingga 3.6 untuk pastikan scope tidak bercampur.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-AC-FINAL-01 | Semua persona login/logout masih PASS | Login/logout regression PASS | PASS |
| LP-AC-FINAL-02 | Session selepas logout block semua persona | Protected routes redirect login selepas logout | PASS |
| LP-AC-FINAL-03 | Menu setiap persona tidak bercampur scope | Menu scoped mengikut persona | PASS |
| LP-AC-FINAL-04 | System Manager tidak masuk System Admin/Owner/Branch/Customer areas | Blocked | PASS |
| LP-AC-FINAL-05 | System Admin tidak masuk System Manager strategy/Owner persona/Branch operation/Customer portal | Blocked | PASS |
| LP-AC-FINAL-06 | Business Owner tidak masuk Admin/System/Customer/business lain/branch lain | Blocked | PASS |
| LP-AC-FINAL-07 | Branch Manager tidak masuk Admin/System/Customer/Owner/business lain/branch lain | Blocked | PASS |
| LP-AC-FINAL-08 | BO cum BM hanya own business + assigned branch | Enforced | PASS |
| LP-AC-FINAL-09 | Customer hanya own portal/status/reward/feedback | Enforced | PASS |
| LP-AC-FINAL-10 | Capture Purchase hanya branch-authorized persona | Enforced | PASS |
| LP-AC-FINAL-11 | Mark No Purchase hanya branch-authorized persona | Enforced | PASS |
| LP-AC-FINAL-12 | Pending Purchase Capture visibility betul | BM/BO cum BM assigned branch; BO business read-only; Customer not shown | PASS |
| LP-AC-FINAL-13 | Analytics / AI Insight / AI Action scope betul | System Manager platform, System Admin support, BO own business, BM assigned branch, Customer blocked | PASS |
| LP-AC-FINAL-14 | User/role setup scope betul | System Admin allowed, Business Owner restricted/later phase, BM/Customer blocked | PASS |
| LP-AC-FINAL-15 | Dokumen Bahagian 3.0 hingga 3.7 lengkap dan tiada test ID tertinggal | Disemak | PASS |

### Fix / Alignment Dibuat Untuk Bahagian 3.3-3.7

| Area | Fix |
| --- | --- |
| Branch operation guard | Capture Purchase, Mark No Purchase, branch check-in operation, dan online reference operation hanya untuk Branch Manager / BO cum BM yang ada assigned branch |
| Business Owner check-in visibility | Business Owner boleh lihat business-level check-ins secara read-only; operation form tidak dipaparkan |
| Business-level owner pages | Branch Manager, System Admin, dan System Manager diblock daripada owner dashboard/customer/follow-up/loyalty/redeem pages |
| Branch reward operation | Branch reward/redeem hanya untuk branch-authorized persona |
| Regression tests | Capture/reward/feedback helper dikemaskini supaya branch operation dilakukan oleh Branch Manager |

### Command / Check Dijalankan

| Command / Check | Tujuan | Result |
| --- | --- | --- |
| `git status -sb` + `git log --oneline origin/main..HEAD` | Pre-check main selari remote | PASS |
| `php artisan test tests/Feature/RemainingAccessControlTest.php` | Focused 3.3-3.7 access test | PASS: 5 tests, 143 assertions |
| Login/persona/dashboard/access regression | Auth/menu/dashboard/persona | PASS |
| Check-in/purchase/reward/feedback regression | Pastikan launch-ready flow tidak rosak | PASS |
| Analytics/AI Insight/AI Action regression | Scope analytics dan AI | PASS |
| `php artisan about --only=environment` | Semak app bootstrap | PASS |
| `php artisan migrate:status` | Semak migration status | PASS |
| `php -l` touched PHP/test files | Syntax check | PASS |
| `php artisan view:clear` | Clear compiled views selepas view change | PASS |
| `git diff --check` | Whitespace check | PASS |
| Changed-files secret scan | Tiada secret value dikesan | PASS |

### Final Conclusion Bahagian 3

| Item | Result |
| --- | --- |
| Bahagian 3.0 Access Matrix | PASS |
| Bahagian 3.1 System Manager | PASS |
| Bahagian 3.2 System Admin | PASS |
| Bahagian 3.3 Business Owner | PASS |
| Bahagian 3.4 Branch Manager | PASS |
| Bahagian 3.5 BO cum BM | PASS |
| Bahagian 3.6 Customer | PASS |
| Bahagian 3.7 Cross-Persona Final Review | PASS |
| Issue/BLOCKER tinggal | Tiada |

Keputusan Bahagian 3: ACCESS CONTROL TEST PASS.

## Bahagian 3.8: Final Review + Commit + Push Bahagian 3

Tarikh semakan: 2026-07-06

Bahagian 3.8 dibuat untuk semak semula keseluruhan Access Control Test Bahagian 3.0 hingga 3.7 sebelum Bahagian 4 dimulakan.

### Status Bahagian 3

| Bahagian | Scope | Status |
| --- | --- | --- |
| 3.0 | Access Control Scope & Matrix | PASS |
| 3.1 | System Manager Access Control Test | PASS |
| 3.2 | System Admin Access Control Test | PASS |
| 3.3 | Business Owner Access Control Test | PASS |
| 3.4 | Branch Manager Access Control Test | PASS |
| 3.5 | Business Owner cum Branch Manager Access Control Test | PASS |
| 3.6 | Customer Access Control Test | PASS |
| 3.7 | Cross-Persona Final Review | PASS |
| 3.8 | Final Review + Commit + Push Bahagian 3 | PASS |

### Final Review Result

| Item | Result |
| --- | --- |
| Dokumen mengandungi Bahagian 3.0 hingga 3.8 | PASS |
| Semua test ID LP-AC-SM, LP-AC-SA, LP-AC-BO, LP-AC-BM, LP-AC-BOBM, LP-AC-CUST, dan LP-AC-FINAL direkod | PASS |
| System Manager scope kekal platform/GOS business performance | PASS |
| System Admin scope kekal admin/support/setup/check-and-balance | PASS |
| Business Owner scope kekal own business sahaja | PASS |
| Branch Manager scope kekal assigned branch sahaja | PASS |
| BO cum BM scope kekal own business + assigned branch dengan tab jelas | PASS |
| Customer scope kekal Customer Portal sendiri sahaja | PASS |
| Unrelated dirty files tidak disentuh | PASS |
| Secret/credential tidak dikesan dalam perubahan final review | PASS |

### Command / Check Dijalankan

| Command / Check | Tujuan | Result |
| --- | --- | --- |
| `git branch --show-current` | Semak branch semasa | PASS: main |
| `git remote -v` | Semak remote origin | PASS |
| `git status -sb` | Semak status local vs remote | PASS: main selari origin/main sebelum final review docs |
| `git log --oneline origin/main..HEAD` | Semak commit belum push | PASS: kosong sebelum final review docs |
| `php artisan about --only=environment` | Semak app bootstrap | PASS |
| `php artisan migrate:status` | Semak migration status | PASS |
| `php -l` test files Bahagian 3 | Syntax check | PASS |
| `php artisan test tests/Feature/SystemManagerAccessControlTest.php tests/Feature/SystemAdminAccessControlTest.php tests/Feature/RemainingAccessControlTest.php` | Focused Access Control Test | PASS: 31 tests, 228 assertions |
| Regression auth/persona/dashboard/check-in/purchase/reward/feedback/analytics/AI | Semak regression utama | PASS: 120 tests, 690 assertions |
| `php artisan view:clear` | Clear compiled views | PASS |
| `git diff --check` | Whitespace check | PASS |

### Commit / Push Status

| Item | Status |
| --- | --- |
| Commit Bahagian 3.0 | Pushed |
| Commit Bahagian 3.1 | Pushed |
| Commit Bahagian 3.2 | Pushed |
| Commit Bahagian 3.3-3.7 | Pushed |
| Commit Bahagian 3.8 final review | Dibuat dan dipush selepas semakan ini |

### Keputusan Bahagian 3.8

Tiada ISSUE/BLOCKER ditemui untuk Bahagian 3 final review.

Keputusan 3.8: BAHAGIAN 3 FINAL REVIEW + PUSH PASS.

## Bahagian 4: Customer Check-in Test

Tarikh semakan: 2026-07-06

Scope Bahagian 4 ialah Customer check-in sahaja. Customer tidak membuat order/purchase dalam GOS-F&B; pending purchase capture hanya digunakan oleh Branch Manager / BO cum BM.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-OP-CI-01 | Customer login dan Customer Portal allowed | Portal allowed dan customer-only | PASS |
| LP-OP-CI-02 | Valid check-in branch berjaya | Check-in berjaya | PASS |
| LP-OP-CI-03 | Valid check-in tidak confirm reward terus | Tiada stamp/reward granted | PASS |
| LP-OP-CI-04 | Valid check-in create Pending Purchase Capture untuk Branch Manager processing | `pending_product` created secara internal | PASS |
| LP-OP-CI-05 | Customer tidak nampak pending purchase/reward pending state | Customer hanya nampak check-in berjaya direkod | PASS |
| LP-OP-CI-06 | Branch Manager nampak pending assigned branch | Pending muncul di branch check-ins | PASS |
| LP-OP-CI-07 | Check-in semula dalam cooldown ditolak | Cooldown blocked | PASS |
| LP-OP-CI-08 | Cooldown blocked tidak create pending/reward/stamp baru | Tiada check-in/stamp tambahan | PASS |
| LP-OP-CI-09 | Branch invalid/tidak wujud blocked | Validation error | PASS |
| LP-OP-CI-10 | Customer check-in flow tidak expose internal dashboard/menu | Customer portal sahaja; owner dashboard forbidden | PASS |

Keputusan Bahagian 4: CUSTOMER CHECK-IN TEST PASS.

## Bahagian 5: Pending Purchase Capture Test

Tarikh semakan: 2026-07-06

Scope Bahagian 5 ialah status selepas valid check-in sebelum staff/Branch Manager capture purchase.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-OP-PPC-01 | Branch Manager boleh buka Branch Operations / pending purchase capture assigned branch | Allowed | PASS |
| LP-OP-PPC-02 | Pending dari valid check-in muncul | Pending visible | PASS |
| LP-OP-PPC-03 | Pending tunjuk customer, branch, timestamp/status dengan jelas | Customer, branch, status visible | PASS |
| LP-OP-PPC-04 | Customer tidak nampak Pending Purchase Capture | Pending tidak dipaparkan kepada Customer | PASS |
| LP-OP-PPC-05 | Branch Manager hanya nampak assigned branch | Branch lain forbidden / tidak muncul | PASS |
| LP-OP-PPC-06 | Business Owner bukan BM tidak boleh process pending operation | Read-only; action hidden; capture blocked | PASS |
| LP-OP-PPC-07 | BO cum BM boleh access pending assigned branch | Allowed | PASS |
| LP-OP-PPC-08 | Pending lewat tidak auto jadi No Reward | Status Overdue / Manual Review, bukan No Reward | PASS |
| LP-OP-PPC-09 | Pending tidak kelihatan sebagai reward confirmed | Wording reward belum confirm | PASS |
| LP-OP-PPC-10 | Pending list action hanya untuk authorized branch persona | Capture Purchase / Mark No Purchase scoped | PASS |

Keputusan Bahagian 5: PENDING PURCHASE CAPTURE TEST PASS.

## Bahagian 5A: Physical Check-in + Online Check-in Update

Tarikh semakan: 2026-07-11

Scope update ini ialah flow baru `physical` dan `online` untuk Customer Check-in tanpa menjadikan GOS-F&B POS/order/payment system.

| Rule | Result |
| --- | --- |
| Physical Check-in = customer scan QR premis / check-in di kedai | Implemented melalui mode `physical`; QR sedia ada default kepada physical |
| Online Check-in = customer portal/link/code untuk order melalui WhatsApp, delivery, pickup, atau external channel | Implemented melalui mode `online`; online link/code hanya create check-in pending |
| Customer tidak order/purchase dalam platform | Locked; wording customer tidak imply order/payment dalam GOS-F&B |
| Customer tidak self-claim purchase/reward | Locked; request purchase/reward fields daripada customer tidak digunakan |
| BM/BO cum BM assigned branch validate purchase | Capture Purchase kekal internal assigned branch sahaja |
| Pending Purchase Capture customer-hidden | Customer portal/status tidak memaparkan Pending Purchase Capture |
| BM label by mode | `Pending Purchase Capture — Physical` dan `Pending Purchase Capture — Online` |
| No Purchase | Mark No Purchase untuk kedua-dua mode tidak create reward/stamp |
| Reward/stamp | Hanya selepas valid check-in + valid Product/Service Capture |
| Feedback | `Hantar Maklumbalas` kekal bebas; tiada mandatory Pending Feedback |
| Analytics/AI | Mode signal tersedia untuk physical/online count, pending by mode, no purchase by mode, capture conversion by mode; AI Action suggestion-only |

## Bahagian 6: Capture Purchase / Mark No Purchase Test

Tarikh semakan: 2026-07-06

Scope Bahagian 6 ialah staff/Branch Manager capture pembelian yang berlaku di luar platform, atau sahkan customer tidak beli.

### Capture Purchase

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-OP-CP-01 | Branch Manager capture purchase pending assigned branch | Allowed | PASS |
| LP-OP-CP-02 | Product/Service active dari master list boleh dipilih | Product active visible/selectable | PASS |
| LP-OP-CP-03 | Quantity = 1 diterima | Accepted | PASS |
| LP-OP-CP-04 | Quantity > 1 diterima dan total amount betul | Accepted; amount calculated | PASS |
| LP-OP-CP-05 | Quantity 0/negatif ditolak | Validation error | PASS |
| LP-OP-CP-06 | Product inactive/invalid ditolak | Rejected | PASS |
| LP-OP-CP-07 | Capture tanpa valid pending check-in ditolak | Missing check-in not found | PASS |
| LP-OP-CP-08 | Capture untuk branch lain ditolak | Forbidden | PASS |
| LP-OP-CP-09 | Customer self-capture purchase ditolak | Forbidden | PASS |
| LP-OP-CP-10 | Duplicate fake purchase ditolak/dicegah | Duplicate reference ignored; no extra stamp | PASS |
| LP-OP-CP-11 | Product sama boleh dicapture semula untuk separate valid purchase | Allowed dengan reference berbeza | PASS |
| LP-OP-CP-12 | Capture sah convert pending kepada confirmed reward state | Status confirmed/granted | PASS |

### Mark No Purchase

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-OP-MNP-01 | Branch Manager Mark No Purchase assigned branch | Allowed | PASS |
| LP-OP-MNP-02 | Status jadi No Reward - No Purchase | Status jelas | PASS |
| LP-OP-MNP-03 | Tiada reward/stamp | No stamp transaction | PASS |
| LP-OP-MNP-04 | Tiada feedback wajib | Tiada feedback wajib created | PASS |
| LP-OP-MNP-05 | Customer tidak nampak pending/no-reward operation state | Customer hanya nampak reward/stamp confirmed jika layak | PASS |
| LP-OP-MNP-06 | Unauthorized persona Mark No Purchase ditolak | Owner/customer blocked | PASS |

Keputusan Bahagian 6: CAPTURE PURCHASE / MARK NO PURCHASE TEST PASS.

## Bahagian 7: Reward Update Test

Tarikh semakan: 2026-07-06

Scope Bahagian 7 ialah memastikan reward/stamp hanya berubah selepas valid check-in + valid Product/Service capture.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-OP-RW-01 | Selepas valid check-in sahaja reward belum confirm | Pending product; tiada stamp | PASS |
| LP-OP-RW-02 | Selepas capture purchase sah reward/stamp updated | Reward granted; stamp created | PASS |
| LP-OP-RW-03 | Customer nampak confirmed reward/stamp | Confirmed Reward visible | PASS |
| LP-OP-RW-04 | Branch Manager nampak reward status assigned branch | Visible | PASS |
| LP-OP-RW-05 | Business Owner nampak reward summary own business jika tersedia | Visible own business | PASS |
| LP-OP-RW-06 | Mark No Purchase tidak beri reward | No Reward; tiada stamp | PASS |
| LP-OP-RW-07 | Cooldown blocked tidak beri reward/stamp | Tiada stamp tambahan | PASS |
| LP-OP-RW-08 | Duplicate fake purchase tidak tambah reward/stamp | Stamp tidak duplicate | PASS |
| LP-OP-RW-09 | Quantity > 1 tidak rosakkan reward rule semasa | Capture valid; stamp rule kekal 1 per valid check-in | PASS |
| LP-OP-RW-10 | Customer tidak boleh manipulate reward sendiri | Reward operation forbidden | PASS |

Keputusan Bahagian 7: REWARD UPDATE TEST PASS.

## Bahagian 8: Free Feedback & Feedback Submission Test

Tarikh semakan: 2026-07-06

Scope Bahagian 8 ialah feedback bebas oleh Customer. Feedback tidak wajib selepas purchase, tidak memerlukan check-in/purchase, dan tidak memberi reward/stamp.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-OP-FB-01 | Capture purchase sah tidak create feedback wajib | Tiada Pending Feedback created | PASS |
| LP-OP-FB-02 | Customer nampak form `Hantar Maklumbalas` bebas | Form visible; tiada Pending Feedback | PASS |
| LP-OP-FB-03 | Customer submit feedback valid tanpa purchase/check-in wajib | Submitted | PASS |
| LP-OP-FB-04 | Selepas submit, feedback masuk history | Status submitted | PASS |
| LP-OP-FB-05 | Feedback history customer updated | Comment visible to customer | PASS |
| LP-OP-FB-06 | Branch Manager nampak feedback assigned branch | Visible | PASS |
| LP-OP-FB-07 | Business Owner nampak feedback summary own business jika tersedia | Visible own business | PASS |
| LP-OP-FB-08 | Customer submit feedback tanpa pending allowed jika input valid | Allowed | PASS |
| LP-OP-FB-09 | Customer tidak nampak feedback customer lain | Other customer feedback hidden | PASS |
| LP-OP-FB-10 | Mark No Purchase tidak create feedback wajib | Tiada feedback wajib | PASS |
| LP-OP-FB-11 | Cooldown/invalid check-in tidak create feedback wajib | Tiada feedback tambahan | PASS |
| LP-OP-FB-12 | Rating/comment validation | Invalid rating rejected; valid comment accepted | PASS |

### Fix / Alignment Dibuat Untuk Blok A

| Area | Fix |
| --- | --- |
| Customer feedback bebas | Customer feedback portal membenarkan feedback umum tanpa pending purchase, purchase capture, atau check-in |
| Customer feedback UI | Label dikunci sebagai `Hantar Maklumbalas`; label `Hantar Maklumbalas Lain` tidak digunakan |
| Purchase capture feedback | Capture Purchase tidak lagi create Pending Feedback wajib |
| Core operation coverage | `CoreOperationFlowTest` ditambah untuk check-in, pending purchase, capture/no purchase, reward, dan feedback |

### Dummy / Master Data Readiness

| Data | Status |
| --- | --- |
| Business | PASS |
| Branch | PASS |
| Branch Manager assigned | PASS |
| Business Owner | PASS |
| BO cum BM | PASS |
| Customer | PASS |
| Product/Service active | PASS |
| Reward rule active | PASS |
| Check-in scenario | PASS |
| Purchase scenario | PASS |
| No-purchase scenario | PASS |

### Command / Check Blok A

| Command / Check | Tujuan | Result |
| --- | --- | --- |
| `git status -sb` + `git log --oneline origin/main..HEAD` | Pre-check main selari remote; ada commit lokal Blok A belum push | PASS |
| `php artisan test tests/Feature/PurchaseCaptureAlignmentTest.php tests/Feature/CoreOperationFlowTest.php tests/Feature/FeedbackLaunchReadinessTest.php` | Focused customer pending/feedback realignment | PASS: 30 tests, 307 assertions |
| Auth/persona/access/customer portal/check-in/purchase/reward/feedback regression | Pastikan flow utama tidak regress | PASS: 108 tests, 576 assertions |
| Old wording search selepas fix | Pastikan rule lama tidak tinggal sebagai behavior aktif | PASS; baki rujukan hanya negative assertions / rule baru |

### Final Conclusion Blok A

| Item | Result |
| --- | --- |
| Bahagian 4 Customer Check-in | PASS |
| Bahagian 5 Pending Purchase Capture | PASS |
| Bahagian 6 Capture Purchase / Mark No Purchase | PASS |
| Bahagian 7 Reward Update | PASS |
| Bahagian 8 Free Feedback & Feedback Submission | PASS |
| Issue/BLOCKER tinggal | Tiada |
| Blok B dimulakan | Tidak |

Keputusan Blok A Bahagian 4-8: CORE OPERATION FLOW PASS.

### Requirement Realignment: Customer Pending / Feedback Rule Update

Tarikh semakan: 2026-07-06

| Area | Rule Baru | Status |
| --- | --- | --- |
| Customer task | Customer hanya check-in dan melihat reward/stamp confirmed yang layak | PASS |
| Pending Purchase Capture | Hanya Branch Manager / BO cum BM assigned branch boleh lihat dan proses | PASS |
| Customer pending visibility | Customer tidak nampak Pending Purchase Capture atau reward pending purchase state | PASS |
| Flow A Customer beli | Customer Check-in -> Purchase outside platform -> Branch Manager Capture Purchase -> Reward/Stamp confirmed -> Customer sees confirmed reward/stamp | PASS |
| Flow B Customer tidak beli | Customer Check-in -> Branch Manager Mark No Purchase -> No reward/stamp | PASS |
| Feedback | Customer boleh hantar `Hantar Maklumbalas` secara bebas tanpa purchase/check-in wajib | PASS |
| Feedback vs reward | Feedback tidak trigger reward/stamp dan tidak close pending purchase capture | PASS |
| Purchase capture vs feedback | Capture Purchase tidak create Pending Feedback wajib | PASS |

Keputusan realignment: CUSTOMER PENDING / FEEDBACK RULE UPDATE PASS.

## Bahagian 9: Analytics Update Test

Tarikh semakan: 2026-07-06

Scope Bahagian 9 ialah memastikan data Blok A masuk analytics tanpa mengubah rule operasi. Customer hanya check-in; Purchase berlaku di luar platform; GOS-F&B hanya capture purchase untuk reward, feedback signal, analytics, AI Insight, dan AI Action.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-INT-AN-01 | Baseline analytics boleh dibaca | Business Owner analytics dibuka tanpa error | PASS |
| LP-INT-AN-02 | Valid check-in ubah count analytics | Check-in masuk Total check-ins / Core Operation Analytics | PASS |
| LP-INT-AN-03 | Check-in tanpa purchase ubah pending internal analytics | Pending purchase capture dan check-ins without capture direkod | PASS |
| LP-INT-AN-04 | Capture purchase sah ubah purchase analytics | Total transaction/capture dan sales berubah | PASS |
| LP-INT-AN-05 | Capture purchase sah ubah reward/stamp analytics | Reward/stamp issued berubah | PASS |
| LP-INT-AN-06 | Mark No Purchase ubah no-purchase/check-in without purchase analytics | No purchase / check-in without purchase direkod | PASS |
| LP-INT-AN-07 | `Hantar Maklumbalas` bebas ubah feedback signal | Submitted feedback dan Feedback Analytics berubah | PASS |
| LP-INT-AN-08 | Product/service captured ubah product analytics | Sales by Product/Service dan Product/Service Analytics berubah | PASS |
| LP-INT-AN-09 | Quantity > 1 tidak rosak volume analytics | Qty dan amount dikira ikut quantity | PASS |
| LP-INT-AN-10 | Duplicate fake purchase tidak double count | Duplicate reference tidak tambah capture/reward | PASS |
| LP-INT-AN-11 | Business Owner analytics own business sahaja | Business lain tidak muncul | PASS |
| LP-INT-AN-12 | Branch Manager analytics assigned branch sahaja | Branch lain tidak muncul / forbidden | PASS |
| LP-INT-AN-13 | System Manager analytics platform/GOS scope | GOS platform/business analytics visible | PASS |
| LP-INT-AN-14 | System Admin analytics admin/support scope | System & Access Support Analytics visible | PASS |
| LP-INT-AN-15 | Customer blocked dari internal analytics | 403 Forbidden | PASS |

Keputusan Bahagian 9: ANALYTICS UPDATE TEST PASS.

## Bahagian 10: AI Insight Test

Tarikh semakan: 2026-07-06

AI Insight local pilot menggunakan internal rule-based engine. Tiada OpenAI/Gemini/API key diperlukan.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-INT-AIINS-01 | Insight muncul dengan check-in + purchase | AI Insight Engine tidak empty | PASS |
| LP-INT-AIINS-02 | Check-in tinggi purchase rendah dikesan | Purchase conversion / capture backlog insight muncul | PASS |
| LP-INT-AIINS-03 | Pending purchase banyak dikesan | Pending purchase capture evidence muncul | PASS |
| LP-INT-AIINS-04 | Overdue/manual review dikesan | Operational follow-up risk insight muncul | PASS |
| LP-INT-AIINS-05 | Mark No Purchase pattern dikesan | No Purchase pattern insight muncul | PASS |
| LP-INT-AIINS-06 | Reward/stamp meningkat dikesan | Reward effectiveness insight muncul | PASS |
| LP-INT-AIINS-07 | General feedback digunakan sebagai signal | Feedback pattern insight muncul | PASS |
| LP-INT-AIINS-08 | Product/service tinggi dikesan | Popular/high-performing Product/Service evidence muncul | PASS |
| LP-INT-AIINS-09 | Product/service rendah dikesan | Weak/low activity Product/Service evidence muncul | PASS |
| LP-INT-AIINS-10 | Business Owner own business scope | Business lain tidak muncul | PASS |
| LP-INT-AIINS-11 | Branch Manager assigned branch scope | Branch lain tidak muncul | PASS |
| LP-INT-AIINS-12 | System Manager platform/GOS scope | GOS platform performance insight visible | PASS |
| LP-INT-AIINS-13 | System Admin admin/support scope | System setup/access insight visible | PASS |
| LP-INT-AIINS-14 | Customer blocked dari AI Insight | 403 Forbidden | PASS |
| LP-INT-AIINS-15 | External AI provider/API tidak diperlukan | Source scan tiada OpenAI/Gemini/API key call | PASS |

Keputusan Bahagian 10: AI INSIGHT TEST PASS.

## Bahagian 11: AI Action Test

Tarikh semakan: 2026-07-06

AI Action local pilot hanya cadangan tindakan. Human review diperlukan; sistem tidak auto-execute campaign, message, atau data change.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-INT-AIACT-01 | Action suggestion muncul dengan data valid | AI Action Engine tidak empty | PASS |
| LP-INT-AIACT-02 | Pending purchase tinggi cadang semak/capture pending | `Review pending purchase capture backlog` muncul | PASS |
| LP-INT-AIACT-03 | Overdue/manual review tinggi cadang follow-up | `Follow up overdue purchase review` muncul | PASS |
| LP-INT-AIACT-04 | Check-in tinggi purchase rendah cadang conversion/capture improvement | Capture backlog action muncul | PASS |
| LP-INT-AIACT-05 | Feedback isu sistem/reward/check-in cadang support/clarity | Negative feedback follow-up action muncul | PASS |
| LP-INT-AIACT-06 | Product/service rendah cadang review | Weak Product/Service action muncul | PASS |
| LP-INT-AIACT-07 | Product/service tinggi cadang maintain/promote | High-potential Product/Service action muncul | PASS |
| LP-INT-AIACT-08 | Business Owner own business action sahaja | Own business action visible | PASS |
| LP-INT-AIACT-09 | Branch Manager assigned branch action sahaja | Assigned branch action visible | PASS |
| LP-INT-AIACT-10 | System Manager GOS/platform scope | GOS platform/business action visible | PASS |
| LP-INT-AIACT-11 | System Admin admin/support scope | System Admin support action visible | PASS |
| LP-INT-AIACT-12 | Customer blocked dari AI Action | 403 Forbidden | PASS |
| LP-INT-AIACT-13 | AI Action tidak auto-send message/campaign | Tiada Auto Execute / Send Campaign / Send Message | PASS |
| LP-INT-AIACT-14 | AI Action tidak auto-change reward/data | DB count check-in/capture/feedback/stamp tidak berubah selepas view AI Action | PASS |
| LP-INT-AIACT-15 | External AI provider/API tidak diperlukan | Source scan tiada OpenAI/Gemini/API key call | PASS |

Keputusan Bahagian 11: AI ACTION TEST PASS.

## Bahagian 12: Full End-to-End Local Pilot Simulation

Tarikh semakan: 2026-07-06

Simulasi penuh menggunakan persona seeded local pilot.

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-E2E-01 | System Admin setup/check persona/business/branch/product/reward rule | Pilot data ready | PASS |
| LP-E2E-02 | Customer login dan check-in | Check-in berjaya direkodkan | PASS |
| LP-E2E-03 | Customer beli di luar platform | Tiada order/payment dalam Customer Portal | PASS |
| LP-E2E-04 | Branch Manager nampak Pending Purchase Capture | Pending visible assigned branch | PASS |
| LP-E2E-05 | Customer tidak nampak Pending Purchase Capture | Customer portal tidak expose pending internal state | PASS |
| LP-E2E-06 | Branch Manager capture purchase | Purchase captured | PASS |
| LP-E2E-07 | Reward/stamp confirmed | Customer nampak Confirmed Reward | PASS |
| LP-E2E-08 | Customer submit `Hantar Maklumbalas` bebas | Feedback accepted | PASS |
| LP-E2E-09 | No-purchase scenario | Mark No Purchase -> no reward/stamp | PASS |
| LP-E2E-10 | Cooldown scenario | No extra reward/stamp/pending duplicate | PASS |
| LP-E2E-11 | Analytics selepas scenario | Check-in, purchase, no purchase, reward, feedback reflected | PASS |
| LP-E2E-12 | AI Insight selepas scenario | AI Insight muncul berdasarkan data | PASS |
| LP-E2E-13 | AI Action selepas scenario | Action suggestion muncul dan tidak auto-execute | PASS |
| LP-E2E-14 | Access scope sepanjang simulation | Tiada persona leak | PASS |
| LP-E2E-15 | Logout/session security | Customer portal blocked selepas logout | PASS |

Keputusan Bahagian 12: FULL END-TO-END LOCAL PILOT SIMULATION PASS.

## Bahagian 13: Final Local Pilot Review

Tarikh semakan: 2026-07-06

| Test ID | Expected | Actual | Status |
| --- | --- | --- | --- |
| LP-FINAL-01 | Bahagian 1 PASS | Environment dan persona account ready | PASS |
| LP-FINAL-02 | Bahagian 2/2A/2B/2C PASS | Login/logout, issue resolve, capture alignment, role/access alignment PASS | PASS |
| LP-FINAL-03 | Bahagian 3.0-3.8 PASS | Access matrix dan access control PASS | PASS |
| LP-FINAL-04 | Bahagian 4-8 Blok A PASS dengan requirement terbaru | Core operation flow PASS | PASS |
| LP-FINAL-05 | Bahagian 9 Analytics PASS | Analytics update PASS | PASS |
| LP-FINAL-06 | Bahagian 10 AI Insight PASS | AI Insight rule-based PASS | PASS |
| LP-FINAL-07 | Bahagian 11 AI Action PASS | AI Action suggestion-only PASS | PASS |
| LP-FINAL-08 | Bahagian 12 E2E Simulation PASS | E2E local pilot PASS | PASS |
| LP-FINAL-09 | Customer flow tidak mengelirukan | Customer hanya check-in, purchase outside platform, no customer pending purchase, confirmed reward/stamp only, Hantar Maklumbalas bebas | PASS |
| LP-FINAL-10 | Branch Manager flow betul | Pending purchase capture, capture purchase, mark no purchase, assigned branch sahaja | PASS |
| LP-FINAL-11 | Business Owner / BO cum BM flow betul | Own business + assigned branch operations scope jelas | PASS |
| LP-FINAL-12 | System Manager / System Admin flow betul | System Manager GOS performance; System Admin support/admin | PASS |
| LP-FINAL-13 | Access Control regression | Customer/internal/persona leak tidak dikesan | PASS |
| LP-FINAL-14 | Analytics / AI Insight / AI Action internal rule-based engine | Internal rule-based confirmed | PASS |
| LP-FINAL-15 | Tiada external AI/API key dependency | Tiada external AI/API key dependency dikesan | PASS |
| LP-FINAL-16 | Docs lengkap dan tidak bercanggah | `docs/local-pilot-test-step-2.md` lengkap Bahagian 1-13 | PASS |
| LP-FINAL-17 | No secret/env exposure | Changed-files secret scan PASS | PASS |
| LP-FINAL-18 | Unresolved ISSUE/BLOCKER | Tiada BLOCKER | PASS |
| LP-FINAL-19 | Readiness decision | READY FOR CONTROLLED PILOT PREPARATION | PASS |
| LP-FINAL-20 | Next step recommendation | Sambung Controlled Pilot Preparation selepas commit Blok B | PASS |

### Fix / Penambahan Blok B

| Area | Fix / Penambahan |
| --- | --- |
| Analytics | Tambah `Core Operation Analytics` untuk pending purchase, overdue, manual review, no purchase, check-ins without/with Product/Service capture |
| AI Insight | Tambah rule-based insight untuk purchase conversion/capture backlog, operational follow-up risk, dan No Purchase pattern |
| AI Action | Tambah rule-based action untuk pending capture backlog, overdue/manual review follow-up, dan no-purchase conversion signal |
| Tests | Tambah `IntelligenceFlowTest`, `EndToEndLocalPilotSimulationTest`, `FinalLocalPilotReviewTest` |
| External AI | Confirmed internal rule-based; tiada OpenAI/Gemini/API key call |

### Keputusan Akhir Step 2 Local Pilot Test

| Item | Result |
| --- | --- |
| Customer flow | PASS |
| Customer hanya nampak confirmed reward/stamp | PASS |
| Branch Manager flow | PASS |
| Business Owner / BO cum BM flow | PASS |
| System Manager / System Admin scope | PASS |
| Analytics | PASS |
| AI Insight | PASS |
| AI Action | PASS |
| E2E Simulation | PASS |
| Issue/BLOCKER tinggal | Tiada |
| Final decision | READY FOR CONTROLLED PILOT PREPARATION |

Keputusan Bahagian 13: FINAL LOCAL PILOT REVIEW PASS.

## Step 2D - Free-Tier AI Provider Priority Chain & System Admin Visibility

Tarikh semakan: 2026-07-07

Scope Step 2D ialah provider architecture sahaja. Step 2 Final Wrap-Up Review tidak dibuat semula.

### Architecture

GOS-F&B MVP kini menyokong external AI free-tier/free-model provider chain dengan internal rule-based AI sebagai safety fallback terakhir.

Priority chain:

1. OpenAI - future/disabled by default.
2. Gemini API free tier - default active external provider untuk MVP apabila API key dikonfigurasikan.
3. Groq free tier / available free usage - external fallback.
4. OpenRouter free models - external fallback.
5. Internal rule-based AI - safety fallback terakhir.

External provider bukan free unlimited. Sistem handle provider disabled, missing API key, quota/rate limit, timeout/connection error, provider error, dan invalid response. Jika provider gagal, manager cuba provider seterusnya. Jika semua external disabled/missing/fail, AI Insight dan AI Action masih kembali melalui rule-based AI.

### Safety / Env

No API key committed. `.env.example` hanya mengandungi placeholder kosong/selamat. `.env` tidak diubah. System Admin hanya melihat status seperti `Configured`, `Missing key`, atau `Disabled`; nilai API key tidak dipaparkan.

AI Action kekal `suggestion_only`: tiada auto-send message, tiada auto-execute campaign, dan tiada auto-change reward/stamp/data.

### System Admin Visibility

System Admin dashboard dan System Admin Analytics memaparkan:

- AI Provider Status.
- Active/default provider: Gemini.
- Priority chain: OpenAI -> Gemini -> Groq -> OpenRouter -> Rule-based.
- Last used provider dan fallback status.
- External AI enabled/disabled.
- Provider health/status ringkas.
- AI Action mode: Suggestion Only.

Customer tidak boleh akses AI provider status kerana Customer masih blocked daripada internal dashboard dan analytics.

### Test Coverage

Focused provider-chain tests cover:

- Default priority chain includes OpenAI, Gemini, Groq, OpenRouter, rule-based.
- OpenAI disabled by default.
- Gemini default active external provider when configured.
- Missing Gemini key skips/falls back safely.
- Gemini failure falls back to Groq.
- Groq failure falls back to OpenRouter.
- OpenRouter quota/failure falls back to rule-based.
- All external disabled/missing still returns rule-based AI Insight.
- AI Action remains suggestion-only.
- System Admin can see provider status.
- API key/secret value is not shown.
- Customer cannot access provider status.

Tests use Laravel HTTP fake/mock responses only and do not call real external APIs.

Keputusan Step 2D: PASS selepas test/check berkaitan lulus.

## Step 2 Final Wrap-Up Review

Tarikh semakan: 2026-07-07

Final wrap-up review direkodkan dalam `docs/step-2-final-wrap-up-review.md`.

Ringkasan:

- Semua bahagian Step 2 Local Pilot Test telah disemak: environment/persona setup, login/logout, role/access, capture purchase, reward rules, feedback bebas, dashboard/persona scope, access control, analytics, AI Insight, AI Action, E2E simulation, dan Step 2D AI Provider Priority Chain.
- Focused Step 2 regression PASS: 134 tests, 1011 assertions.
- `.env` tidak diubah dan secret/API key tidak dipaparkan.
- Real external AI key/call belum divalidasi; provider tests guna fake/mock/fallback.
- Unrelated dirty/untracked files masih wujud dan bukan sebahagian Step 2.

Keputusan akhir:

STEP 2 LOCAL PILOT TEST COMPLETE - READY FOR DASHBOARD PERSONA REVIEW.
