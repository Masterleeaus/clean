# Hosting Decision Checklist

Use this checklist to choose the safest and fastest staging deployment option for a controlled FAP pilot of F&B Growth Core.

## Recommendation

Recommended path for the first supervised staging pilot: **managed Laravel hosting**, if budget allows.

Why:

- Lowest deployment and operations risk for a non-technical founder.
- Better fit for queue workers, cron/scheduler, HTTPS, logs, and backups.
- Easier to keep staging production-like without manually managing a server.

Fallback path: **VPS** only if someone technical will configure, secure, monitor, and back up the server.

Avoid for first pilot unless already proven: **basic Laravel shared hosting**, because queue workers, Composer, Node/npm, SSH, and cron support are often limited or inconsistent.

## Option Comparison

| Criteria | Laravel Shared Hosting | VPS | Managed Laravel Hosting |
| --- | --- | --- | --- |
| Laravel 13 compatibility | Varies by host | Yes, if configured correctly | Usually yes |
| PHP 8.4 support | Often delayed or limited | Yes, if installed | Usually available or easy to select |
| MySQL/MariaDB support | Usually yes | Yes | Usually yes |
| SSH access | Sometimes limited | Full | Usually yes |
| Composer support | Sometimes limited | Full | Usually yes |
| Node/npm or asset build | Often limited | Full | Usually supported or deploy built assets |
| HTTPS | Usually available | Must configure | Usually easy/automatic |
| Queue worker support | Often weak | Yes, via supervisor/systemd | Usually built-in or documented |
| Scheduler/cron support | Usually available but limited | Full cron | Usually built-in or documented |
| Backup capability | Varies | Must configure | Usually built-in or add-on |
| Ease of deployment | Medium if compatible | Harder | Easiest |
| Cost complexity | Low cost, hidden limits | Medium cost, more admin | Higher cost, lower ops burden |
| Risk for non-technical founder | Medium-high | High | Low-medium |

## Minimum Hosting Requirements

The staging host should support:

- PHP 8.4, or at minimum the PHP version required by the current Laravel install.
- Required PHP extensions for Laravel, PDO, database driver, OpenSSL, Mbstring, Tokenizer, XML, Ctype, JSON, BCMath, Fileinfo, and Curl.
- MySQL or MariaDB for production-like staging.
- SSH access.
- Composer install on the server, or a reliable build artifact deployment workflow.
- Node/npm build support, or ability to deploy prebuilt `public/build` assets.
- HTTPS with valid TLS certificate.
- Cron for `php artisan schedule:run`.
- Long-running worker support for `php artisan queue:work`, even if not heavily used yet.
- Writable `storage` and `bootstrap/cache`.
- Configurable web root pointing to Laravel `public`.
- Database backup and restore capability.
- Access to application and web server logs.
- Ability to set environment variables or manage `.env` securely.

## Laravel Shared Hosting Checklist

Choose shared hosting only if all are true:

- PHP 8.4 is available.
- SSH access is available.
- Composer can run without memory/time failures.
- Cron can run every minute.
- Queue workers are supported or the pilot does not require queues yet.
- Web root can point to `public`.
- MySQL/MariaDB database is included.
- HTTPS is included.
- Backups are included and restorable.
- The host allows editing `.env` securely.

Main risk: hidden platform limits during deployment or queue/scheduler setup.

## VPS Checklist

Choose VPS only if a technical operator can own setup and maintenance.

Required setup:

- Install PHP 8.4 and required extensions.
- Install Composer.
- Install Node/npm or deploy built assets.
- Install and secure MySQL/MariaDB.
- Configure Nginx or Apache to serve Laravel `public`.
- Configure HTTPS.
- Configure file permissions.
- Configure queue worker with supervisor/systemd.
- Configure cron scheduler.
- Configure backups.
- Configure firewall and SSH hardening.
- Monitor disk, logs, failed jobs, and database backups.

Main risk: fastest to become fragile if server maintenance is not owned.

## Managed Laravel Hosting Checklist

Best fit if the platform supports:

- PHP 8.4 selection.
- Git or artifact deployment.
- Composer install.
- Build hooks or deploy hooks for `npm run build`.
- Managed MySQL/MariaDB.
- HTTPS.
- Environment variable management.
- Queue worker processes.
- Scheduler/cron.
- Backups and restores.
- Logs and failed deploy visibility.
- Easy rollback.

Main risk: higher monthly cost, but usually lower pilot execution risk.

## Questions To Ask Hosting Provider

Ask these before choosing:

1. Do you support PHP 8.4 for Laravel apps?
2. Can the web root be set to Laravel's `public` directory?
3. Is SSH access available?
4. Can Composer run during deployment?
5. Can Node/npm run during deployment, or can we upload built assets?
6. Which database engines are available: MySQL, MariaDB, PostgreSQL, SQLite?
7. Are database backups automatic?
8. How do we restore a database backup?
9. Is HTTPS included and automatic?
10. Can we run a persistent queue worker?
11. Can we configure cron to run `php artisan schedule:run` every minute?
12. How are `.env` variables stored and protected?
13. Where are Laravel logs available?
14. Is there a deployment rollback option?
15. Are there CPU, memory, process, or execution-time limits that affect Composer, npm, queues, or cron?

## Deployment Readiness Score

Score each option:

- 2 points: fully supported and easy.
- 1 point: supported with manual work or limits.
- 0 points: unsupported or unclear.

Criteria:

- PHP 8.4 support
- Laravel 13 compatibility
- MySQL/MariaDB support
- SSH access
- Composer support
- Node/npm or built-asset workflow
- HTTPS
- Queue worker support
- Scheduler/cron support
- Backup and restore
- Log access
- Rollback support
- Ease for non-technical founder

Suggested decision:

- 20+ points: good staging candidate.
- 14-19 points: acceptable only with technical support.
- Under 14 points: avoid for first FAP pilot.

## Verification Commands After Deployment

Run:

```bash
php artisan about
php artisan migrate:status
php artisan route:list
php artisan test
npm run build
```

If dependencies are installed without dev packages, `php artisan test` may not be available on staging. In that case, tests must pass in CI or locally immediately before deployment.

Also verify:

```bash
php artisan queue:failed
php artisan users:create-owner --help
```

Smoke-test in browser:

- `/login`
- `/businesses`
- `/b/{business-slug}`
- `/b/{business-slug}/feedback`
- `/businesses/{business}/dashboard`
- `/businesses/{business}/reports/weekly`

## Final Decision Rule

For the first controlled FAP pilot, prefer the option that makes rollback, backups, HTTPS, queue workers, cron, and logs easiest to operate.

Do not choose the cheapest option if it creates uncertainty around deployment, backups, or owner access during the pilot.

