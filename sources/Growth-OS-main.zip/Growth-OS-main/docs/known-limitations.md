# F&B Growth Core MVP Known Limitations

## Controlled Pilot Boundaries

This MVP is intended for controlled FAP pilot testing, not open public launch.

## Not Ready Yet

- No WhatsApp API integration.
- No automated WhatsApp broadcast or campaign tracking.
- No AI API integration.
- No email sending or weekly report emails.
- No scheduled report delivery.
- No QR image generator.
- No staff roles.
- No POS, payment, receipt, or inventory integration.
- No customer self-redemption.
- No self-service owner registration.
- No self-service business creation.
- No advanced analytics, charts, cohorts, or export tools.
- No production backup/restore workflow.

## Operational Limitations

- Owner/admin accounts must be created or seeded by the project team.
- Seeded users use demo passwords and must be changed before use with real pilot data.
- Public QR URLs use `/b/{business-slug}`.
- Public QR token column exists, but token-based public routing is not implemented.
- WhatsApp follow-ups are manual `wa.me` links only.
- Customers can submit anonymous feedback.
- Feedback ratings are simple and not sentiment-analyzed.
- Weekly suggestions are rule-based and intentionally basic.

## Data And Security Limitations

- SQLite is suitable for local development and small pilot testing only.
- Public POST routes are throttled, but there is no CAPTCHA or bot protection.
- Duplicate customer and daily check-in protection relies on database constraints and service checks.
- Rare concurrent public submissions may produce a database-level error instead of a polished customer message.
- No audit log exists for owner/admin changes.
- No soft deletes are configured for business/customer data.
- No row-level multi-tenant database layer exists beyond policies, route authorization, and scoped queries.

## UX Limitations

- QR code is shown as a text URL only.
- Mobile layouts are simple and usable, but not fully polished.
- Owner dashboard has no charts.
- Customer search/filtering is basic.
- Error messages are friendly for main flows but not exhaustively customized for every edge case.

## Foundation Limitations

- Mailtrap placeholders exist, but no current flow sends mail.
- Database queue driver is configured, but no queued jobs are required yet.
- Laravel scheduler is available, but no scheduled commands are configured yet.
- No deployment-specific hardening has been performed.

