# Staging Environment Template

Use this as a safe `.env` reference for staging. Replace every placeholder before deployment. Do not commit real `.env` values.

```dotenv
APP_NAME="F&B Growth"
APP_ENV=staging
APP_KEY=<APP_KEY>
APP_DEBUG=false
APP_URL=https://staging.example.com

APP_LOCALE=en
APP_FALLBACK_LOCALE=en
APP_FAKER_LOCALE=en_US

APP_MAINTENANCE_DRIVER=file
BCRYPT_ROUNDS=12

LOG_CHANNEL=stack
LOG_STACK=single
LOG_DEPRECATIONS_CHANNEL=null
LOG_LEVEL=warning
```

## Database

For a small supervised staging pilot, SQLite can work if the host has persistent disk and backups. For a more production-like staging setup, use MySQL or MariaDB.

SQLite example:

```dotenv
DB_CONNECTION=sqlite
DB_DATABASE=/absolute/path/to/database/database.sqlite
DB_FOREIGN_KEYS=true
```

MySQL/MariaDB example:

```dotenv
DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=fbgrowth_staging
DB_USERNAME=fbgrowth_staging_user
DB_PASSWORD=<DB_PASSWORD>
DB_CHARSET=utf8mb4
DB_COLLATION=utf8mb4_unicode_ci
```

## Session, Cache, Queue

Use database-backed drivers for the staging pilot.

```dotenv
SESSION_DRIVER=database
SESSION_LIFETIME=120
SESSION_ENCRYPT=false
SESSION_PATH=/
SESSION_DOMAIN=null
SESSION_SECURE_COOKIE=true
SESSION_HTTP_ONLY=true
SESSION_SAME_SITE=lax

CACHE_STORE=database
QUEUE_CONNECTION=database
```

## Mailtrap SMTP

Mail is currently foundation-ready only. Use Mailtrap sandbox credentials for staging.

```dotenv
MAIL_MAILER=smtp
MAIL_SCHEME=null
MAIL_HOST=sandbox.smtp.mailtrap.io
MAIL_PORT=2525
MAIL_USERNAME=REPLACE_WITH_MAILTRAP_USERNAME
MAIL_PASSWORD=<MAIL_PASSWORD>
MAIL_FROM_ADDRESS="hello@fbgrowth.local"
MAIL_FROM_NAME="${APP_NAME}"
```

## Other Defaults

```dotenv
BROADCAST_CONNECTION=log
FILESYSTEM_DISK=local

REDIS_CLIENT=phpredis
REDIS_HOST=127.0.0.1
REDIS_PASSWORD=null
REDIS_PORT=6379

AWS_ACCESS_KEY_ID=
AWS_SECRET_ACCESS_KEY=
AWS_DEFAULT_REGION=us-east-1
AWS_BUCKET=
AWS_USE_PATH_STYLE_ENDPOINT=false

VITE_APP_NAME="${APP_NAME}"
```

## Staging Checks

- `APP_ENV` must be `staging`.
- `APP_DEBUG` must be `false`.
- `APP_URL` must be the real HTTPS staging URL.
- `APP_KEY` must be generated and kept secret.
- Database credentials must not be shared in docs or chat.
- `QUEUE_CONNECTION` should remain `database`.
- Mailtrap credentials must be sandbox credentials only.

