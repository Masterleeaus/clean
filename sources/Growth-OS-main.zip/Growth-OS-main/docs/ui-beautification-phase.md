# UI Beautification Phase

## Direction

GOS-F&B uses a mature SaaS dashboard foundation: neutral slate background, white content panels, subtle borders, restrained blue accent, and status colors only where they clarify state.

The UI remains a business growth platform. It is not a POS, ordering, cart, payment, or customer purchase self-claim surface.

## UI-1 Scope

UI-1 focuses on global foundation only:

- App shell, sticky page header, persona/context labels, spacing, and content width.
- Responsive left sidebar with active states and mobile fallback.
- Persona-aware navigation without changing access logic, routes, policies, or business rules.
- Reusable Blade/CSS primitives for future dashboard-specific beautification.

## Left Sidebar

Sidebar navigation is built from persona-specific menu groups:

- System Manager: platform dashboard and Platform Analytics / AI.
- System Admin: admin dashboard, admin analytics, business setup, create business, and AI Provider Status.
- Business Owner: dashboard, Business Performance, Analytics / AI, and Businesses.
- Branch Manager: branch operation, pending capture, branch analytics, and Capture Purchase when an assigned branch exists.
- Business Owner / Branch Manager: Business Performance plus Branch Operations, with Capture Purchase only for assigned branch scope.
- Customer: Customer Portal, Customer Check-in, Rewards, and Feedback.

The mobile menu uses the same menu source as desktop to avoid wrong link leakage.

## Design System Primitives

Anonymous Blade components were added for:

- Dashboard card
- Metric card
- Section panel
- Status badge
- Action button
- Empty state
- Alert/banner
- Table wrapper
- AI Insight card
- AI Action card
- Floating action button

## Floating Button Pattern

The floating action button is reusable and context-aware. UI-1 uses it on the Customer Portal only, where it anchors to the existing customer check-in section. It does not introduce new behavior or expose internal purchase capture actions.

## Rules Preserved

- No route, controller, policy, model, reward, check-in, purchase capture, or feedback logic changed.
- Customer still cannot see Pending Purchase Capture or self-claim purchase.
- Pending Purchase Capture remains BM/BO cum BM assigned branch only.
- AI Action remains suggestion-only.
- AI Provider Status remains System Admin scoped.

## Checks

UI-1 validation should include focused persona navigation/access tests, customer portal checks, core operation checks if affected, Blade/PHP linting, `php artisan view:clear`, `git diff --check`, frontend build, changed-files secret scan, and confirmation that `.env` is untouched.

## Next UI Steps

- UI-2: Persona dashboard data presentation polish.
- UI-3: Beautify branch operation and capture views without changing capture rules.
- UI-4: Beautify customer portal, rewards, and feedback flows while preserving customer-only boundaries.

## UI-2 - Persona Dashboard Data Presentation Polish

UI-2 polishes dashboard and portal data presentation without changing routes, authorization, queries, reward rules, check-in rules, capture rules, feedback rules, or AI provider configuration.

Scope:

- System Manager dashboard: platform overview, GOS/F&B vertical effectiveness, adoption/usage signals, high-level risk/opportunity, and strategic suggestion-only AI cards.
- System Admin dashboard: system overview, user/access/support summary, setup/configuration support, AI Provider Status, and admin/support suggestion-only AI cards.
- Business Owner dashboard: business overview, branch summary, product/service signal, reward/stamp summary, feedback summary, weekly report insight, and business actions.
- Branch Manager dashboard: assigned branch identity, today activity, Physical/Online summary, Pending/Overdue/Manual Review cards, assigned-branch action area, branch rewards/feedback, and branch-level suggestion-only AI card.
- Business Owner cum Branch Manager dashboard: two-tab presentation for Business Performance and Branch Operations, keeping capture/no-purchase actions inside Branch Operations only.
- Customer Portal: mobile-friendly check-in, confirmed reward/stamp, reward/loyalty status, submitted feedback, and clear explanation that reward is confirmed after branch verification.

Data presentation rules:

- Use the UI-1 components for cards, panels, metrics, badges, empty states, AI cards, action buttons, and the customer floating action button.
- Keep dashboard sections grouped and scannable; use 3-5 key metrics per section.
- Use status badges for Physical, Online, Pending, Overdue, Manual Review, Captured, No Purchase, and confirmed reward/stamp states where relevant.
- Keep customer screens free from internal analytics, admin/provider status, and purchase capture actions.

Checks for UI-2:

- Lint changed Blade/test files with `php -l`.
- Run focused persona/dashboard/customer/access/core operation regression tests.
- Run `php artisan view:clear`, `git diff --check`, `npm run build`, changed-files secret scan, and `.env` staged/modified check.

Next recommended UI step:

- UI-3 should polish branch operation and capture views in detail, while preserving BM/BO cum BM assigned-branch-only capture access.

## UI-3 — Customer Portal & Branch Operation UX Polish

UI-3 focuses on the two highest-use flows: Customer Portal check-in/reward/feedback and Branch Operation pending purchase capture. It remains UI-only and does not change access, routes, reward rules, capture behavior, feedback behavior, or AI/provider behavior.

Customer Portal UX changes:

- Added a concise welcome/intro flow with the rule: reward is confirmed after branch verification.
- Presented `Check-in di Premis` and `Check-in untuk Order Online` as clear mobile-friendly option cards.
- Kept confirmed reward/stamp presentation only, with `Reward Confirmed` status where relevant.
- Kept `Hantar Maklumbalas` as free/general feedback and avoided mandatory feedback wording.
- Kept the floating action button customer-only, anchored to `#customer-check-in`.

Branch Operation UX changes:

- Added branch operation guidance: verify real transactions outside the system before capture.
- Split pending capture readability into `Pending Purchase Capture - Physical` and `Pending Purchase Capture - Online`.
- Added status badges for Physical, Online, Pending, Overdue, Manual Review, Captured, No Purchase, and Reward Confirmed where relevant.
- Polished the pending capture work queue to show customer/reference, check-in mode, check-in time, status, captured items, and action area.
- Kept Capture Purchase as the primary action and Mark No Purchase as a lighter destructive action.

BO cum BM branch operations:

- The `Business Performance` tab remains free from capture/no-purchase operation buttons.
- The `Branch Operations` tab keeps assigned-branch pending capture, guidance, and operation actions.

Checks for UI-3:

- Lint changed Blade/test files with `php -l`.
- Run focused customer portal, Physical/Online check-in, branch operation, BO cum BM, access-control, and core operation regressions.
- Run `php artisan view:clear`, `git diff --check`, `npm run build`, changed-files secret scan, and `.env` staged/modified check.

Next recommended UI step:

- UI-4 should polish business/customer supporting pages and any remaining table-heavy screens without changing business logic.

## UI-4 — Responsive & Visual QA Review

UI-4 completes responsive and visual QA across dashboard, customer, and branch operation surfaces. It remains UI-only and does not change routes, policies, controller logic, model logic, reward rules, check-in rules, purchase capture rules, feedback rules, analytics calculation, or AI provider behavior.

Responsive QA scope:

- System Manager and System Admin dashboards.
- Business Owner, Branch Manager, and Business Owner cum Branch Manager dashboards.
- Customer Portal and Customer Feedback.
- Branch Check-ins, Pending Purchase Capture, Capture Purchase, Mark No Purchase, and Online Check-in reference UI.
- Global layout, sidebar, mobile navigation, cards, tables, badges, buttons, forms, AI cards, and FAB.

Breakpoints reviewed:

- Mobile: 360px-430px.
- Tablet: 768px.
- Desktop: 1280px+.

Visual fixes made:

- Added global min-width, text wrapping, focus-visible, mobile menu scrolling, and safe FAB positioning safeguards.
- Improved mobile card/panel spacing and full-width mobile action buttons.
- Made sidebar labels, persona labels, status badges, and long dashboard text resilient to overflow.
- Made BO cum BM tabs and branch operation action groups wrap cleanly on mobile.
- Improved customer check-in option cards, feedback header action, branch work queue columns, and capture form field stacking.
- Kept AI Insight/AI Action wording suggestion-only and protected System Admin-only AI Provider Status visibility.

Components reviewed:

- App shell/header/sidebar/mobile menu.
- Dashboard card, section panel, metric card, status badge, action button, alert/banner, table wrapper, AI cards, and floating action button.
- Shared primary, secondary, and danger button components.

Checks for UI-4:

- Lint changed Blade/test files with `php -l`.
- Run focused UI responsive QA, persona dashboard/access, customer portal/feedback, branch operation, BO cum BM, Physical/Online check-in, and core operation regression tests.
- Run `php artisan view:clear`, `git diff --check`, `npm run build`, changed-files secret scan, and `.env` staged/modified check.
- Full suite remains intentionally skipped while unrelated pre-existing failures are present.

Next recommended UI step:

- Controlled Pilot Preparation can start after UI-4 is pushed, with no real AI provider key configured until explicitly approved.

## UI Beautification Final Review

Final review covers UI-1 through UI-4 and confirms the beautification phase can be closed without changing business logic, access control, reward behavior, check-in behavior, purchase capture behavior, feedback behavior, analytics calculation, or AI provider configuration.

UI-1 to UI-4 summary:

- UI-1 established the global app shell, left sidebar, mobile navigation fallback, persona/context labels, reusable UI primitives, and customer-only FAB pattern.
- UI-2 polished persona dashboard data presentation with metric cards, section panels, status badges, AI Insight cards, and AI Action suggestion-only cards.
- UI-3 polished Customer Portal, Physical/Online check-in presentation, reward/stamp confirmation wording, free `Hantar Maklumbalas`, and Branch Operation pending capture UX.
- UI-4 completed responsive and visual QA for mobile 360px-430px, tablet 768px, and desktop 1280px+ across dashboards, portal, sidebar, cards, badges, buttons, forms, tables, and FAB.

Final visual/readability status:

- The UI uses a mature SaaS visual foundation with neutral background, white panels, restrained blue accents, clear status colors, consistent spacing, readable empty states, and stable button/badge hierarchy.
- Dashboard and portal content is grouped by persona workflow instead of showing broad operational clutter.
- Branch operation actions remain readable and distinct: Capture Purchase is primary; Mark No Purchase stays clear and scoped to operation users.

Persona dashboard status:

- System Manager remains platform/strategy focused.
- System Admin remains admin/support focused and is the only persona with AI Provider Status visibility.
- Business Owner remains business performance focused and does not expose capture/no-purchase actions.
- Branch Manager remains assigned-branch operation focused.
- Business Owner cum Branch Manager keeps two responsive tabs: `Business Performance` and `Branch Operations`.
- Customer remains portal/check-in/reward/feedback only.

Customer portal status:

- `Check-in di Premis` and `Check-in untuk Order Online` are clear mobile-friendly choices.
- Customer screens do not expose Pending Purchase Capture, Capture Purchase, Mark No Purchase, internal analytics, admin setup, or AI Provider Status.
- Reward/stamp wording remains tied to branch verification and valid Product/Service capture.
- `Hantar Maklumbalas` remains free/general and not mandatory.

Branch operation status:

- Pending Purchase Capture is separated into Physical and Online context where needed.
- Branch Operation work queue remains scoped to BM/BO cum BM assigned branch access.
- BO cum BM keeps capture/no-purchase actions inside `Branch Operations`, not `Business Performance`.

Known limitations:

- Full suite is intentionally not used as the final signal while four unrelated pre-existing failures remain in dirty/unrelated areas.
- This review does not configure a real AI provider key and does not start Controlled Pilot Preparation.

Final checks:

- Focused final UI regression should cover persona dashboards, access/menu visibility, Customer Portal, Physical/Online check-in UI, Branch Operation visibility, BO cum BM tabs, AI Provider Status visibility, and customer/internal boundary checks.
- Static checks should include `php artisan view:clear`, `npm run build`, `git diff --check`, changed-files secret scan, and confirmation that `.env` is not modified or staged.

Readiness decision:

- UI BEAUTIFICATION PHASE COMPLETE — READY FOR CONTROLLED PILOT PREPARATION

Next recommended step:

- Start Controlled Pilot Preparation only after this final review commit is pushed and after the unrelated dirty work is handled separately.
