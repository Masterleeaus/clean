# URS GOS-F&B MVP

Dokumen ini ialah sumber rujukan utama untuk user requirements GOS-F&B MVP. Jika ada dokumen lama yang bercanggah dengan keputusan semasa, keperluan dalam URS ini perlu diikuti.

## 1. Overview GOS-F&B

GOS-F&B ialah vertical F&B untuk GOS, iaitu platform pertumbuhan bisnes berasaskan AI. Sistem ini membantu bisnes F&B mengurus hubungan pelanggan, check-in, loyalty, feedback, scoreboard prestasi, insight, dan cadangan tindakan.

## 2. Objektif MVP

Objektif MVP ialah membina aliran asas yang membolehkan pengguna GOS-F&B mengakses sistem mengikut persona, mengurus bisnes/branch, merekod aktiviti pelanggan, melihat prestasi, dan menerima insight/action asas daripada AI.

MVP mesti dibina secara berperingkat mengikut build order yang dikunci supaya setiap fungsi siap dan boleh diuji sebelum fungsi seterusnya dibina.

## 3. Persona Dikunci

Persona GOS-F&B yang dikunci untuk MVP:

1. System Manager
2. System Admin
3. Business Owner
4. Branch Manager
5. Customer

## 4. Keperluan Role Dan Access

Setiap user account mesti mempunyai role utama. Secara default, satu user mempunyai satu role sahaja.

System Manager mesti mempunyai akses kepada platform / vertical overview. Persona ini melihat gambaran besar GOS-F&B dan bukan fokus kepada operasi harian branch.

System Admin mesti mempunyai akses kepada system/admin operation. Persona ini digunakan untuk kerja operasi dalaman sistem seperti setup, semakan, dan pentadbiran.

Business Owner mesti mempunyai akses pada tahap bisnes. Jika Business Owner mempunyai banyak branch, ini masih dikira satu role dengan scope akses lebih luas, bukan multi-role.

Branch Manager mesti mempunyai akses pada branch yang ditugaskan sahaja. Jika Branch Manager menjaga banyak branch, ini masih dikira satu role dengan multiple branch scope, bukan multi-role.

Customer hanya boleh mengakses customer portal/page. Customer tidak boleh mengakses admin dashboard, business dashboard, branch dashboard, atau platform dashboard.

Sistem mesti redirect user ke dashboard atau portal yang betul selepas login berdasarkan role dan access scope.

## 5. Keputusan Combined Role

MVP hanya menyokong dua kes combined role:

1. Business Owner / Branch Manager
2. System Manager / System Admin untuk kegunaan dalaman GOS sahaja

Business Owner / Branch Manager mesti mendapat akses dan dashboard handling gabungan yang sesuai untuk pengguna yang perlu melihat business-level dan assigned branch-level access.

System Manager / System Admin mesti mendapat akses dan dashboard handling gabungan untuk kegunaan internal GOS.

Tiada combined role lain dibenarkan dalam MVP.

## 6. MVP Scope Dikunci

Skop MVP yang dikunci:

1. System Manager dashboard
2. System Admin dashboard
3. Business Owner dashboard
4. Branch Manager dashboard
5. Customer portal/page
6. Business & Branch setup
7. User account + role/access
8. Combined Dashboard for Business Owner / Branch Manager
9. Customer check-in
10. Customer profile
11. Product/Service purchased/subscribed
12. Reward/Loyalty
13. Feedback free text
14. Analytics/Scoreboard
15. AI Insight Engine - MVP scope
16. AI Action Engine - MVP scope

## 7. MVP Build Order

Build order MVP mesti diikuti seperti berikut:

1. Persona + Access
2. Business/Branch
3. Customer Check-in
4. Product/Service Capture
5. Reward/Loyalty
6. Feedback
7. Dashboard/Scoreboard
8. Analytics
9. AI Insight
10. AI Action
11. Final Testing

## 8. Build Order 1: Persona + Access

Build Order 1 mesti menyediakan foundation untuk user account, role assignment, access scope, permission rules, combined role handling, dashboard redirect, demo users, dan test asas.

Sistem mesti menyokong lima persona yang dikunci. Sistem mesti boleh menentukan dashboard atau portal yang betul untuk setiap persona. Sistem mesti menghalang Customer daripada mengakses mana-mana dashboard admin, business, branch, atau platform.

Branch Manager mesti hanya melihat scope yang ditugaskan kepadanya. Business Owner mesti melihat business miliknya. System Manager dan System Admin mesti mempunyai access yang sesuai untuk penggunaan platform/internal mengikut role masing-masing.

## 9. Build Order 2: Business / Branch

Build Order 2 mesti menjadikan Business sebagai client business dan Branch sebagai outlet/lokasi di bawah Business.

Satu Business boleh mempunyai satu atau banyak Branch. Setiap Branch mesti dipautkan kepada satu Business.

Business Owner mesti boleh mengakses Business yang ditugaskan kepadanya dan semua Branch di bawah Business tersebut.

Branch Manager mesti hanya boleh mengakses Branch yang ditugaskan kepadanya. Jika Branch Manager menjaga beberapa Branch, aksesnya mesti terhad kepada Branch tersebut sahaja.

Business Owner / Branch Manager mesti mendapat business-level view dan assigned branch-level view yang sesuai dengan scope gabungan.

System Manager mesti boleh melihat overview Business dan Branch pada tahap platform. System Admin mesti boleh mengurus setup/admin operation untuk Business dan Branch.

Customer tidak boleh mengakses mana-mana surface admin untuk Business atau Branch.

Status Build Order 2: Business / Branch foundation dibina untuk MVP.

## 10. Build Order 3: Customer Check-in

Build Order 3 mesti membolehkan Customer check-in kepada Branch yang dipilih di bawah sesuatu Business.

Setiap check-in mesti merekod Customer, Business, Branch, masa check-in, dan sumber check-in jika tersedia.

GOS-F&B mesti menyokong dua jenis check-in: Physical Check-in dan Online Check-in.

Physical Check-in berlaku apabila Customer check-in melalui QR atau entry point branch. Sistem mesti mengenal pasti Business, Branch, dan lokasi/context daripada QR atau entry point tersebut.

Online Check-in berlaku apabila Customer membuat order melalui WhatsApp, delivery, pickup, atau channel luar dan merekod check-in melalui Customer Portal atau link/code online jika tersedia.

Customer hanya membuat check-in. Customer tidak membuat order, payment, purchase capture, atau self-claim purchase dalam GOS-F&B.

Customer hanya dikira sebagai valid check-in untuk reward apabila check-in tersebut mempunyai Product/Service purchase/subscription yang sah dicapture oleh Branch Manager / BO cum BM assigned branch.

Check-in tanpa Product/Service purchase/subscription tidak boleh memberi reward/point. Purchase/subscription tanpa check-in juga tidak memberi reward/point untuk MVP ini.

Pickup dan delivery bukan jenis check-in. Pickup dan delivery hanya fulfillment method.

Untuk Online Check-in, sistem mesti merekod mode `online` dan mengekalkan status pending purchase capture sehingga purchase sah dicapture oleh Branch Manager / BO cum BM assigned branch.

Customer tidak boleh menggunakan online check-in sebagai self-claim purchase atau self-claim reward.

Business Owner mesti boleh melihat check-in untuk Business miliknya. Branch Manager mesti hanya boleh melihat check-in untuk Branch yang ditugaskan kepadanya.

Business Owner / Branch Manager mesti boleh melihat check-in mengikut akses business-level dan assigned branch-level yang dibenarkan.

System Manager dan System Admin boleh melihat overview check-in mengikut akses platform/admin yang sesuai untuk MVP.

Customer hanya boleh menggunakan customer portal/page untuk check-in. Customer tidak boleh mengakses surface admin Business atau Branch.

Sistem mesti menghalang duplicate check-in yang jelas untuk Customer yang sama di Branch yang sama dalam hari/window check-in yang munasabah.

Branch mesti mempunyai setting cooldown check-in. Customer yang sama hanya boleh check-in semula pada Branch yang sama selepas tempoh cooldown tersebut tamat pada hari yang sama.

Business Owner mesti boleh melihat dan mengurus setting cooldown untuk Branch di bawah Business miliknya. Branch Manager mesti boleh melihat dan mengurus setting cooldown untuk Branch yang ditugaskan sahaja. Customer tidak boleh mengurus setting ini.

Sistem mesti menghalang duplicate reward/check-in yang jelas daripada double click, retry browser/network, percubaan banyak device/browser, duplicate customer profile jika boleh dikesan, duplicate manual staff entry, dan online transaction/reference yang cuba digunakan lebih daripada sekali.

Sistem boleh menanda aktiviti mencurigakan atau abnormal untuk semakan apabila sesuai, tanpa menghalang operasi normal secara berlebihan.

Customer-facing message mesti jelas untuk physical/online check-in berjaya direkodkan, reward/stamp hanya selepas purchase disahkan branch, cooldown belum selesai, online check-in code/reference sudah digunakan, online check-in reference tidak sah, dan reward tidak dikemaskini apabila belum ada valid capture.

Check-in yang disekat kerana cooldown tidak boleh menambah Reward/Loyalty stamp atau point.

Status Build Order 3: Customer Check-in branch-level dibina untuk MVP.

## 11. Build Order 4: Product/Service Capture

Build Order 4 mesti membolehkan Business merekod Product/Service seperti makanan, minuman, combo, menu item, atau service item.

Product/Service mesti dimiliki oleh satu Business. Availability Product/Service boleh ditetapkan untuk semua Branch atau Branch tertentu.

Setiap Product/Service mesti mempunyai nama, category, type, price, status aktif/tidak aktif, Business, dan Branch availability.

Price adalah wajib dan mesti menyokong nilai Ringgit dan Sen kerana ia penting untuk business value, Analytics, AI Insight, AI Action, dan integrasi masa depan.

Customer check-in mesti boleh dikaitkan dengan satu atau lebih Product/Service yang dibeli atau dilanggan.

Setiap Product/Service Capture mesti dikaitkan dengan Customer, Customer Check-in, Business, Branch, Product/Service, quantity, price pada masa capture, total amount, dan capture source.

Sistem mesti menyimpan price pada masa capture. Jika price Product/Service berubah kemudian, rekod capture lama tidak boleh berubah.

Product/Service yang sama boleh dicapture lebih daripada sekali jika pembelian/langganan tersebut sah. Quantity lebih daripada satu juga sah. Pembelian tambahan dalam visit/check-in yang sama juga sah.

Sistem mesti menghalang false duplicate capture seperti double click, network retry, staff menghantar transaction yang sama dua kali, atau online reference yang sama cuba digunakan lebih daripada sekali. Sistem tidak boleh menghalang repeated purchase yang sah.

Reward/point hanya diberi daripada Product/Service purchase/subscription yang sah dan dikaitkan dengan check-in yang sah. Check-in tanpa Product/Service purchase/subscription tidak boleh memberi reward.

Business Owner mesti boleh melihat dan mengurus Product/Service untuk Business miliknya. Branch Manager mesti boleh melihat dan capture Product/Service usage hanya untuk Branch yang ditugaskan kepadanya.

Business Owner / Branch Manager mesti boleh menggunakan business-level dan assigned branch-level Product/Service capture mengikut access yang dibenarkan.

Customer boleh melihat Product/Service yang direkod untuk aktiviti sendiri jika sesuai. Customer tidak boleh mengakses surface admin Product/Service.

Data Product/Service Capture mesti bersedia untuk Analytics, AI Insight, AI Action, dan integrasi POS/order/payment masa depan, tetapi integrasi tersebut bukan skop Build Order ini.

Status Build Order 4: Product/Service Capture dibina untuk MVP.

## 12. Build Order 5: Reward/Loyalty

Build Order 5 mesti membolehkan sistem mengira progress reward/loyalty Customer secara mudah.

Untuk MVP, Customer mendapat 1 stamp/point hanya bagi check-in yang sah dengan Product/Service purchase/subscription yang sah. Reward dianggap earned apabila stamp/point mencapai jumlah yang ditetapkan.

Reward/point hanya diberi untuk valid physical atau online check-in bersama Product/Service purchase/subscription yang sah dicapture oleh Branch Manager / BO cum BM assigned branch.

Reward/stamp mesti meningkat sekali sahaja untuk check-in dan purchase/reference yang sama.

Reward/Loyalty mesti dikaitkan dengan Customer, Business, dan Branch jika berkaitan.

Customer mesti boleh melihat status reward/loyalty sendiri dalam customer portal.

Business Owner mesti boleh melihat reward/loyalty untuk Business miliknya. Branch Manager mesti hanya boleh melihat dan mengurus reward/loyalty untuk Branch yang ditugaskan.

Sistem mesti menyokong redemption mudah supaya reward yang earned boleh direkod sebagai redeemed.

Status Build Order 5: Reward/Loyalty MVP dibina.

## 13. Build Order 6: Feedback

Build Order 6 mesti membolehkan Customer menghantar maklumbalas free text yang mudah selepas berinteraksi dengan branch atau menggunakan sistem.

Feedback tidak wajib selepas purchase, check-in, atau activity lengkap. Customer boleh menghantar feedback secara bebas apabila perlu.

Sistem tidak perlu mewujudkan Pending Feedback wajib selepas purchase capture.

Customer mesti boleh menulis feedback menggunakan free text dalam ayat sendiri melalui form `Hantar Maklumbalas`. Rating boleh kekal optional jika tersedia.

Feedback bebas mesti dikaitkan dengan Customer, Business, dan Branch jika tersedia. Product/Service boleh dipilih jika relevan, tetapi feedback tidak perlu dikaitkan dengan check-in, purchase, atau transaction/capture.

Sistem mesti menyediakan AI/rule-based MVP summary untuk free-text feedback. Summary mesti mengenal pasti maksud utama, point positif, point negatif, expectation Customer, issue category, dan Product/Service yang disebut jika dapat dikenal pasti.

Jika feedback tidak jelas, sistem tidak boleh mereka maksud. Sistem mesti menandakan feedback sebagai unclear atau needs review.

Feedback status mesti menyokong Pending, Submitted, Reviewed, Action Needed, dan Resolved untuk kegunaan semakan dalaman jika diperlukan.

Business Owner mesti boleh melihat maklumbalas untuk Business miliknya. Branch Manager mesti hanya boleh melihat maklumbalas untuk Branch yang ditugaskan kepadanya.

Branch Manager mesti boleh mengemaskini status feedback untuk Branch yang ditugaskan sahaja. Business Owner boleh melihat feedback pattern merentas Branch di bawah Business miliknya.

Business Owner / Branch Manager mesti boleh melihat maklumbalas mengikut business-level dan assigned branch-level access yang dibenarkan.

Customer boleh melihat submitted feedback sendiri dalam customer portal. Customer tidak boleh mengakses surface admin maklumbalas Business atau Branch.

Feedback bebas tidak boleh memberi reward/stamp, tidak boleh menutup Pending Purchase Capture, dan tidak dianggap sebagai bukti purchase.

Maklumbalas mesti disimpan dengan struktur yang sesuai supaya Analytics, AI Insight, dan AI Action boleh menggunakannya, tetapi build ini tidak membina dashboard Analytics, AI Insight, atau AI Action baharu.

Status Build Order 6: Feedback MVP dibina.

## 14. Build Order 7: Dashboard/Scoreboard

Build Order 7 mesti menyediakan dashboard atau scoreboard untuk semua persona yang dikunci.

System Manager mesti melihat platform/vertical overview seperti jumlah Business, Branch, Customer, check-in, dan feedback.

System Admin mesti melihat ringkasan setup/admin operation seperti status Business, Branch, user, dan pautan asas untuk kerja admin.

Business Owner mesti melihat business performance scoreboard untuk Business miliknya, termasuk ringkasan Branch, check-in, Product/Service capture, Reward/Loyalty, dan feedback.

Branch Manager mesti melihat operation scoreboard untuk Branch yang ditugaskan sahaja, termasuk check-in terkini, Product/Service captured, Reward/Loyalty, dan feedback terkini.

Customer mesti melihat customer portal/dashboard sendiri sahaja, termasuk status/history check-in, Reward/Loyalty, maklumbalas yang dihantar, dan konteks Business/Branch berkaitan.

Business Owner / Branch Manager mesti mendapat dashboard gabungan yang membezakan business-level information dan assigned branch-level information dengan jelas.

Setiap dashboard mesti hanya memaparkan data dalam access scope persona tersebut. Customer tidak boleh mengakses dashboard admin, business, branch, atau platform.

Status Build Order 7: Dashboard/Scoreboard MVP dibina.

## 15. Build Order 8: Analytics

Build Order 8 mesti menyediakan Analytics Launch Readiness berdasarkan data sebenar yang direkod dalam sistem, termasuk check-in, Product/Service capture, price, quantity, total amount, reward, feedback, Customer, Business, dan Branch.

Analytics bermaksud sistem mengira, menyusun, dan memaparkan data sebenar mengikut persona supaya pengguna boleh memahami prestasi atau status support yang berkaitan. Analytics bukan AI Insight dan tidak membuat tafsiran AI mendalam.

Sales/Revenue Analytics mesti menunjukkan total sales/value, total transaction/capture, average transaction value, sales mengikut day/week/month, sales mengikut Branch, dan sales mengikut Product/Service.

Customer Analytics mesti menunjukkan total Customer, new Customer, repeat Customer, active Customer, check-in count, purchase count, dan customer value.

Product/Service Analytics mesti menunjukkan popular Product/Service, highest sales Product/Service, most purchased Product/Service, weak/low activity Product/Service, dan quantity sold/subscribed.

Branch Performance Analytics mesti menunjukkan branch sales/value, branch check-in count, branch customer count, branch repeat customer, branch feedback status, dan branch comparison.

Reward Analytics mesti menunjukkan reward/stamp issued, reward redeemed, reward pending jika tersedia, dan reward activity mengikut Customer, Branch, atau Business jika data tersedia.

Feedback Analytics mesti menunjukkan total feedback, pending feedback, submitted feedback, reviewed, action needed, resolved, issue category, serta ringkasan positif, negatif, atau unclear.

Analytics mesti menyokong time filter untuk today, this week, this month, dan custom date range jika selamat dan ringkas.

Sistem mesti menyemak data completeness untuk mengenal pasti data lemah atau tidak lengkap seperti check-in tidak mencukupi, Product/Service capture tidak konsisten, price/category Product/Service tidak lengkap, feedback rendah atau masih pending, Customer data tidak mencukupi, repeat Customer data tidak mencukupi, Branch dengan data lemah, dan reward data tidak mencukupi.

Untuk data completeness, sistem mesti menunjukkan apa yang kurang, kenapa ia penting, kesan kepada ketepatan analytics, dan recommendation seperti aktifkan QR check-in di branch, pastikan staff capture Product/Service setiap transaksi, minta Customer submit pending feedback, lengkapkan harga/kategori Product/Service, rekod online purchase dengan reference, atau galakkan repeat check-in.

System Manager bertanggungjawab memantau prestasi business GOS Sdn Bhd. System Manager Analytics mesti memberi GOS-level/platform-level view seperti business/subscriber growth jika data tersedia, business category/vertical performance seperti F&B, Carwash, atau Salon jika data tersedia, platform effectiveness mengikut category/vertical, active/inactive businesses, active/inactive branches, usage check-in, Product/Service capture, feedback, reward, dan data completeness merentas business/category.

Revenue/ringgit-sen adalah objektif business yang wajib, tetapi jika revenue/subscription data GOS belum tersedia, sistem mesti memaparkannya sebagai data gap dan tidak mencipta nombor palsu.

System Admin bertanggungjawab untuk system/admin/support dan platform usage support. System Admin Analytics mesti fokus kepada total users, total businesses, total branches, setup completeness, role/access issues, businesses/branches missing required setup, branch tanpa assigned manager, configuration missing, platform usage support indicators, dan error/log/status indicators jika tersedia. System Admin Analytics bukan untuk commercial strategy.

Business Owner mesti melihat analytics dan data completeness untuk Business serta Branch miliknya. Branch Manager mesti melihat analytics dan data completeness untuk Branch yang ditugaskan sahaja. Business Owner / Branch Manager mesti mendapat analytics gabungan yang membezakan business-level information dan assigned branch-level information dengan jelas.

Customer tidak boleh mengakses internal analytics. Customer masih boleh melihat maklumat peribadi ringkas dalam customer portal seperti history check-in, status reward/loyalty, dan feedback history, tetapi bahagian ini tidak dipanggil Analytics.

Analytics mesti mengira dengan tepat, mengelakkan duplicate sales/reward counting, tidak mengira aktiviti tidak lengkap sebagai valid revenue, dan menunjukkan empty-state yang jelas apabila data belum cukup.

Data Analytics mesti disusun supaya boleh digunakan kemudian oleh AI Insight dan AI Action, tetapi Build Order ini tidak membina AI Insight atau AI Action.

Status Build Order 8: Analytics Launch Readiness dibina.

## 16. Build Order 9: AI Insight

Build Order 9 mesti menyediakan AI Insight Launch Readiness yang mentafsir data Analytics dan menerangkan maksud data tersebut untuk business.

AI Insight mesti menjawab apa yang sedang berlaku dalam business, pattern apa yang kelihatan, isu yang mungkin wujud, peluang yang mungkin wujud, dan data apa yang masih tidak mencukupi untuk insight yang kuat.

AI Insight mesti menggunakan data Analytics yang tersedia seperti sales/revenue analytics, Customer analytics, Product/Service analytics, Branch performance analytics, Reward analytics, Feedback analytics, dan Analytics Data Completeness & Recommendation.

AI Insight boleh menghasilkan insight seperti sales meningkat/menurun, Branch kuat/lemah, Product/Service berpotensi tinggi, Product/Service lemah, repeat Customer rendah/tinggi, feedback negatif berulang, concern terhadap reward effectiveness, dan data yang belum cukup untuk kesimpulan kuat.

Setiap insight mesti mempunyai insight title, penerangan ringkas, supporting data/evidence, confidence level, confidence reason, dan data gap jika ada. Confidence level mesti menggunakan high, medium, atau low.

Data gap bermaksud data yang hilang, tidak lengkap, tidak konsisten, atau belum cukup untuk kesimpulan kuat. Jika data lemah, AI Insight mesti menyatakan confidence rendah atau memerlukan lebih data.

Jika data tidak mencukupi, AI Insight mesti menunjukkan bahawa insight belum kuat, data apa yang kurang, kenapa data itu penting, dan area mana yang memerlukan lebih data. Sistem tidak boleh mencipta insight palsu.

AI Insight boleh menerangkan maksud masalah atau peluang, tetapi tidak boleh menghasilkan detailed action plan. Cadangan tindakan terperinci adalah skop AI Action.

Jika AI provider sebenar belum tersedia, sistem mesti menggunakan rule-based MVP insight yang selamat, berasaskan data sedia ada, dan berhati-hati dalam wording.

System Manager bertanggungjawab untuk GOS Sdn Bhd business performance monitoring. System Manager AI Insight mesti fokus kepada GOS platform/business performance, business/subscriber growth jika data tersedia, category/vertical performance, platform effectiveness, active/inactive business dan branch, usage check-in/Product/Service/feedback/reward, data completeness, revenue/subscription data gap jika data belum tersedia, dan strategic growth monitoring GOS.

System Admin AI Insight mesti fokus kepada system/admin/support sahaja seperti role setup incomplete, branch tidak assigned kepada manager, business setup incomplete, Product/Service configuration missing, data configuration missing, permission/access issue, dan usage/support issue. System Admin tidak boleh menerima commercial strategy insight seperti vertical paling profitable, category yang patut GOS expand, GOS revenue strategy, atau subscriber revenue optimization.

Business Owner mesti melihat AI Insight untuk Business dan Branch miliknya. Branch Manager mesti melihat AI Insight untuk Branch yang ditugaskan sahaja. Business Owner / Branch Manager mesti mendapat insight gabungan mengikut scope access yang dibenarkan. Customer tidak boleh mengakses AI Insight.

Output AI Insight mesti disusun supaya boleh digunakan oleh AI Action kemudian, tetapi Build Order ini tidak membina AI Action, campaign automation, POS/order/payment integration, atau integrasi luaran.

Status Build Order 9: AI Insight Launch Readiness dibina.

## 17. Build Order 10: AI Action

Build Order 10 mesti menyediakan AI Action Launch Readiness yang menukar Analytics dan AI Insight kepada recommended action yang jelas untuk persona internal/business.

AI Action mesti menjawab apa yang patut dibuat, kenapa ia penting, siapa yang patut mengurusnya, target apa yang terlibat, kejayaan patut kelihatan bagaimana, tahap confidence, dan data gap yang masih wujud jika ada.

AI Action mesti menggunakan Analytics, AI Insight, feedback summary, Product/Service performance, Branch performance, Customer repeat pattern, Reward activity, dan Data Completeness/Data Gap.

Setiap AI Action mesti mempunyai action title, recommended action, reason/why it matters, linked insight, evidence, target, owner/person in charge, priority, confidence level, success metric, suggested period, data gap jika ada, dan status.

AI Action status mesti menyokong Suggested, Planned, In Progress, Done, dan Dismissed.

AI Action boleh mencadangkan tindakan seperti meningkatkan sales Product/Service tertentu, memperbaiki Product/Service lemah, follow up feedback negatif berulang, menggalakkan repeat Customer, memperbaiki prestasi Branch lemah, menyemak reward effectiveness, melengkapkan data lemah, membantu business menggunakan GOS dengan betul, menyelesaikan isu setup/admin/support, dan menyokong monitoring prestasi platform/business GOS Sdn Bhd.

Business Owner mesti melihat AI Action untuk Business dan Branch miliknya sahaja. Branch Manager mesti melihat AI Action untuk Branch yang ditugaskan sahaja.

System Admin mesti melihat AI Action untuk admin/support sahaja seperti lengkapkan branch setup, assign Branch Manager, review role/access, fix missing configuration, support business dengan platform usage rendah, dan resolve setup/access/support issue. System Admin tidak boleh menerima commercial strategy action seperti vertical expansion, revenue strategy, atau subscriber revenue optimization.

System Manager mesti melihat AI Action untuk GOS Sdn Bhd business/platform performance seperti platform effectiveness by vertical/category, business/subscriber growth jika data tersedia, active/inactive business usage, data completeness across businesses/categories, revenue/subscription data gap jika revenue data belum wujud, dan strategic growth monitoring GOS. Sistem tidak boleh mencipta nombor revenue/subscription palsu.

Customer tidak boleh mengakses AI Action.

AI Action tidak boleh auto-execute apa-apa dalam MVP. Sistem tidak boleh menjalankan auto campaign, auto customer message, atau auto data change. Human review adalah wajib.

Jika data tidak mencukupi, AI Action mesti berhati-hati, menggunakan low atau medium confidence, menunjukkan data gap, dan mencadangkan data completion terlebih dahulu jika sesuai.

AI Action mesti evidence-based, practical, clear, cautious apabila data lemah, linked kepada data/insight sebenar, dan disusun supaya boleh menyokong execution workflow pada masa depan tanpa menjalankan execution secara automatik.

Status Build Order 10: AI Action Launch Readiness dibina.

## 18. Out Of Scope Untuk Build Order Semasa

Perkara berikut tidak termasuk dalam Build Order 10 dan tidak perlu dibina sekarang:

1. Campaign automation
2. POS/order/payment integration
3. External AI API integration
4. Advanced reports
5. Advanced charts
