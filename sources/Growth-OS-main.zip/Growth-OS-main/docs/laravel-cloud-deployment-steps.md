# Laravel Cloud Deployment Steps

Use this guide after the project has been pushed to a private GitHub repository.

## 1. Connect GitHub Repository

1. Open Laravel Cloud.
2. Connect GitHub.
3. Authorize access to the private F&B Growth repository only.
4. Select branch: `main`.
5. Confirm the selected repository is the standalone F&B Growth app, not NUSA KING.

## 2. Create Laravel Cloud App

1. Create a new Laravel Cloud application.
2. Environment name: `staging`.
3. Choose the smallest suitable compute option for a 1-2 FAP pilot.
4. Set spending limit before sharing links.
5. Enable HTTPS.
6. Confirm web root is Laravel `public`.

## 3. Configure Environment Variables

Use safe staging values. Do not paste real secrets into docs or chat.

Required:

```dotenv
APP_NAME="F&B Growth"
APP_ENV=staging
APP_DEBUG=false
APP_URL=https://your-staging-domain

SESSION_DRIVER=database
CACHE_STORE=database
QUEUE_CONNECTION=database
```

Mailtrap sandbox:

```dotenv
MAIL_MAILER=smtp
MAIL_HOST=sandbox.smtp.mailtrap.io
MAIL_PORT=2525
MAIL_USERNAME=REPLACE_WITH_MAILTRAP_USERNAME
MAIL_PASSWORD=REPLACE_WITH_MAILTRAP_PASSWORD
MAIL_FROM_ADDRESS="hello@fbgrowth.local"
MAIL_FROM_NAME="${APP_NAME}"
```

Database values should come from the managed database resource.

## 4. Attach Managed Database

1. Add a managed MySQL or MariaDB database if available.
2. Attach it to the staging app.
3. Confirm environment variables are injected or copy them securely.
4. Confirm backups/export capability.
5. Record restore process before pilot data is entered.

SQLite is not recommended for cloud staging unless persistent disk behavior and backups are confirmed.

## 5. Deploy And Build

Laravel Cloud should run Composer during deployment. Configure build/deploy steps for assets:

```bash
npm ci
npm run build
```

Confirm `public/build/manifest.json` exists after deployment.

## 6. Generate App Key If Needed

If `APP_KEY` is missing:

```bash
php artisan key:generate --force
```

Do not rotate `APP_KEY` after pilot data exists unless the impact is understood.

## 7. Run Migrations

Before real pilot data:

```bash
php artisan migrate:fresh --seed
```

After pilot data exists:

```bash
php artisan migrate --force
```

Never run `migrate:fresh --seed` after real FAP data exists unless a backup is verified and data loss is intentional.

## 8. Create Owner Account

Public owner registration is disabled. Use:

```bash
php artisan users:create-owner --name="Owner Name" --email="owner@example.com" --password="temporary-strong-password"
```

Then:

- Ask owner to log in.
- Ask owner to change password.
- Confirm business belongs to owner.
- Confirm active loyalty program exists.

## 9. Queue Worker Setup

Current MVP does not require queued jobs for core flows, but queue is configured for database.

If enabling a worker:

```bash
php artisan queue:work database --queue=default --tries=3 --timeout=90
```

Use Laravel Cloud worker/process settings if available.

## 10. Scheduler Setup

No scheduled product jobs are enabled yet, but staging should be scheduler-ready.

Configure scheduler/cron equivalent:

```bash
php artisan schedule:run
```

Run every minute if supported.

## 11. Test Public QR Link

Open:

```text
https://your-staging-domain/b/wanchu-corner
```

Confirm:

- Business name appears.
- Registration form appears.
- Check-in form appears.
- Feedback link appears.
- Mobile browser can submit forms.

## 12. Run First FAP Smoke Test

Use:

```text
docs/first-fap-smoke-test.md
```

Confirm:

- Owner login.
- Business dashboard.
- QR customer registration.
- Repeat check-in.
- Reward eligibility.
- Reward redemption.
- Feedback submit.
- Follow-up page.
- Weekly report.

## 13. Final Deployment Checks

Run:

```bash
php artisan route:list
php artisan migrate:status
php artisan users:create-owner --help
php artisan queue:failed
```

If test dependencies are installed in staging:

```bash
php artisan test
```

If not, tests must pass locally or in CI immediately before deployment.

## 14. Before Inviting FAP

- Confirm spending limit.
- Confirm backup/export works.
- Confirm demo passwords changed.
- Confirm `APP_DEBUG=false`.
- Confirm public owner `/register` is unavailable.
- Confirm `DELETE /profile` is unavailable.
- Confirm owner cannot access another owner's business.

