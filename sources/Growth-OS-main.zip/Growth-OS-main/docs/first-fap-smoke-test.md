# First FAP Smoke Test

Run this after staging deployment and before inviting the first FAP tester.

Use one business first, for example `wanchu-corner`.

## 1. Owner Login

1. Open the staging login URL.
2. Log in as the supervised owner account.
3. Confirm login succeeds.
4. Confirm `/register` is not available for public owner registration.

Expected result: owner reaches dashboard or can open `/businesses`.

## 2. Business Dashboard

1. Open `/businesses`.
2. Open the pilot business.
3. Open Dashboard.
4. Confirm cards load.
5. Confirm public QR link is visible.

Expected result: owner sees only their own business unless logged in as admin.

## 3. QR Customer Registration

1. Open `/b/{business-slug}` in a private/incognito browser or phone.
2. Register a customer with:
   - Name: `Smoke Test Customer`
   - WhatsApp: a test number not already used
3. Submit.

Expected result:

- Status page loads.
- Customer name appears.
- Stamp progress appears.
- Welcome stamp is granted if enabled.

## 4. Repeat Check-In

1. Return to `/b/{business-slug}`.
2. Enter the same WhatsApp number in Returning customer check-in.
3. Submit.

Expected result:

- If the registration already created today's welcome check-in, the app says today's check-in has already been recorded.
- No duplicate daily stamp is added.

## 5. Reward Eligibility

1. In staging test data, prepare a customer with enough stamps or use repeated controlled data setup.
2. Open the customer status page through check-in.

Expected result:

- Status page shows the customer is eligible to claim the reward.
- Customer cannot self-redeem.
- Message tells customer to show the screen to staff/owner.

## 6. Reward Redemption

1. Log in as owner.
2. Open business detail page.
3. Find the eligible customer section.
4. Click Redeem.

Expected result:

- Redemption succeeds.
- Redemption history shows reward.
- Current stamps reset to 0.
- Total stamps earned does not reset.
- Total rewards redeemed increments.

## 7. Feedback Submit

1. Open `/b/{business-slug}/feedback`.
2. Submit food rating, service rating, price feedback, and a short comment.
3. Submit another feedback with matching WhatsApp if needed.

Expected result:

- Thank-you page loads.
- Owner feedback page shows latest feedback.
- Matching WhatsApp attaches feedback to customer.
- Non-matching or blank WhatsApp remains anonymous.

## 8. Follow-Up Page

1. Log in as owner.
2. Open Follow-ups from dashboard.

Expected result:

- Dormant customers section loads.
- New customers section loads.
- Near-reward customers section loads.
- Eligible reward customers section loads.
- Open WhatsApp buttons use `wa.me` links when numbers are valid.
- Copy Message button is visible.

## 9. Weekly Report

1. Log in as owner.
2. Open Weekly Report from dashboard.

Expected result:

- New customers this week appears.
- Check-ins this week appears.
- Feedback summary appears.
- Price feedback summary appears.
- Rule-based suggestions appear.
- Copy Summary block is visible.

## 10. Access Control Spot Check

1. Log in as one owner.
2. Try opening another business dashboard URL.

Expected result: request is forbidden.

## Smoke Test Pass Criteria

- Owner can log in.
- Owner sees only authorized business data.
- Public customer registration works.
- Duplicate daily check-in is blocked.
- Reward redemption works from authenticated owner area.
- Feedback works.
- Follow-up page loads.
- Weekly report loads.
- No debug stack traces are visible.

