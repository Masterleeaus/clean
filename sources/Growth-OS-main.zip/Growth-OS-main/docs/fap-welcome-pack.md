# Welcome Pack FAP Growth OS-F&B

Dokumen ini disediakan untuk Founding Advisory Partners (FAP) yang membantu menguji, memberi maklum balas, dan membentuk arah awal Growth OS-F&B.

## 1. Apa Itu Growth OS-F&B

Growth OS-F&B ialah sistem operasi pertumbuhan ringkas untuk bisnes makanan dan minuman. Fokus awalnya ialah membantu pemilik F&B mengurus hubungan pelanggan melalui aliran loyalty, check-in pelanggan, rekod ganjaran, maklum balas pelanggan, dan follow-up manual.

Pada peringkat pilot ini, Growth OS-F&B bukan sistem lengkap untuk semua operasi restoran. Ia ialah produk awal yang sedang diuji bersama bisnes sebenar supaya masalah, keperluan, dan workflow harian pemilik dapat difahami dengan lebih tepat.

## 2. Tujuan FAP

FAP diwujudkan untuk membina produk ini bersama pengguna awal yang benar-benar faham dunia F&B.

Tujuan utama FAP ialah:

- Menguji sama ada workflow awal mudah difahami oleh pemilik dan pelanggan.
- Memberi maklum balas jujur tentang apa yang berguna, mengelirukan, atau tidak perlu.
- Membantu mengenal pasti masalah sebenar dalam operasi loyalty dan follow-up pelanggan.
- Membantu menentukan ciri mana yang patut diberi keutamaan selepas pilot awal.
- Menjadi rakan penasihat awal, bukan sekadar pengguna percubaan.

## 3. Siapa FAP Sesuai

FAP sesuai untuk:

- Pemilik kafe, restoran, gerai, food truck, home-based F&B, kiosk, atau jenama makanan kecil.
- Pengusaha yang mahu pelanggan datang semula dengan lebih konsisten.
- Bisnes yang sudah ada pelanggan berulang, walaupun belum ada sistem loyalty formal.
- Pemilik yang sanggup mencuba workflow baru secara terkawal.
- Pengusaha yang boleh beri maklum balas praktikal berdasarkan pengalaman harian.

FAP mungkin kurang sesuai jika bisnes memerlukan integrasi POS, automasi WhatsApp penuh, sistem staff kompleks, atau modul kewangan lengkap dari hari pertama.

## 4. Apa Yang FAP Akan Dapat

Sebagai FAP, anda akan mendapat:

- Akses awal kepada Growth OS-F&B untuk pilot terkawal.
- Panduan onboarding dan demo ringkas.
- Ruang memberi input tentang ciri yang paling penting untuk bisnes F&B sebenar.
- Keutamaan untuk maklum balas produk semasa fasa awal.
- Peluang membentuk arah produk sebelum ia dibuka kepada lebih ramai pengguna.
- Komunikasi terus untuk isu, cadangan, dan pemerhatian semasa pilot.

FAP tidak dikenakan komitmen jangka panjang hanya kerana menyertai pilot awal. Sebarang terma komersial masa depan akan dibincangkan secara berasingan.

## 5. Apa Yang FAP Perlu Bantu

FAP diminta membantu dalam perkara berikut:

- Cuba aliran owner dashboard dan public customer page.
- Guna link QR/public link bersama pelanggan terpilih secara terkawal.
- Perhatikan sama ada pelanggan faham proses daftar, check-in, stamp, dan reward.
- Semak sama ada mesej follow-up manual sesuai untuk dihantar melalui WhatsApp.
- Beri maklum balas tentang perkataan, paparan, langkah, dan data yang ditunjukkan.
- Laporkan isu, kekeliruan, atau cadangan penambahbaikan.
- Beri input tentang ciri mana yang paling bernilai untuk fasa seterusnya.

Maklum balas tidak perlu formal. Nota ringkas, voice note, mesej WhatsApp, atau sesi panggilan pendek sudah memadai.

## 6. Skop Pilot Awal

Skop pilot awal tertumpu kepada fungsi asas berikut:

- Profil bisnes dan maklumat owner.
- Loyalty program ringkas berdasarkan stamp.
- Public customer page melalui link bisnes.
- Pendaftaran pelanggan dengan nama dan nombor WhatsApp.
- Check-in pelanggan berulang.
- Paparan status stamp dan reward eligibility.
- Pengesahan redemption oleh owner.
- Maklum balas pelanggan.
- Senarai follow-up manual untuk pelanggan tertentu.
- Weekly report asas untuk owner.

Pilot awal boleh dijalankan dengan jumlah pelanggan terhad. Matlamatnya ialah memahami kualiti workflow, bukan mengejar penggunaan besar-besaran.

## 7. Apa Yang Bukan Dalam Skop Pilot

Perkara berikut bukan sebahagian daripada skop pilot awal:

- Integrasi POS.
- Pembayaran dalam aplikasi.
- Inventory atau stok.
- Jadual staff, role staff kompleks, atau payroll.
- Automasi WhatsApp penuh.
- Broadcast marketing automatik.
- AI recommendation.
- Advanced CRM.
- Loyalty multi-branch yang kompleks.
- Mobile app native.
- Self-service public signup untuk semua owner.

Jika perkara di atas penting untuk bisnes anda, ia boleh direkodkan sebagai input untuk fasa akan datang.

## 8. Cara Komunikasi

Komunikasi pilot akan dibuat secara ringkas dan terus.

Saluran utama:

- WhatsApp untuk update, soalan cepat, isu kecil, dan maklum balas harian.
- Google Meet atau panggilan ringkas untuk onboarding, demo, atau review.
- Dokumen ringkas atau checklist jika perlu untuk sesi testing.

Untuk isu penting, sila sertakan:

- Apa yang anda cuba buat.
- Apa yang berlaku.
- Screenshot jika sesuai.
- Sama ada isu berlaku kepada owner atau pelanggan.
- Masa lebih kurang isu berlaku.

## 9. Timeline Ringkas

Timeline pilot awal dicadangkan seperti berikut:

- Hari 0: FAP setuju menyertai pilot dan maklumat asas bisnes dikumpulkan.
- Hari 1-2: Setup akaun owner, profil bisnes, loyalty offer, dan link public customer page.
- Hari 3-7: Onboarding, demo, dan testing dalaman bersama owner.
- Minggu 2: Ujian dengan pelanggan terpilih secara terkawal.
- Minggu 3: Kumpul maklum balas, semak isu, dan tentukan penambahbaikan utama.
- Minggu 4: Review ringkas sama ada pilot patut diteruskan, diubah, atau dihentikan.

Timeline ini boleh disesuaikan mengikut kesediaan bisnes dan tahap aktiviti pelanggan.

## 10. Expectation Yang Jelas

Sebelum memulakan pilot, harap maklum perkara berikut:

- Ini ialah produk awal, jadi mungkin ada kekurangan, perubahan, atau isu kecil.
- Pilot dijalankan secara terkawal, bukan public launch besar-besaran.
- Fokus utama ialah pembelajaran dan validasi workflow.
- Maklum balas jujur lebih penting daripada penggunaan yang kelihatan sempurna.
- Tidak semua cadangan boleh dibina serta-merta.
- Sebarang data pelanggan yang digunakan perlu dikendalikan dengan berhati-hati.
- Jangan gunakan pilot untuk promosi besar sebelum aliran disahkan stabil.

Matlamat bersama ialah membina sistem yang benar-benar berguna untuk bisnes F&B, bukan sekadar menambah ciri.

## 11. Confidentiality / Jangan Kongsi Akses

Akses pilot adalah untuk FAP dan pasukan bisnes yang dibenarkan sahaja.

Sila patuhi perkara berikut:

- Jangan kongsi username, password, atau link akses owner dengan pihak luar.
- Jangan beri akses dashboard kepada individu yang tidak terlibat dalam pilot.
- Jangan sebarkan screenshot yang mengandungi data pelanggan.
- Jangan kongsi data pelanggan, nombor WhatsApp, atau rekod transaksi loyalty kepada pihak luar.
- Jangan umumkan akses pilot sebagai produk terbuka tanpa persetujuan terlebih dahulu.

Jika anda mahu libatkan team member tertentu, maklumkan dahulu supaya akses dan skop boleh diurus dengan betul.

## 12. Next Steps Selepas Mereka Setuju

Selepas FAP bersetuju untuk menyertai pilot:

1. Kongsi nama bisnes, nama owner, nombor WhatsApp owner, dan jenis bisnes.
2. Tetapkan tawaran loyalty awal, contohnya jumlah stamp diperlukan dan jenis reward.
3. Tetapkan satu sesi onboarding ringkas.
4. Setup akaun owner dan profil bisnes.
5. Semak public customer page bersama-sama.
6. Jalankan demo owner flow dan customer flow.
7. Pilih kumpulan pelanggan kecil untuk testing awal.
8. Kumpul maklum balas selepas beberapa hari penggunaan.
9. Buat review ringkas tentang isu, peluang, dan keputusan fasa seterusnya.

Terima kasih kerana menjadi sebahagian daripada fasa awal Growth OS-F&B. Input FAP akan membantu memastikan produk ini dibina berdasarkan realiti operasi F&B sebenar.
