# Physical Check-in + Online Check-in Flow

Date: 2026-07-11

Status: implemented.

## Locked Rule

GOS-F&B is not a POS, ordering, cart, delivery, pickup, or payment system. Purchase/order/payment remains outside the platform.

Customer only performs check-in:

- `physical`: `Check-in di Premis`
- `online`: `Check-in untuk Order Online`

Physical Check-in means the customer scans the premises QR or uses the customer portal while at the shop.

Online Check-in means the customer uses customer portal mode or an online link/code for an order made through WhatsApp, delivery, pickup, or another external channel.

## Reward Rule

Reward/stamp is confirmed only after:

- valid check-in exists; and
- Branch Manager / Business Owner cum Branch Manager assigned to the branch captures a valid Product/Service purchase.

Cooldown-blocked check-in does not create reward/stamp. No Purchase does not create reward/stamp.

Customer cannot self-claim purchase, choose reward, set purchase status, or call Capture Purchase / Mark No Purchase routes.

## Internal Operation

Pending Purchase Capture is internal to assigned Branch Manager / BO cum BM only.

BM-facing labels:

- `Pending Purchase Capture — Physical`
- `Pending Purchase Capture — Online`

Both modes use the same internal decisions:

- Capture Purchase: valid Product/Service capture grants reward/stamp.
- Mark No Purchase: check-in becomes no-reward/no-purchase and no stamp is issued.

## Customer Visibility

Customer sees check-in success and confirmed reward/stamp only. Customer does not see Pending Purchase Capture, Capture Purchase, Mark No Purchase, AI Insight, or AI Action.

Feedback remains free through `Hantar Maklumbalas`. There is no mandatory Pending Feedback.

## Analytics / AI

Analytics now carries mode signals for:

- physical check-ins count
- online check-ins count
- pending purchase capture by mode
- no purchase by mode
- capture conversion by mode

AI Insight / AI Action remain internal and suggestion-only.
