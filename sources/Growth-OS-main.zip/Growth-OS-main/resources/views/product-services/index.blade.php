<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Product/Service') }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ $business->name }}</p>
            </div>
            @can('create', App\Models\ProductService::class)
                <a href="{{ route('businesses.product-services.create', array_filter(['business' => $business, 'category' => $activeCategory])) }}" class="rounded-md bg-gray-900 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-700">{{ __('Add Product/Service') }}</a>
            @endcan
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            @if (session('status'))
                <div class="mb-6 rounded-md bg-green-50 p-4 text-sm font-medium text-green-800">{{ session('status') }}</div>
            @endif

            @if (session('review_warnings'))
                <div class="mb-6 rounded-md bg-yellow-50 p-4 text-sm font-medium text-yellow-900">
                    <p class="font-semibold">{{ __('Product/Service Review Alerts') }}</p>
                    <ul class="mt-2 list-disc space-y-1 ps-5">
                        @foreach (session('review_warnings') as $warning)
                            <li>{{ $warning }}</li>
                        @endforeach
                    </ul>
                </div>
            @endif

            <nav class="mb-6 flex gap-2 overflow-x-auto rounded-lg bg-white p-2 shadow-sm" aria-label="{{ __('Product/Service categories') }}">
                <a href="{{ route('businesses.product-services.index', $business) }}" data-category-tab="Semua" class="shrink-0 rounded-md px-3 py-2 text-sm font-semibold {{ $activeCategory === null ? 'bg-gray-900 text-white' : 'text-gray-700 hover:bg-gray-50' }}">
                    {{ __('Semua') }} ({{ $products->count() }})
                </a>
                @foreach ($categoryTabs as $categoryTab)
                    @php
                        $categoryCount = ($groupedProducts->get($categoryTab) ?? collect())->count();
                    @endphp
                    <a href="{{ route('businesses.product-services.index', ['business' => $business, 'category' => $categoryTab]) }}" data-category-tab="{{ $categoryTab }}" class="shrink-0 rounded-md px-3 py-2 text-sm font-semibold {{ $activeCategory === $categoryTab ? 'bg-gray-900 text-white' : 'text-gray-700 hover:bg-gray-50' }}">
                        {{ $categoryTab }} ({{ $categoryCount }})
                    </a>
                @endforeach
            </nav>

            @forelse ($visibleGroupedProducts as $category => $categoryProducts)
                <section class="mb-6 overflow-hidden rounded-lg bg-white shadow-sm" data-category="{{ $category }}">
                    <div class="flex flex-wrap items-center justify-between gap-3 border-b border-gray-100 bg-gray-50 px-5 py-4">
                        <h3 class="text-sm font-semibold uppercase tracking-wide text-gray-900">{{ $category }}</h3>
                        <x-status-badge>{{ trans_choice(':count item|:count items', $categoryProducts->count(), ['count' => $categoryProducts->count()]) }}</x-status-badge>
                    </div>
                    <div class="divide-y divide-gray-100">
                        @forelse ($categoryProducts as $product)
                            <div class="grid gap-3 p-5 sm:grid-cols-[1fr_auto] sm:items-center" data-product-name="{{ $product->name }}">
                                <div>
                                    <p class="font-medium text-gray-900">{{ $product->name }}</p>
                                    <p class="mt-1 text-sm text-gray-500">
                                        {{ $product->type }}
                                        @if ($product->branch)
                                            - {{ $product->branch->name }}
                                        @else
                                            - {{ __('All branches') }}
                                        @endif
                                    </p>
                                    <p class="mt-1 text-sm font-medium text-gray-700">{{ __('RM :price', ['price' => number_format((float) $product->price, 2)]) }}</p>
                                    @if ($product->review_status && $product->review_status !== 'active')
                                        <p class="mt-2 text-xs font-semibold text-yellow-800">{{ $product->review_note }}</p>
                                    @endif
                                </div>
                                <div class="flex flex-wrap items-center gap-3 sm:justify-end">
                                    <span class="text-sm {{ $product->is_active ? 'text-green-700' : 'text-gray-500' }}">{{ $product->is_active ? __('Active') : __('Inactive') }}</span>
                                    @if (($product->review_status ?? 'active') === 'flagged')
                                        <x-status-badge tone="danger">{{ __('Flagged') }}</x-status-badge>
                                    @elseif (($product->review_status ?? 'active') === 'needs_review')
                                        <x-status-badge tone="warning">{{ __('Needs Review') }}</x-status-badge>
                                    @elseif (($product->review_status ?? 'active') === 'archived')
                                        <x-status-badge tone="slate">{{ __('Archived') }}</x-status-badge>
                                    @endif
                                    @can('update', $product)
                                        <a href="{{ route('businesses.product-services.edit', ['business' => $business, 'productService' => $product]) }}" class="rounded-md border border-gray-300 px-3 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Edit') }}</a>
                                    @endcan
                                    @can('delete', $product)
                                        <form method="POST" action="{{ route('businesses.product-services.destroy', ['business' => $business, 'productService' => $product]) }}">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm font-semibold text-red-700 hover:bg-red-100">
                                                {{ $product->captures_count > 0 ? __('Archive') : __('Delete') }}
                                            </button>
                                        </form>
                                    @endcan
                                </div>
                            </div>
                        @empty
                            <p class="p-5 text-sm text-gray-500">{{ __('Tiada Product/Service dalam kategori ini.') }}</p>
                        @endforelse
                    </div>
                </section>
            @empty
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <p class="text-sm text-gray-500">{{ __('No Product/Service records yet.') }}</p>
                </section>
            @endforelse
        </div>
    </div>
</x-app-layout>
