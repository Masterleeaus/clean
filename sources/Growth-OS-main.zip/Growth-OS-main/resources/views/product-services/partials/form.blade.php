@php
    $selectedCategoryValue = old('category', $productService?->category ?? ($selectedCategory ?? 'Makanan'));
    $isNewCategory = $selectedCategoryValue === '__new';
@endphp

<div>
    <x-input-label for="name" :value="__('Name')" />
    <x-text-input id="name" name="name" type="text" class="mt-1 block w-full" :value="old('name', $productService?->name)" required autofocus />
    <x-input-error class="mt-2" :messages="$errors->get('name')" />
</div>

<div x-data="{ category: @js($selectedCategoryValue) }">
    <x-input-label for="category" :value="__('Kategori')" />
    <select id="category" name="category" x-model="category" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
        @foreach ($categoryOptions as $category)
            <option value="{{ $category }}" @selected($selectedCategoryValue === $category)>{{ $category }}</option>
        @endforeach
        <option value="__new" @selected($isNewCategory)>{{ __('+ Tambah kategori baharu') }}</option>
    </select>
    <x-input-error class="mt-2" :messages="$errors->get('category')" />
    <div class="mt-3" x-show="category === '__new'" x-cloak>
        <x-input-label for="category_new" :value="__('Nama kategori baharu')" />
        <x-text-input id="category_new" name="category_new" type="text" class="mt-1 block w-full" :value="old('category_new')" placeholder="Contoh: Catering" />
        <x-input-error class="mt-2" :messages="$errors->get('category_new')" />
    </div>
</div>

<div>
    <x-input-label for="type" :value="__('Type')" />
    <select id="type" name="type" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
        @foreach (['product' => 'Product', 'service' => 'Service', 'subscription' => 'Subscription'] as $value => $label)
            <option value="{{ $value }}" @selected(old('type', $productService?->type ?? 'product') === $value)>{{ __($label) }}</option>
        @endforeach
    </select>
    <x-input-error class="mt-2" :messages="$errors->get('type')" />
</div>

<div>
    <x-input-label for="price" :value="__('Price (RM)')" />
    <x-text-input id="price" name="price" type="number" min="0" step="0.01" class="mt-1 block w-full" :value="old('price', $productService?->price)" required />
    <x-input-error class="mt-2" :messages="$errors->get('price')" />
</div>

<div>
    <x-input-label for="branch_id" :value="__('Branch')" />
    <select id="branch_id" name="branch_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
        @unless (auth()->user()?->isBranchManager() && ! auth()->user()?->isOwner() && ! auth()->user()?->isSystemAdmin())
            <option value="">{{ __('All branches') }}</option>
        @endunless
        @foreach ($branches as $branch)
            <option value="{{ $branch->id }}" @selected(old('branch_id', $productService?->branch_id) == $branch->id)>{{ $branch->name }}</option>
        @endforeach
    </select>
    <x-input-error class="mt-2" :messages="$errors->get('branch_id')" />
</div>

<label class="flex items-center gap-3">
    <input type="checkbox" name="is_active" value="1" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" @checked(old('is_active', $productService?->is_active ?? true))>
    <span class="text-sm font-medium text-gray-700">{{ __('Active') }}</span>
</label>
