<x-app-layout>
    <x-slot name="header">
        <div>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __($title) }}</h2>
            <p class="mt-1 text-sm text-gray-500">{{ __($subtitle) }}</p>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            <section class="rounded-lg bg-white p-6 shadow-sm">
                <div class="flex flex-col gap-4 lg:flex-row lg:items-end lg:justify-between">
                    <div>
                        <p class="text-sm font-medium uppercase tracking-wide text-gray-500">{{ __('Analytics scope') }}</p>
                        <h3 class="mt-2 text-lg font-semibold text-gray-900">{{ __($scopeLabel) }}</h3>
                        <p class="mt-1 text-sm text-gray-500">{{ $period['date_from'] }} - {{ $period['date_to'] }}</p>
                    </div>

                    <form method="GET" action="{{ route('analytics.index') }}" class="grid gap-3 sm:grid-cols-[160px_1fr_1fr_auto]">
                        <select name="period" class="rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            @foreach ($periodOptions as $value => $label)
                                <option value="{{ $value }}" @selected($period['filter'] === $value)>{{ __($label) }}</option>
                            @endforeach
                        </select>
                        <input type="date" name="date_from" value="{{ $period['date_from'] }}" class="rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        <input type="date" name="date_to" value="{{ $period['date_to'] }}" class="rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                        <button type="submit" class="rounded-md bg-gray-900 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-700">{{ __('Filter') }}</button>
                    </form>
                </div>
            </section>

            @if ($emptyState)
                <section class="rounded-lg bg-yellow-50 p-6 text-sm text-yellow-900 shadow-sm">
                    {{ __($emptyState) }}
                </section>
            @endif

            <section class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                @foreach ($summary as $label => $value)
                    <div class="rounded-lg bg-white p-5 shadow-sm">
                        <p class="text-sm font-medium text-gray-500">{{ __($label) }}</p>
                        <p class="mt-2 text-2xl font-semibold text-gray-900">{{ $value }}</p>
                    </div>
                @endforeach
            </section>

            @if (! empty($platformMetrics))
                <section id="ai-provider-status" class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('GOS Platform / Business Performance') }}</h3>
                    <div class="mt-5 grid gap-4 lg:grid-cols-2">
                        @foreach ($platformMetrics as $group => $items)
                            <div class="rounded-md bg-gray-50 p-4">
                                <h4 class="text-sm font-semibold uppercase tracking-wide text-gray-700">{{ __($group) }}</h4>
                                <dl class="mt-3 space-y-2">
                                    @foreach ($items as $label => $value)
                                        <div class="flex items-start justify-between gap-4">
                                            <dt class="text-sm text-gray-500">{{ __($label) }}</dt>
                                            <dd class="text-right text-sm font-semibold text-gray-900">{{ $value }}</dd>
                                        </div>
                                    @endforeach
                                </dl>
                            </div>
                        @endforeach
                    </div>
                </section>
            @endif

            @if (! empty($adminSupportMetrics))
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('System Admin Support Analytics') }}</h3>
                    <div class="mt-5 grid gap-4 lg:grid-cols-3">
                        @foreach ($adminSupportMetrics as $group => $items)
                            <div class="rounded-md bg-gray-50 p-4">
                                <h4 class="text-sm font-semibold uppercase tracking-wide text-gray-700">{{ __($group) }}</h4>
                                <dl class="mt-3 space-y-2">
                                    @foreach ($items as $label => $value)
                                        <div class="flex items-start justify-between gap-4">
                                            <dt class="text-sm text-gray-500">{{ __($label) }}</dt>
                                            <dd class="text-right text-sm font-semibold text-gray-900">{{ $value }}</dd>
                                        </div>
                                    @endforeach
                                </dl>
                            </div>
                        @endforeach
                    </div>
                </section>
            @endif

            @if (($personaScope ?? null) === 'system_admin' && ! empty($aiProviderStatus))
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('AI Provider Status') }}</h3>
                    <dl class="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                        <div class="rounded-md bg-gray-50 p-4">
                            <dt class="text-sm text-gray-500">{{ __('Active/default provider') }}</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ $aiProviderStatus['default_provider_label'] }}</dd>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <dt class="text-sm text-gray-500">{{ __('External AI') }}</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ $aiProviderStatus['external_enabled'] ? __('Enabled') : __('Disabled') }}</dd>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <dt class="text-sm text-gray-500">{{ __('Last used provider') }}</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ $aiProviderStatus['last_used_provider_label'] ?? __('None yet') }}</dd>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <dt class="text-sm text-gray-500">{{ __('AI Action mode') }}</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ __('Suggestion Only') }}</dd>
                        </div>
                    </dl>

                    <div class="mt-5 rounded-md bg-gray-50 p-4">
                        <p class="text-sm font-medium text-gray-500">{{ __('Priority chain') }}</p>
                        <div class="mt-3 flex flex-wrap items-center gap-2 text-sm">
                            @foreach ($aiProviderStatus['priority_chain'] as $provider)
                                <span class="rounded-md border border-gray-200 bg-white px-3 py-1 font-medium text-gray-800">
                                    {{ $provider['label'] }}: {{ __($provider['status']) }}
                                </span>
                                @if (! $loop->last)
                                    <span class="text-gray-400">&rarr;</span>
                                @endif
                            @endforeach
                        </div>
                    </div>

                    <p class="mt-4 text-sm text-gray-600">
                        {{ $aiProviderStatus['fallback_used'] ? __('Fallback used in last AI run.') : __('No fallback recorded in last AI run.') }}
                    </p>
                </section>
            @endif

            @if (($personaScope ?? null) !== 'system_admin')
            <section class="grid gap-6 lg:grid-cols-3">
                <div class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Sales by day/week/month') }}</h3>
                    <div class="mt-5 divide-y divide-gray-100">
                        @forelse ($salesAnalytics['salesByPeriod'] as $row)
                            <div class="flex items-center justify-between py-3">
                                <p class="font-semibold text-gray-900">{{ $row['label'] }}</p>
                                <p class="text-sm text-gray-600">RM {{ number_format($row['total'], 2) }} / {{ $row['captures'] }}</p>
                            </div>
                        @empty
                            <p class="text-sm text-gray-500">{{ __('No valid revenue yet.') }}</p>
                        @endforelse
                    </div>
                </div>

                <div class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Sales by branch') }}</h3>
                    <div class="mt-5 divide-y divide-gray-100">
                        @forelse ($salesAnalytics['salesByBranch'] as $row)
                            <div class="flex items-center justify-between py-3">
                                <p class="font-semibold text-gray-900">{{ $row['name'] }}</p>
                                <p class="text-sm text-gray-600">RM {{ number_format($row['total'], 2) }}</p>
                            </div>
                        @empty
                            <p class="text-sm text-gray-500">{{ __('No branch sales yet.') }}</p>
                        @endforelse
                    </div>
                </div>

                <div class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Sales by Product/Service') }}</h3>
                    <div class="mt-5 divide-y divide-gray-100">
                        @forelse ($salesAnalytics['salesByProduct'] as $row)
                            <div class="py-3">
                                <p class="font-semibold text-gray-900">{{ $row['name'] }}</p>
                                <p class="mt-1 text-sm text-gray-600">{{ __('Qty') }}: {{ $row['quantity'] }} / RM {{ number_format($row['total'], 2) }}</p>
                            </div>
                        @empty
                            <p class="text-sm text-gray-500">{{ __('No Product/Service sales yet.') }}</p>
                        @endforelse
                    </div>
                </div>
            </section>

            <section class="grid gap-6 lg:grid-cols-2">
                <div class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Customer Analytics') }}</h3>
                    <div class="mt-5 grid gap-4 sm:grid-cols-2">
                        @foreach ($customerAnalytics as $label => $value)
                            <div class="rounded-md bg-gray-50 p-4">
                                <p class="text-sm text-gray-500">{{ __(ucwords(str_replace('_', ' ', $label))) }}</p>
                                <p class="mt-2 text-2xl font-semibold text-gray-900">
                                    {{ $label === 'value' ? 'RM '.number_format($value, 2) : $value }}
                                </p>
                            </div>
                        @endforeach
                    </div>
                </div>

                <div class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Product/Service Analytics') }}</h3>
                    <div class="mt-5 grid gap-4 sm:grid-cols-2">
                        <div class="rounded-md bg-gray-50 p-4">
                            <p class="text-sm text-gray-500">{{ __('Popular Product/Service') }}</p>
                            <p class="mt-2 font-semibold text-gray-900">{{ $productAnalytics['popular']['name'] ?? '-' }}</p>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <p class="text-sm text-gray-500">{{ __('Highest sales Product/Service') }}</p>
                            <p class="mt-2 font-semibold text-gray-900">{{ $productAnalytics['highestSales']['name'] ?? '-' }}</p>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <p class="text-sm text-gray-500">{{ __('Most purchased Product/Service') }}</p>
                            <p class="mt-2 font-semibold text-gray-900">{{ $productAnalytics['mostPurchased']['name'] ?? '-' }}</p>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <p class="text-sm text-gray-500">{{ __('Weak/low activity Product/Service') }}</p>
                            <p class="mt-2 font-semibold text-gray-900">{{ $productAnalytics['lowActivity']->first()['name'] ?? '-' }}</p>
                        </div>
                    </div>
                </div>
            </section>

            <section class="rounded-lg bg-white p-6 shadow-sm">
                <h3 class="text-base font-semibold text-gray-900">{{ __('Branch Performance Analytics') }}</h3>
                <div class="mt-5 divide-y divide-gray-100">
                    @forelse ($branchAnalytics as $branch)
                        <div class="grid gap-3 py-4 md:grid-cols-3 lg:grid-cols-6">
                            <p class="font-semibold text-gray-900 md:col-span-3 lg:col-span-1">{{ $branch['name'] }}</p>
                            <p class="text-sm text-gray-600">{{ __('Sales') }}: RM {{ number_format($branch['sales'], 2) }}</p>
                            <p class="text-sm text-gray-600">{{ __('Check-ins') }}: {{ $branch['check_ins'] }}</p>
                            <p class="text-sm text-gray-600">{{ __('Customers') }}: {{ $branch['customers'] }}</p>
                            <p class="text-sm text-gray-600">{{ __('Repeat') }}: {{ $branch['repeat_customers'] }}</p>
                            <p class="text-sm text-gray-600">{{ __('Feedback') }}: {{ $branch['feedback_pending'] }} pending / {{ $branch['feedback_action_needed'] }} action</p>
                        </div>
                    @empty
                        <p class="text-sm text-gray-500">{{ __('No branch analytics available.') }}</p>
                    @endforelse
                </div>
            </section>

            <section class="rounded-lg bg-white p-6 shadow-sm">
                <h3 class="text-base font-semibold text-gray-900">{{ __('Core Operation Analytics') }}</h3>
                <div class="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                    @foreach ($operationAnalytics as $label => $value)
                        <div class="rounded-md bg-gray-50 p-4">
                            <p class="text-sm text-gray-500">{{ __($label) }}</p>
                            <p class="mt-2 text-2xl font-semibold text-gray-900">{{ $value }}</p>
                        </div>
                    @endforeach
                </div>
            </section>

            <section class="grid gap-6 lg:grid-cols-2">
                <div class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Reward Analytics') }}</h3>
                    <div class="mt-5 grid gap-4 sm:grid-cols-3">
                        @foreach ($rewardAnalytics as $label => $value)
                            <div class="rounded-md bg-gray-50 p-4">
                                <p class="text-sm text-gray-500">{{ __($label) }}</p>
                                <p class="mt-2 text-2xl font-semibold text-gray-900">{{ $value }}</p>
                            </div>
                        @endforeach
                    </div>
                </div>

                <div class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Feedback Analytics') }}</h3>
                    <div class="mt-5 grid gap-4 sm:grid-cols-2">
                        @foreach ($feedbackAnalytics as $label => $value)
                            <div class="rounded-md bg-gray-50 p-4">
                                <p class="text-sm text-gray-500">{{ __($label) }}</p>
                                <p class="mt-2 text-2xl font-semibold text-gray-900">{{ $value }}</p>
                            </div>
                        @endforeach
                    </div>
                </div>
            </section>

            <section class="rounded-lg bg-white p-6 shadow-sm">
                <h3 class="text-base font-semibold text-gray-900">{{ __('Analytics Data Completeness & Recommendation') }}</h3>
                <div class="mt-5 divide-y divide-gray-100">
                    @forelse ($dataCompleteness as $item)
                        <div class="grid gap-3 py-4 lg:grid-cols-4">
                            <p class="font-semibold text-gray-900">{{ __($item['missing']) }}</p>
                            <p class="text-sm text-gray-600">{{ __($item['reason']) }}</p>
                            <p class="text-sm text-gray-600">{{ __($item['effect']) }}</p>
                            <p class="text-sm font-medium text-gray-900">{{ __($item['recommendation']) }}</p>
                        </div>
                    @empty
                        <p class="text-sm text-gray-500">{{ __('Data mencukupi untuk analytics asas.') }}</p>
                    @endforelse
                </div>
            </section>
            @endif

            <section class="rounded-lg bg-white p-6 shadow-sm">
                <div class="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                    <div>
                        <h3 class="text-base font-semibold text-gray-900">{{ __('AI Insight Engine') }}</h3>
                        <p class="mt-1 text-sm text-gray-500">{{ __('Insight menerangkan maksud data analytics; action plan berada dalam AI Action.') }}</p>
                    </div>
                    <p class="text-sm text-gray-500">
                        {{ __('Rule-based MVP, data-based safety fallback') }}; {{ __('Provider') }}: {{ $aiInsightProvider['provider'] ?? 'rule_based' }}
                    </p>
                </div>

                <div class="mt-5 grid gap-4 lg:grid-cols-2">
                    @forelse ($aiInsights as $insight)
                        <article class="rounded-lg border border-gray-200 p-5">
                            <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                                <h4 class="text-sm font-semibold uppercase tracking-wide text-gray-900">{{ __($insight['title']) }}</h4>
                                <span class="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold uppercase text-gray-700">{{ __($insight['confidence']) }}</span>
                            </div>
                            <p class="mt-3 text-sm text-gray-700">{{ __($insight['explanation']) }}</p>

                            <div class="mt-4">
                                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Supporting data/evidence') }}</p>
                                <ul class="mt-2 space-y-1 text-sm text-gray-700">
                                    @foreach ($insight['evidence'] as $evidence)
                                        <li>{{ $evidence }}</li>
                                    @endforeach
                                </ul>
                            </div>

                            <div class="mt-4 grid gap-3 sm:grid-cols-2">
                                <div class="rounded-md bg-gray-50 p-3">
                                    <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Confidence reason') }}</p>
                                    <p class="mt-1 text-sm text-gray-700">{{ __($insight['confidence_reason']) }}</p>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3">
                                    <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Data gap') }}</p>
                                    <p class="mt-1 text-sm text-gray-700">{{ $insight['data_gap'] ? __($insight['data_gap']) : __('No major data gap for this insight.') }}</p>
                                </div>
                            </div>
                        </article>
                    @empty
                        <p class="text-sm text-gray-500">{{ __('Data belum cukup untuk insight yang kuat.') }}</p>
                    @endforelse
                </div>
            </section>

            <section class="rounded-lg bg-white p-6 shadow-sm">
                <div class="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
                    <div>
                        <h3 class="text-base font-semibold text-gray-900">{{ __('AI Action Engine') }}</h3>
                        <p class="mt-1 text-sm text-gray-500">{{ __('Suggested action sahaja. Human review diperlukan; sistem tidak auto-execute campaign, message, atau data change.') }}</p>
                    </div>
                    <div class="text-sm text-gray-500">
                        {{ __('Statuses') }}: {{ implode(', ', $aiActionStatuses ?? []) }}
                    </div>
                </div>

                <div class="mt-5 grid gap-4 lg:grid-cols-2">
                    @forelse ($aiActions as $action)
                        <article class="rounded-lg border border-gray-200 p-5">
                            <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                                <h4 class="text-sm font-semibold uppercase tracking-wide text-gray-900">{{ __($action['title']) }}</h4>
                                <span class="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold uppercase text-gray-700">{{ __($action['status']) }}</span>
                            </div>

                            <dl class="mt-4 grid gap-3 text-sm sm:grid-cols-2">
                                <div class="rounded-md bg-gray-50 p-3 sm:col-span-2">
                                    <dt class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Recommended Action') }}</dt>
                                    <dd class="mt-1 text-gray-800">{{ __($action['recommended_action']) }}</dd>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3 sm:col-span-2">
                                    <dt class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Reason / Why It Matters') }}</dt>
                                    <dd class="mt-1 text-gray-800">{{ __($action['reason']) }}</dd>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3">
                                    <dt class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Linked Insight') }}</dt>
                                    <dd class="mt-1 text-gray-800">{{ __($action['linked_insight']) }}</dd>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3">
                                    <dt class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Target') }}</dt>
                                    <dd class="mt-1 text-gray-800">{{ __($action['target']) }}</dd>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3">
                                    <dt class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Owner / Person In Charge') }}</dt>
                                    <dd class="mt-1 text-gray-800">{{ __($action['owner']) }}</dd>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3">
                                    <dt class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Priority') }}</dt>
                                    <dd class="mt-1 text-gray-800">{{ __($action['priority']) }}</dd>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3">
                                    <dt class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Confidence') }}</dt>
                                    <dd class="mt-1 text-gray-800">{{ __($action['confidence']) }}</dd>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3">
                                    <dt class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Suggested Period') }}</dt>
                                    <dd class="mt-1 text-gray-800">{{ __($action['suggested_period']) }}</dd>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3 sm:col-span-2">
                                    <dt class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Success Metric') }}</dt>
                                    <dd class="mt-1 text-gray-800">{{ __($action['success_metric']) }}</dd>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3 sm:col-span-2">
                                    <dt class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Data Gap') }}</dt>
                                    <dd class="mt-1 text-gray-800">{{ $action['data_gap'] ? __($action['data_gap']) : __('No major data gap for this action.') }}</dd>
                                </div>
                            </dl>

                            <div class="mt-4">
                                <p class="text-xs font-semibold uppercase tracking-wide text-gray-500">{{ __('Evidence') }}</p>
                                <ul class="mt-2 space-y-1 text-sm text-gray-700">
                                    @foreach ($action['evidence'] as $evidence)
                                        <li>{{ $evidence }}</li>
                                    @endforeach
                                </ul>
                            </div>

                            @foreach ($action['target_lists'] as $targetList)
                                <div class="mt-5 rounded-md border border-gray-200 p-4">
                                    <h5 class="text-sm font-semibold text-gray-900">{{ __($targetList['title']) }}</h5>
                                    <div class="mt-3 divide-y divide-gray-100">
                                        @forelse ($targetList['items'] as $item)
                                            <div class="grid gap-2 py-3 sm:grid-cols-2">
                                                @foreach ($item as $label => $value)
                                                    <p class="text-sm text-gray-600"><span class="font-medium text-gray-900">{{ __($label) }}:</span> {{ $value }}</p>
                                                @endforeach
                                            </div>
                                        @empty
                                            <p class="text-sm text-gray-500">{{ __('No related target list available within this access scope.') }}</p>
                                        @endforelse
                                    </div>
                                </div>
                            @endforeach
                        </article>
                    @empty
                        <p class="text-sm text-gray-500">{{ __('Data belum cukup untuk AI Action yang kuat.') }}</p>
                    @endforelse
                </div>
            </section>

            @if ($combinedBranches->isNotEmpty())
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Combined Role Analytics') }}</h3>
                    <p class="mt-2 text-sm text-gray-600">{{ __('Business-level analytics dipaparkan bersama assigned branch-level analytics untuk role gabungan.') }}</p>
                    <div class="mt-5 divide-y divide-gray-100">
                        @foreach ($combinedBranches as $branch)
                            <div class="py-3">
                                <p class="font-semibold text-gray-900">{{ $branch->name }}</p>
                                <p class="mt-1 text-sm text-gray-500">{{ $branch->business?->name }}</p>
                            </div>
                        @endforeach
                    </div>
                </section>
            @endif
        </div>
    </div>
</x-app-layout>
