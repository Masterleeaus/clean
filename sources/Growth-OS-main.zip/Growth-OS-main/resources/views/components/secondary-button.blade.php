<button {{ $attributes->merge(['type' => 'button', 'class' => 'inline-flex w-full items-center justify-center rounded-md border border-slate-300 bg-white px-4 py-2 text-center text-xs font-semibold uppercase tracking-normal text-slate-700 shadow-sm transition duration-150 ease-in-out hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-emerald-600 focus:ring-offset-2 disabled:opacity-25 sm:w-auto']) }}>
    {{ $slot }}
</button>
