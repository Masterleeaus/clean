@props(['title' => null, 'confidence' => null])

<article {{ $attributes->merge(['class' => 'gos-ai-card']) }}>
    @if ($title || $confidence)
        <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
            @if ($title)
                <h3 class="gos-card-title">{{ $title }}</h3>
            @endif

            @if ($confidence)
                <x-status-badge tone="info">{{ $confidence }}</x-status-badge>
            @endif
        </div>
    @endif

    <div class="{{ $title || $confidence ? 'mt-4' : '' }}">
        {{ $slot }}
    </div>
</article>
