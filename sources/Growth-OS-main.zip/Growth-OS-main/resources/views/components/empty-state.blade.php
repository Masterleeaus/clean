@props(['title' => null, 'body' => null])

<div {{ $attributes->merge(['class' => 'gos-empty-state']) }}>
    @if ($title)
        <p class="gos-empty-state-title">{{ $title }}</p>
    @endif

    @if ($body)
        <p class="gos-empty-state-body">{{ $body }}</p>
    @endif

    @if (! $slot->isEmpty())
        <div class="mt-4">
            {{ $slot }}
        </div>
    @endif
</div>
