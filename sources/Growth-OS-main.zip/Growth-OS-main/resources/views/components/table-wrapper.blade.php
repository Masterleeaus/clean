<div {{ $attributes->merge(['class' => 'gos-table-wrapper']) }}>
    {{ $slot }}
</div>
