@props(['title' => null, 'eyebrow' => null])

<section {{ $attributes->merge(['class' => 'gos-section-panel']) }}>
    @if ($eyebrow || $title)
        <div class="gos-panel-header">
            @if ($eyebrow)
                <p class="gos-eyebrow">{{ $eyebrow }}</p>
            @endif

            @if ($title)
                <h3 class="gos-panel-title">{{ $title }}</h3>
            @endif
        </div>
    @endif

    {{ $slot }}
</section>
