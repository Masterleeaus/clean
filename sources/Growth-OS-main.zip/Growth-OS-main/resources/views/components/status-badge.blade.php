@props(['tone' => 'neutral'])

@php
    $toneClass = match ($tone) {
        'success' => 'is-success',
        'warning' => 'is-warning',
        'danger' => 'is-danger',
        'info' => 'is-info',
        'premium', 'gold' => 'is-premium',
        'purple' => 'is-purple',
        'slate', 'neutral' => 'is-slate',
        default => '',
    };
@endphp

<span {{ $attributes->merge(['class' => trim('gos-status-badge '.$toneClass)]) }}>
    {{ $slot }}
</span>
