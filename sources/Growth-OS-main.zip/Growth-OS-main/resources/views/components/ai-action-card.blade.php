@props(['title' => null, 'status' => null])

<article {{ $attributes->merge(['class' => 'gos-ai-card is-action']) }}>
    @if ($title || $status)
        <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
            @if ($title)
                <h3 class="gos-card-title">{{ $title }}</h3>
            @endif

            @if ($status)
                <x-status-badge tone="premium">{{ $status }}</x-status-badge>
            @endif
        </div>
    @endif

    <div class="{{ $title || $status ? 'mt-4' : '' }}">
        {{ $slot }}
    </div>
</article>
