@props(['href' => null, 'label' => __('Action'), 'icon' => 'plus', 'type' => 'button'])

@php
    $paths = [
        'plus' => '<path d="M12 5v14"/><path d="M5 12h14"/>',
        'check' => '<path d="M20 6 9 17l-5-5"/>',
        'arrow-down' => '<path d="M12 5v14"/><path d="m19 12-7 7-7-7"/>',
        'message' => '<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/>',
    ];
    $svg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.($paths[$icon] ?? $paths['plus']).'</svg>';
@endphp

@if ($href)
    <a href="{{ $href }}" aria-label="{{ $label }}" {{ $attributes->merge(['class' => 'gos-floating-action']) }}>
        <span class="gos-fab-icon">{!! $svg !!}</span>
        <span class="min-w-0">{{ $label }}</span>
    </a>
@else
    <button type="{{ $type }}" aria-label="{{ $label }}" {{ $attributes->merge(['class' => 'gos-floating-action']) }}>
        <span class="gos-fab-icon">{!! $svg !!}</span>
        <span class="min-w-0">{{ $label }}</span>
    </button>
@endif
