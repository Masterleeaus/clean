<button {{ $attributes->merge(['type' => 'submit', 'class' => 'inline-flex w-full items-center justify-center rounded-md border border-red-200 bg-red-50 px-4 py-2 text-center text-xs font-semibold uppercase tracking-normal text-red-700 transition duration-150 ease-in-out hover:bg-red-100 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-offset-2 active:bg-red-100 sm:w-auto']) }}>
    {{ $slot }}
</button>
