@props(['tone' => 'info'])

@php
    $toneClass = match ($tone) {
        'success' => 'is-success',
        'warning' => 'is-warning',
        'danger' => 'is-danger',
        default => 'is-info',
    };
@endphp

<div role="status" {{ $attributes->merge(['class' => 'gos-alert '.$toneClass]) }}>
    {{ $slot }}
</div>
