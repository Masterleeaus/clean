@props(['label', 'value' => null, 'hint' => null])

<div {{ $attributes->merge(['class' => 'gos-metric-card']) }}>
    <div class="gos-metric-topline">
        <p class="gos-metric-label">{{ $label }}</p>
        <span class="gos-metric-orb" aria-hidden="true">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round">
                <path d="M4 17V7" />
                <path d="M8 17v-5" />
                <path d="M12 17V9" />
                <path d="M16 17v-7" />
                <path d="M20 17V5" />
            </svg>
        </span>
    </div>
    <p class="gos-metric-value">{{ $value ?? $slot }}</p>

    @if ($hint)
        <p class="gos-metric-hint">{{ $hint }}</p>
    @endif
</div>
