@props(['title' => null, 'eyebrow' => null])

<section {{ $attributes->merge(['class' => 'gos-card']) }}>
    @if ($eyebrow || $title)
        <div class="gos-card-header">
            @if ($eyebrow)
                <p class="gos-eyebrow">{{ $eyebrow }}</p>
            @endif

            @if ($title)
                <h3 class="gos-card-title">{{ $title }}</h3>
            @endif
        </div>
    @endif

    {{ $slot }}

    @isset($footer)
        <div class="mt-5 border-t border-slate-100 pt-4">
            {{ $footer }}
        </div>
    @endisset
</section>
