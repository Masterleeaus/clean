<button {{ $attributes->merge(['type' => 'submit', 'class' => 'inline-flex w-full items-center justify-center rounded-md border border-transparent bg-emerald-900 px-4 py-2 text-center text-xs font-semibold uppercase tracking-normal text-white shadow-sm transition duration-150 ease-in-out hover:bg-emerald-800 focus:bg-emerald-800 focus:outline-none focus:ring-2 focus:ring-emerald-700 focus:ring-offset-2 active:bg-emerald-950 sm:w-auto']) }}>
    {{ $slot }}
</button>
