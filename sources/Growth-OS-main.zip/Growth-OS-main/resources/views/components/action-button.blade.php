@props(['href' => null, 'variant' => 'primary', 'type' => 'button'])

@php
    $variantClass = $variant === 'secondary' ? 'is-secondary' : 'is-primary';
    $classes = 'gos-action-button '.$variantClass;
@endphp

@if ($href)
    <a href="{{ $href }}" {{ $attributes->merge(['class' => $classes]) }}>
        {{ $slot }}
    </a>
@else
    <button type="{{ $type }}" {{ $attributes->merge(['class' => $classes]) }}>
        {{ $slot }}
    </button>
@endif
