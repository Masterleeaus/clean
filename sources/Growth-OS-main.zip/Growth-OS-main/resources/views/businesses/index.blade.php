<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-1 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Businesses') }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ __('Manage your F&B loyalty locations.') }}</p>
            </div>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            @if (session('status'))
                <div class="mb-6 rounded-md bg-green-50 p-4 text-sm font-medium text-green-800">
                    {{ session('status') }}
                </div>
            @endif

            <div class="overflow-hidden rounded-lg bg-white shadow-sm">
                <div class="divide-y divide-gray-100">
                    @forelse ($businesses as $business)
                        <a href="{{ route('businesses.show', $business) }}" class="block p-5 transition hover:bg-gray-50 sm:p-6">
                            <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                                <div>
                                    <h3 class="text-lg font-semibold text-gray-900">{{ $business->name }}</h3>
                                    <p class="mt-1 text-sm text-gray-500">{{ $business->business_type }} · {{ $business->owner_name }}</p>
                                    <p class="mt-2 text-sm text-gray-600">{{ $business->loyaltyPrograms->first()?->reward_name ?? __('No loyalty program yet') }}</p>
                                </div>
                                <div class="grid grid-cols-3 gap-3 text-center text-sm sm:min-w-80">
                                    <div class="rounded-md bg-gray-50 p-3">
                                        <p class="font-semibold text-gray-900">{{ $business->customers_count }}</p>
                                        <p class="text-gray-500">{{ __('Customers') }}</p>
                                    </div>
                                    <div class="rounded-md bg-gray-50 p-3">
                                        <p class="font-semibold text-gray-900">{{ $business->check_ins_count }}</p>
                                        <p class="text-gray-500">{{ __('Check-ins') }}</p>
                                    </div>
                                    <div class="rounded-md bg-gray-50 p-3">
                                        <p class="font-semibold text-gray-900">{{ $business->reward_redemptions_count }}</p>
                                        <p class="text-gray-500">{{ __('Rewards') }}</p>
                                    </div>
                                </div>
                            </div>
                        </a>
                    @empty
                        <div class="p-6 text-sm text-gray-500">{{ __('No businesses available for your account yet.') }}</div>
                    @endforelse
                </div>
            </div>
        </div>
    </div>
</x-app-layout>
