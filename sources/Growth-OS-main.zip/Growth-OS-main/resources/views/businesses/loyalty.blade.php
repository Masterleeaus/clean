<x-app-layout>
    <x-slot name="header">
        <div>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Edit Loyalty Program') }}</h2>
            <p class="mt-1 text-sm text-gray-500">{{ $business->name }}</p>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <form method="POST" action="{{ route('businesses.loyalty.update', $business) }}" class="space-y-6 rounded-lg bg-white p-6 shadow-sm">
                @csrf
                @method('PATCH')

                <div>
                    <x-input-label for="name" :value="__('Program Name')" />
                    <x-text-input id="name" name="name" type="text" class="mt-1 block w-full" :value="old('name', $loyaltyProgram->name)" required autofocus />
                    <x-input-error class="mt-2" :messages="$errors->get('name')" />
                </div>

                <div>
                    <x-input-label for="stamps_required" :value="__('Stamps Required')" />
                    <x-text-input id="stamps_required" name="stamps_required" type="number" min="1" class="mt-1 block w-full" :value="old('stamps_required', $loyaltyProgram->stamps_required)" required />
                    <x-input-error class="mt-2" :messages="$errors->get('stamps_required')" />
                </div>

                <div>
                    <x-input-label for="reward_name" :value="__('Reward Name')" />
                    <x-text-input id="reward_name" name="reward_name" type="text" class="mt-1 block w-full" :value="old('reward_name', $loyaltyProgram->reward_name)" required />
                    <x-input-error class="mt-2" :messages="$errors->get('reward_name')" />
                </div>

                <div>
                    <x-input-label for="reward_description" :value="__('Reward Description')" />
                    <textarea id="reward_description" name="reward_description" rows="4" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">{{ old('reward_description', $loyaltyProgram->reward_description) }}</textarea>
                    <x-input-error class="mt-2" :messages="$errors->get('reward_description')" />
                </div>

                <div class="space-y-3">
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="welcome_stamp_enabled" value="1" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" @checked(old('welcome_stamp_enabled', $loyaltyProgram->welcome_stamp_enabled))>
                        <span class="text-sm text-gray-700">{{ __('Welcome stamp enabled') }}</span>
                    </label>
                    <label class="flex items-center gap-2">
                        <input type="checkbox" name="is_active" value="1" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" @checked(old('is_active', $loyaltyProgram->is_active))>
                        <span class="text-sm text-gray-700">{{ __('Program active') }}</span>
                    </label>
                </div>

                <div class="flex flex-col gap-3 sm:flex-row sm:justify-end">
                    <a href="{{ route('businesses.show', $business) }}" class="inline-flex justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Cancel') }}</a>
                    <x-primary-button>{{ __('Save Loyalty Program') }}</x-primary-button>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>
