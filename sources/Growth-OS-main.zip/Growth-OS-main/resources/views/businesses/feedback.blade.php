<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Customer Feedback') }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ $branch ? $business->name.' - '.$branch->name : $business->name }}</p>
            </div>
            <div class="flex flex-wrap gap-2">
                <a href="{{ route('businesses.dashboard', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Dashboard') }}</a>
                <a href="{{ route('businesses.show', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Overview') }}</a>
            </div>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            <section class="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                <div class="rounded-lg bg-white p-5 shadow-sm">
                    <p class="text-sm font-medium text-gray-500">{{ __('Avg food') }}</p>
                    <p class="mt-2 text-3xl font-semibold text-gray-900">{{ $summary['average_food_rating'] ?? '-' }}</p>
                </div>
                <div class="rounded-lg bg-white p-5 shadow-sm">
                    <p class="text-sm font-medium text-gray-500">{{ __('Avg service') }}</p>
                    <p class="mt-2 text-3xl font-semibold text-gray-900">{{ $summary['average_service_rating'] ?? '-' }}</p>
                </div>
                <div class="rounded-lg bg-white p-5 shadow-sm">
                    <p class="text-sm font-medium text-gray-500">{{ __('Cheap') }}</p>
                    <p class="mt-2 text-3xl font-semibold text-gray-900">{{ $summary['price_counts']['cheap'] }}</p>
                </div>
                <div class="rounded-lg bg-white p-5 shadow-sm">
                    <p class="text-sm font-medium text-gray-500">{{ __('OK') }}</p>
                    <p class="mt-2 text-3xl font-semibold text-gray-900">{{ $summary['price_counts']['ok'] }}</p>
                </div>
                <div class="rounded-lg bg-white p-5 shadow-sm">
                    <p class="text-sm font-medium text-gray-500">{{ __('Expensive') }}</p>
                    <p class="mt-2 text-3xl font-semibold text-gray-900">{{ $summary['price_counts']['expensive'] }}</p>
                </div>
            </section>

            <section class="rounded-lg bg-white p-6 shadow-sm">
                <h3 class="text-base font-semibold text-gray-900">{{ __('Latest Feedback') }}</h3>
                @if (session('status'))
                    <div class="mt-4 rounded-md bg-green-50 p-4 text-sm text-green-700">{{ session('status') }}</div>
                @endif
                <div class="mt-5 divide-y divide-gray-100">
                    @forelse ($feedback as $entry)
                        <div class="grid gap-4 py-4 lg:grid-cols-[1fr_1fr_auto] lg:items-start">
                            <div>
                                <p class="font-semibold text-gray-900">{{ $entry->customer?->name ?? __('Anonymous') }}</p>
                                <p class="mt-1 text-sm text-gray-500">{{ __('Submitted') }}: {{ $entry->submitted_at?->format('M j, Y g:i A') ?? '-' }}</p>
                                <p class="mt-1 text-sm text-gray-500">{{ __('Branch') }}: {{ $entry->branch?->name ?? '-' }}</p>
                                <p class="mt-1 text-sm text-gray-500">{{ __('Status') }}: {{ $entry->status }}</p>
                            </div>
                            <div class="grid gap-2 text-sm text-gray-600 sm:grid-cols-3">
                                <p>{{ __('Food') }}: {{ $entry->food_rating ?? '-' }}</p>
                                <p>{{ __('Service') }}: {{ $entry->service_rating ?? '-' }}</p>
                                <p>{{ __('Rating') }}: {{ $entry->rating ?? '-' }}</p>
                                <p>{{ __('Price') }}: {{ $entry->price_feedback ? __(ucfirst($entry->price_feedback)) : '-' }}</p>
                                <p>{{ __('Product/Service') }}: {{ $entry->productService?->name ?? '-' }}</p>
                                <p>{{ __('Check-in') }}: {{ $entry->checkIn?->check_in_at?->format('M j, Y') ?? '-' }}</p>
                                <p>{{ __('Total') }}: RM {{ number_format((float) ($entry->capture?->total_amount ?? 0), 2) }}</p>
                            </div>
                            <div class="space-y-2 text-sm text-gray-700 lg:max-w-sm">
                                <p>{{ $entry->comment ?: __('No comment') }}</p>
                                @if ($entry->summary_main_meaning)
                                    <p class="text-gray-500">{{ __('Summary') }}: {{ $entry->summary_main_meaning }}</p>
                                    <p class="text-gray-500">{{ __('Category') }}: {{ $entry->summary_issue_category ?? '-' }}</p>
                                @endif
                                @if ($entry->branch)
                                    <form method="POST" action="{{ route('businesses.branches.feedback.status.update', ['business' => $business, 'branch' => $entry->branch, 'feedback' => $entry]) }}" class="flex gap-2">
                                        @csrf
                                        @method('PATCH')
                                        <select name="status" class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                                            @foreach (App\Models\CustomerFeedback::statuses() as $status)
                                                <option value="{{ $status }}" @selected($entry->status === $status)>{{ $status }}</option>
                                            @endforeach
                                        </select>
                                        <button type="submit" class="rounded-md bg-gray-900 px-3 py-2 text-sm font-semibold text-white hover:bg-gray-700">{{ __('Update') }}</button>
                                    </form>
                                @endif
                            </div>
                        </div>
                    @empty
                        <p class="text-sm text-gray-500">{{ __('No feedback yet.') }}</p>
                    @endforelse
                </div>
            </section>
        </div>
    </div>
</x-app-layout>
