<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Manual WhatsApp Follow-ups') }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ $business->name }}</p>
            </div>
            <a href="{{ route('businesses.dashboard', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Dashboard') }}</a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            <div class="rounded-lg bg-amber-50 p-4 text-sm text-amber-900">
                {{ __('Manual only. Messages are not sent automatically. Open WhatsApp or copy the message when you are ready.') }}
            </div>

            @foreach ([
                'dormant' => __('Dormant Customers'),
                'new' => __('New Customers'),
                'near_reward' => __('Reward-Near Customers'),
                'eligible_reward' => __('Eligible Reward Customers'),
            ] as $key => $title)
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ $title }}</h3>
                    <div class="mt-5 divide-y divide-gray-100">
                        @forelse ($groups[$key] as $item)
                            @php
                                $customer = $item['customer'];
                                $copyId = 'copy-message-'.$key.'-'.$customer->id;
                            @endphp
                            <div class="grid gap-4 py-4 lg:grid-cols-[1fr_1.5fr_auto] lg:items-start">
                                <div>
                                    <p class="font-semibold text-gray-900">{{ $customer->name }}</p>
                                    <p class="text-sm text-gray-500">{{ $customer->whatsapp_number }}</p>
                                    <p class="mt-1 text-sm text-gray-500">{{ __('Last check-in') }}: {{ $item['last_check_in'] ? \Carbon\Carbon::parse($item['last_check_in'])->toFormattedDateString() : 'Never' }}</p>
                                    <p class="mt-1 text-sm text-gray-500">{{ __('Current stamps') }}: {{ $item['current_stamps'] }}</p>
                                    <p class="mt-1 text-sm font-medium text-gray-700">{{ $item['type'] }}</p>
                                </div>
                                <textarea id="{{ $copyId }}" class="min-h-28 w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" readonly>{{ $item['message'] }}</textarea>
                                <div class="flex flex-col gap-2">
                                    @if ($item['wa_url'])
                                        <a href="{{ $item['wa_url'] }}" target="_blank" rel="noopener" class="rounded-md bg-green-600 px-4 py-2 text-center text-sm font-semibold text-white hover:bg-green-500">{{ __('Open WhatsApp') }}</a>
                                    @else
                                        <button type="button" class="rounded-md bg-gray-200 px-4 py-2 text-sm font-semibold text-gray-500" disabled>{{ __('Invalid number') }}</button>
                                    @endif
                                    <button type="button" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50" onclick="navigator.clipboard && navigator.clipboard.writeText(document.getElementById('{{ $copyId }}').value)">
                                        {{ __('Copy Message') }}
                                    </button>
                                </div>
                            </div>
                        @empty
                            <p class="py-4 text-sm text-gray-500">{{ __('No customers in this group right now.') }}</p>
                        @endforelse
                    </div>
                </section>
            @endforeach
        </div>
    </div>
</x-app-layout>
