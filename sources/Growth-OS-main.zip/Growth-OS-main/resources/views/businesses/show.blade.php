<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ $business->name }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ __('Business dashboard') }}</p>
            </div>
            <div class="flex flex-wrap gap-2">
                <a href="{{ route('businesses.dashboard', $business) }}" class="rounded-md bg-gray-900 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-700">{{ __('Dashboard') }}</a>
                <a href="{{ route('businesses.customers.index', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Customers') }}</a>
                <a href="{{ route('businesses.follow-ups', $business) }}" class="rounded-md bg-green-600 px-4 py-2 text-sm font-semibold text-white hover:bg-green-500">{{ __('Follow-ups') }}</a>
                <a href="{{ route('businesses.feedback', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Feedback') }}</a>
                <a href="{{ route('businesses.reports.weekly', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Weekly Report') }}</a>
                <a href="{{ route('businesses.edit', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Edit Business') }}</a>
                <a href="{{ route('businesses.loyalty.edit', $business) }}" class="rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500">{{ __('Edit Loyalty') }}</a>
            </div>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            @if (session('status'))
                <div class="rounded-md bg-green-50 p-4 text-sm font-medium text-green-800">
                    {{ session('status') }}
                </div>
            @endif
            @if ($errors->any())
                <div class="rounded-md bg-red-50 p-4 text-sm font-medium text-red-800">
                    {{ $errors->first() }}
                </div>
            @endif

            <div class="grid gap-6 lg:grid-cols-[2fr_1fr]">
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Business Profile') }}</h3>
                    <dl class="mt-5 grid gap-4 sm:grid-cols-2">
                        <div>
                            <dt class="text-sm font-medium text-gray-500">{{ __('Owner') }}</dt>
                            <dd class="mt-1 text-gray-900">{{ $business->owner_name }}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">{{ __('WhatsApp') }}</dt>
                            <dd class="mt-1 text-gray-900">{{ $business->owner_whatsapp }}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">{{ __('Type') }}</dt>
                            <dd class="mt-1 text-gray-900">{{ $business->business_type }}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">{{ __('Slug') }}</dt>
                            <dd class="mt-1 text-gray-900">{{ $business->slug }}</dd>
                        </div>
                    </dl>
                </section>

                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('QR Check-in Placeholder') }}</h3>
                    <p class="mt-3 break-all rounded-md bg-gray-50 p-3 text-sm text-gray-700">
                        {{ route('public.business.show', ['business' => $business->slug]) }}
                    </p>
                    <p class="mt-3 text-sm text-gray-500">{{ __('Share this URL for customer registration. QR image generation will be added later.') }}</p>
                </section>
            </div>

            <div class="grid gap-6 lg:grid-cols-2">
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Active Loyalty Program') }}</h3>
                    @if ($loyaltyProgram)
                        <dl class="mt-5 space-y-4">
                            <div>
                                <dt class="text-sm font-medium text-gray-500">{{ __('Program') }}</dt>
                                <dd class="mt-1 text-gray-900">{{ $loyaltyProgram->name }}</dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-gray-500">{{ __('Reward') }}</dt>
                                <dd class="mt-1 text-gray-900">{{ $loyaltyProgram->reward_name }}</dd>
                            </div>
                            <div>
                                <dt class="text-sm font-medium text-gray-500">{{ __('Stamps Required') }}</dt>
                                <dd class="mt-1 text-gray-900">{{ $loyaltyProgram->stamps_required }}</dd>
                            </div>
                            @if ($loyaltyProgram->reward_description)
                                <div>
                                    <dt class="text-sm font-medium text-gray-500">{{ __('Description') }}</dt>
                                    <dd class="mt-1 text-gray-900">{{ $loyaltyProgram->reward_description }}</dd>
                                </div>
                            @endif
                        </dl>
                    @else
                        <p class="mt-3 text-sm text-gray-500">{{ __('No active loyalty program yet.') }}</p>
                    @endif
                </section>

                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Activity Summary') }}</h3>
                    <div class="mt-5 grid grid-cols-3 gap-3 text-center">
                        <div class="rounded-md bg-gray-50 p-4">
                            <p class="text-2xl font-semibold text-gray-900">{{ $business->customers_count }}</p>
                            <p class="mt-1 text-sm text-gray-500">{{ __('Customers') }}</p>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <p class="text-2xl font-semibold text-gray-900">{{ $business->check_ins_count }}</p>
                            <p class="mt-1 text-sm text-gray-500">{{ __('Check-ins') }}</p>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <p class="text-2xl font-semibold text-gray-900">{{ $business->reward_redemptions_count }}</p>
                            <p class="mt-1 text-sm text-gray-500">{{ __('Rewards') }}</p>
                        </div>
                    </div>
                </section>
            </div>

            <div class="grid gap-6 lg:grid-cols-2">
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Recent Check-ins') }}</h3>
                    <div class="mt-5 divide-y divide-gray-100">
                        @forelse ($recentCheckIns as $checkIn)
                            <div class="flex items-center justify-between gap-4 py-3">
                                <div>
                                    <p class="font-medium text-gray-900">{{ $checkIn->customer->name }}</p>
                                    <p class="text-sm text-gray-500">{{ $checkIn->check_in_date->toFormattedDateString() }}</p>
                                </div>
                                <p class="text-sm font-semibold text-gray-700">+{{ $checkIn->stamps_earned }}</p>
                            </div>
                        @empty
                            <p class="text-sm text-gray-500">{{ __('No check-ins yet.') }}</p>
                        @endforelse
                    </div>
                </section>

                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Eligible Customers') }}</h3>
                    <div class="mt-5 divide-y divide-gray-100">
                        @forelse ($eligibleAccounts as $account)
                            <div class="flex flex-col gap-3 py-3 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    <p class="font-medium text-gray-900">{{ $account->customer->name }}</p>
                                    <p class="text-sm text-gray-500">{{ $account->customer->whatsapp_number }}</p>
                                    <p class="text-sm text-gray-500">{{ __('Reward: :reward', ['reward' => $loyaltyProgram->reward_name]) }}</p>
                                </div>
                                <div class="flex flex-col gap-2 sm:items-end">
                                    <p class="text-sm font-semibold text-gray-700">{{ $account->current_stamps }} / {{ $loyaltyProgram->stamps_required }}</p>
                                    <form method="POST" action="{{ route('businesses.customers.redeem', ['business' => $business, 'customer' => $account->customer]) }}">
                                        @csrf
                                        <button type="submit" class="rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white hover:bg-green-500">
                                            {{ __('Redeem') }}
                                        </button>
                                    </form>
                                </div>
                            </div>
                        @empty
                            <p class="text-sm text-gray-500">{{ __('No customers are eligible yet.') }}</p>
                        @endforelse
                    </div>
                </section>
            </div>

            <section class="rounded-lg bg-white p-6 shadow-sm">
                <h3 class="text-base font-semibold text-gray-900">{{ __('Redemption History') }}</h3>
                <div class="mt-5 divide-y divide-gray-100">
                    @forelse ($redemptions as $redemption)
                        <div class="grid gap-2 py-3 sm:grid-cols-[1fr_auto] sm:items-center">
                            <div>
                                <p class="font-medium text-gray-900">{{ $redemption->customer->name }}</p>
                                <p class="text-sm text-gray-500">{{ $redemption->reward_name }}</p>
                                <p class="text-sm text-gray-500">
                                    {{ __('Verified by :name', ['name' => $redemption->verifiedBy?->name ?? 'Unknown']) }}
                                </p>
                            </div>
                            <p class="text-sm text-gray-600">
                                {{ $redemption->redeemed_at?->format('M j, Y g:i A') }}
                            </p>
                        </div>
                    @empty
                        <p class="text-sm text-gray-500">{{ __('No redemptions yet.') }}</p>
                    @endforelse
                </div>
            </section>
        </div>
    </div>
</x-app-layout>
