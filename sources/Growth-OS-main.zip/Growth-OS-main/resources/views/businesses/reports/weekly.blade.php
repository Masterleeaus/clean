<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Weekly Growth Report') }}</h2>
                <p class="mt-1 text-sm text-gray-500">
                    {{ $business->name }} &middot; {{ $report['period_start']->format('M j') }} - {{ $report['period_end']->format('M j, Y') }}
                </p>
            </div>
            <div class="flex flex-wrap gap-2">
                <a href="{{ route('businesses.dashboard', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Dashboard') }}</a>
                <a href="{{ route('businesses.show', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Overview') }}</a>
            </div>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            <section class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                @foreach ([
                    __('New customers this week') => $report['metrics']['new_customers'],
                    __('Check-ins this week') => $report['metrics']['check_ins'],
                    __('Repeat customers this week') => $report['metrics']['repeat_customers'],
                    __('Dormant customers') => $report['metrics']['dormant_customers'],
                    __('Rewards redeemed this week') => $report['metrics']['rewards_redeemed'],
                    __('Feedback submitted this week') => $report['metrics']['feedback_submitted'],
                ] as $label => $value)
                    <div class="rounded-lg bg-white p-5 shadow-sm">
                        <p class="text-sm font-medium text-gray-500">{{ $label }}</p>
                        <p class="mt-2 text-3xl font-semibold text-gray-900">{{ $value }}</p>
                    </div>
                @endforeach
            </section>

            <section class="grid gap-4 lg:grid-cols-2">
                <div class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Feedback This Week') }}</h3>
                    <dl class="mt-5 grid gap-4 sm:grid-cols-2">
                        <div>
                            <dt class="text-sm font-medium text-gray-500">{{ __('Average food rating') }}</dt>
                            <dd class="mt-1 text-2xl font-semibold text-gray-900">{{ $report['metrics']['average_food_rating'] ?? '-' }}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">{{ __('Average service rating') }}</dt>
                            <dd class="mt-1 text-2xl font-semibold text-gray-900">{{ $report['metrics']['average_service_rating'] ?? '-' }}</dd>
                        </div>
                    </dl>
                </div>

                <div class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Price Feedback Summary') }}</h3>
                    <div class="mt-5 grid grid-cols-3 gap-3 text-center">
                        <div class="rounded-md bg-gray-50 p-4">
                            <p class="text-sm font-medium text-gray-500">{{ __('Cheap') }}</p>
                            <p class="mt-2 text-2xl font-semibold text-gray-900">{{ $report['metrics']['price_feedback']['cheap'] }}</p>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <p class="text-sm font-medium text-gray-500">{{ __('OK') }}</p>
                            <p class="mt-2 text-2xl font-semibold text-gray-900">{{ $report['metrics']['price_feedback']['ok'] }}</p>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <p class="text-sm font-medium text-gray-500">{{ __('Expensive') }}</p>
                            <p class="mt-2 text-2xl font-semibold text-gray-900">{{ $report['metrics']['price_feedback']['expensive'] }}</p>
                        </div>
                    </div>
                </div>
            </section>

            <section class="rounded-lg bg-white p-6 shadow-sm">
                <h3 class="text-base font-semibold text-gray-900">{{ __('What should I do next?') }}</h3>
                <div class="mt-5 space-y-3">
                    @foreach ($report['suggestions'] as $suggestion)
                        <div class="rounded-md bg-indigo-50 p-4 text-sm font-medium text-indigo-950">
                            {{ $suggestion }}
                        </div>
                    @endforeach
                </div>
            </section>

            <section class="rounded-lg bg-white p-6 shadow-sm">
                <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Copy Summary') }}</h3>
                    <button type="button" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50" onclick="navigator.clipboard && navigator.clipboard.writeText(document.getElementById('weekly-report-summary').value)">
                        {{ __('Copy Summary') }}
                    </button>
                </div>
                <textarea id="weekly-report-summary" class="mt-4 min-h-48 w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" readonly>{{ $report['copy_summary'] }}</textarea>
            </section>
        </div>
    </div>
</x-app-layout>
