<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Customers') }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ $business->name }}</p>
            </div>
            <a href="{{ route('businesses.dashboard', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Dashboard') }}</a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            <form method="GET" action="{{ route('businesses.customers.index', $business) }}" class="grid gap-3 rounded-lg bg-white p-4 shadow-sm sm:grid-cols-[1fr_auto_auto]">
                <x-text-input name="search" type="search" class="w-full" :value="$search" placeholder="Search name or WhatsApp" />
                <select name="filter" class="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                    <option value="">{{ __('All customers') }}</option>
                    <option value="eligible" @selected($filter === 'eligible')>{{ __('Eligible reward') }}</option>
                    <option value="dormant" @selected($filter === 'dormant')>{{ __('Dormant') }}</option>
                </select>
                <x-primary-button class="justify-center">{{ __('Apply') }}</x-primary-button>
            </form>

            <section class="overflow-hidden rounded-lg bg-white shadow-sm">
                <div class="divide-y divide-gray-100">
                    @forelse ($customers as $customer)
                        @php
                            $account = $accountFor($customer);
                            $status = $statusFor($customer);
                        @endphp
                        <a href="{{ route('businesses.customers.show', ['business' => $business, 'customer' => $customer]) }}" class="block p-5 hover:bg-gray-50">
                            <div class="grid gap-4 lg:grid-cols-[1.3fr_1fr_1fr_auto] lg:items-center">
                                <div>
                                    <p class="font-semibold text-gray-900">{{ $customer->name }}</p>
                                    <p class="text-sm text-gray-500">{{ $customer->whatsapp_number }}</p>
                                </div>
                                <div class="text-sm text-gray-700">
                                    <p>{{ __('Current stamps') }}: {{ $account?->current_stamps ?? 0 }}</p>
                                    <p>{{ __('Total earned') }}: {{ $account?->total_stamps_earned ?? 0 }}</p>
                                </div>
                                <div class="text-sm text-gray-700">
                                    <p>{{ __('Rewards redeemed') }}: {{ $account?->total_rewards_redeemed ?? 0 }}</p>
                                    <p>{{ __('Last check-in') }}: {{ $customer->check_ins_max_check_in_date ? \Carbon\Carbon::parse($customer->check_ins_max_check_in_date)->toFormattedDateString() : 'Never' }}</p>
                                </div>
                                <span class="w-fit rounded-full bg-gray-100 px-3 py-1 text-sm font-medium text-gray-700">{{ $status }}</span>
                            </div>
                        </a>
                    @empty
                        <p class="p-6 text-sm text-gray-500">{{ __('No customers found.') }}</p>
                    @endforelse
                </div>
            </section>
        </div>
    </div>
</x-app-layout>
