<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ $customer->name }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ $business->name }} · {{ $status }}</p>
            </div>
            <a href="{{ route('businesses.customers.index', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Back to Customers') }}</a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            <div class="grid gap-6 lg:grid-cols-[1fr_1fr]">
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Customer Profile') }}</h3>
                    <dl class="mt-5 space-y-4">
                        <div>
                            <dt class="text-sm font-medium text-gray-500">{{ __('WhatsApp') }}</dt>
                            <dd class="mt-1 text-gray-900">{{ $customer->whatsapp_number }}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">{{ __('Birthday') }}</dt>
                            <dd class="mt-1 text-gray-900">{{ $customer->birthday?->toFormattedDateString() ?? 'Not provided' }}</dd>
                        </div>
                        <div>
                            <dt class="text-sm font-medium text-gray-500">{{ __('Promo consent') }}</dt>
                            <dd class="mt-1 text-gray-900">{{ $customer->consent_promo ? 'Yes' : 'No' }}</dd>
                        </div>
                    </dl>
                </section>

                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Stamp Progress') }}</h3>
                    @if ($loyaltyProgram && $account)
                        <p class="mt-5 text-4xl font-semibold text-gray-900">{{ $account->current_stamps }} / {{ $loyaltyProgram->stamps_required }}</p>
                        <p class="mt-2 text-sm text-gray-500">{{ __('Reward: :reward', ['reward' => $loyaltyProgram->reward_name]) }}</p>
                        <p class="mt-2 text-sm text-gray-500">{{ __('Total earned: :count', ['count' => $account->total_stamps_earned]) }}</p>
                        <p class="mt-2 text-sm text-gray-500">{{ __('Rewards redeemed: :count', ['count' => $account->total_rewards_redeemed]) }}</p>
                    @else
                        <p class="mt-5 text-sm text-gray-500">{{ __('No active loyalty account found.') }}</p>
                    @endif
                </section>
            </div>

            <div class="grid gap-6 lg:grid-cols-3">
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Check-in History') }}</h3>
                    <div class="mt-5 divide-y divide-gray-100">
                        @forelse ($checkIns as $checkIn)
                            <div class="py-3 text-sm text-gray-700">{{ $checkIn->check_in_date->toFormattedDateString() }} · +{{ $checkIn->stamps_earned }}</div>
                        @empty
                            <p class="text-sm text-gray-500">{{ __('No check-ins yet.') }}</p>
                        @endforelse
                    </div>
                </section>

                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Stamp Transactions') }}</h3>
                    <div class="mt-5 divide-y divide-gray-100">
                        @forelse ($stampTransactions as $transaction)
                            <div class="py-3">
                                <p class="text-sm font-medium text-gray-900">{{ $transaction->type }} · {{ $transaction->stamps }}</p>
                                <p class="text-sm text-gray-500">{{ $transaction->description }}</p>
                            </div>
                        @empty
                            <p class="text-sm text-gray-500">{{ __('No stamp transactions yet.') }}</p>
                        @endforelse
                    </div>
                </section>

                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Redemption History') }}</h3>
                    <div class="mt-5 divide-y divide-gray-100">
                        @forelse ($redemptions as $redemption)
                            <div class="py-3">
                                <p class="text-sm font-medium text-gray-900">{{ $redemption->reward_name }}</p>
                                <p class="text-sm text-gray-500">{{ $redemption->redeemed_at?->format('M j, Y g:i A') }}</p>
                                <p class="text-sm text-gray-500">{{ __('Verified by :name', ['name' => $redemption->verifiedBy?->name ?? 'Unknown']) }}</p>
                            </div>
                        @empty
                            <p class="text-sm text-gray-500">{{ __('No redemptions yet.') }}</p>
                        @endforelse
                    </div>
                </section>
            </div>
        </div>
    </div>
</x-app-layout>
