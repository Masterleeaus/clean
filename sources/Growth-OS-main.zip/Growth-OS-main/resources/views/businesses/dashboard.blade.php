<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ $business->name }} {{ __('Dashboard') }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ __('Pilot operations snapshot') }}</p>
            </div>
            <div class="flex flex-wrap gap-2">
                <a href="{{ route('businesses.show', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Overview') }}</a>
                <a href="{{ route('businesses.customers.index', $business) }}" class="rounded-md bg-gray-900 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-700">{{ __('Customers') }}</a>
                <a href="{{ route('businesses.follow-ups', $business) }}" class="rounded-md bg-green-600 px-4 py-2 text-sm font-semibold text-white hover:bg-green-500">{{ __('Follow-ups') }}</a>
                <a href="{{ route('businesses.feedback', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Feedback') }}</a>
                <a href="{{ route('businesses.reports.weekly', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Weekly Report') }}</a>
            </div>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            <section class="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                @foreach ([
                    __('Total customers') => $totalCustomers,
                    __('New customers today') => $newCustomersToday,
                    __('Check-ins today') => $checkInsToday,
                    __('Repeat customers') => $repeatCustomersCount,
                    __('Eligible rewards') => $eligibleRewardsCount,
                    __('Rewards redeemed') => $rewardsRedeemedCount,
                ] as $label => $value)
                    <div class="rounded-lg bg-white p-5 shadow-sm">
                        <p class="text-sm font-medium text-gray-500">{{ $label }}</p>
                        <p class="mt-2 text-3xl font-semibold text-gray-900">{{ $value }}</p>
                    </div>
                @endforeach
            </section>

            <section class="rounded-lg bg-white p-6 shadow-sm">
                <h3 class="text-base font-semibold text-gray-900">{{ __('Public QR Link') }}</h3>
                <p class="mt-3 break-all rounded-md bg-gray-50 p-3 text-sm text-gray-700">{{ $publicUrl }}</p>
            </section>

            <section class="grid gap-4 lg:grid-cols-3">
                <div class="rounded-lg bg-white p-5 shadow-sm">
                    <h3 class="font-semibold text-gray-900">{{ __('Ask customers to scan this QR link') }}</h3>
                    <p class="mt-2 text-sm text-gray-500">{{ __('Use the public link at the counter, table, or receipt.') }}</p>
                </div>
                <div class="rounded-lg bg-white p-5 shadow-sm">
                    <h3 class="font-semibold text-gray-900">{{ __('Verify eligible rewards') }}</h3>
                    <p class="mt-2 text-sm text-gray-500">{{ __('Open eligible customers and redeem only after checking their screen.') }}</p>
                </div>
                <div class="rounded-lg bg-white p-5 shadow-sm">
                    <h3 class="font-semibold text-gray-900">{{ __('Follow up dormant customers later') }}</h3>
                    <p class="mt-2 text-sm text-gray-500">{{ __('Dormant filtering is available in the customers page for later outreach.') }}</p>
                    <a href="{{ route('businesses.follow-ups', $business) }}" class="mt-4 inline-flex text-sm font-semibold text-green-700 hover:text-green-600">{{ __('Open follow-ups') }}</a>
                </div>
            </section>

            <div class="grid gap-6 lg:grid-cols-2">
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Recent Check-ins') }}</h3>
                    <div class="mt-5 divide-y divide-gray-100">
                        @forelse ($recentCheckIns as $checkIn)
                            <div class="flex items-center justify-between gap-4 py-3">
                                <div>
                                    <p class="font-medium text-gray-900">{{ $checkIn->customer->name }}</p>
                                    <p class="text-sm text-gray-500">{{ $checkIn->check_in_date->toFormattedDateString() }}</p>
                                </div>
                                <p class="text-sm font-semibold text-gray-700">+{{ $checkIn->stamps_earned }}</p>
                            </div>
                        @empty
                            <p class="text-sm text-gray-500">{{ __('No check-ins yet.') }}</p>
                        @endforelse
                    </div>
                </section>

                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Recent Redemptions') }}</h3>
                    <div class="mt-5 divide-y divide-gray-100">
                        @forelse ($recentRedemptions as $redemption)
                            <div class="py-3">
                                <p class="font-medium text-gray-900">{{ $redemption->customer->name }}</p>
                                <p class="text-sm text-gray-500">{{ $redemption->reward_name }}</p>
                                <p class="text-sm text-gray-500">{{ $redemption->redeemed_at?->format('M j, Y g:i A') }}</p>
                            </div>
                        @empty
                            <p class="text-sm text-gray-500">{{ __('No redemptions yet.') }}</p>
                        @endforelse
                    </div>
                </section>
            </div>
        </div>
    </div>
</x-app-layout>
