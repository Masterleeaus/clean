<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Edit Business') }}</h2>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <form method="POST" action="{{ route('businesses.update', $business) }}" class="space-y-6 rounded-lg bg-white p-6 shadow-sm">
                @csrf
                @method('PATCH')

                <div>
                    <x-input-label for="name" :value="__('Business Name')" />
                    <x-text-input id="name" name="name" type="text" class="mt-1 block w-full" :value="old('name', $business->name)" required autofocus />
                    <x-input-error class="mt-2" :messages="$errors->get('name')" />
                </div>

                <div>
                    <x-input-label for="slug" :value="__('Slug')" />
                    <x-text-input id="slug" name="slug" type="text" class="mt-1 block w-full" :value="old('slug', $business->slug)" required />
                    <x-input-error class="mt-2" :messages="$errors->get('slug')" />
                </div>

                <div>
                    <x-input-label for="owner_name" :value="__('Owner Name')" />
                    <x-text-input id="owner_name" name="owner_name" type="text" class="mt-1 block w-full" :value="old('owner_name', $business->owner_name)" required />
                    <x-input-error class="mt-2" :messages="$errors->get('owner_name')" />
                </div>

                <div>
                    <x-input-label for="owner_whatsapp" :value="__('Owner WhatsApp')" />
                    <x-text-input id="owner_whatsapp" name="owner_whatsapp" type="text" class="mt-1 block w-full" :value="old('owner_whatsapp', $business->owner_whatsapp)" required />
                    <x-input-error class="mt-2" :messages="$errors->get('owner_whatsapp')" />
                </div>

                <div>
                    <x-input-label for="business_type" :value="__('Business Type')" />
                    <x-text-input id="business_type" name="business_type" type="text" class="mt-1 block w-full" :value="old('business_type', $business->business_type)" required />
                    <x-input-error class="mt-2" :messages="$errors->get('business_type')" />
                </div>

                <div class="flex flex-col gap-3 sm:flex-row sm:justify-end">
                    <a href="{{ route('businesses.show', $business) }}" class="inline-flex justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Cancel') }}</a>
                    <x-primary-button>{{ __('Save Business') }}</x-primary-button>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>
