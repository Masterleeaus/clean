<x-app-layout>
    <x-slot name="header">
        <div>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Reward/Loyalty') }}</h2>
            <p class="mt-1 text-sm text-gray-500">{{ __('Status ganjaran pelanggan') }}</p>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-5xl px-4 sm:px-6 lg:px-8">
            <section class="overflow-hidden rounded-lg bg-white shadow-sm">
                <div class="border-b border-gray-100 p-5">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Confirmed Reward/Stamp Status') }}</h3>
                    <p class="mt-1 text-sm text-gray-500">{{ __('Hanya stamp/reward yang sudah confirmed selepas branch capture purchase dipaparkan. Customer tidak boleh self-claim purchase atau redeem reward melalui portal ini.') }}</p>
                </div>
                <div class="divide-y divide-gray-100">
                    @forelse ($accounts as $account)
                        <div class="p-5">
                            <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                                <div>
                                    <p class="font-medium text-gray-900">{{ $account->business->name }}</p>
                                    <p class="mt-1 text-sm text-gray-500">{{ $account->loyaltyProgram->reward_name }}</p>
                                </div>
                                <div class="text-sm font-semibold {{ $account->isRewardEligible() ? 'text-green-700' : 'text-gray-700' }}">
                                    {{ $account->isRewardEligible() ? __('Reward earned') : __('In progress') }}
                                </div>
                            </div>
                            <div class="mt-4 grid gap-3 sm:grid-cols-3">
                                <div class="rounded-md bg-gray-50 p-3">
                                    <p class="text-sm text-gray-500">{{ __('Current stamps') }}</p>
                                    <p class="mt-1 text-2xl font-semibold text-gray-900">{{ $account->current_stamps }}</p>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3">
                                    <p class="text-sm text-gray-500">{{ __('Required') }}</p>
                                    <p class="mt-1 text-2xl font-semibold text-gray-900">{{ $account->loyaltyProgram->stamps_required }}</p>
                                </div>
                                <div class="rounded-md bg-gray-50 p-3">
                                    <p class="text-sm text-gray-500">{{ __('Redeemed') }}</p>
                                    <p class="mt-1 text-2xl font-semibold text-gray-900">{{ $account->total_rewards_redeemed }}</p>
                                </div>
                            </div>
                        </div>
                    @empty
                        <p class="p-5 text-sm text-gray-500">{{ __('Belum ada reward/loyalty status.') }}</p>
                    @endforelse
                </div>
            </section>

            <section class="mt-6 overflow-hidden rounded-lg bg-white shadow-sm">
                <div class="border-b border-gray-100 p-5">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Reward/Stamp History') }}</h3>
                    <p class="mt-1 text-sm text-gray-500">{{ __('Sejarah sendiri sahaja.') }}</p>
                </div>

                <div class="divide-y divide-gray-100">
                    @forelse ($stampTransactions as $transaction)
                        <div class="p-5">
                            <p class="font-medium text-gray-900">{{ $transaction->business?->name }} - {{ $transaction->branch?->name ?? __('Business') }}</p>
                            <p class="mt-1 text-sm text-gray-500">{{ __($transaction->type) }}: {{ $transaction->stamps }} {{ __('stamps') }}</p>
                            <p class="mt-1 text-xs text-gray-500">{{ $transaction->created_at?->format('M j, Y g:i A') }}</p>
                        </div>
                    @empty
                        <p class="p-5 text-sm text-gray-500">{{ __('Belum ada confirmed stamp history.') }}</p>
                    @endforelse
                </div>
            </section>

            <section class="mt-6 overflow-hidden rounded-lg bg-white shadow-sm">
                <div class="border-b border-gray-100 p-5">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Reward Redemption History') }}</h3>
                </div>

                <div class="divide-y divide-gray-100">
                    @forelse ($rewardRedemptions as $redemption)
                        <div class="p-5">
                            <p class="font-medium text-gray-900">{{ $redemption->reward_name }}</p>
                            <p class="mt-1 text-sm text-gray-500">{{ $redemption->business?->name }} - {{ $redemption->branch?->name ?? __('Business') }}</p>
                            <p class="mt-1 text-xs text-gray-500">{{ $redemption->redeemed_at?->format('M j, Y g:i A') ?? __('Pending verification') }}</p>
                        </div>
                    @empty
                        <p class="p-5 text-sm text-gray-500">{{ __('Belum ada reward redemption history.') }}</p>
                    @endforelse
                </div>
            </section>
        </div>
    </div>
</x-app-layout>
