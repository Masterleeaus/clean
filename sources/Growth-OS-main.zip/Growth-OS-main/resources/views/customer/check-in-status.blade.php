@php
    $isOnlineCheckIn = ($check_in_type ?? \App\Models\CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL) === \App\Models\CustomerCheckIn::CHECK_IN_TYPE_ONLINE;
@endphp

<x-app-layout>
    <x-slot name="header">
        <div>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Customer Check-in') }}</h2>
            <p class="mt-1 text-sm text-gray-500">{{ $business?->name ?? __('Unknown business') }} - {{ $branch?->name ?? __('Unknown branch') }}</p>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <section class="rounded-lg bg-white p-6 shadow-sm">
                <h3 class="text-lg font-semibold text-gray-900">{{ __('Hai, :name', ['name' => $customer?->name ?? __('Customer')]) }}</h3>

                @if (($status ?? null) === 'check_in_too_soon')
                    <div class="mt-5 rounded-md bg-blue-50 p-4 text-sm text-blue-900">
                        {{ __('Cooldown belum selesai. Check-in/reward tidak dikemaskini.') }}
                    </div>
                @elseif (($status ?? null) === 'invalid_online_reference')
                    <div class="mt-5 rounded-md bg-red-50 p-4 text-sm text-red-900">
                        {{ __('Online check-in reference tidak sah. Reward tidak dikemaskini.') }}
                    </div>
                @elseif (($status ?? null) === 'online_reference_used')
                    <div class="mt-5 rounded-md bg-yellow-50 p-4 text-sm text-yellow-900">
                        {{ __('Online check-in link/code sudah digunakan. Reward tidak dikemaskini lagi.') }}
                    </div>
                @elseif (($status ?? null) === 'customer_mismatch')
                    <div class="mt-5 rounded-md bg-red-50 p-4 text-sm text-red-900">
                        {{ __('Online check-in reference tidak sepadan dengan customer ini. Reward tidak dikemaskini.') }}
                    </div>
                @elseif (($status ?? null) === 'online_check_in_recorded')
                    <div class="mt-5 rounded-md bg-green-50 p-4 text-sm text-green-900">
                        {{ __('Check-in berjaya direkodkan. Check-in order online berjaya direkodkan. Reward akan disahkan selepas pembelian disahkan oleh branch.') }}
                    </div>
                @elseif (($check_in_stamp_granted ?? false) === true)
                    <div class="mt-5 rounded-md bg-green-50 p-4 text-sm text-green-900">
                        {{ __('Check-in berjaya dan reward dikemaskini.') }}
                    </div>
                @elseif ($isOnlineCheckIn)
                    <div class="mt-5 rounded-md bg-green-50 p-4 text-sm text-green-900">
                        {{ __('Check-in berjaya direkodkan. Check-in order online berjaya direkodkan. Reward akan disahkan selepas pembelian disahkan oleh branch.') }}
                    </div>
                @else
                    <div class="mt-5 rounded-md bg-green-50 p-4 text-sm text-green-900">
                        {{ __('Check-in berjaya direkodkan. Check-in premis berjaya direkodkan. Reward akan disahkan selepas pembelian disahkan oleh branch.') }}
                    </div>
                @endif

                <p class="mt-4 text-sm text-gray-600">
                    {{ __('Reward/stamp hanya confirmed selepas Branch Manager capture Product/Service purchase yang sah. Customer tidak perlu dan tidak boleh self-claim purchase dalam portal ini.') }}
                </p>

                <dl class="mt-5 grid gap-4 sm:grid-cols-2">
                    <div>
                        <dt class="text-sm font-medium text-gray-500">{{ __('Business') }}</dt>
                        <dd class="mt-1 text-gray-900">{{ $business?->name ?? '-' }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">{{ __('Branch') }}</dt>
                        <dd class="mt-1 text-gray-900">{{ $branch?->name }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">{{ __('Tarikh') }}</dt>
                        <dd class="mt-1 text-gray-900">{{ now()->format('Y-m-d H:i') }}</dd>
                    </div>
                </dl>

                <a href="{{ route('customer.portal') }}" class="mt-6 inline-flex rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
                    {{ __('Kembali') }}
                </a>
            </section>
        </div>
    </div>
</x-app-layout>
