<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div class="min-w-0">
                <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Customer Feedback') }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ __('Kongsi maklumbalas umum tentang sistem, check-in, reward, feedback, atau pengalaman outlet.') }}</p>
            </div>
            <a href="{{ route('customer.portal') }}" class="inline-flex w-full items-center justify-center rounded-md border border-gray-300 px-4 py-2 text-center text-sm font-semibold text-gray-700 hover:bg-gray-50 sm:w-auto">{{ __('Portal') }}</a>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-4xl space-y-6 px-4 sm:px-6 lg:px-8">
            @if (session('status'))
                <x-alert-banner tone="success">{{ session('status') }}</x-alert-banner>
            @endif

            <x-dashboard-card :title="__('Hantar Maklumbalas')" :eyebrow="__('Feedback bebas/general')">
                <p class="text-sm leading-6 text-gray-600">
                    {{ __('Kongsi pengalaman outlet, check-in, reward, service, atau cadangan umum. Maklumbalas ini tidak wajib dan tidak mengubah reward/stamp secara automatik.') }}
                </p>

                <form method="POST" action="{{ route('customer.feedback.store') }}" class="mt-5 space-y-5">
                    @csrf

                    <x-input-error class="rounded-md bg-red-50 p-3 text-sm text-red-700" :messages="$errors->get('feedback')" />

                    <div>
                        <x-input-label for="branch_id" :value="__('Branch')" />
                        <select id="branch_id" name="branch_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                            <option value="">{{ __('Pilih branch') }}</option>
                            @foreach ($branches as $branch)
                                <option value="{{ $branch->id }}" @selected((string) old('branch_id') === (string) $branch->id)>
                                    {{ $branch->business->name }} - {{ $branch->name }}
                                </option>
                            @endforeach
                        </select>
                        <x-input-error class="mt-2" :messages="$errors->get('branch_id')" />
                    </div>

                    <div>
                        <x-input-label for="product_service_id" :value="__('Product/Service (optional)')" />
                        <select id="product_service_id" name="product_service_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">{{ __('Tidak pilih') }}</option>
                            @foreach ($productServices as $productService)
                                <option value="{{ $productService->id }}" @selected((string) old('product_service_id') === (string) $productService->id)>
                                    {{ $productService->name }}
                                </option>
                            @endforeach
                        </select>
                        <x-input-error class="mt-2" :messages="$errors->get('product_service_id')" />
                    </div>

                    <div>
                        <x-input-label for="rating" :value="__('Rating (optional)')" />
                        <select id="rating" name="rating" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="">{{ __('Pilih rating') }}</option>
                            @foreach ([1, 2, 3, 4, 5] as $rating)
                                <option value="{{ $rating }}" @selected((string) old('rating') === (string) $rating)>{{ $rating }}</option>
                            @endforeach
                        </select>
                        <x-input-error class="mt-2" :messages="$errors->get('rating')" />
                    </div>

                    <div>
                        <x-input-label for="comment" :value="__('Maklumbalas')" />
                        <textarea id="comment" name="comment" rows="4" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">{{ old('comment') }}</textarea>
                        <x-input-error class="mt-2" :messages="$errors->get('comment')" />
                    </div>

                    <x-primary-button>{{ __('Hantar') }}</x-primary-button>
                </form>
            </x-dashboard-card>

            <x-section-panel :title="__('Maklumbalas Saya')" :eyebrow="__('Submitted feedback')">
                <div class="mt-5 divide-y divide-gray-100">
                    @forelse ($feedback as $entry)
                        <div class="py-4">
                            <p class="break-words font-semibold text-gray-900">{{ $entry->branch?->name ?? $entry->business?->name }}</p>
                            <p class="mt-1 text-sm text-gray-500">{{ $entry->submitted_at?->format('M j, Y g:i A') ?? '-' }}</p>
                            <p class="mt-1 text-sm text-gray-500">{{ __('Status') }}: {{ $entry->status }}</p>
                            @if ($entry->productService)
                                <p class="mt-1 text-sm text-gray-500">{{ __('Product/Service') }}: {{ $entry->productService->name }}</p>
                            @endif
                            <p class="mt-2 text-sm text-gray-700">{{ $entry->comment ?: __('Tiada komen') }}</p>
                        </div>
                    @empty
                        <x-empty-state :title="__('Belum ada maklumbalas.')" :body="__('Maklumbalas boleh dihantar bila-bila masa selepas pengalaman anda.')" />
                    @endforelse
                </div>
            </x-section-panel>
        </div>
    </div>
</x-app-layout>
