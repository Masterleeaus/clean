<x-app-layout>
    <x-slot name="header">
        <div>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Customer Portal') }}</h2>
            <p class="mt-1 text-sm text-gray-500">{{ __('Customer-only access for GOS-F&B.') }}</p>
        </div>
    </x-slot>

    <x-slot name="fab">
        <x-floating-action-button href="#customer-check-in" icon="check" :label="__('Check-in')" />
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            <x-dashboard-card id="dashboard-overview" :title="__('Selamat datang, :name', ['name' => auth()->user()->name])" :eyebrow="__('Customer dashboard')">
                <div class="grid gap-5 lg:grid-cols-[1.35fr_0.65fr]">
                    <div class="min-w-0">
                        <p class="text-sm leading-6 text-gray-600">
                            {{ __('Customer account hanya boleh akses portal pelanggan. Check-in merekodkan lawatan; reward/stamp hanya confirmed selepas Branch Manager capture Product/Service purchase yang sah. Platform ini bukan POS atau ordering system.') }}
                        </p>
                        <p class="mt-3 text-sm font-semibold text-gray-900">
                            {{ __('Reward akan disahkan selepas pembelian disahkan oleh branch.') }}
                        </p>
                        <div class="mt-4 flex flex-wrap gap-2">
                            <x-status-badge tone="info">{{ __('Check-in di Premis') }}</x-status-badge>
                            <x-status-badge tone="info">{{ __('Check-in untuk Order Online') }}</x-status-badge>
                            <x-status-badge tone="success">{{ __('Confirmed stamps sahaja') }}</x-status-badge>
                        </div>
                    </div>

                    <div class="rounded-md border border-emerald-100 bg-emerald-50 p-4">
                        <p class="text-xs font-semibold uppercase text-emerald-700">{{ __('Flow mudah') }}</p>
                        <p class="mt-2 text-sm font-semibold text-slate-900">{{ __('1. Check-in  2. Branch verify purchase  3. Reward Confirmed') }}</p>
                    </div>
                </div>

                <div class="mt-5 flex flex-wrap gap-2">
                    <x-action-button href="#customer-check-in">{{ __('Mulakan Check-in') }}</x-action-button>
                    <x-action-button :href="route('customer.rewards')" variant="secondary">{{ __('Lihat Reward/Loyalty') }}</x-action-button>
                    <x-action-button :href="route('customer.feedback')" variant="secondary">{{ __('Hantar Maklumbalas') }}</x-action-button>
                </div>
            </x-dashboard-card>

            <section id="dashboard-metrics" class="grid gap-4 md:grid-cols-3">
                <x-metric-card :label="__('Check-in saya')" :value="$recentCheckIns->count()" :hint="__('Physical/Online visits recorded')" />
                <x-metric-card :label="__('Reward/Loyalty')" :value="$loyaltyAccounts->sum('current_stamps')" :hint="__('Confirmed stamps sahaja')" />
                <x-metric-card :label="__('Maklumbalas saya')" :value="$recentFeedback->count()" :hint="__('Feedback submitted freely')" />
            </section>

            <section id="dashboard-activity" class="grid gap-6 lg:grid-cols-3">
                <x-section-panel :title="__('Recent Check-ins')" :eyebrow="__('Visit history')">
                    <div class="divide-y divide-gray-100">
                        @forelse ($recentCheckIns as $checkIn)
                            <div class="py-3">
                                <div class="flex flex-wrap items-start justify-between gap-3">
                                    <div class="min-w-0">
                                        <p class="font-semibold text-gray-900">{{ $checkIn->branch?->name ?? $checkIn->business?->name }}</p>
                                        <p class="mt-1 text-sm text-gray-500">{{ $checkIn->check_in_at?->format('M j, Y g:i A') }}</p>
                                    </div>
                                    <x-status-badge :tone="$checkIn->check_in_type === \App\Models\CustomerCheckIn::CHECK_IN_TYPE_ONLINE ? 'info' : 'slate'">{{ __($checkIn->checkInTypeLabel()) }}</x-status-badge>
                                </div>
                                @if ($checkIn->reward_status === \App\Models\CustomerCheckIn::REWARD_STATUS_GRANTED)
                                    <div class="mt-2">
                                        <x-status-badge tone="premium">{{ __('Confirmed Reward') }}</x-status-badge>
                                    </div>
                                @else
                                    <p class="mt-2 text-xs font-semibold text-gray-600">{{ __('Reward/stamp confirmed after branch verifies purchase.') }}</p>
                                @endif
                                <div class="mt-2 space-y-1">
                                    @foreach ($checkIn->productServiceCaptures as $capture)
                                        <p class="text-sm text-gray-700">
                                            {{ $capture->productService?->name ?? __('Product/Service') }}
                                            x{{ $capture->quantity }}
                                            - RM {{ number_format((float) $capture->total_amount, 2) }}
                                        </p>
                                    @endforeach
                                </div>
                            </div>
                        @empty
                            <x-empty-state :title="__('Belum ada check-in.')" :body="__('Gunakan Check-in di Premis atau Check-in untuk Order Online apabila sesuai.')" />
                        @endforelse
                    </div>
                </x-section-panel>

                <x-section-panel :title="__('Reward/Loyalty Status')" :eyebrow="__('Confirmed reward/stamp')">
                    <p class="text-sm text-gray-500">{{ __('Hanya confirmed reward/stamp dipaparkan di sini.') }}</p>
                    <div class="mt-4 divide-y divide-gray-100">
                        @forelse ($loyaltyAccounts as $account)
                            <div class="py-3">
                                <div class="flex flex-wrap items-start justify-between gap-3">
                                    <div class="min-w-0">
                                        <p class="font-semibold text-gray-900">{{ $account->business?->name }}</p>
                                        <p class="mt-1 text-sm text-gray-500">{{ $account->current_stamps }} / {{ $account->loyaltyProgram?->stamps_required ?? '-' }} {{ __('stamps') }}</p>
                                    </div>
                                    <x-status-badge tone="premium">{{ __('Reward Confirmed') }}</x-status-badge>
                                </div>
                            </div>
                        @empty
                            <x-empty-state :title="__('Belum ada reward/loyalty.')" :body="__('Confirmed stamps akan dipaparkan selepas branch verify purchase yang sah.')" />
                        @endforelse
                    </div>
                </x-section-panel>

                <x-section-panel :title="__('Submitted Feedback')" :eyebrow="__('Hantar Maklumbalas')">
                    <p class="mb-3 text-sm text-gray-500">{{ __('Maklumbalas bebas/general. Ia bukan syarat reward dan tidak diwajibkan selepas check-in.') }}</p>
                    <div class="divide-y divide-gray-100">
                        @forelse ($recentFeedback as $entry)
                            <div class="py-3">
                                <p class="break-words font-semibold text-gray-900">{{ $entry->branch?->name ?? $entry->business?->name }}</p>
                                <p class="mt-1 text-sm text-gray-700">{{ $entry->comment ?: __('Tiada komen') }}</p>
                            </div>
                        @empty
                            <x-empty-state :title="__('Belum ada maklumbalas.')" :body="__('Anda boleh hantar maklumbalas tanpa menunggu completed purchase.')" />
                        @endforelse
                    </div>
                </x-section-panel>
            </section>

            <x-section-panel id="customer-check-in" :title="__('Customer Check-in')" :eyebrow="__('Physical / Online')">
                <p class="text-sm text-gray-500">{{ __('Pilih mode check-in sahaja. Purchase dibuat di luar GOS-F&B; staff branch akan capture purchase yang sah sebelum reward/stamp confirmed.') }}</p>

                @if ($errors->any())
                    <x-alert-banner tone="danger" class="mt-4">
                        {{ $errors->first() }}
                    </x-alert-banner>
                @endif

                <form method="POST" action="{{ route('customer.check-in.store') }}" class="mt-5 space-y-5">
                    @csrf

                    <fieldset>
                        <legend class="text-sm font-medium text-gray-700">{{ __('Mode check-in') }}</legend>
                        <div class="mt-3 grid gap-3 md:grid-cols-2">
                            <label class="flex min-w-0 cursor-pointer items-start gap-3 rounded-md border border-emerald-100 bg-emerald-50 p-4 shadow-sm">
                                <input type="radio" name="check_in_mode" value="physical" class="mt-1 border-gray-300 text-emerald-700 focus:ring-emerald-600" @checked(old('check_in_mode', 'physical') === 'physical') required>
                                <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-white text-emerald-700">
                                    <svg viewBox="0 0 24 24" class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <path d="M4 10h16" />
                                        <path d="M5 10l1-5h12l1 5" />
                                        <path d="M6 10v9h12v-9" />
                                        <path d="M9 19v-5h6v5" />
                                    </svg>
                                </span>
                                <span class="min-w-0">
                                    <span class="block text-sm font-semibold text-gray-900">{{ __('Check-in di Premis') }}</span>
                                    <span class="mt-1 block text-sm text-gray-500">{{ __('Gunakan jika anda berada di kedai.') }}</span>
                                    <span class="mt-3 inline-flex text-xs font-bold text-emerald-700">{{ __('Pilih mode ini') }}</span>
                                </span>
                            </label>

                            <label class="flex min-w-0 cursor-pointer items-start gap-3 rounded-md border border-slate-200 bg-white p-4 shadow-sm">
                                <input type="radio" name="check_in_mode" value="online" class="mt-1 border-gray-300 text-emerald-700 focus:ring-emerald-600" @checked(old('check_in_mode') === 'online') required>
                                <span class="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-slate-50 text-slate-700">
                                    <svg viewBox="0 0 24 24" class="h-5 w-5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
                                        <rect x="5" y="3" width="14" height="18" rx="2" />
                                        <path d="M9 7h6" />
                                        <path d="M9 11h6" />
                                        <path d="M9 15h3" />
                                    </svg>
                                </span>
                                <span class="min-w-0">
                                    <span class="block text-sm font-semibold text-gray-900">{{ __('Check-in untuk Order Online') }}</span>
                                    <span class="mt-1 block text-sm text-gray-500">{{ __('Gunakan jika anda membuat order melalui WhatsApp, delivery, pickup atau channel luar.') }}</span>
                                    <span class="mt-3 inline-flex text-xs font-bold text-slate-700">{{ __('Pilih mode ini') }}</span>
                                </span>
                            </label>
                        </div>
                        <x-input-error class="mt-2" :messages="$errors->get('check_in_mode')" />
                    </fieldset>

                    <div>
                        <x-input-label for="branch_id" :value="__('Branch')" />
                        <select id="branch_id" name="branch_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                            <option value="">{{ __('Pilih branch') }}</option>
                            @foreach ($branches as $branch)
                                <option value="{{ $branch->id }}" @selected(old('branch_id') == $branch->id)>{{ $branch->business->name }} - {{ $branch->name }}</option>
                            @endforeach
                        </select>
                        <x-input-error class="mt-2" :messages="$errors->get('branch_id')" />
                    </div>

                    <div>
                        <x-input-label for="whatsapp_number" :value="__('WhatsApp')" />
                        <x-text-input id="whatsapp_number" name="whatsapp_number" type="text" class="mt-1 block w-full" :value="old('whatsapp_number')" required />
                        <x-input-error class="mt-2" :messages="$errors->get('whatsapp_number')" />
                    </div>

                    <x-primary-button>{{ __('Rekod Check-in') }}</x-primary-button>
                </form>
            </x-section-panel>

            <x-section-panel id="dashboard-actions" :title="__('Online Check-in Link/Code')" :eyebrow="__('Customer check-in reference')">
                <p class="text-sm text-gray-500">{{ __('Gunakan link/code online jika diberi oleh branch. Ini hanya rekod check-in; bukan borang order, payment, atau self-claim purchase.') }}</p>

                <form method="POST" action="{{ route('customer.online-check-in.store') }}" class="mt-5 space-y-5">
                    @csrf

                    <div>
                        <x-input-label for="code" :value="__('Online check-in code/reference')" />
                        <x-text-input id="code" name="code" type="text" class="mt-1 block w-full" :value="old('code')" required />
                        <x-input-error class="mt-2" :messages="$errors->get('code')" />
                    </div>

                    <x-primary-button>{{ __('Rekod Online Check-in') }}</x-primary-button>
                </form>
            </x-section-panel>
        </div>
    </div>
</x-app-layout>
