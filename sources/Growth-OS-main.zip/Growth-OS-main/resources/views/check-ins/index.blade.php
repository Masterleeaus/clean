@php
    $canOperate = $canOperateCheckIns ?? false;
    $physicalCheckIns = $checkIns->where('check_in_type', \App\Models\CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL)->count();
    $onlineCheckIns = $checkIns->where('check_in_type', \App\Models\CustomerCheckIn::CHECK_IN_TYPE_ONLINE)->count();
    $pendingCapture = $checkIns->filter(fn ($checkIn) => $checkIn->isAwaitingPurchaseCapture())->count();
    $capturedPurchases = $checkIns->where('reward_status', \App\Models\CustomerCheckIn::REWARD_STATUS_GRANTED)->count();
    $noPurchase = $checkIns->where('reward_status', \App\Models\CustomerCheckIn::REWARD_STATUS_NO_PURCHASE)->count();
    $pendingPhysical = $checkIns
        ->filter(fn ($checkIn) => $checkIn->isAwaitingPurchaseCapture() && $checkIn->check_in_type === \App\Models\CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL)
        ->count();
    $pendingOnline = $checkIns
        ->filter(fn ($checkIn) => $checkIn->isAwaitingPurchaseCapture() && $checkIn->check_in_type === \App\Models\CustomerCheckIn::CHECK_IN_TYPE_ONLINE)
        ->count();
    $overdueCapture = $checkIns
        ->filter(fn ($checkIn) => $checkIn->purchaseCaptureStatus() === \App\Models\CustomerCheckIn::PURCHASE_STATUS_OVERDUE)
        ->count();
    $manualReview = $checkIns
        ->filter(fn ($checkIn) => $checkIn->purchaseCaptureStatus() === \App\Models\CustomerCheckIn::PURCHASE_STATUS_MANUAL_REVIEW)
        ->count();

    $statusTone = function (string $status): string {
        return match ($status) {
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_CONFIRMED => 'success',
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_NO_PURCHASE => 'slate',
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_OVERDUE => 'danger',
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_MANUAL_REVIEW => 'purple',
            default => 'warning',
        };
    };

    $checkInTypeTone = function (string $type): string {
        return $type === \App\Models\CustomerCheckIn::CHECK_IN_TYPE_ONLINE ? 'info' : 'slate';
    };

    $statusShortLabel = function (string $status): string {
        return match ($status) {
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_CONFIRMED => __('Captured'),
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_NO_PURCHASE => __('No Purchase'),
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_OVERDUE => __('Overdue'),
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_MANUAL_REVIEW => __('Manual Review'),
            default => __('Pending'),
        };
    };
@endphp

<x-app-layout>
    <x-slot name="header">
        <div>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __($title) }}</h2>
            <p class="mt-1 text-sm text-gray-500">
                {{ $branch ? $business->name.' - '.$branch->name : $business->name }}
            </p>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            @if (session('status'))
                <x-alert-banner tone="success">{{ session('status') }}</x-alert-banner>
            @endif

            <x-dashboard-card :title="__('Branch Check-ins')" :eyebrow="$branch ? __('Assigned branch operation') : __('Business check-in view')">
                <div class="grid gap-5 lg:grid-cols-[1.35fr_0.65fr]">
                    <div class="min-w-0">
                        <p class="text-sm leading-6 text-gray-600">
                            {{ __('Sahkan pembelian hanya selepas transaksi sebenar berlaku di luar sistem.') }}
                        </p>
                        <p class="mt-2 text-sm leading-6 text-gray-600">
                            {{ __('Physical check-in: Semak pembelian di premis sebelum capture purchase. Online check-in: Semak order/payment melalui channel luar sebelum capture purchase.') }}
                        </p>
                    </div>
                    <div class="rounded-md border border-slate-200 bg-slate-50 p-4">
                        <p class="text-xs font-semibold uppercase text-slate-500">{{ __('Operation scope') }}</p>
                        <p class="mt-2 break-words text-sm font-semibold text-slate-900">{{ $branch ? $branch->name : $business->name }}</p>
                        <p class="mt-1 text-xs text-slate-500">
                            {{ $canOperate ? __('Capture Purchase / Mark No Purchase hanya untuk assigned branch.') : __('Operation actions are limited to assigned branch operators.') }}
                        </p>
                    </div>
                </div>
            </x-dashboard-card>

            <section id="dashboard-metrics" class="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                <x-metric-card :label="__('Physical check-ins')" :value="$physicalCheckIns" :hint="__('Mode: Physical')" />
                <x-metric-card :label="__('Online check-ins')" :value="$onlineCheckIns" :hint="__('Mode: Online')" />
                <x-metric-card :label="__('Pending capture')" :value="$pendingCapture" :hint="__('Needs branch action')" class="bg-yellow-50" />
                <x-metric-card :label="__('Captured purchases')" :value="$capturedPurchases" :hint="__('Reward Confirmed')" />
                <x-metric-card :label="__('No Purchase')" :value="$noPurchase" :hint="__('No reward/stamp')" />
            </section>

            @if ($canOperate)
                <section id="dashboard-operation-alerts" class="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
                    <x-metric-card :label="__('Pending Purchase Capture — Physical')" :value="$pendingPhysical" :hint="__('Semak pembelian di premis sebelum capture purchase.')" class="bg-yellow-50" />
                    <x-metric-card :label="__('Pending Purchase Capture — Online')" :value="$pendingOnline" :hint="__('Semak order/payment melalui channel luar sebelum capture purchase.')" class="bg-yellow-50" />
                    <x-metric-card :label="__('Overdue')" :value="$overdueCapture" :hint="__('Overdue Purchase Capture')" class="bg-orange-50" />
                    <x-metric-card :label="__('Manual Review')" :value="$manualReview" :hint="__('Manual Review Required')" class="bg-red-50" />
                </section>
            @endif

            @if ($branch && $canOperate)
                <section class="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(280px,420px)]">
                    <x-section-panel :title="__('Online Check-in Links')" :eyebrow="__('Online reference')">
                        <p class="text-sm text-gray-500">{{ __('Link/code ini hanya rekod online check-in. Purchase masih perlu Capture Purchase selepas disahkan branch.') }}</p>
                        <div class="mt-4 divide-y divide-gray-100">
                            @forelse ($onlineReferences as $reference)
                                <div class="py-3 text-sm">
                                    <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between">
                                        <div class="min-w-0">
                                            <p class="font-semibold text-gray-900">{{ $reference->code }}</p>
                                            <p class="break-words text-gray-600">
                                                {{ $reference->customer?->name }} - {{ __('Reference item') }}: {{ $reference->productService?->name }}
                                                - RM {{ number_format((float) $reference->total_amount, 2) }}
                                            </p>
                                        </div>
                                        <x-status-badge :tone="$reference->status === \App\Models\OnlineCheckInReference::STATUS_CLAIMED ? 'success' : 'warning'">
                                            {{ __(ucfirst($reference->status)) }}
                                        </x-status-badge>
                                    </div>
                                </div>
                            @empty
                                <x-empty-state :title="__('No online check-in references yet.')" :body="__('Generate a reference only when the order is handled through an external channel.')" />
                            @endforelse
                        </div>
                    </x-section-panel>

                    <form method="POST" action="{{ route('businesses.branches.online-check-ins.store', ['business' => $business, 'branch' => $branch]) }}" class="space-y-3 rounded-lg border border-slate-200 bg-white p-5 shadow-sm">
                        @csrf
                        <h3 class="text-base font-semibold text-gray-900">{{ __('Create Online Check-in Link') }}</h3>
                        <p class="text-sm text-gray-500">{{ __('Bukan capture purchase. Customer guna code untuk check-in online; BM/BO cum BM capture purchase kemudian jika sah.') }}</p>

                        <select name="customer_id" class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                            <option value="">{{ __('Select customer') }}</option>
                            @foreach ($customers as $customer)
                                <option value="{{ $customer->id }}">{{ $customer->name }} - {{ $customer->whatsapp_number }}</option>
                            @endforeach
                        </select>

                        <select name="product_service_id" class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                            <option value="">{{ __('Select Product/Service') }}</option>
                            @foreach ($productsForBranch($branch) as $product)
                                <option value="{{ $product->id }}">{{ $product->category }} - {{ $product->name }} - RM {{ number_format((float) $product->price, 2) }}</option>
                            @endforeach
                        </select>

                        <div class="grid gap-2 sm:grid-cols-2">
                            <input name="quantity" type="number" min="1" max="100" value="1" class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                            <select name="capture_type" class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                                <option value="purchase">{{ __('Purchase') }}</option>
                                <option value="subscription">{{ __('Subscription') }}</option>
                            </select>
                        </div>

                        <input name="purchase_reference" type="text" class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="{{ __('Online order/reference, if any') }}">

                        <x-action-button type="submit" class="w-full">{{ __('Generate Link Code') }}</x-action-button>
                    </form>
                </section>
            @endif

            <x-section-panel :title="__('Pending Purchase Capture')" :eyebrow="__('Check-in work queue')">
                <div class="divide-y divide-gray-100">
                    @forelse ($checkIns as $checkIn)
                        @php
                            $purchaseStatus = $checkIn->purchaseCaptureStatus();
                            $isOnline = $checkIn->check_in_type === \App\Models\CustomerCheckIn::CHECK_IN_TYPE_ONLINE;
                        @endphp

                        <div class="grid gap-4 py-5 lg:grid-cols-[minmax(0,1fr)_minmax(280px,360px)]">
                            <div class="min-w-0">
                                <div class="flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
                                    <div class="min-w-0">
                                        <div class="flex flex-wrap items-center gap-2">
                                            <p class="font-medium text-gray-900">{{ $checkIn->customer?->name ?? __('Unknown customer') }}</p>
                                            <x-status-badge :tone="$checkInTypeTone($checkIn->check_in_type)">{{ __($checkIn->checkInTypeLabel()) }}</x-status-badge>
                                            <x-status-badge :tone="$statusTone($purchaseStatus)">{{ $statusShortLabel($purchaseStatus) }}</x-status-badge>
                                        </div>
                                        <p class="mt-1 text-sm text-gray-500">
                                            {{ $checkIn->branch?->name ?? $branch?->name ?? __('Business-level check-in') }}
                                            @if ($checkIn->purchase_reference)
                                                - {{ __('Reference') }}: {{ $checkIn->purchase_reference }}
                                            @endif
                                        </p>
                                        <p class="mt-1 text-xs text-gray-500">
                                            {{ __('Check-in time') }}: {{ $checkIn->check_in_at?->format('Y-m-d H:i') ?? $checkIn->created_at?->format('Y-m-d H:i') }}
                                        </p>
                                        @if ($checkIn->isAwaitingPurchaseCapture())
                                            <p class="mt-2 text-xs font-semibold text-yellow-800">{{ $checkIn->pendingPurchaseCaptureLabel() }}</p>
                                        @endif
                                    </div>
                                    <p class="text-xs text-gray-600 sm:text-sm">
                                        {{ $checkIn->check_in_at?->format('Y-m-d H:i') ?? $checkIn->created_at?->format('Y-m-d H:i') }}
                                    </p>
                                </div>

                                <div class="mt-4 rounded-md bg-gray-50 p-3">
                                    <div class="flex flex-col gap-2 sm:flex-row sm:items-start sm:justify-between sm:gap-3">
                                        <p class="text-sm font-medium text-gray-700">{{ __('Product/Service captured') }}</p>
                                        <x-status-badge :tone="$checkIn->productServiceCaptures->isNotEmpty() ? 'success' : 'warning'">
                                            {{ $checkIn->productServiceCaptures->isNotEmpty() ? __('Captured') : __('Pending') }}
                                        </x-status-badge>
                                    </div>
                                    <div class="mt-2 space-y-1">
                                        @forelse ($checkIn->productServiceCaptures as $capture)
                                            <p class="text-sm text-gray-600">
                                                {{ $capture->productService?->name ?? __('Unknown item') }}
                                                x{{ $capture->quantity }}
                                                - {{ $capture->capture_type }}
                                                - RM {{ number_format((float) $capture->total_amount, 2) }}
                                            </p>
                                        @empty
                                            <p class="text-sm text-gray-500">{{ __('No Product/Service captured yet.') }}</p>
                                        @endforelse
                                    </div>
                                </div>
                            </div>

                            @if ($checkIn->branch && $canOperate)
                                @php($products = $productsForBranch($checkIn->branch))
                                <div class="min-w-0 space-y-3 rounded-md border border-gray-200 bg-white p-3">
                                    <div class="rounded-md bg-slate-50 p-3">
                                        <p class="text-xs font-semibold uppercase text-slate-500">{{ __('Branch operation guidance') }}</p>
                                        <p class="mt-1 text-sm text-slate-700">
                                            {{ $isOnline ? __('Semak order/payment melalui channel luar sebelum capture purchase.') : __('Semak pembelian di premis sebelum capture purchase.') }}
                                        </p>
                                    </div>

                                    @if ($checkIn->reward_status !== \App\Models\CustomerCheckIn::REWARD_STATUS_NO_PURCHASE)
                                        <form method="POST" action="{{ route('businesses.branches.check-ins.product-services.store', ['business' => $business, 'branch' => $checkIn->branch, 'checkIn' => $checkIn]) }}" class="space-y-3">
                                            @csrf
                                            <input type="hidden" name="capture_reference" value="{{ (string) Illuminate\Support\Str::uuid() }}">
                                            <p class="text-sm font-semibold text-gray-900">{{ __('Capture Product/Service') }}</p>

                                            <select name="product_service_id" class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                                                <option value="">{{ __('Select item') }}</option>
                                                @foreach ($products as $product)
                                                    <option value="{{ $product->id }}">{{ $product->category }} - {{ $product->name }} - RM {{ number_format((float) $product->price, 2) }}</option>
                                                @endforeach
                                            </select>

                                            <div class="grid gap-2 sm:grid-cols-2">
                                                <input name="quantity" type="number" min="1" max="100" value="1" class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                                                <select name="capture_type" class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" required>
                                                    <option value="purchase">{{ __('Purchase') }}</option>
                                                    <option value="subscription">{{ __('Subscription') }}</option>
                                                </select>
                                            </div>

                                            <input name="notes" type="text" class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="{{ __('Optional receipt/reference/payment note') }}">

                                            <x-action-button type="submit" class="w-full">{{ __('Capture Purchase') }}</x-action-button>
                                        </form>
                                    @endif

                                    @if ($checkIn->isAwaitingPurchaseCapture() && $checkIn->productServiceCaptures->isEmpty())
                                        <form method="POST" action="{{ route('businesses.branches.check-ins.no-purchase', ['business' => $business, 'branch' => $checkIn->branch, 'checkIn' => $checkIn]) }}" class="border-t border-gray-100 pt-3">
                                            @csrf
                                            @method('PATCH')
                                            <input name="no_purchase_reason" type="text" class="block w-full rounded-md border-gray-300 text-sm shadow-sm focus:border-indigo-500 focus:ring-indigo-500" placeholder="{{ __('Reason for No Purchase') }}">
                                            <button type="submit" class="mt-2 w-full rounded-md border border-red-200 bg-red-50 px-3 py-2 text-sm font-semibold text-red-700 hover:bg-red-100">{{ __('Mark No Purchase') }}</button>
                                        </form>
                                    @endif
                                </div>
                            @endif
                        </div>
                    @empty
                        <x-empty-state :title="__('No check-ins yet.')" :body="__('Pending capture work queue will appear after customer check-ins.')" />
                    @endforelse
                </div>
            </x-section-panel>
        </div>
    </div>
</x-app-layout>
