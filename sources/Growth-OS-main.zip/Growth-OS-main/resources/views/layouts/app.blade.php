<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <!-- Fonts -->
        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        <!-- Scripts -->
        @include('layouts.partials.vite-assets')
    </head>
    <body class="gos-app font-sans antialiased">
        @php
            $user = Auth::user();
            $personaLabel = match (true) {
                $user?->hasInternalCombinedAccess() => __('System Manager / Admin'),
                $user?->hasBusinessCombinedAccess() => __('Business Owner / Branch Manager'),
                $user?->isSystemManager() => __('System Manager'),
                $user?->isSystemAdmin() => __('System Admin'),
                $user?->isOwner() => __('Business Owner'),
                $user?->isBranchManager() => __('Branch Manager'),
                $user?->isCustomer() => __('Customer'),
                default => __('Workspace'),
            };
            $contextLabel = match (true) {
                $user?->hasInternalCombinedAccess() => __('Platform + Admin'),
                $user?->hasBusinessCombinedAccess() => __('Business + Branch'),
                $user?->isSystemManager() => __('Platform Strategy'),
                $user?->isSystemAdmin() => __('Admin Support'),
                $user?->isOwner() => __('Business Performance'),
                $user?->isBranchManager() => __('Branch Operation'),
                $user?->isCustomer() => __('Customer Portal'),
                default => __('Local Pilot'),
            };
        @endphp

        <div class="gos-shell min-h-screen text-slate-900 lg:pl-72">
            @include('layouts.navigation')

            <!-- Page Heading -->
            @isset($header)
                <header class="gos-page-header sticky top-0 z-20 border-b border-slate-200/80 bg-white/95 shadow-sm backdrop-blur">
                    <div class="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-4 sm:px-6 lg:px-8">
                        <div class="min-w-0">
                            {{ $header }}
                        </div>
                        <div class="hidden items-center gap-2 md:flex">
                            <span class="gos-context-pill">
                                {{ $personaLabel }}
                            </span>
                            <span class="gos-context-pill is-strong">
                                {{ $contextLabel }}
                            </span>
                        </div>
                    </div>
                </header>
            @endisset

            <!-- Page Content -->
            <main class="gos-main pb-12">
                {{ $slot }}
            </main>

            @isset($fab)
                {{ $fab }}
            @endisset
        </div>
    </body>
</html>
