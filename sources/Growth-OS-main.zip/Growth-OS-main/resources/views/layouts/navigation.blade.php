@php
    $user = Auth::user();
    $isInternalCombined = $user?->hasInternalCombinedAccess();
    $isBusinessCombined = $user?->hasBusinessCombinedAccess();
    $isPureSystemManager = $user?->isSystemManager() && ! $user?->isSystemAdmin();
    $isPureSystemAdmin = $user?->isSystemAdmin() && ! $user?->isSystemManager();
    $isPureOwner = $user?->isOwner() && ! $user?->isBranchManager();
    $isPureBranchManager = $user?->isBranchManager() && ! $user?->isOwner();
    $isCustomer = $user?->isCustomer();
    $dashboardUrl = $user ? route($user->dashboardRouteName()) : route('dashboard');
    $dashboardActive = request()->routeIs('dashboard') || request()->routeIs('dashboards.*') || request()->routeIs('customer.portal');

    $assignedBranch = null;
    if ($user && ($isPureBranchManager || $isBusinessCombined)) {
        $branchIds = $user->scopedBranchIds();
        $assignedBranch = \App\Models\Branch::query()
            ->with('business')
            ->where(function ($query) use ($user, $branchIds) {
                $query->where('manager_user_id', $user->id);

                if ($branchIds !== []) {
                    $query->orWhereIn('id', $branchIds);
                }
            })
            ->orderBy('name')
            ->first();
    }

    $personaLabel = match (true) {
        $isInternalCombined => __('System Manager / Admin'),
        $isBusinessCombined => __('Business Owner / Branch Manager'),
        $isPureSystemManager => __('System Manager'),
        $isPureSystemAdmin => __('System Admin'),
        $isPureOwner => __('Business Owner'),
        $isPureBranchManager => __('Branch Manager'),
        $isCustomer => __('Customer'),
        default => __('Workspace'),
    };

    $navIcon = function (string $name): \Illuminate\Support\HtmlString {
        $paths = [
            'home' => '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 10v10h14V10"/><path d="M9 20v-6h6v6"/>',
            'metrics' => '<path d="M4 19V5"/><path d="M4 19h16"/><path d="M8 16v-5"/><path d="M12 16V8"/><path d="M16 16v-9"/>',
            'action' => '<path d="m13 2-8 12h6l-1 8 8-12h-6z"/>',
            'activity' => '<path d="M4 12h4l2-6 4 12 2-6h4"/>',
            'check' => '<path d="M20 6 9 17l-5-5"/>',
            'analytics' => '<path d="M4 19V5"/><path d="M8 17V9"/><path d="M12 17V5"/><path d="M16 17v-6"/><path d="M20 19H4"/>',
            'business' => '<path d="M4 20V6a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v14"/><path d="M16 10h2a2 2 0 0 1 2 2v8"/><path d="M8 8h4"/><path d="M8 12h4"/><path d="M8 16h4"/>',
            'admin' => '<path d="M12 3 4 6v5c0 5 3.5 8 8 10 4.5-2 8-5 8-10V6z"/><path d="m9 12 2 2 4-4"/>',
            'branch' => '<path d="M6 4v16"/><path d="M18 4v16"/><path d="M6 8h12"/><path d="M6 16h12"/><path d="M10 8v8"/><path d="M14 8v8"/>',
            'capture' => '<path d="M4 7V5a1 1 0 0 1 1-1h2"/><path d="M17 4h2a1 1 0 0 1 1 1v2"/><path d="M20 17v2a1 1 0 0 1-1 1h-2"/><path d="M7 20H5a1 1 0 0 1-1-1v-2"/><path d="M8 12h8"/><path d="M12 8v8"/>',
            'reward' => '<path d="M20 12v8H4v-8"/><path d="M2 7h20v5H2z"/><path d="M12 7v13"/><path d="M12 7H8.5a2.5 2.5 0 1 1 0-5C11 2 12 7 12 7z"/><path d="M12 7h3.5a2.5 2.5 0 1 0 0-5C13 2 12 7 12 7z"/>',
            'feedback' => '<path d="M21 15a4 4 0 0 1-4 4H8l-5 3V7a4 4 0 0 1 4-4h10a4 4 0 0 1 4 4z"/><path d="M8 9h8"/><path d="M8 13h5"/>',
            'user' => '<path d="M20 21a8 8 0 0 0-16 0"/><circle cx="12" cy="7" r="4"/>',
            'logout' => '<path d="M10 17l5-5-5-5"/><path d="M15 12H3"/><path d="M21 19V5"/>',
            'menu' => '<path d="M4 7h16"/><path d="M4 12h16"/><path d="M4 17h16"/>',
        ];

        return new \Illuminate\Support\HtmlString(
            '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'.$paths[$name].'</svg>'
        );
    };

    $sections = [[
        'label' => __('Current View'),
        'links' => [
            ['label' => __('Overview'), 'href' => '#dashboard-overview', 'icon' => 'home', 'active' => $dashboardActive],
            ['label' => __('Key Numbers'), 'href' => '#dashboard-metrics', 'icon' => 'metrics', 'active' => false],
            ['label' => __('Actions'), 'href' => '#dashboard-actions', 'icon' => 'action', 'active' => false],
        ],
    ]];

    if ($isCustomer) {
        $sections[0]['links'][] = ['label' => __('Customer Check-in'), 'href' => '#customer-check-in', 'icon' => 'check', 'active' => false];
        $sections[] = [
            'label' => __('Customer'),
            'links' => [
                ['label' => __('Customer Portal'), 'href' => route('customer.portal'), 'icon' => 'home', 'active' => request()->routeIs('customer.portal')],
                ['label' => __('Rewards'), 'href' => route('customer.rewards'), 'icon' => 'reward', 'active' => request()->routeIs('customer.rewards')],
                ['label' => __('Feedback'), 'href' => route('customer.feedback'), 'icon' => 'feedback', 'active' => request()->routeIs('customer.feedback')],
            ],
        ];
    } elseif ($isPureSystemManager) {
        $sections[] = [
            'label' => __('Platform'),
            'links' => [
                ['label' => __('Dashboard'), 'href' => $dashboardUrl, 'icon' => 'home', 'active' => request()->routeIs('dashboards.system-manager')],
                ['label' => __('Platform Analytics / AI'), 'href' => route('analytics.index'), 'icon' => 'analytics', 'active' => request()->routeIs('analytics.*')],
            ],
        ];
    } elseif ($isPureSystemAdmin) {
        $sections[] = [
            'label' => __('Admin Support'),
            'links' => [
                ['label' => __('Dashboard'), 'href' => $dashboardUrl, 'icon' => 'home', 'active' => request()->routeIs('dashboards.system-admin')],
                ['label' => __('Admin Analytics'), 'href' => route('analytics.index'), 'icon' => 'analytics', 'active' => request()->routeIs('analytics.*')],
                ['label' => __('Business setup'), 'href' => route('businesses.index'), 'icon' => 'business', 'active' => request()->routeIs('businesses.index')],
                ['label' => __('Create business'), 'href' => route('businesses.create'), 'icon' => 'admin', 'active' => request()->routeIs('businesses.create')],
                ['label' => __('AI Provider Status'), 'href' => route('analytics.index').'#ai-provider-status', 'icon' => 'admin', 'active' => false],
            ],
        ];
    } elseif ($isInternalCombined) {
        $sections[] = [
            'label' => __('Internal Workspace'),
            'links' => [
                ['label' => __('Dashboard'), 'href' => $dashboardUrl, 'icon' => 'home', 'active' => request()->routeIs('dashboards.internal-combined')],
                ['label' => __('Platform Analytics / AI'), 'href' => route('analytics.index'), 'icon' => 'analytics', 'active' => request()->routeIs('analytics.*')],
                ['label' => __('Business setup'), 'href' => route('businesses.index'), 'icon' => 'business', 'active' => request()->routeIs('businesses.index')],
                ['label' => __('Create business'), 'href' => route('businesses.create'), 'icon' => 'admin', 'active' => request()->routeIs('businesses.create')],
                ['label' => __('AI Provider Status'), 'href' => route('analytics.index').'#ai-provider-status', 'icon' => 'admin', 'active' => false],
            ],
        ];
    } elseif ($isBusinessCombined) {
        $businessLinks = [
            ['label' => __('Dashboard'), 'href' => $dashboardUrl, 'icon' => 'home', 'active' => request()->routeIs('dashboards.business-branch-combined')],
            ['label' => __('Business Performance'), 'href' => '#business-performance', 'icon' => 'metrics', 'active' => false],
            ['label' => __('Branch Operations'), 'href' => '#branch-operations', 'icon' => 'branch', 'active' => false],
            ['label' => __('Analytics / AI'), 'href' => route('analytics.index'), 'icon' => 'analytics', 'active' => request()->routeIs('analytics.*')],
            ['label' => __('Businesses'), 'href' => route('businesses.index'), 'icon' => 'business', 'active' => request()->routeIs('businesses.*') && ! request()->routeIs('businesses.branches.check-ins')],
        ];

        if ($assignedBranch) {
            $businessLinks[] = [
                'label' => __('Product/Service'),
                'href' => route('businesses.product-services.index', $assignedBranch->business),
                'icon' => 'business',
                'active' => request()->routeIs('businesses.product-services.*'),
            ];

            $businessLinks[] = [
                'label' => __('Capture Purchase'),
                'href' => route('businesses.branches.check-ins', ['business' => $assignedBranch->business, 'branch' => $assignedBranch]),
                'icon' => 'capture',
                'active' => request()->routeIs('businesses.branches.check-ins'),
            ];
        }

        $sections[] = ['label' => __('Business + Branch'), 'links' => $businessLinks];
    } elseif ($isPureOwner) {
        $sections[] = [
            'label' => __('Business'),
            'links' => [
                ['label' => __('Dashboard'), 'href' => $dashboardUrl, 'icon' => 'home', 'active' => request()->routeIs('dashboards.business-owner')],
                ['label' => __('Business Performance'), 'href' => '#dashboard-overview', 'icon' => 'metrics', 'active' => false],
                ['label' => __('Analytics / AI'), 'href' => route('analytics.index'), 'icon' => 'analytics', 'active' => request()->routeIs('analytics.*')],
                ['label' => __('Businesses'), 'href' => route('businesses.index'), 'icon' => 'business', 'active' => request()->routeIs('businesses.*')],
            ],
        ];
    } elseif ($isPureBranchManager) {
        $branchLinks = [
            ['label' => __('Dashboard'), 'href' => $dashboardUrl, 'icon' => 'home', 'active' => request()->routeIs('dashboards.branch-manager')],
            ['label' => __('Branch Operation'), 'href' => '#dashboard-operation-alerts', 'icon' => 'branch', 'active' => false],
            ['label' => __('Pending Capture'), 'href' => '#dashboard-operation-alerts', 'icon' => 'activity', 'active' => false],
            ['label' => __('Branch Analytics / AI'), 'href' => route('analytics.index'), 'icon' => 'analytics', 'active' => request()->routeIs('analytics.*')],
        ];

        if ($assignedBranch) {
            $branchLinks[] = [
                'label' => __('Product/Service'),
                'href' => route('businesses.product-services.index', $assignedBranch->business),
                'icon' => 'business',
                'active' => request()->routeIs('businesses.product-services.*'),
            ];

            $branchLinks[] = [
                'label' => __('Capture Purchase'),
                'href' => route('businesses.branches.check-ins', ['business' => $assignedBranch->business, 'branch' => $assignedBranch]),
                'icon' => 'capture',
                'active' => request()->routeIs('businesses.branches.check-ins'),
            ];
        }

        $sections[] = ['label' => __('Branch'), 'links' => $branchLinks];
    }
@endphp

<nav x-data="{ open: false }">
    <aside class="gos-sidebar fixed inset-y-0 left-0 z-40 hidden w-72 border-r border-slate-200 bg-white px-4 py-5 shadow-sm lg:flex lg:flex-col">
        <a href="{{ $dashboardUrl }}" class="gos-brand">
            <span class="gos-brand-mark" aria-hidden="true">G</span>
            <span class="min-w-0">
                <span class="block text-sm font-bold text-slate-950">{{ __('GOS-F&B') }}</span>
                <span class="block truncate text-xs font-medium text-slate-500">{{ __('Growth operating system') }}</span>
            </span>
        </a>

        <div class="mt-4 rounded-lg border border-slate-200 bg-slate-50 p-3">
            <p class="text-[11px] font-bold uppercase text-slate-500">{{ __('Persona') }}</p>
            <p class="mt-1 break-words text-sm font-semibold text-slate-950">{{ $personaLabel }}</p>
        </div>

        <div class="mt-6 flex-1 space-y-6 overflow-y-auto pr-1">
            @foreach ($sections as $section)
                <div>
                    <p class="px-3 text-[11px] font-bold uppercase text-slate-400">{{ $section['label'] }}</p>
                    <div class="mt-2 space-y-1">
                        @foreach ($section['links'] as $link)
                            <a href="{{ $link['href'] }}" class="gos-side-link {{ $link['active'] ? 'is-active' : '' }}">
                                <span class="gos-side-icon" aria-hidden="true">{!! $navIcon($link['icon']) !!}</span>
                                <span class="truncate">{{ $link['label'] }}</span>
                            </a>
                        @endforeach
                    </div>
                </div>
            @endforeach
        </div>

        <div class="mt-5 rounded-lg border border-blue-100 bg-blue-50 p-4">
            <p class="text-sm font-bold text-slate-950">{{ __('Local pilot workspace') }}</p>
            <p class="mt-1 text-xs leading-5 text-slate-600">{{ __('Menu visibility follows the approved persona scope.') }}</p>
        </div>

        <div class="mt-4 rounded-lg border border-slate-200 bg-white p-3">
            <div class="flex items-center gap-3">
                <span class="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-slate-900 text-xs font-bold text-white">
                    {{ strtoupper(substr($user?->name ?? 'U', 0, 1)) }}
                </span>
                <div class="min-w-0">
                    <p class="truncate text-sm font-semibold text-slate-900">{{ $user?->name }}</p>
                    <p class="truncate text-xs text-slate-500">{{ $user?->email }}</p>
                </div>
            </div>
            <div class="mt-3 grid grid-cols-2 gap-2">
                <a href="{{ route('profile.edit') }}" class="gos-account-button">
                    {{ __('Profile') }}
                </a>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="gos-account-button is-primary">
                        {{ __('Logout') }}
                    </button>
                </form>
            </div>
        </div>
    </aside>

    <div class="gos-mobile-bar sticky top-0 z-40 border-b border-slate-200 bg-white/95 px-4 py-3 shadow-sm backdrop-blur lg:hidden">
        <div class="flex items-center justify-between gap-3">
            <a href="{{ $dashboardUrl }}" class="gos-brand min-w-0">
                <span class="gos-brand-mark h-9 w-9 text-xs" aria-hidden="true">G</span>
                <span class="min-w-0">
                    <span class="block truncate text-sm font-bold text-slate-950">{{ __('GOS-F&B') }}</span>
                    <span class="block truncate text-xs font-medium text-slate-500">{{ $personaLabel }}</span>
                </span>
            </a>
            <button type="button" @click="open = ! open" class="gos-menu-button" :aria-expanded="open.toString()" aria-controls="gos-mobile-menu">
                <span class="gos-menu-icon">{!! $navIcon('menu') !!}</span>
                <span class="sr-only">{{ __('Open navigation') }}</span>
            </button>
        </div>

        <div id="gos-mobile-menu" x-show="open" x-cloak x-transition class="mt-3 space-y-4 border-t border-slate-100 pt-3">
            @foreach ($sections as $section)
                <div>
                    <p class="px-2 text-[11px] font-bold uppercase text-slate-400">{{ $section['label'] }}</p>
                    <div class="mt-2 grid gap-1">
                        @foreach ($section['links'] as $link)
                            <a href="{{ $link['href'] }}" @click="open = false" class="gos-mobile-link {{ $link['active'] ? 'is-active' : '' }}">
                                <span class="gos-mobile-icon" aria-hidden="true">{!! $navIcon($link['icon']) !!}</span>
                                <span class="min-w-0 break-words">{{ $link['label'] }}</span>
                            </a>
                        @endforeach
                    </div>
                </div>
            @endforeach

            <div class="grid grid-cols-2 gap-2 border-t border-slate-100 pt-3">
                <a href="{{ route('profile.edit') }}" class="gos-mobile-link">
                    <span class="gos-mobile-icon" aria-hidden="true">{!! $navIcon('user') !!}</span>
                    <span class="min-w-0 break-words">{{ __('Profile') }}</span>
                </a>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="gos-mobile-link w-full">
                        <span class="gos-mobile-icon" aria-hidden="true">{!! $navIcon('logout') !!}</span>
                        <span class="min-w-0 break-words">{{ __('Logout') }}</span>
                    </button>
                </form>
            </div>
        </div>
    </div>
</nav>
