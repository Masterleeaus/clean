@php
    $currentUser = auth()->user();
    $isPureBranchManager = $currentUser?->isBranchManager() && ! $currentUser?->isOwner();
    $isCombinedBusinessBranch = $currentUser?->hasBusinessCombinedAccess();
    $primaryBranch = $assignedBranches->first() ?? $branches->first();
    $recentPhysicalCheckIns = $recentCheckIns->where('check_in_type', \App\Models\CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL)->count();
    $recentOnlineCheckIns = $recentCheckIns->where('check_in_type', \App\Models\CustomerCheckIn::CHECK_IN_TYPE_ONLINE)->count();
    $recentNoPurchaseCheckIns = $recentCheckIns->where('reward_status', \App\Models\CustomerCheckIn::REWARD_STATUS_NO_PURCHASE)->count();
    $dashboardMetrics = $isPureBranchManager
        ? [
            ['label' => __('Physical check-ins'), 'value' => $recentPhysicalCheckIns, 'hint' => __('Recent assigned-branch visits')],
            ['label' => __('Online check-ins'), 'value' => $recentOnlineCheckIns, 'hint' => __('Recent assigned-branch references')],
            ['label' => __('Pending Purchase Capture'), 'value' => $pendingPurchaseCaptures ?? 0, 'hint' => __('Physical/Online awaiting branch action')],
            ['label' => __('Captured purchases'), 'value' => $productCaptures, 'hint' => __('Validated staff captures')],
            ['label' => __('No Purchase'), 'value' => $recentNoPurchaseCheckIns, 'hint' => __('Recent no-reward check-ins')],
        ]
        : [
            ['label' => __('Pendaftaran pelanggan hari ini'), 'value' => $todayRegistrations, 'hint' => __('Customer acquisition signal')],
            ['label' => __('Check-in hari ini'), 'value' => $todayCheckIns, 'hint' => __('Physical/Online visits')],
            ['label' => __('Pelanggan repeat'), 'value' => $repeatCustomers, 'hint' => __('Retention signal')],
            ['label' => __('Product/Service captured'), 'value' => $productCaptures, 'hint' => __('Validated purchase signal')],
            ['label' => __('Ganjaran ditebus'), 'value' => $rewardsRedeemed, 'hint' => __('Reward engagement')],
        ];

    $statusTone = function (string $status): string {
        return match ($status) {
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_CONFIRMED => 'success',
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_OVERDUE,
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_MANUAL_REVIEW => 'danger',
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_NO_PURCHASE => 'warning',
            default => 'warning',
        };
    };

    $statusShortLabel = function (string $status): string {
        return match ($status) {
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_CONFIRMED => __('Captured'),
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_NO_PURCHASE => __('No Purchase'),
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_OVERDUE => __('Overdue'),
            \App\Models\CustomerCheckIn::PURCHASE_STATUS_MANUAL_REVIEW => __('Manual Review'),
            default => __('Pending'),
        };
    };
@endphp

<x-app-layout>
    <x-slot name="header">
        <div>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __($dashboardTitle ?? 'Business Owner Dashboard') }}</h2>
            <p class="mt-1 text-sm text-gray-500">{{ __('Ringkasan operasi pilot Growth OS-F&B') }}</p>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            <x-dashboard-card id="dashboard-overview" :title="__('Selamat datang, :name', ['name' => auth()->user()->name])" :eyebrow="$isPureBranchManager ? __('Branch operation dashboard') : __('Business performance dashboard')">
                <div class="grid gap-5 lg:grid-cols-[1.4fr_1fr]">
                    <div class="min-w-0">
                        <p class="text-sm leading-6 text-gray-600">
                            @if ($isPureBranchManager)
                                {{ $primaryBranch ? __('Pantau operasi branch assigned sahaja: check-in, Product/Service capture, ganjaran, feedback, dan action branch yang perlukan perhatian.') : __('Belum ada branch dipautkan kepada akaun ini.') }}
                            @else
                                {{ $primaryBusiness ? __('Pantau performance business milik anda: branch summary, customer activity, Product/Service signal, reward, feedback, analytics, AI Insight, dan AI Action suggestion-only.') : __('Belum ada bisnes dipautkan kepada akaun ini.') }}
                            @endif
                        </p>

                        <div class="mt-4 flex flex-wrap gap-2">
                            @if ($isPureBranchManager)
                                <x-status-badge tone="info">{{ __('Assigned branch') }}</x-status-badge>
                                <x-status-badge tone="warning">{{ __('Pending') }}</x-status-badge>
                                <x-status-badge>{{ __('Physical') }}</x-status-badge>
                                <x-status-badge>{{ __('Online') }}</x-status-badge>
                            @else
                                <x-status-badge tone="info">{{ __('Business overview') }}</x-status-badge>
                                <x-status-badge>{{ __('Branch performance summary') }}</x-status-badge>
                                <x-status-badge>{{ __('AI Action suggestion-only') }}</x-status-badge>
                            @endif
                        </div>
                    </div>

                    <div class="rounded-md border border-slate-200 bg-slate-50 p-4">
                        <p class="text-xs font-semibold uppercase text-slate-500">{{ $isPureBranchManager ? __('Assigned branch identity') : __('Business scope') }}</p>
                        <p class="mt-2 break-words text-sm font-semibold text-slate-900">
                            @if ($isPureBranchManager)
                                {{ $assignedBranches->pluck('name')->join(', ') ?: __('No assigned branch') }}
                            @else
                                {{ $businesses->pluck('name')->join(', ') ?: __('No business') }}
                            @endif
                        </p>
                        <p class="mt-1 text-xs text-slate-500">{{ __('Branch dalam scope') }}: {{ $branches->count() }}</p>
                    </div>
                </div>
            </x-dashboard-card>

            <section id="dashboard-metrics" class="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                @foreach ($dashboardMetrics as $metric)
                    <x-metric-card :label="$metric['label']" :value="$metric['value']" :hint="$metric['hint']" />
                @endforeach
            </section>

            @if (! $isPureBranchManager && ($productServiceReviewAlerts ?? collect())->isNotEmpty())
                <x-section-panel :title="__('Product/Service Review Alerts')" :eyebrow="__('Catalog quality')">
                    <div class="divide-y divide-gray-100">
                        @foreach ($productServiceReviewAlerts as $alert)
                            <div class="grid gap-3 py-4 lg:grid-cols-[minmax(0,1fr)_minmax(220px,280px)]">
                                <div class="min-w-0">
                                    <div class="flex flex-wrap items-center gap-2">
                                        <p class="font-semibold text-gray-900">{{ $alert->productService?->name ?? __('Product/Service') }}</p>
                                        <x-status-badge tone="warning">{{ __(str_replace('_', ' ', $alert->issue_type)) }}</x-status-badge>
                                    </div>
                                    <p class="mt-1 text-sm text-gray-600">{{ $alert->message }}</p>
                                    <p class="mt-1 text-xs text-gray-500">{{ $alert->suggested_review }}</p>
                                </div>
                                <div class="min-w-0 rounded-md bg-gray-50 p-3 text-sm">
                                    <p class="font-semibold text-gray-900">{{ $alert->branch?->name ?? __('All branches') }}</p>
                                    <p class="mt-1 text-gray-500">{{ __('Changed by') }}: {{ $alert->actor?->name ?? __('System') }}</p>
                                    <p class="mt-1 text-xs text-gray-500">{{ $alert->created_at?->diffForHumans() }}</p>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </x-section-panel>
            @endif

            @if ($isPureBranchManager)
                <section id="dashboard-operation-alerts" class="grid gap-4 md:grid-cols-3">
                    <x-metric-card :label="__('Pending Purchase Capture')" :value="$pendingPurchaseCaptures ?? 0" :hint="__('Physical/Online check-ins awaiting capture')" class="bg-yellow-50" />
                    <x-metric-card :label="__('Overdue Purchase Capture')" :value="$overduePurchaseCaptures ?? 0" :hint="__('Past standard capture window')" class="bg-orange-50" />
                    <x-metric-card :label="__('Manual Review Required')" :value="$manualReviewPurchaseCaptures ?? 0" :hint="__('Needs manager attention')" class="bg-red-50" />
                </section>

                <section class="grid gap-6 lg:grid-cols-[1.1fr_0.9fr]">
                    <x-section-panel :title="__('Pending Purchase Capture by mode')" :eyebrow="__('Branch operation')">
                        <p class="mb-4 text-sm leading-6 text-gray-600">{{ __('Sahkan pembelian hanya selepas transaksi sebenar berlaku di luar sistem.') }}</p>
                        <div class="grid gap-3 sm:grid-cols-2">
                            <div class="rounded-md bg-gray-50 p-4">
                                <div class="flex flex-col items-start gap-2 sm:flex-row sm:items-center sm:justify-between sm:gap-3">
                                    <p class="text-sm font-semibold text-gray-900">{{ __('Pending Purchase Capture — Physical') }}</p>
                                    <x-status-badge tone="warning">{{ __('Pending') }}</x-status-badge>
                                </div>
                                <p class="mt-2 text-2xl font-semibold text-gray-900">{{ $recentPhysicalCheckIns }}</p>
                                <p class="mt-1 text-xs text-gray-500">{{ __('Semak pembelian di premis sebelum capture purchase.') }}</p>
                            </div>
                            <div class="rounded-md bg-gray-50 p-4">
                                <div class="flex flex-col items-start gap-2 sm:flex-row sm:items-center sm:justify-between sm:gap-3">
                                    <p class="text-sm font-semibold text-gray-900">{{ __('Pending Purchase Capture — Online') }}</p>
                                    <x-status-badge tone="warning">{{ __('Pending') }}</x-status-badge>
                                </div>
                                <p class="mt-2 text-2xl font-semibold text-gray-900">{{ $recentOnlineCheckIns }}</p>
                                <p class="mt-1 text-xs text-gray-500">{{ __('Semak order/payment melalui channel luar sebelum capture purchase.') }}</p>
                            </div>
                        </div>
                    </x-section-panel>

                    <x-section-panel :title="__('Capture Purchase / Mark No Purchase action area')" :eyebrow="__('Assigned branch only')">
                        @if ($primaryBranch)
                            <div class="grid gap-3">
                                <x-action-button :href="route('businesses.product-services.index', $primaryBranch->business)">
                                    {{ __('Product/Service Management') }}
                                </x-action-button>
                                <x-action-button :href="route('businesses.branches.check-ins', ['business' => $primaryBranch->business, 'branch' => $primaryBranch])">
                                    {{ __('Branch Check-ins') }}
                                </x-action-button>
                                <x-action-button :href="route('businesses.branches.show', ['business' => $primaryBranch->business, 'branch' => $primaryBranch])" variant="secondary">
                                    {{ __('Assigned Branch Overview') }}
                                </x-action-button>
                            </div>
                        @else
                            <x-empty-state :title="__('No assigned branch')" :body="__('Operation actions appear after branch assignment is available.')" />
                        @endif
                    </x-section-panel>
                </section>

                <x-ai-insight-card id="dashboard-ai" :title="__('Branch Analytics / AI Insight / AI Action')" :confidence="__('Suggestion Only')">
                    <div class="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                        <p class="text-sm leading-6 text-gray-700">
                            {{ __('Branch-level analytics, AI Insight, dan AI Action suggestion-only untuk assigned branch sahaja. Human review diperlukan; tiada auto-execute campaign, message, reward, stamp, atau data change.') }}
                        </p>
                        <x-action-button :href="route('analytics.index')">{{ __('Open Branch Analytics / AI') }}</x-action-button>
                    </div>
                </x-ai-insight-card>
            @endif

            @if ($isCombinedBusinessBranch)
                <x-section-panel id="dashboard-combined-scope" :title="__('Business Owner cum Branch Manager')" :eyebrow="__('Dual-role dashboard')">
                    <p class="text-sm leading-6 text-gray-600">{{ __('Role gabungan ini disengajakan. Gunakan tab Business Performance untuk owner-level dan Branch Operations untuk kerja harian branch assigned.') }}</p>

                    <div class="mt-5 flex flex-wrap gap-2 border-b border-gray-200 pb-3">
                        <a href="#business-performance" class="w-full rounded-t-md border border-b-0 border-gray-300 bg-white px-4 py-2 text-center text-sm font-semibold text-gray-900 sm:w-auto">{{ __('Business Performance') }}</a>
                        <a href="#branch-operations" class="w-full rounded-t-md border border-b-0 border-gray-300 bg-gray-50 px-4 py-2 text-center text-sm font-semibold text-gray-700 sm:w-auto">{{ __('Branch Operations') }}</a>
                    </div>

                    <div class="mt-5 grid gap-5 lg:grid-cols-2">
                        <div id="business-performance" role="tabpanel" aria-label="{{ __('Business Performance') }}" class="min-w-0 rounded-md bg-gray-50 p-4">
                            <div class="flex flex-wrap items-start justify-between gap-3">
                                <div class="min-w-0">
                                    <h4 class="text-sm font-semibold text-gray-900">{{ __('Business Performance') }}</h4>
                                    <p class="mt-2 text-sm text-gray-600">{{ __('Owner-level: business overview, branch comparison, Product/Service performance, reward summary, feedback summary, analytics, AI Insight, dan AI Action suggestion-only untuk business growth. Branch operation actions berada dalam tab Branch Operations.') }}</p>
                                </div>
                                <x-status-badge tone="info">{{ __('Business analytics') }}</x-status-badge>
                            </div>
                            <dl class="mt-4 grid gap-3 sm:grid-cols-2">
                                <div>
                                    <dt class="text-xs font-medium text-gray-500">{{ __('Business scope') }}</dt>
                                    <dd class="mt-1 font-semibold text-gray-900">{{ $businesses->pluck('name')->join(', ') ?: __('No business') }}</dd>
                                </div>
                                <div>
                                    <dt class="text-xs font-medium text-gray-500">{{ __('Branches compared') }}</dt>
                                    <dd class="mt-1 font-semibold text-gray-900">{{ $branches->count() }}</dd>
                                </div>
                                <div>
                                    <dt class="text-xs font-medium text-gray-500">{{ __('Product/Service captured') }}</dt>
                                    <dd class="mt-1 font-semibold text-gray-900">{{ $productCaptures }}</dd>
                                </div>
                                <div>
                                    <dt class="text-xs font-medium text-gray-500">{{ __('Feedback summary') }}</dt>
                                    <dd class="mt-1 font-semibold text-gray-900">{{ $feedbackSubmitted }}</dd>
                                </div>
                            </dl>
                            <div class="mt-4 rounded-md bg-white p-3">
                                <p class="text-xs font-semibold uppercase text-gray-500">{{ __('Branch comparison') }}</p>
                                <p class="mt-1 break-words text-sm font-semibold text-gray-900">{{ $branches->pluck('name')->join(', ') ?: __('No branches available for your scope.') }}</p>
                            </div>
                            <a href="{{ route('analytics.index') }}" class="mt-4 inline-flex text-sm font-semibold text-indigo-700 hover:text-indigo-600">{{ __('Open Analytics / AI') }}</a>
                        </div>

                        <div id="branch-operations" role="tabpanel" aria-label="{{ __('Branch Operations') }}" class="min-w-0 rounded-md bg-gray-50 p-4">
                            <div class="flex flex-wrap items-start justify-between gap-3">
                                <div class="min-w-0">
                                    <h4 class="text-sm font-semibold text-gray-900">{{ __('Branch Operations') }}</h4>
                                    <p class="mt-2 text-sm text-gray-600">{{ __('Branch-level: assigned/current branch, pending purchase capture, overdue purchase capture, manual review, Capture Purchase, Mark No Purchase, today check-ins, branch rewards, branch feedback, branch-level analytics, AI Insight, dan AI Action suggestion-only.') }}</p>
                                    <p class="mt-2 text-xs font-semibold text-gray-700">{{ __('Sahkan pembelian hanya selepas transaksi sebenar berlaku di luar sistem.') }}</p>
                                </div>
                                <x-status-badge tone="warning">{{ __('Pending') }}</x-status-badge>
                            </div>
                            <dl class="mt-4 grid gap-3 sm:grid-cols-2">
                                <div>
                                    <dt class="text-xs font-medium text-gray-500">{{ __('Assigned/current branch') }}</dt>
                                    <dd class="mt-1 font-semibold text-gray-900">{{ $assignedBranches->pluck('name')->join(', ') ?: __('No assigned branch') }}</dd>
                                </div>
                                <div>
                                    <dt class="text-xs font-medium text-gray-500">{{ __('Pending Purchase Capture') }}</dt>
                                    <dd class="mt-1 font-semibold text-gray-900">{{ $pendingPurchaseCaptures ?? 0 }}</dd>
                                </div>
                                <div>
                                    <dt class="text-xs font-medium text-gray-500">{{ __('Overdue Purchase Capture') }}</dt>
                                    <dd class="mt-1 font-semibold text-gray-900">{{ $overduePurchaseCaptures ?? 0 }}</dd>
                                </div>
                                <div>
                                    <dt class="text-xs font-medium text-gray-500">{{ __('Manual Review Required') }}</dt>
                                    <dd class="mt-1 font-semibold text-gray-900">{{ $manualReviewPurchaseCaptures ?? 0 }}</dd>
                                </div>
                            </dl>
                            <div class="mt-4 grid gap-3 sm:grid-cols-2">
                                <div class="rounded-md bg-white p-3">
                                    <div class="flex flex-col items-start gap-2 sm:flex-row sm:items-center sm:justify-between sm:gap-3">
                                        <p class="text-sm font-semibold text-gray-900">{{ __('Pending Purchase Capture — Physical') }}</p>
                                        <x-status-badge>{{ __('Physical') }}</x-status-badge>
                                    </div>
                                    <p class="mt-1 text-2xl font-semibold text-gray-900">{{ $recentPhysicalCheckIns }}</p>
                                    <p class="mt-1 text-xs text-gray-500">{{ __('Semak pembelian di premis sebelum capture purchase.') }}</p>
                                </div>
                                <div class="rounded-md bg-white p-3">
                                    <div class="flex flex-col items-start gap-2 sm:flex-row sm:items-center sm:justify-between sm:gap-3">
                                        <p class="text-sm font-semibold text-gray-900">{{ __('Pending Purchase Capture — Online') }}</p>
                                        <x-status-badge>{{ __('Online') }}</x-status-badge>
                                    </div>
                                    <p class="mt-1 text-2xl font-semibold text-gray-900">{{ $recentOnlineCheckIns }}</p>
                                    <p class="mt-1 text-xs text-gray-500">{{ __('Semak order/payment melalui channel luar sebelum capture purchase.') }}</p>
                                </div>
                            </div>
                            @if ($primaryBranch)
                                <div class="mt-4 flex flex-wrap gap-2">
                                    <a href="{{ route('businesses.product-services.index', $primaryBranch->business) }}" class="inline-flex w-full items-center justify-center rounded-md border border-gray-300 px-3 py-2 text-center text-sm font-semibold text-gray-700 hover:bg-gray-50 sm:w-auto">{{ __('Product/Service Management') }}</a>
                                    <a href="{{ route('businesses.branches.check-ins', ['business' => $primaryBranch->business, 'branch' => $primaryBranch]) }}" class="inline-flex w-full items-center justify-center rounded-md bg-gray-900 px-3 py-2 text-center text-sm font-semibold text-white hover:bg-gray-700 sm:w-auto">{{ __('Capture Purchase / Mark No Purchase') }}</a>
                                    <a href="{{ route('analytics.index') }}" class="inline-flex w-full items-center justify-center rounded-md border border-gray-300 px-3 py-2 text-center text-sm font-semibold text-gray-700 hover:bg-gray-50 sm:w-auto">{{ __('Branch Analytics / AI') }}</a>
                                    <a href="{{ route('businesses.branches.rewards.index', ['business' => $primaryBranch->business, 'branch' => $primaryBranch]) }}" class="inline-flex w-full items-center justify-center rounded-md border border-gray-300 px-3 py-2 text-center text-sm font-semibold text-gray-700 hover:bg-gray-50 sm:w-auto">{{ __('Branch Rewards') }}</a>
                                    <a href="{{ route('businesses.branches.feedback', ['business' => $primaryBranch->business, 'branch' => $primaryBranch]) }}" class="inline-flex w-full items-center justify-center rounded-md border border-gray-300 px-3 py-2 text-center text-sm font-semibold text-gray-700 hover:bg-gray-50 sm:w-auto">{{ __('Branch Feedback') }}</a>
                                </div>
                            @endif
                        </div>
                    </div>
                </x-section-panel>
            @endif

            <section id="dashboard-activity" class="grid gap-6 lg:grid-cols-2">
                <x-section-panel :title="__('Branches Summary')" :eyebrow="__('Branch performance summary')">
                    <div class="divide-y divide-gray-100">
                        @forelse ($branches as $branch)
                            <div class="flex items-start justify-between gap-4 py-3">
                                <div class="min-w-0">
                                    <p class="font-semibold text-gray-900">{{ $branch->name }}</p>
                                    <p class="mt-1 text-sm text-gray-500">{{ $branch->business?->name }}</p>
                                </div>
                                <x-status-badge>{{ __('Active') }}</x-status-badge>
                            </div>
                        @empty
                            <x-empty-state :title="__('No branches available for your scope.')" />
                        @endforelse
                    </div>
                </x-section-panel>

                <x-section-panel :title="__('Recent Check-ins')" :eyebrow="$isPureBranchManager ? __('Today activity') : __('Customer activity')">
                    <div class="divide-y divide-gray-100">
                        @forelse ($recentCheckIns as $checkIn)
                            @php
                                $purchaseStatus = $checkIn->purchaseCaptureStatus();
                            @endphp
                            <div class="py-3">
                                <div class="flex flex-wrap items-start justify-between gap-3">
                                    <div class="min-w-0">
                                        <p class="font-semibold text-gray-900">{{ $checkIn->customer?->name ?? __('Customer') }}</p>
                                        <p class="mt-1 text-sm text-gray-500">{{ $checkIn->branch?->name ?? $checkIn->business?->name }} - {{ $checkIn->check_in_at?->format('M j, Y g:i A') }}</p>
                                    </div>
                                    <div class="flex flex-wrap gap-2">
                                        <x-status-badge>{{ __($checkIn->checkInTypeLabel()) }}</x-status-badge>
                                        <x-status-badge :tone="$statusTone($purchaseStatus)">{{ $statusShortLabel($purchaseStatus) }}</x-status-badge>
                                    </div>
                                </div>
                                <p class="mt-2 text-xs font-semibold text-gray-700">{{ __($checkIn->purchaseCaptureStatusLabel()) }}</p>
                            </div>
                        @empty
                            <x-empty-state :title="__('No check-ins yet.')" :body="__('Activity will appear after customers check in.')" />
                        @endforelse
                    </div>
                </x-section-panel>

                <x-section-panel :title="__('Recent Feedback')" :eyebrow="__('Feedback summary')">
                    <div class="divide-y divide-gray-100">
                        @forelse ($recentFeedback as $entry)
                            <div class="py-3">
                                <p class="font-semibold text-gray-900">{{ $entry->branch?->name ?? $entry->business?->name }}</p>
                                <p class="mt-1 text-sm text-gray-700">{{ $entry->comment ?: __('No comment') }}</p>
                            </div>
                        @empty
                            <x-empty-state :title="__('No feedback yet.')" :body="__('Feedback summary will appear after customers submit feedback.')" />
                        @endforelse
                    </div>
                </x-section-panel>

                <x-section-panel :title="__('Reward/Loyalty Summary')" :eyebrow="__('Reward/stamp summary')">
                    <div class="grid gap-4 sm:grid-cols-2">
                        <x-metric-card :label="__('Loyalty accounts')" :value="$loyaltyAccounts" :hint="__('Active customer stamp accounts')" />
                        <x-metric-card :label="__('Rewards redeemed')" :value="$rewardsRedeemed" :hint="__('Reward Confirmed redemptions')" />
                    </div>
                </x-section-panel>
            </section>

            <section id="dashboard-reports" class="grid gap-6 lg:grid-cols-[2fr_1fr]">
                <x-section-panel id="dashboard-actions" :title="__('Ringkasan laporan mingguan')" :eyebrow="$isPureBranchManager ? __('Branch-level note') : __('Business-level analytics')">
                    @if ($weeklyReport)
                        <div class="grid gap-4 sm:grid-cols-3">
                            <x-metric-card :label="__('Check-in minggu ini')" :value="$weeklyReport['metrics']['check_ins']" />
                            <x-metric-card :label="__('Feedback minggu ini')" :value="$weeklyReport['metrics']['feedback_submitted']" />
                            <x-metric-card :label="__('Ganjaran minggu ini')" :value="$weeklyReport['metrics']['rewards_redeemed']" />
                        </div>

                        <x-ai-insight-card class="mt-5" :title="__('Business growth AI Insight')" :confidence="__('Suggestion Only')">
                            <p class="text-sm text-gray-700">{{ $weeklyReport['suggestions'][0] }}</p>
                        </x-ai-insight-card>
                    @else
                        <x-empty-state
                            :title="$isPureBranchManager ? __('Branch Analytics recommended') : __('No weekly report yet.')"
                            :body="$isPureBranchManager ? __('Laporan mingguan owner-level tidak dipaparkan untuk pure Branch Manager. Gunakan Branch Analytics untuk assigned branch operation.') : __('Laporan mingguan akan dipaparkan selepas bisnes tersedia.')"
                        />
                    @endif
                </x-section-panel>

                <x-section-panel :title="__('Tindakan Pantas')" :eyebrow="$isPureBranchManager ? __('Branch actions') : __('Business actions')">
                    @if ($isPureBranchManager && $primaryBranch)
                        <div class="grid gap-3">
                            <x-action-button :href="route('analytics.index')">{{ __('Branch Analytics') }}</x-action-button>
                            <x-action-button :href="route('businesses.branches.show', ['business' => $primaryBranch->business, 'branch' => $primaryBranch])">{{ __('Assigned Branch Overview') }}</x-action-button>
                            <x-action-button :href="route('businesses.branches.check-ins', ['business' => $primaryBranch->business, 'branch' => $primaryBranch])" variant="secondary">{{ __('Branch Check-ins') }}</x-action-button>
                            <x-action-button :href="route('businesses.branches.feedback', ['business' => $primaryBranch->business, 'branch' => $primaryBranch])" variant="secondary">{{ __('Branch Feedback') }}</x-action-button>
                            <x-action-button :href="route('businesses.branches.rewards.index', ['business' => $primaryBranch->business, 'branch' => $primaryBranch])" variant="secondary">{{ __('Branch Rewards') }}</x-action-button>
                        </div>
                    @elseif ($primaryBusiness)
                        <div class="grid gap-3">
                            <x-action-button :href="route('analytics.index')">{{ __('Analytics') }}</x-action-button>
                            <x-action-button :href="route('businesses.show', $primaryBusiness)">{{ __('Business Profile / QR') }}</x-action-button>
                            <x-action-button :href="route('businesses.customers.index', $primaryBusiness)" variant="secondary">{{ __('Senarai Customer') }}</x-action-button>
                            <x-action-button :href="route('businesses.reports.weekly', $primaryBusiness)" variant="secondary">{{ __('Laporan Mingguan') }}</x-action-button>
                            <x-action-button :href="route('businesses.follow-ups', $primaryBusiness)" variant="secondary">{{ __('Follow-up') }}</x-action-button>
                        </div>
                    @else
                        <x-empty-state :title="__('No quick actions yet.')" :body="__('Tindakan pantas akan tersedia selepas akaun mempunyai bisnes.')" />
                    @endif
                </x-section-panel>
            </section>
        </div>
    </div>
</x-app-layout>
