<x-app-layout>
    <x-slot name="header">
        <div>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __($title) }}</h2>
            <p class="mt-1 text-sm text-gray-500">{{ $branch ? $business->name.' - '.$branch->name : $business->name }}</p>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
            @if (session('status'))
                <div class="mb-6 rounded-md bg-green-50 p-4 text-sm font-medium text-green-800">{{ session('status') }}</div>
            @endif

            <section class="overflow-hidden rounded-lg bg-white shadow-sm">
                <div class="divide-y divide-gray-100">
                    @forelse ($accounts as $account)
                        <div class="grid gap-4 p-5 lg:grid-cols-[1fr_auto] lg:items-center">
                            <div>
                                <p class="font-medium text-gray-900">{{ $account->customer->name }}</p>
                                <p class="mt-1 text-sm text-gray-500">
                                    {{ $account->current_stamps }} / {{ $account->loyaltyProgram->stamps_required }}
                                    - {{ $account->loyaltyProgram->reward_name }}
                                </p>
                                <p class="mt-1 text-sm text-gray-500">{{ __('Redeemed: :count', ['count' => $account->total_rewards_redeemed]) }}</p>
                            </div>
                            <div class="flex flex-col gap-2 sm:items-end">
                                <span class="text-sm font-semibold {{ $account->isRewardEligible() ? 'text-green-700' : 'text-gray-500' }}">
                                    {{ $account->isRewardEligible() ? __('Reward earned') : __('In progress') }}
                                </span>
                                @if ($branch && $account->isRewardEligible())
                                    <form method="POST" action="{{ route('businesses.branches.rewards.redeem', ['business' => $business, 'branch' => $branch, 'customer' => $account->customer]) }}">
                                        @csrf
                                        <button type="submit" class="rounded-md bg-green-600 px-3 py-2 text-sm font-semibold text-white hover:bg-green-500">{{ __('Redeem') }}</button>
                                    </form>
                                @endif
                            </div>
                        </div>
                    @empty
                        <p class="p-5 text-sm text-gray-500">{{ __('No reward/loyalty records yet.') }}</p>
                    @endforelse
                </div>
            </section>
        </div>
    </div>
</x-app-layout>
