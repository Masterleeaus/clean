<x-guest-layout>
    <div class="text-center">
        <p class="text-sm font-medium uppercase tracking-wide text-indigo-600">{{ $business->name }}</p>
        <h1 class="mt-2 text-2xl font-bold text-gray-900">{{ __('Thank you!') }}</h1>
        <p class="mt-4 text-sm leading-6 text-gray-600">{{ __('Your feedback has been submitted. We appreciate you taking the time to share it.') }}</p>
    </div>

    <a href="{{ route('public.business.show', ['business' => $business->slug]) }}" class="mt-6 inline-flex w-full justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500">
        {{ __('Back to Loyalty Page') }}
    </a>
</x-guest-layout>
