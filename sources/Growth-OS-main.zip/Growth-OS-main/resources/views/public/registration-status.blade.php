@php
    $isOnlineCheckIn = ($check_in_type ?? \App\Models\CustomerCheckIn::CHECK_IN_TYPE_PHYSICAL) === \App\Models\CustomerCheckIn::CHECK_IN_TYPE_ONLINE;
@endphp

<x-guest-layout>
    <div class="text-center">
        <p class="text-sm font-medium uppercase tracking-wide text-indigo-600">{{ $business->name }}</p>
        <h1 class="mt-2 text-2xl font-bold text-gray-900">
            {{ __('Hai, :name!', ['name' => $customer->name]) }}
        </h1>
    </div>

    <div class="mt-6 rounded-lg bg-gray-50 p-5">
        <p class="text-sm font-medium text-gray-500">{{ __('Progress stamp') }}</p>
        <div class="mt-3 grid grid-cols-2 gap-3 text-center">
            <div class="rounded-md bg-white p-4">
                <p class="text-sm text-gray-500">{{ __('Stamp semasa') }}</p>
                <p class="mt-1 text-3xl font-bold text-gray-900">{{ $account->current_stamps }}</p>
            </div>
            <div class="rounded-md bg-white p-4">
                <p class="text-sm text-gray-500">{{ __('Stamp diperlukan') }}</p>
                <p class="mt-1 text-3xl font-bold text-gray-900">{{ $program->stamps_required }}</p>
            </div>
        </div>
        <p class="mt-4 text-sm text-gray-600">
            {{ __('Ganjaran: :reward', ['reward' => $program->reward_name]) }}
        </p>
    </div>

    @if ($welcome_stamp_granted)
        <div class="mt-5 rounded-lg bg-green-50 p-4 text-sm text-green-900">
            {{ __('Anda sudah daftar. Stamp pertama telah ditambah hari ini.') }}
        </div>
    @elseif ($check_in_stamp_granted ?? false)
        <div class="mt-5 rounded-lg bg-green-50 p-4 text-sm text-green-900">
            {{ __('Check-in pembelian direkodkan. 1 stamp telah ditambah.') }}
        </div>
    @elseif (($status ?? null) === 'check_in_too_soon')
        <div class="mt-5 rounded-lg bg-blue-50 p-4 text-sm text-blue-900">
            {{ __('Check-in terlalu awal. Sila tunggu sekurang-kurangnya :minutes minit antara pembelian yang layak untuk stamp baharu.', ['minutes' => $check_in_cooldown_minutes ?? 60]) }}
            <span class="mt-2 block">{{ __('Cooldown-blocked check-in tidak create reward/stamp. No Purchase tidak beri reward/stamp.') }}</span>
        </div>
    @elseif (($status ?? null) === 'checked_in')
        <div class="mt-5 rounded-lg bg-yellow-50 p-4 text-sm text-yellow-900">
            @if ($isOnlineCheckIn)
                {{ __('Check-in direkodkan. Check-in order online berjaya direkodkan. Reward akan disahkan selepas pembelian disahkan oleh branch.') }}
            @else
                {{ __('Check-in direkodkan. Check-in premis berjaya direkodkan. Reward akan disahkan selepas pembelian disahkan oleh branch.') }}
            @endif
        </div>
    @elseif ($existing_customer)
        <div class="mt-5 rounded-lg bg-blue-50 p-4 text-sm text-blue-900">
            {{ __('Anda sudah daftar di sini. Tiada stamp welcome tambahan untuk hari ini.') }}
        </div>
    @else
        <div class="mt-5 rounded-lg bg-gray-50 p-4 text-sm text-gray-700">
            {{ __('Anda sudah daftar. Mula kumpul stamp setiap kali datang.') }}
        </div>
    @endif

    @if ($account->current_stamps >= $program->stamps_required)
        <div class="mt-5 rounded-lg bg-amber-50 p-4 text-sm font-medium text-amber-900">
            {{ __('Anda layak tebus: :reward', ['reward' => $program->reward_name]) }}
            <span class="mt-2 block font-normal">{{ __('Langkah seterusnya: minta Branch Manager verify redemption sebelum ganjaran diberi. Dalam MVP single-branch, Business Owner / Branch Manager boleh verify.') }}</span>
        </div>
    @else
        <div class="mt-5 rounded-lg bg-indigo-50 p-4 text-sm text-indigo-950">
            {{ __('Langkah seterusnya: terus scan QR selepas pembelian seterusnya untuk tambah stamp jika jarak masa minimum dipenuhi.') }}
        </div>
    @endif

    <a href="{{ route('public.business.feedback', ['business' => $business->slug]) }}" class="mt-6 inline-flex w-full justify-center rounded-md bg-indigo-600 px-4 py-2 text-sm font-semibold text-white hover:bg-indigo-500">
        {{ __('Beri Maklumbalas') }}
    </a>

    <a href="{{ route('public.business.show', ['business' => $business->slug]) }}" class="mt-3 inline-flex w-full justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
        {{ __('Kembali') }}
    </a>
</x-guest-layout>
