<x-guest-layout>
    <div class="text-center">
        <p class="text-sm font-medium uppercase tracking-wide text-indigo-600">{{ $business->name }}</p>
        <h1 class="mt-2 text-2xl font-bold text-gray-900">{{ __('Share Feedback') }}</h1>
        <p class="mt-3 text-sm leading-6 text-gray-600">{{ __('Tell us how your visit was. This takes less than a minute.') }}</p>
    </div>

    <form method="POST" action="{{ route('public.business.feedback.store', ['business' => $business->slug]) }}" class="mt-6 space-y-5">
        @csrf

        <div>
            <x-input-label for="whatsapp_number" :value="__('WhatsApp Number (optional)')" />
            <x-text-input id="whatsapp_number" name="whatsapp_number" type="tel" class="mt-1 block w-full" :value="old('whatsapp_number')" autocomplete="tel" placeholder="60123456789" />
            <p class="mt-1 text-xs text-gray-500">{{ __('Add this if you want us to match feedback to your loyalty account.') }}</p>
            <x-input-error class="mt-2" :messages="$errors->get('whatsapp_number')" />
        </div>

        <div>
            <x-input-label for="food_rating" :value="__('Food Rating')" />
            <select id="food_rating" name="food_rating" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                <option value="">{{ __('Choose rating') }}</option>
                @foreach ([1, 2, 3, 4, 5] as $rating)
                    <option value="{{ $rating }}" @selected((string) old('food_rating') === (string) $rating)>{{ $rating }}</option>
                @endforeach
            </select>
            <x-input-error class="mt-2" :messages="$errors->get('food_rating')" />
        </div>

        <div>
            <x-input-label for="service_rating" :value="__('Service Rating')" />
            <select id="service_rating" name="service_rating" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                <option value="">{{ __('Choose rating') }}</option>
                @foreach ([1, 2, 3, 4, 5] as $rating)
                    <option value="{{ $rating }}" @selected((string) old('service_rating') === (string) $rating)>{{ $rating }}</option>
                @endforeach
            </select>
            <x-input-error class="mt-2" :messages="$errors->get('service_rating')" />
        </div>

        <div>
            <x-input-label for="price_feedback" :value="__('Price Feedback')" />
            <select id="price_feedback" name="price_feedback" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                <option value="">{{ __('Choose one') }}</option>
                <option value="cheap" @selected(old('price_feedback') === 'cheap')>{{ __('Cheap') }}</option>
                <option value="ok" @selected(old('price_feedback') === 'ok')>{{ __('OK') }}</option>
                <option value="expensive" @selected(old('price_feedback') === 'expensive')>{{ __('Expensive') }}</option>
            </select>
            <x-input-error class="mt-2" :messages="$errors->get('price_feedback')" />
        </div>

        <div>
            <x-input-label for="comment" :value="__('Comment (optional)')" />
            <textarea id="comment" name="comment" rows="4" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">{{ old('comment') }}</textarea>
            <x-input-error class="mt-2" :messages="$errors->get('comment')" />
        </div>

        <x-primary-button class="w-full justify-center">
            {{ __('Submit Feedback') }}
        </x-primary-button>
    </form>

    <a href="{{ route('public.business.show', ['business' => $business->slug]) }}" class="mt-4 inline-flex w-full justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
        {{ __('Back') }}
    </a>
</x-guest-layout>
