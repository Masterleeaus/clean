<x-guest-layout>
    <div class="text-center">
        <p class="text-sm font-medium uppercase tracking-wide text-indigo-600">{{ __('Welcome to') }}</p>
        <h1 class="mt-2 text-2xl font-bold text-gray-900">{{ $business->name }}</h1>
    </div>

    @if ($loyaltyProgram)
        <div class="mt-6 rounded-lg bg-indigo-50 p-4">
            <p class="text-sm font-medium text-indigo-900">{{ __('Reward offer') }}</p>
            <p class="mt-1 text-lg font-semibold text-indigo-950">{{ $loyaltyProgram->reward_name }}</p>
            <p class="mt-1 text-sm text-indigo-800">
                {{ __('Collect :stamps stamps to redeem.', ['stamps' => $loyaltyProgram->stamps_required]) }}
            </p>
        </div>

        <p class="mt-5 text-sm leading-6 text-gray-600">
            {{ __('Register or check in to collect stamps. If you already registered here, we will show your current stamp status.') }}
        </p>

        <form method="POST" action="{{ route('public.business.check-in', ['business' => $business->slug]) }}" class="mt-6 space-y-4 rounded-lg border border-gray-200 p-4">
            @csrf

            <div>
                <h2 class="text-base font-semibold text-gray-900">{{ __('Returning customer') }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ __('Enter your WhatsApp number to check in today.') }}</p>
            </div>

            <div>
                <x-input-label for="check_in_whatsapp_number" :value="__('WhatsApp Number')" />
                <x-text-input id="check_in_whatsapp_number" name="whatsapp_number" type="tel" class="mt-1 block w-full" :value="old('whatsapp_number')" required autocomplete="tel" placeholder="60123456789" />
                <x-input-error class="mt-2" :messages="$errors->get('check_in')" />
                <x-input-error class="mt-2" :messages="$errors->get('whatsapp_number')" />
            </div>

            <x-primary-button class="w-full justify-center">
                {{ __('Check-in Today') }}
            </x-primary-button>
        </form>

        <form method="POST" action="{{ route('public.business.register', ['business' => $business->slug]) }}" class="mt-6 space-y-4 rounded-lg border border-gray-200 p-4">
            @csrf

            <div>
                <h2 class="text-base font-semibold text-gray-900">{{ __('New customer') }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ __('Register once to start collecting stamps here.') }}</p>
            </div>

            <div>
                <x-input-label for="name" :value="__('Name')" />
                <x-text-input id="name" name="name" type="text" class="mt-1 block w-full" :value="old('name')" required autofocus autocomplete="name" />
                <x-input-error class="mt-2" :messages="$errors->get('name')" />
            </div>

            <div>
                <x-input-label for="whatsapp_number" :value="__('WhatsApp Number')" />
                <x-text-input id="whatsapp_number" name="whatsapp_number" type="tel" class="mt-1 block w-full" :value="old('whatsapp_number')" required autocomplete="tel" placeholder="60123456789" />
                <x-input-error class="mt-2" :messages="$errors->get('whatsapp_number')" />
            </div>

            <div>
                <x-input-label for="birthday" :value="__('Birthday (optional)')" />
                <x-text-input id="birthday" name="birthday" type="date" class="mt-1 block w-full" :value="old('birthday')" />
                <x-input-error class="mt-2" :messages="$errors->get('birthday')" />
            </div>

            <label class="flex items-start gap-3">
                <input type="checkbox" name="consent_promo" value="1" class="mt-1 rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" @checked(old('consent_promo'))>
                <span class="text-sm text-gray-600">{{ __('I agree to receive simple reward updates from this business.') }}</span>
            </label>

            <x-input-error class="mt-2" :messages="$errors->get('loyalty_program')" />

            <x-primary-button class="w-full justify-center">
                {{ __('Register') }}
            </x-primary-button>
        </form>

        <a href="{{ route('public.business.feedback', ['business' => $business->slug]) }}" class="mt-6 inline-flex w-full justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
            {{ __('Share Feedback') }}
        </a>
    @else
        <div class="mt-6 rounded-lg bg-amber-50 p-4 text-sm text-amber-900">
            {{ __('This loyalty program is not available yet. Please ask the business owner to activate it.') }}
        </div>

        <a href="{{ route('public.business.feedback', ['business' => $business->slug]) }}" class="mt-6 inline-flex w-full justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">
            {{ __('Share Feedback') }}
        </a>
    @endif
</x-guest-layout>
