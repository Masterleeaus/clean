<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <title>{{ config('app.name', 'Laravel') }}</title>

        <link rel="preconnect" href="https://fonts.bunny.net">
        <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />

        @include('layouts.partials.vite-assets')
    </head>
    <body class="gos-auth font-sans text-gray-900 antialiased">
        <div class="flex min-h-screen flex-col items-center px-4 py-8 sm:justify-center">
            <div class="mb-6 flex items-center gap-3">
                <a href="/" class="flex h-11 w-11 items-center justify-center rounded-xl bg-orange-500 text-sm font-bold text-white shadow-sm">
                    G
                </a>
                <div>
                    <p class="text-sm font-bold text-slate-950">{{ __('GOS-F&B') }}</p>
                    <p class="text-xs font-medium text-slate-500">{{ __('Simple. Smart. Secure.') }}</p>
                </div>
            </div>

            <div class="gos-auth-card w-full overflow-hidden bg-white px-6 py-6 sm:max-w-md">
                <div class="mb-6 rounded-xl border border-slate-200 bg-slate-50 p-4">
                    <p class="text-xs font-bold uppercase tracking-wide text-orange-600">{{ __('Local Pilot') }}</p>
                    <h1 class="mt-2 text-xl font-bold text-slate-950">{{ __('Log in to GOS-F&B') }}</h1>
                    <p class="mt-1 text-sm text-slate-600">{{ __('Use your persona test account to open the approved dashboard.') }}</p>
                </div>

                <x-auth-session-status class="mb-4" :status="session('status')" />

                <form method="POST" action="{{ route('login') }}">
                    @csrf

                    <div>
                        <x-input-label for="email" :value="__('Email')" />
                        <x-text-input id="email" class="mt-1 block w-full" type="email" name="email" :value="old('email')" required autofocus autocomplete="username" placeholder="name@example.com" />
                        <x-input-error :messages="$errors->get('email')" class="mt-2" />
                    </div>

                    <div class="mt-4">
                        <x-input-label for="password" :value="__('Password')" />

                        <x-text-input id="password" class="mt-1 block w-full"
                                        type="password"
                                        name="password"
                                        required autocomplete="current-password"
                                        placeholder="{{ __('Password') }}" />

                        <x-input-error :messages="$errors->get('password')" class="mt-2" />
                    </div>

                    <div class="mt-4 block">
                        <label for="remember_me" class="inline-flex items-center">
                            <input id="remember_me" type="checkbox" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" name="remember">
                            <span class="ms-2 text-sm text-gray-600">{{ __('Remember me') }}</span>
                        </label>
                    </div>

                    <div class="mt-5 flex items-center justify-between gap-4">
                        @if (Route::has('password.request'))
                            <a class="rounded-md text-sm font-semibold text-slate-500 hover:text-slate-900 focus:outline-none focus:ring-2 focus:ring-orange-500 focus:ring-offset-2" href="{{ route('password.request') }}">
                                {{ __('Forgot your password?') }}
                            </a>
                        @endif

                        <x-primary-button class="bg-slate-900 px-5 py-2.5 hover:bg-slate-700">
                            {{ __('Log in') }}
                        </x-primary-button>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>
