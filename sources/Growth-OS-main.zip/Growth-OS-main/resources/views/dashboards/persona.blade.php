@php
    $isAdminSupportDashboard = ! empty($aiProviderStatus);
    $isPlatformDashboard = ($linksTitle ?? null) === 'Platform Links';
    $statsCollection = collect($stats ?? []);
@endphp

<x-app-layout>
    <x-slot name="header">
        <div>
            <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __($title) }}</h2>
            <p class="mt-1 text-sm text-gray-500">{{ __($subtitle) }}</p>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-7xl space-y-6 px-4 sm:px-6 lg:px-8">
            <x-dashboard-card id="dashboard-overview" :eyebrow="__('Access scope')" :title="__($scope)">
                <div class="grid gap-5 lg:grid-cols-[1.35fr_1fr]">
                    <div class="min-w-0">
                        <p class="text-sm leading-6 text-gray-600">
                            {{ __('Dashboard/scoreboard MVP is active for this persona.') }}
                        </p>
                        <div class="mt-4 flex flex-wrap gap-2">
                            @if ($isAdminSupportDashboard)
                                <x-status-badge tone="info">{{ __('Admin Support') }}</x-status-badge>
                                <x-status-badge>{{ __('Setup/configuration support') }}</x-status-badge>
                                <x-status-badge>{{ __('User/access/support summary') }}</x-status-badge>
                            @else
                                <x-status-badge tone="info">{{ __('Platform overview') }}</x-status-badge>
                                <x-status-badge>{{ __('GOS/F&B vertical effectiveness') }}</x-status-badge>
                                <x-status-badge>{{ __('Adoption/usage signals') }}</x-status-badge>
                            @endif
                        </div>
                    </div>

                    <div class="rounded-md border border-slate-200 bg-slate-50 p-4">
                        <p class="text-xs font-semibold uppercase text-slate-500">{{ __('Dashboard focus') }}</p>
                        <p class="mt-2 text-sm font-semibold text-slate-900">
                            @if ($isAdminSupportDashboard)
                                {{ __('System overview, support readiness, access setup, and provider visibility.') }}
                            @else
                                {{ __('Platform/business strategy signals, adoption health, and high-level risk/opportunity.') }}
                            @endif
                        </p>
                    </div>
                </div>
            </x-dashboard-card>

            @if ($statsCollection->isNotEmpty())
                <section id="dashboard-metrics" class="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
                    @foreach ($statsCollection->take(5) as $label => $value)
                        <x-metric-card :label="__($label)" :value="$value" />
                    @endforeach
                </section>
            @endif

            <section id="dashboard-activity" class="grid gap-6 lg:grid-cols-2">
                <x-section-panel :title="$isAdminSupportDashboard ? __('System overview') : __('Platform overview')" :eyebrow="$isAdminSupportDashboard ? __('Support health') : __('Strategy health')">
                    <div class="grid gap-3 sm:grid-cols-2">
                        @forelse ($statsCollection->take(4) as $label => $value)
                            <div class="rounded-md bg-gray-50 p-4">
                                <p class="text-sm text-gray-500">{{ __($label) }}</p>
                                <p class="mt-1 text-2xl font-semibold text-gray-900">{{ $value }}</p>
                            </div>
                        @empty
                            <x-empty-state :title="__('No overview data yet.')" :body="__('Data will appear after pilot activity is available.')" />
                        @endforelse
                    </div>
                </x-section-panel>

                <x-section-panel :title="$isAdminSupportDashboard ? __('Setup/configuration support') : __('GOS/F&B vertical effectiveness')" :eyebrow="__('Signals')">
                    <div class="space-y-3 text-sm text-gray-700">
                        @if ($isAdminSupportDashboard)
                            <div class="flex flex-col gap-2 rounded-md bg-gray-50 p-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
                                <span>{{ __('Business setup') }}</span>
                                <x-status-badge tone="info">{{ __('Configured') }}</x-status-badge>
                            </div>
                            <div class="flex flex-col gap-2 rounded-md bg-gray-50 p-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
                                <span>{{ __('Branch/user access support') }}</span>
                                <x-status-badge>{{ __('Monitored') }}</x-status-badge>
                            </div>
                            <div class="flex flex-col gap-2 rounded-md bg-gray-50 p-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
                                <span>{{ __('Provider visibility') }}</span>
                                <x-status-badge tone="success">{{ __('Visible to System Admin') }}</x-status-badge>
                            </div>
                        @else
                            <div class="flex flex-col gap-2 rounded-md bg-gray-50 p-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
                                <span>{{ __('Business and branch adoption') }}</span>
                                <x-status-badge>{{ __('Tracked') }}</x-status-badge>
                            </div>
                            <div class="flex flex-col gap-2 rounded-md bg-gray-50 p-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
                                <span>{{ __('Customer check-in usage') }}</span>
                                <x-status-badge tone="info">{{ __('Adoption signal') }}</x-status-badge>
                            </div>
                            <div class="flex flex-col gap-2 rounded-md bg-gray-50 p-3 sm:flex-row sm:items-start sm:justify-between sm:gap-4">
                                <span>{{ __('High-level risk/opportunity') }}</span>
                                <x-status-badge tone="warning">{{ __('Review in Analytics') }}</x-status-badge>
                            </div>
                        @endif
                    </div>
                </x-section-panel>
            </section>

            @if (! empty($aiProviderStatus))
                <x-section-panel id="dashboard-ai" :title="__('AI Provider Status')" :eyebrow="__('Admin/support visibility')">
                    <dl class="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                        <div class="rounded-md bg-gray-50 p-4">
                            <dt class="text-sm text-gray-500">{{ __('Active/default provider') }}</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ $aiProviderStatus['default_provider_label'] }}</dd>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <dt class="text-sm text-gray-500">{{ __('External AI') }}</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ $aiProviderStatus['external_enabled'] ? __('Enabled') : __('Disabled') }}</dd>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <dt class="text-sm text-gray-500">{{ __('Last used provider') }}</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ $aiProviderStatus['last_used_provider_label'] ?? __('None yet') }}</dd>
                        </div>
                        <div class="rounded-md bg-gray-50 p-4">
                            <dt class="text-sm text-gray-500">{{ __('AI Action mode') }}</dt>
                            <dd class="mt-1 font-semibold text-gray-900">{{ __('Suggestion Only') }}</dd>
                        </div>
                    </dl>

                    <div class="mt-5 rounded-md bg-gray-50 p-4">
                        <p class="text-sm font-medium text-gray-500">{{ __('Priority chain') }}</p>
                        <div class="mt-3 flex flex-wrap items-center gap-2 text-sm">
                            @foreach ($aiProviderStatus['priority_chain'] as $provider)
                                <x-status-badge :tone="$provider['status'] === 'Configured' || $provider['status'] === 'Available' ? 'success' : 'warning'">
                                    {{ $provider['label'] }}: {{ __($provider['status']) }}
                                </x-status-badge>
                            @endforeach
                        </div>
                    </div>

                    <p class="mt-4 text-sm text-gray-600">
                        {{ $aiProviderStatus['fallback_used'] ? __('Fallback used in last AI run.') : __('No fallback recorded in last AI run.') }}
                    </p>
                </x-section-panel>
            @endif

            <section class="grid gap-6 lg:grid-cols-2">
                <x-ai-insight-card :title="$isAdminSupportDashboard ? __('Admin/support AI Insight') : __('Strategic AI Insight')" :confidence="__('Suggestion Only')">
                    <p class="text-sm leading-6 text-gray-700">
                        @if ($isAdminSupportDashboard)
                            {{ __('Admin/support insight focuses on setup gaps, access readiness, and provider visibility without exposing sensitive configuration values.') }}
                        @else
                            {{ __('Strategic insight focuses on platform adoption, F&B vertical effectiveness, and high-level business opportunity signals.') }}
                        @endif
                    </p>
                </x-ai-insight-card>

                <x-ai-action-card :title="$isAdminSupportDashboard ? __('Admin/support AI Action') : __('Strategic AI Action')" :status="__('Human review required')">
                    <p class="text-sm leading-6 text-gray-700">
                        @if ($isAdminSupportDashboard)
                            {{ __('Suggested action stays limited to support/configuration follow-up. No provider configuration value is displayed.') }}
                        @else
                            {{ __('Suggested action stays high-level for platform strategy and does not include branch operation buttons.') }}
                        @endif
                    </p>
                </x-ai-action-card>
            </section>

            @isset($links)
                <x-section-panel id="dashboard-actions" :title="__($linksTitle ?? 'Links')" :eyebrow="__('Next steps')">
                    <div class="flex flex-wrap gap-3">
                        <x-action-button :href="route('analytics.index')">{{ __('Analytics') }}</x-action-button>
                        @foreach ($links as $label => $url)
                            <x-action-button :href="$url" variant="secondary">{{ __($label) }}</x-action-button>
                        @endforeach
                    </div>
                </x-section-panel>
            @endisset
        </div>
    </div>
</x-app-layout>
