<x-app-layout>
    <x-slot name="header">
        <div class="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
            <div>
                <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ $branch->name }}</h2>
                <p class="mt-1 text-sm text-gray-500">{{ $business->name }} - {{ __('Branch profile') }}</p>
            </div>
            <div class="flex flex-wrap gap-2">
                <a href="{{ route('businesses.show', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Business') }}</a>
                @can('update', $branch)
                    <a href="{{ route('businesses.branches.edit', ['business' => $business, 'branch' => $branch]) }}" class="rounded-md bg-gray-900 px-4 py-2 text-sm font-semibold text-white hover:bg-gray-700">{{ __('Edit Branch') }}</a>
                @endcan
                <a href="{{ route('businesses.branches.check-ins', ['business' => $business, 'branch' => $branch]) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Check-ins') }}</a>
                <a href="{{ route('businesses.branches.rewards.index', ['business' => $business, 'branch' => $branch]) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Rewards') }}</a>
                <a href="{{ route('businesses.product-services.index', $business) }}" class="rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Product/Service') }}</a>
            </div>
        </div>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-5xl space-y-6 px-4 sm:px-6 lg:px-8">
            @if (session('status'))
                <div class="rounded-md bg-green-50 p-4 text-sm font-medium text-green-800">
                    {{ session('status') }}
                </div>
            @endif

            <section class="rounded-lg bg-white p-6 shadow-sm">
                <h3 class="text-base font-semibold text-gray-900">{{ __('Branch Basic Profile') }}</h3>
                <dl class="mt-5 grid gap-4 sm:grid-cols-2">
                    <div>
                        <dt class="text-sm font-medium text-gray-500">{{ __('Business') }}</dt>
                        <dd class="mt-1 text-gray-900">{{ $business->name }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">{{ __('Branch Manager') }}</dt>
                        <dd class="mt-1 text-gray-900">{{ $branch->manager?->name ?? __('Not assigned') }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">{{ __('Code') }}</dt>
                        <dd class="mt-1 text-gray-900">{{ $branch->code ?? '-' }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">{{ __('Status') }}</dt>
                        <dd class="mt-1 text-gray-900">{{ $branch->is_active ? __('Active') : __('Inactive') }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">{{ __('Phone') }}</dt>
                        <dd class="mt-1 text-gray-900">{{ $branch->phone ?? '-' }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">{{ __('Address') }}</dt>
                        <dd class="mt-1 text-gray-900">{{ $branch->address ?? '-' }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">{{ __('Check-ins') }}</dt>
                        <dd class="mt-1 text-gray-900">{{ $branch->check_ins_count }}</dd>
                    </div>
                    <div>
                        <dt class="text-sm font-medium text-gray-500">{{ __('Check-in cooldown') }}</dt>
                        <dd class="mt-1 text-gray-900">{{ $branch->check_in_cooldown_minutes }} {{ __('minutes') }}</dd>
                    </div>
                </dl>
            </section>

            @if (
                auth()->user()->isSystemAdmin()
                    || (auth()->user()->isOwner() && $business->owner_user_id === auth()->id())
                    || (auth()->user()->isBranchManager() && auth()->user()->canAccessBranch($branch))
            )
                <section class="rounded-lg bg-white p-6 shadow-sm">
                    <h3 class="text-base font-semibold text-gray-900">{{ __('Check-in Cooldown Setting') }}</h3>
                    <form method="POST" action="{{ route('businesses.branches.cooldown.update', ['business' => $business, 'branch' => $branch]) }}" class="mt-5 space-y-4">
                        @csrf
                        @method('PATCH')

                        <div>
                            <x-input-label for="check_in_cooldown_minutes" :value="__('Cooldown minutes')" />
                            <x-text-input id="check_in_cooldown_minutes" name="check_in_cooldown_minutes" type="number" min="15" max="1440" class="mt-1 block w-full max-w-xs" :value="old('check_in_cooldown_minutes', $branch->check_in_cooldown_minutes)" />
                            <p class="mt-1 text-xs text-gray-500">{{ __('Duplicate check-in sebelum tempoh ini tamat akan disekat.') }}</p>
                            <x-input-error class="mt-2" :messages="$errors->get('check_in_cooldown_minutes')" />
                        </div>

                        <x-primary-button>{{ __('Save Cooldown') }}</x-primary-button>
                    </form>
                </section>
            @endif
        </div>
    </div>
</x-app-layout>
