<x-app-layout>
    <x-slot name="header">
        <h2 class="text-xl font-semibold leading-tight text-gray-800">{{ __('Create Branch') }}</h2>
    </x-slot>

    <div class="py-8">
        <div class="mx-auto max-w-3xl px-4 sm:px-6 lg:px-8">
            <form method="POST" action="{{ route('businesses.branches.store', $business) }}" class="space-y-6 rounded-lg bg-white p-6 shadow-sm">
                @csrf

                @include('branches.partials.form', ['branch' => null])

                <div class="flex flex-col gap-3 sm:flex-row sm:justify-end">
                    <a href="{{ route('businesses.show', $business) }}" class="inline-flex justify-center rounded-md border border-gray-300 px-4 py-2 text-sm font-semibold text-gray-700 hover:bg-gray-50">{{ __('Cancel') }}</a>
                    <x-primary-button>{{ __('Save Branch') }}</x-primary-button>
                </div>
            </form>
        </div>
    </div>
</x-app-layout>
