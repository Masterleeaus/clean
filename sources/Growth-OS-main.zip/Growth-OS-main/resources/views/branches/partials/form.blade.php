<div>
    <x-input-label for="name" :value="__('Branch Name')" />
    <x-text-input id="name" name="name" type="text" class="mt-1 block w-full" :value="old('name', $branch?->name)" required autofocus />
    <x-input-error class="mt-2" :messages="$errors->get('name')" />
</div>

<div>
    <x-input-label for="code" :value="__('Branch Code')" />
    <x-text-input id="code" name="code" type="text" class="mt-1 block w-full" :value="old('code', $branch?->code)" />
    <x-input-error class="mt-2" :messages="$errors->get('code')" />
</div>

<div>
    <x-input-label for="manager_user_id" :value="__('Branch Manager')" />
    <select id="manager_user_id" name="manager_user_id" class="mt-1 block w-full rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
        <option value="">{{ __('No manager assigned') }}</option>
        @foreach ($managers as $manager)
            <option value="{{ $manager->id }}" @selected(old('manager_user_id', $branch?->manager_user_id) == $manager->id)>{{ $manager->name }} - {{ $manager->email }}</option>
        @endforeach
    </select>
    <x-input-error class="mt-2" :messages="$errors->get('manager_user_id')" />
</div>

<div>
    <x-input-label for="address" :value="__('Address')" />
    <x-text-input id="address" name="address" type="text" class="mt-1 block w-full" :value="old('address', $branch?->address)" />
    <x-input-error class="mt-2" :messages="$errors->get('address')" />
</div>

<div>
    <x-input-label for="phone" :value="__('Phone')" />
    <x-text-input id="phone" name="phone" type="text" class="mt-1 block w-full" :value="old('phone', $branch?->phone)" />
    <x-input-error class="mt-2" :messages="$errors->get('phone')" />
</div>

<label class="flex items-center gap-3">
    <input type="checkbox" name="is_active" value="1" class="rounded border-gray-300 text-indigo-600 shadow-sm focus:ring-indigo-500" @checked(old('is_active', $branch?->is_active ?? true))>
    <span class="text-sm font-medium text-gray-700">{{ __('Active branch') }}</span>
</label>

<div>
    <x-input-label for="check_in_cooldown_minutes" :value="__('Check-in cooldown minutes')" />
    <x-text-input id="check_in_cooldown_minutes" name="check_in_cooldown_minutes" type="number" min="15" max="1440" class="mt-1 block w-full" :value="old('check_in_cooldown_minutes', $branch?->check_in_cooldown_minutes ?? 60)" />
    <p class="mt-1 text-xs text-gray-500">{{ __('Customer yang sama hanya boleh check-in semula selepas tempoh ini pada hari yang sama.') }}</p>
    <x-input-error class="mt-2" :messages="$errors->get('check_in_cooldown_minutes')" />
</div>
