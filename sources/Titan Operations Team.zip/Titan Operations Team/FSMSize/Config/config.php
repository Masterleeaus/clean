<?php

return ['name' => 'FSMSize'];
