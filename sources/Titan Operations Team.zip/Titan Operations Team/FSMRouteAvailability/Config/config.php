<?php

return ['name' => 'FSMRouteAvailability'];
