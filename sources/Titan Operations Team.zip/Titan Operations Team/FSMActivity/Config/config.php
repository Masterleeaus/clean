<?php

return [
    'name' => 'FSMActivity',
];
