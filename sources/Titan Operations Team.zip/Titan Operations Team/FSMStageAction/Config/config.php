<?php

return ['name' => 'FSMStageAction'];
