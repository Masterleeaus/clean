<?php

return [
    'name' => 'AuditLog',
];
