<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('ext_marketing_campaigns', function (Blueprint $table) {
            if (!Schema::hasColumn('ext_marketing_campaigns', 'instruction')) {
                $table->text('instruction')->nullable()->after('witch_campaign_question');
            }
            if (!Schema::hasColumn('ext_marketing_campaigns', 'ai_reply')) {
                $table->boolean('ai_reply')->default(true)->nullable();
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('ext_marketing_campaigns', function (Blueprint $table) {
            $table->dropColumn('instruction');
            $table->dropColumn('ai_reply');
        });
    }
};
