<?php

namespace Modules\InstantAds\Filament\Pages;

use Filament\Pages\Page;

class BatchVariantPage extends Page
{
    protected static \BackedEnum|string|null $navigationIcon = 'heroicon-o-squares-plus';
    protected static ?string $navigationLabel = 'Batch Variants';
    protected string $view = 'instantads::filament.pages.batch-variant-page';
}
