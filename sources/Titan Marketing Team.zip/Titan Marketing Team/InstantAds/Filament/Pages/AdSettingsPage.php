<?php

namespace Modules\InstantAds\Filament\Pages;

use Filament\Pages\Page;

class AdSettingsPage extends Page
{
    protected static \BackedEnum|string|null $navigationIcon = 'heroicon-o-cog-8-tooth';
    protected static ?string $navigationLabel = 'InstantAds Settings';
    protected string $view = 'instantads::filament.pages.ad-settings-page';
}
