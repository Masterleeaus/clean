<?php

return [
    'name' => 'FSMWorkflow',
];
