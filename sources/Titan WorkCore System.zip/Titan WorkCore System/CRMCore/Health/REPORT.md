# CRMCore Health Report

- Healthy: yes
- Panels: `*`
- Namespace: `Modules\CRMCore\`

- [WARNING] class_file_missing: Class was declared in manifest/discovery but no local file was found: Modules\CRMCore\app\Providers\CRMCoreServiceProvider
- [WARNING] class_file_missing: Class was declared in manifest/discovery but no local file was found: Modules\CRMCore\app\Providers\EventServiceProvider
- [WARNING] class_file_missing: Class was declared in manifest/discovery but no local file was found: Modules\CRMCore\app\Providers\RouteServiceProvider
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
- [WARNING] possible_filament_api_drift: Possible old Filament API/reference to review: getPages()
