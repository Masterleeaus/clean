# CRMCore UI

Control-panel UI layer adapted from the Titan controlled-module scaffold. CRMCore exposes a single Filament page: CONTACTS HUB > Customer Details.

Primary surfaces:
- KPI cards
- Customer Agent chat card
- Cleaning Growth Actions
- Attachments panel
- Bottom tab tables
