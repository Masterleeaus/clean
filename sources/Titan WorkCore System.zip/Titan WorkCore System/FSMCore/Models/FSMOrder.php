<?php

namespace Modules\FSMCore\Models;

use App\Traits\HasCompany;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class FSMOrder extends Model
{
    use HasCompany;

    protected $table = 'fsm_orders';

    protected $fillable = [
        'company_id',
        'name',
        'location_id',
        'person_id',
        'vehicle_id',
        'team_id',
        'stage_id',
        'template_id',
        'agreement_id',
        'fsm_recurring_id',
        'lead_id',
        'estimate_id',
        'priority',
        'color',
        'scheduled_date_start',
        'scheduled_date_end',
        'date_start',
        'date_end',
        'description',
        // FSMSales fields (added by FSMSales module migration)
        'billing_policy',
        'billing_amount',
        'hourly_rate',
        'is_invoiced',
        // FSMWorkflow fields (added by FSMWorkflow module migration)
        'size_id',
        'estimated_sqm',
        'room_count',
    ];

    protected $casts = [
        'company_id' => 'integer',
        'location_id' => 'integer',
        'person_id' => 'integer',
        'vehicle_id' => 'integer',
        'team_id' => 'integer',
        'stage_id' => 'integer',
        'template_id' => 'integer',
        'agreement_id' => 'integer',
        'lead_id' => 'integer',
        'estimate_id' => 'integer',
        'color' => 'integer',
        'scheduled_date_start' => 'datetime',
        'scheduled_date_end' => 'datetime',
        'date_start' => 'datetime',
        'date_end' => 'datetime',
        'size_id' => 'integer',
        'estimated_sqm' => 'integer',
        'room_count' => 'integer',
    ];

    public function location()
    {
        return $this->belongsTo(FSMLocation::class, 'location_id');
    }

    public function person()
    {
        return $this->belongsTo(\App\Models\User::class, 'person_id');
    }

    public function team()
    {
        return $this->belongsTo(FSMTeam::class, 'team_id');
    }

    public function stage()
    {
        return $this->belongsTo(FSMStage::class, 'stage_id');
    }

    public function project(): BelongsTo
    {
        return $this->belongsTo(\App\Models\Project::class, 'project_id');
    }

    public function task(): BelongsTo
    {
        return $this->belongsTo(\App\Models\Task::class, 'task_id');
    }

    public function template()
    {
        return $this->belongsTo(FSMTemplate::class, 'template_id');
    }

    public function equipment()
    {
        return $this->belongsToMany(FSMEquipment::class, 'fsm_order_equipment', 'fsm_order_id', 'fsm_equipment_id');
    }

    public function tags()
    {
        return $this->belongsToMany(FSMTag::class, 'fsm_order_tag', 'fsm_order_id', 'fsm_tag_id');
    }

    public function isUrgent(): bool
    {
        return $this->priority === '1';
    }

    public function agreement()
    {
        return $this->belongsTo(\Modules\FSMServiceAgreement\Models\FSMServiceAgreement::class, 'agreement_id');
    }

    public function vehicle()
    {
        return $this->belongsTo(\Modules\FSMVehicle\Models\FSMVehicle::class, 'vehicle_id');
    }

    public function recurringSchedule()
    {
        if (!class_exists(\Modules\FSMRecurring\Models\FSMRecurring::class)) {
            return null;
        }
        return $this->belongsTo(\Modules\FSMRecurring\Models\FSMRecurring::class, 'fsm_recurring_id');
    }

    public function lead()
    {
        return $this->belongsTo(\App\Models\Lead::class, 'lead_id');
    }

    public function estimate()
    {
        return $this->belongsTo(\App\Models\Estimate::class, 'estimate_id');
    }

    public function photos()
    {
        return $this->hasMany(FSMOrderPhoto::class, 'fsm_order_id');
    }

    public function attachments()
    {
        return $this->hasMany(FSMOrderAttachment::class, 'fsm_order_id')->latest();
    }

    public function size()
    {
        if (!class_exists(\Modules\FSMWorkflow\Models\FSMSize::class)) {
            return null;
        }
        return $this->belongsTo(\Modules\FSMWorkflow\Models\FSMSize::class, 'size_id');
    }

    public function invoices()
    {
        return $this->belongsToMany(
            \App\Models\Invoice::class,
            'fsm_order_invoice',
            'fsm_order_id',
            'invoice_id'
        );
    }
}
