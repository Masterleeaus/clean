<?php

namespace Modules\CleaningJobs\Listeners\JobBoard;

use App\Events\GivePermissionToRole;
use Modules\CleaningJobs\Models\JobBoard\TaskUtility;

class GiveRoleToPermission
{
    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  object  $event
     * @return void
     */
    public function handle(GivePermissionToRole $event)
    {
        $role_id = $event->role_id;
        $rolename = $event->rolename;
        $user_module = $event->user_module;
        if(!empty($user_module))
        {
            if (in_array("JobBoard", $user_module))
            {
                TaskUtility::GivePermissionToRoles($role_id,$rolename);
            }
        }
    }
}
