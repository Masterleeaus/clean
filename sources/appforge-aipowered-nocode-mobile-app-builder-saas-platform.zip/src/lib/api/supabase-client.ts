/**
 * Supabase API Client
 * All operations go directly through Supabase
 */

import { supabase } from '@/integrations/supabase/client';
import { toast } from "@/hooks/use-toast";
import type { Json } from '@/integrations/supabase/types';

// ============ USER API ============
export const userApi = {
  async getProfile() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async updateProfile(updates: Partial<UserProfile>) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('profiles')
      .update(updates)
      .eq('id', user.id)
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async getCredits() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('user_credits')
      .select('*')
      .eq('user_id', user.id)
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async useCredits(amount: number, actionType = 'app_build', description?: string) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase.rpc('use_credits', {
      p_user_id: user.id,
      p_amount: amount,
      p_action_type: actionType,
      p_description: description || null,
    });

    return { data: { success: data }, error: error ? new Error(error.message) : null };
  },

  async getSubscription() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('user_subscriptions')
      .select(`
        *,
        plan:subscription_plans(*)
      `)
      .eq('user_id', user.id)
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async getCreditHistory(limit = 50) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('credit_usage_history')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(limit);

    return { data, error: error ? new Error(error.message) : null };
  },

  async deleteAccount() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    // Delete user data in order
    await supabase.from('credit_usage_history').delete().eq('user_id', user.id);
    await supabase.from('user_credits').delete().eq('user_id', user.id);
    await supabase.from('user_subscriptions').delete().eq('user_id', user.id);
    await supabase.from('app_builds').delete().eq('user_id', user.id);
    await supabase.from('app_projects').delete().eq('user_id', user.id);
    await supabase.from('profiles').delete().eq('id', user.id);
    
    // Sign out
    await supabase.auth.signOut();
    
    return { data: { message: 'Account deleted' }, error: null };
  },

  async getTransactions() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('payment_transactions')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    return { data, error: error ? new Error(error.message) : null };
  },

  async getInvoices() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('invoices')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    return { data, error: error ? new Error(error.message) : null };
  },
  async exportData() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    // Gather all user data
    const [profile, credits, projects, builds, history] = await Promise.all([
      supabase.from('profiles').select('*').eq('id', user.id).single(),
      supabase.from('user_credits').select('*').eq('user_id', user.id).single(),
      supabase.from('app_projects').select('*').eq('user_id', user.id),
      supabase.from('app_builds').select('*').eq('user_id', user.id),
      supabase.from('credit_usage_history').select('*').eq('user_id', user.id),
    ]);

    return {
      data: {
        profile: profile.data,
        credits: credits.data,
        projects: projects.data,
        builds: builds.data,
        creditHistory: history.data,
        exportedAt: new Date().toISOString(),
      },
      error: null,
    };
  },
};

// ============ PROJECTS API ============
export const projectsApi = {
  async list() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('app_projects')
      .select('*')
      .eq('user_id', user.id)
      .order('updated_at', { ascending: false });

    return { data, error: error ? new Error(error.message) : null };
  },

  async get(id: string) {
    const { data, error } = await supabase
      .from('app_projects')
      .select('*')
      .eq('id', id)
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async create(project: Omit<AppProject, 'id' | 'created_at' | 'updated_at' | 'user_id'>) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('app_projects')
      .insert({
        ...project,
        user_id: user.id,
      })
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async update(id: string, updates: Partial<AppProject>) {
    const { data, error } = await supabase
      .from('app_projects')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async delete(id: string) {
    const { error } = await supabase
      .from('app_projects')
      .delete()
      .eq('id', id);

    return { data: { message: 'Project deleted' }, error: error ? new Error(error.message) : null };
  },

  async getBuilds(projectId?: string) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    let query = supabase
      .from('app_builds')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    if (projectId) {
      query = query.eq('project_id', projectId);
    }

    const { data, error } = await query;

    return { data, error: error ? new Error(error.message) : null };
  },
};

const sanitizePackageSegment = (segment: string, fallback: string) => {
  const cleaned = segment.toLowerCase().replace(/[^a-z0-9_]/g, '');
  if (!cleaned) return fallback;
  return /^[a-z]/.test(cleaned) ? cleaned : `app${cleaned}`;
};

const sanitizePackageName = (rawPackageName: string | undefined, appName: string) => {
  const fallbackSegments = ['com', 'app', sanitizePackageSegment(appName, 'mobile')];
  const sourceSegments = (rawPackageName || '').split('.').filter(Boolean);
  const normalizedSegments = sourceSegments.length > 0
    ? sourceSegments.map((segment, index) =>
        sanitizePackageSegment(segment, fallbackSegments[index] || 'app')
      )
    : fallbackSegments;

  while (normalizedSegments.length < 3) {
    normalizedSegments.push(fallbackSegments[normalizedSegments.length] || 'app');
  }

  return normalizedSegments.join('.');
};

// ============ BUILD API ============
export const buildApi = {
  async startBuild(config: Record<string, unknown>) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const platform = (config.platform as string) || 'android';
    const appName = (config.appName as string) || 'My App';
    const packageName = sanitizePackageName(config.packageName as string | undefined, appName);
    const normalizedConfig = {
      ...config,
      packageName,
    };

    // Create build record
    const { data, error } = await supabase
      .from('app_builds')
      .insert([{
        user_id: user.id,
        app_name: appName,
        package_name: packageName,
        website_url: config.websiteUrl as string,
        config: normalizedConfig as Json,
        status: 'pending',
        progress: 0,
      }])
      .select()
      .single();

    if (error) return { data: null, error: new Error(error.message) };
    if (!data) return { data: null, error: new Error('Build could not be created') };

    // Trigger real cloud build via edge function
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session?.access_token) throw new Error('No active session');

      const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
      const res = await fetch(`${supabaseUrl}/functions/v1/cloud-build`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({
          buildId: data.id,
          websiteUrl: config.websiteUrl,
          appName,
          platform,
          packageName,
          config: normalizedConfig,
        }),
      });

      const result = await res.json();
      if (!res.ok) {
        const errorMessage = result.error || result.details || 'Build trigger failed';
        // Surface the error so the UI can display it immediately
        return { data: { buildId: data.id }, error: new Error(errorMessage) };
      }

      return { data: { buildId: data.id, cloudBuildId: result.cloudBuildId, message: 'Cloud build started' }, error: null };
    } catch (cloudErr) {
      console.error('Cloud build trigger failed:', cloudErr);
      // Build record exists — user can see the error in status polling
      return { data: { buildId: data.id, message: 'Build created but cloud trigger failed' }, error: null };
    }
  },

  // Alias for Android builds
  async startAndroidBuild(config: Record<string, unknown>) {
    return buildApi.startBuild({ ...config, platform: 'android' });
  },

  // Alias for iOS builds
  async startIosBuild(config: Record<string, unknown>) {
    return buildApi.startBuild({ ...config, platform: 'ios' });
  },

  async getBuildStatus(buildId: string) {
    // Try cloud-build-status edge function first for real-time Codemagic sync
    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.access_token) {
        const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
        const res = await fetch(`${supabaseUrl}/functions/v1/cloud-build-status`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${session.access_token}`,
          },
          body: JSON.stringify({ buildId }),
        });
        if (res.ok) {
          const data = await res.json();
          return { data, error: null };
        }
      }
    } catch {
      // Fall back to direct DB query
    }

    const { data, error } = await supabase
      .from('app_builds')
      .select('*')
      .eq('id', buildId)
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async listBuilds(limit = 20) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('app_builds')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .limit(limit);

    return { data, error: error ? new Error(error.message) : null };
  },
};

// ============ AUTOMATION API ============
export const automationApi = {
  async list(projectId?: string) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    let query = supabase
      .from('automation_configs')
      .select('*')
      .eq('user_id', user.id);

    if (projectId) {
      query = query.eq('project_id', projectId);
    }

    const { data, error } = await query.order('created_at', { ascending: false });

    return { data: { automations: data || [] }, error: error ? new Error(error.message) : null };
  },

  async toggle(automationId: string, enabled: boolean) {
    const { data, error } = await supabase
      .from('automation_configs')
      .update({ is_enabled: enabled })
      .eq('id', automationId)
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async getLogs(automationId: string) {
    const { data, error } = await supabase
      .from('automation_logs')
      .select('*')
      .eq('automation_id', automationId)
      .order('created_at', { ascending: false });

    return { data: { logs: data || [] }, error: error ? new Error(error.message) : null };
  },

  async create(projectId: string, workflowType: string, config: Record<string, unknown>) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('automation_configs')
      .insert([{
        user_id: user.id,
        project_id: projectId,
        workflow_type: workflowType,
        config: config as Json,
      }])
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async delete(automationId: string) {
    const { error } = await supabase
      .from('automation_configs')
      .delete()
      .eq('id', automationId);

    return { data: { message: 'Automation deleted' }, error: error ? new Error(error.message) : null };
  },

  async execute(automationId: string) {
    // Placeholder - would need edge function for actual execution
    return { data: { message: 'Automation execution triggered' }, error: null };
  },

  async updateConfig(automationId: string, config: Record<string, unknown>) {
    const { data, error } = await supabase
      .from('automation_configs')
      .update({ config: config as Json })
      .eq('id', automationId)
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },
};

// ============ TEMPLATES API ============
export const templatesApi = {
  async list() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('app_templates')
      .select('*')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false });

    return { data, error: error ? new Error(error.message) : null };
  },

  async create(template: { name: string; description?: string; config: Record<string, unknown> }) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('app_templates')
      .insert([{
        name: template.name,
        description: template.description,
        config: template.config as Json,
        user_id: user.id,
      }])
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async delete(id: string) {
    const { error } = await supabase
      .from('app_templates')
      .delete()
      .eq('id', id);

    return { data: { message: 'Template deleted' }, error: error ? new Error(error.message) : null };
  },
};

// ============ SUBSCRIPTION PLANS API ============
export const plansApi = {
  async list() {
    const { data, error } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('is_active', true)
      .order('price_monthly', { ascending: true });

    return { data, error: error ? new Error(error.message) : null };
  },
  
  async get(id: string) {
    const { data, error } = await supabase
      .from('subscription_plans')
      .select('*')
      .eq('id', id)
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },
};

// ============ CREDIT PACKS API ============
export const creditPacksApi = {
  async list() {
    const { data, error } = await supabase
      .from('credit_packs')
      .select('*')
      .eq('is_active', true)
      .order('price', { ascending: true });

    return { data, error: error ? new Error(error.message) : null };
  },

  async get(id: string) {
    const { data, error } = await supabase
      .from('credit_packs')
      .select('*')
      .eq('id', id)
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },
};

// ============ CHAT API ============
export const chatApi = {
  async getHistory(projectId: string, limit = 50) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('chat_messages')
      .select('*')
      .eq('user_id', user.id)
      .eq('project_id', projectId)
      .order('created_at', { ascending: true })
      .limit(limit);

    return { data, error: error ? new Error(error.message) : null };
  },

  async saveMessage(projectId: string, role: 'user' | 'assistant', content: string) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data, error } = await supabase
      .from('chat_messages')
      .insert({
        user_id: user.id,
        project_id: projectId,
        role,
        content,
      })
      .select()
      .single();

    return { data: { id: data?.id }, error: error ? new Error(error.message) : null };
  },

  async clearHistory(projectId: string) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { error } = await supabase
      .from('chat_messages')
      .delete()
      .eq('user_id', user.id)
      .eq('project_id', projectId);

    return { data: { message: 'Chat history cleared' }, error: error ? new Error(error.message) : null };
  },
};

// ============ BANK TRANSFER API ============
export const bankTransferApi = {
  async create(data: {
    amount: number;
    currency: string;
    plan_id?: string;
    credit_pack_id?: string;
    proof_of_payment_url?: string;
  }) {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: null, error: new Error('Not authenticated') };

    const { data: result, error } = await supabase
      .from('bank_transfer_requests')
      .insert({
        ...data,
        user_id: user.id,
      })
      .select()
      .single();

    return { data: result ? { id: result.id } : null, error: error ? new Error(error.message) : null };
  },

  async getStatus(id: string) {
    const { data, error } = await supabase
      .from('bank_transfer_requests')
      .select('status, admin_notes')
      .eq('id', id)
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  // Admin functions
  async listAll() {
    // First get all bank transfers
    const { data: transfers, error: transferError } = await supabase
      .from('bank_transfer_requests')
      .select(`
        *,
        subscription_plans(name),
        credit_packs(name, credits)
      `)
      .order('created_at', { ascending: false });

    if (transferError || !transfers) {
      return { data: [], error: transferError ? new Error(transferError.message) : null };
    }

    // Get unique user IDs and fetch their profiles
    const userIds = [...new Set(transfers.map(t => t.user_id))];
    const { data: profiles } = await supabase
      .from('profiles')
      .select('id, email, display_name')
      .in('id', userIds);

    // Map profiles to transfers
    const profileMap = new Map(profiles?.map(p => [p.id, p]) || []);
    const enrichedTransfers = transfers.map(t => ({
      ...t,
      profiles: profileMap.get(t.user_id) || null,
    }));

    return { data: enrichedTransfers, error: null };
  },

  async approve(id: string, adminNotes: string) {
    // First get the transfer details
    const { data: transfer, error: fetchError } = await supabase
      .from('bank_transfer_requests')
      .select('*, credit_packs(credits), subscription_plans(monthly_credits)')
      .eq('id', id)
      .single();

    if (fetchError || !transfer) {
      return { data: null, error: new Error(fetchError?.message || 'Transfer not found') };
    }

    // Update transfer status
    const { error: updateError } = await supabase
      .from('bank_transfer_requests')
      .update({
        status: 'approved',
        admin_notes: adminNotes || null,
      })
      .eq('id', id);

    if (updateError) {
      return { data: null, error: new Error(updateError.message) };
    }

    // Add credits if it's a credit pack purchase
    if (transfer.credit_pack_id && transfer.credit_packs?.credits) {
      const { error: creditError } = await supabase.rpc('add_credits', {
        p_user_id: transfer.user_id,
        p_amount: transfer.credit_packs.credits,
        p_credit_type: 'bonus',
        p_action_type: 'bank_transfer_purchase',
        p_description: `Bank transfer approved - ${transfer.credit_packs.credits} credits`,
      });

      if (creditError) {
        console.error('Error adding credits:', creditError);
      }
    }

    // Handle subscription plan upgrade
    if (transfer.plan_id) {
      // Update user subscription to the new plan
      const { error: subError } = await supabase
        .from('user_subscriptions')
        .update({
          plan_id: transfer.plan_id,
          status: 'active',
          payment_method: 'bank_transfer',
          current_period_start: new Date().toISOString(),
          current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        })
        .eq('user_id', transfer.user_id);

      if (subError) {
        // If no existing subscription, insert one
        await supabase.from('user_subscriptions').insert({
          user_id: transfer.user_id,
          plan_id: transfer.plan_id,
          status: 'active',
          payment_method: 'bank_transfer',
          current_period_end: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString(),
        });
      }

      // Add the plan's monthly credits
      const planCredits = (transfer.subscription_plans as any)?.monthly_credits;
      if (planCredits && planCredits > 0) {
        const { error: creditError } = await supabase.rpc('add_credits', {
          p_user_id: transfer.user_id,
          p_amount: planCredits,
          p_credit_type: 'monthly',
          p_action_type: 'subscription_activation',
          p_description: `Subscription activated via bank transfer - ${planCredits} monthly credits`,
        });

        if (creditError) {
          console.error('Error adding subscription credits:', creditError);
        }
      }
    }

    // Create a transaction record
    await supabase.from('payment_transactions').insert({
      user_id: transfer.user_id,
      amount: transfer.amount,
      currency: transfer.currency,
      payment_method: 'bank_transfer',
      transaction_type: transfer.credit_pack_id ? 'credit_purchase' : 'subscription',
      status: 'completed',
      reference_id: id,
    });

    return { data: { success: true }, error: null };
  },

  async reject(id: string, adminNotes: string) {
    const { error } = await supabase
      .from('bank_transfer_requests')
      .update({
        status: 'rejected',
        admin_notes: adminNotes,
      })
      .eq('id', id);

    return { data: error ? null : { success: true }, error: error ? new Error(error.message) : null };
  },
};

// ============ ADMIN API ============
export const adminApi = {
  async getStats() {
    const todayStart = new Date();
    todayStart.setHours(0, 0, 0, 0);
    const todayISO = todayStart.toISOString();

    const [usersResult, buildsResult, projectsResult, subscriptionsResult, activeBuildsResult, subscriptionMRRResult, completedTransactionsResult, newUsersTodayResult, buildsTodayResult] = await Promise.all([
      supabase.from('profiles').select('id', { count: 'exact', head: true }),
      supabase.from('app_builds').select('id', { count: 'exact', head: true }),
      supabase.from('app_projects').select('id', { count: 'exact', head: true }),
      supabase.from('user_subscriptions').select('id', { count: 'exact', head: true }).eq('status', 'active'),
      supabase.from('app_builds').select('id', { count: 'exact', head: true }).in('status', ['pending', 'building']),
      supabase.from('user_subscriptions')
        .select(`
          billing_cycle,
          subscription_plans!inner(price_monthly, price_yearly)
        `)
        .eq('status', 'active'),
      supabase.from('payment_transactions').select('amount').eq('status', 'completed'),
      supabase.from('profiles').select('id', { count: 'exact', head: true }).gte('created_at', todayISO),
      supabase.from('app_builds').select('id', { count: 'exact', head: true }).gte('created_at', todayISO),
    ]);

    // Calculate MRR from active subscriptions
    let mrr = 0;
    if (subscriptionMRRResult.data) {
      mrr = subscriptionMRRResult.data.reduce((sum, sub: any) => {
        const plan = sub.subscription_plans;
        if (!plan) return sum;
        if (sub.billing_cycle === 'yearly') {
          return sum + (Number(plan.price_yearly) / 12);
        }
        return sum + Number(plan.price_monthly);
      }, 0);
    }

    // Calculate total revenue from completed transactions
    let totalRevenue = 0;
    if (completedTransactionsResult.data) {
      totalRevenue = completedTransactionsResult.data.reduce((sum, t: any) => sum + Number(t.amount), 0);
    }

    // Calculate this month's revenue
    const now = new Date();
    const monthStart = new Date(now.getFullYear(), now.getMonth(), 1).toISOString();
    const { data: monthlyTxns } = await supabase
      .from('payment_transactions')
      .select('amount')
      .eq('status', 'completed')
      .gte('created_at', monthStart);

    const monthlyRevenue = monthlyTxns
      ? monthlyTxns.reduce((sum, t: any) => sum + Number(t.amount), 0)
      : 0;

    return {
      data: {
        totalUsers: usersResult.count || 0,
        totalBuilds: buildsResult.count || 0,
        totalProjects: projectsResult.count || 0,
        totalRevenue,
        monthlyRevenue: monthlyRevenue || mrr,
        activeBuilds: activeBuildsResult.count || 0,
        activeSubscriptions: subscriptionsResult.count || 0,
        mrr: mrr,
        revenue: totalRevenue,
        newUsersToday: newUsersTodayResult.count || 0,
        buildsToday: buildsTodayResult.count || 0,
      },
      error: null,
    };
  },

  async getUsers() {
    const { data, error } = await supabase
      .from('profiles')
      .select(`
        *,
        user_roles(role),
        user_credits(monthly_credits, bonus_credits)
      `)
      .order('created_at', { ascending: false })
      .limit(100);

    return { data, error: error ? new Error(error.message) : null };
  },

  async updateUserRole(userId: string, role: 'admin' | 'moderator' | 'user' | null) {
    if (role === null) {
      // Delete role
      const { error } = await supabase
        .from('user_roles')
        .delete()
        .eq('user_id', userId);
      return { data: { message: 'Role removed' }, error: error ? new Error(error.message) : null };
    }

    // First check if role exists
    const { data: existing } = await supabase
      .from('user_roles')
      .select('id')
      .eq('user_id', userId)
      .single();

    if (existing) {
      const { error } = await supabase
        .from('user_roles')
        .update({ role })
        .eq('user_id', userId);
      return { data: { message: 'Role updated' }, error: error ? new Error(error.message) : null };
    } else {
      const { error } = await supabase
        .from('user_roles')
        .insert({ user_id: userId, role });
      return { data: { message: 'Role created' }, error: error ? new Error(error.message) : null };
    }
  },

  async getTransactions() {
    const { data, error } = await supabase
      .from('payment_transactions')
      .select('*')
      .order('created_at', { ascending: false });

    return { data, error: error ? new Error(error.message) : null };
  },

  async getBuilds() {
    const { data, error } = await supabase
      .from('app_builds')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);

    return { data, error: error ? new Error(error.message) : null };
  },

  async getPlans() {
    const { data, error } = await supabase
      .from('subscription_plans')
      .select('*')
      .order('price_monthly', { ascending: true });

    return { data, error: error ? new Error(error.message) : null };
  },

  async createPlan(plan: { name: string; tier: string; price_monthly: number; price_yearly: number; monthly_credits: number; description: string | null; is_active: boolean; features: unknown; stripe_price_id?: string | null; stripe_yearly_price_id?: string | null }) {
    const { data, error } = await supabase
      .from('subscription_plans')
      .insert([plan as any])
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async updatePlan(id: string, updates: Partial<SubscriptionPlan>) {
    const { data, error } = await supabase
      .from('subscription_plans')
      .update(updates as any)
      .eq('id', id)
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async getCreditPacks() {
    const { data, error } = await supabase
      .from('credit_packs')
      .select('*')
      .order('price', { ascending: true });

    return { data, error: error ? new Error(error.message) : null };
  },

  async createCreditPack(pack: { name: string; description: string | null; credits: number; price: number; is_active: boolean; stripe_price_id?: string | null }) {
    const { data, error } = await supabase
      .from('credit_packs')
      .insert([pack])
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async updateCreditPack(id: string, updates: Partial<CreditPack>) {
    const { data, error } = await supabase
      .from('credit_packs')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async deleteCreditPack(id: string) {
    const { error } = await supabase
      .from('credit_packs')
      .delete()
      .eq('id', id);

    return { data: { message: 'Credit pack deleted' }, error: error ? new Error(error.message) : null };
  },

  async getSettings() {
    const { data, error } = await supabase
      .from('system_settings')
      .select('*')
      .order('key');

    return { data, error: error ? new Error(error.message) : null };
  },

  async updateSetting(id: string, value: unknown) {
    const { data, error } = await supabase
      .from('system_settings')
      .update({ value: value as Json })
      .eq('id', id)
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async upsertSetting(key: string, value: unknown, category: string = 'general', description?: string) {
    const { data, error } = await supabase
      .from('system_settings')
      .upsert(
        { key, value: value as Json, category, description: description || null },
        { onConflict: 'key' }
      )
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async getEmailTemplates() {
    const { data, error } = await supabase
      .from('email_templates')
      .select('*')
      .order('name');

    return { data, error: error ? new Error(error.message) : null };
  },

  async updateEmailTemplate(id: string, updates: { subject?: string; html_content?: string; text_content?: string | null; is_active?: boolean }) {
    const { data, error } = await supabase
      .from('email_templates')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async getPlugins() {
    const { data, error } = await supabase
      .from('plugins')
      .select('*')
      .order('name');

    return { data, error: error ? new Error(error.message) : null };
  },

  async updatePlugin(id: string, updates: { is_active?: boolean }) {
    const { data, error } = await supabase
      .from('plugins')
      .update(updates)
      .eq('id', id)
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async getApiConfigs() {
    const { data, error } = await supabase
      .from('api_configurations')
      .select('*')
      .order('name');

    return { data, error: error ? new Error(error.message) : null };
  },

  async createApiConfig(config: Omit<ApiConfig, 'id' | 'created_at'>) {
    const { data, error } = await supabase
      .from('api_configurations')
      .insert([config as any])
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async updateApiConfig(id: string, updates: Partial<ApiConfig>) {
    const { data, error } = await supabase
      .from('api_configurations')
      .update(updates as any)
      .eq('id', id)
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async deleteApiConfig(id: string) {
    const { error } = await supabase
      .from('api_configurations')
      .delete()
      .eq('id', id);

    return { data: { message: 'API config deleted' }, error: error ? new Error(error.message) : null };
  },

  async getInvoices() {
    const { data, error } = await supabase
      .from('invoices')
      .select('*')
      .order('created_at', { ascending: false });

    return { data, error: error ? new Error(error.message) : null };
  },

  async createInvoice(invoice: Omit<Invoice, 'id' | 'created_at' | 'paid_at'>) {
    const { data, error } = await supabase
      .from('invoices')
      .insert([invoice as any])
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async updateInvoice(id: string, updates: Partial<Invoice>) {
    const { data, error } = await supabase
      .from('invoices')
      .update(updates as any)
      .eq('id', id)
      .select()
      .single();

    return { data, error: error ? new Error(error.message) : null };
  },

  async getSettingsAuditLog() {
    const { data, error } = await supabase
      .from('settings_audit_log')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);

    return { data, error: error ? new Error(error.message) : null };
  },

  async checkAdminStatus() {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return { data: { isAdmin: false, role: 'user' }, error: null };

    const { data } = await supabase
      .from('user_roles')
      .select('role')
      .eq('user_id', user.id)
      .single();

    return { 
      data: { 
        isAdmin: data?.role === 'admin', 
        role: data?.role || 'user' 
      }, 
      error: null 
    };
  },
};

// ============ STORAGE API ============
export const storageApi = {
  async upload(bucket: string, path: string, file: File) {
    try {
      const { data, error } = await supabase.storage
        .from(bucket)
        .upload(path, file, {
          cacheControl: '3600',
          upsert: true,
        });

      if (error) {
        return { data: null, error: new Error(error.message) };
      }

      const { data: urlData } = supabase.storage
        .from(bucket)
        .getPublicUrl(data.path);

      return { 
        data: { url: urlData.publicUrl, path: data.path }, 
        error: null 
      };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  async delete(bucket: string, path: string) {
    try {
      const { error } = await supabase.storage.from(bucket).remove([path]);
      if (error) {
        return { data: null, error: new Error(error.message) };
      }
      return { data: { message: 'File deleted successfully' }, error: null };
    } catch (error) {
      return { data: null, error: error as Error };
    }
  },

  getPublicUrl(bucket: string, path: string): string {
    const { data } = supabase.storage.from(bucket).getPublicUrl(path);
    return data.publicUrl;
  },

  async list(bucket: string, folder?: string) {
    const { data, error } = await supabase.storage.from(bucket).list(folder);
    if (error) return [];
    return data;
  },
};

// ============ TYPES ============
export interface UserProfile {
  id: string;
  email: string | null;
  display_name: string | null;
  avatar_url: string | null;
  company_name: string | null;
  marketing_consent: boolean | null;
  marketing_consent_date: string | null;
  created_at: string;
  updated_at: string;
}

export interface UserCredits {
  id: string;
  user_id: string;
  monthly_credits: number;
  bonus_credits: number;
  credits_reset_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface SubscriptionPlan {
  id: string;
  name: string;
  tier: 'free' | 'pro' | 'enterprise';
  price_monthly: number;
  price_yearly: number;
  monthly_credits: number;
  features: unknown; // Json type from DB
  description: string | null;
  is_active: boolean;
}

export interface UserSubscription {
  id: string;
  plan_id: string;
  status: string;
  billing_cycle: string;
  current_period_end: string;
  current_period_start: string;
  cancel_at_period_end: boolean;
  plan?: SubscriptionPlan | null;
}

export interface CreditUsageRecord {
  id: string;
  user_id: string;
  amount: number;
  action_type: string;
  description: string | null;
  metadata: unknown; // Json type from DB
  created_at: string;
}

export interface AppProject {
  id: string;
  user_id: string;
  website_url: string;
  app_name: string;
  primary_color: string | null;
  accent_color: string | null;
  app_category: string | null;
  description: string | null;
  features: string[] | null;
  icon_style: string | null;
  navigation_style: string | null;
  splash_screen_style: string | null;
  build_status: string | null;
  created_at: string;
  updated_at: string;
}

export interface AppBuild {
  id: string;
  project_id: string | null;
  user_id: string;
  app_name: string;
  package_name: string;
  website_url: string;
  config: unknown; // Json type from DB
  status: string;
  progress: number;
  download_url: string | null;
  error_message: string | null;
  file_size_bytes: number | null;
  created_at: string;
  updated_at: string;
}

export interface CreditPack {
  id: string;
  name: string;
  credits: number;
  price: number;
  description: string | null;
  is_active: boolean;
  stripe_price_id?: string | null;
  created_at: string;
}

export interface AppTemplate {
  id: string;
  user_id: string;
  name: string;
  description: string | null;
  config: unknown; // Json type from DB
  created_at: string;
  updated_at: string;
}

// Additional types for admin
export interface UserWithDetails {
  id: string;
  email: string | null;
  display_name: string | null;
  avatar_url: string | null;
  company_name: string | null;
  created_at: string;
  role?: 'admin' | 'moderator' | 'user' | null;
  credits?: { monthly_credits: number; bonus_credits: number };
}

export interface Transaction {
  id: string;
  user_id: string;
  amount: number;
  currency: string;
  status: string;
  payment_method: string;
  transaction_type: string;
  created_at: string;
}

export interface BuildRecord {
  id: string;
  user_id: string;
  app_name: string;
  status: string;
  created_at: string;
}

export interface Plugin {
  id: string;
  name: string;
  slug: string;
  type: string;
  description: string | null;
  is_active: boolean;
  version: string | null;
  config: unknown; // Json type from DB
}

export interface SystemSetting {
  id: string;
  key: string;
  value: unknown; // Json type from DB
  category: string;
  description: string | null;
}

export interface EmailTemplate {
  id: string;
  name: string;
  subject: string;
  html_content: string;
  text_content: string | null;
  is_active: boolean;
  variables: unknown; // Json type from DB
}

export interface ApiConfig {
  id: string;
  name: string;
  provider: string;
  is_active: boolean;
  config: unknown; // Json type from DB
  api_key_masked: string | null;
  created_at: string;
}

export interface Invoice {
  id: string;
  user_id: string;
  invoice_number: string;
  amount: number;
  currency: string;
  status: string;
  items: unknown; // Json type from DB
  notes: string | null;
  due_date: string | null;
  paid_at: string | null;
  created_at: string;
}

export interface SettingsAuditLog {
  id: string;
  setting_key: string;
  old_value: unknown;
  new_value: unknown;
  change_type: string;
  changed_by: string | null;
  changed_by_email: string | null;
  created_at: string;
}

export interface AdminStats {
  totalUsers: number;
  totalBuilds: number;
  totalRevenue: number;
  monthlyRevenue: number;
  activeBuilds: number;
  activeSubscriptions: number;
  revenue: number;
  newUsersToday: number;
  buildsToday: number;
}

export interface AutomationConfig {
  id: string;
  project_id: string;
  user_id: string;
  workflow_type: string;
  config: unknown;
  is_enabled: boolean;
  run_count: number;
  last_run_at: string | null;
  next_run_at: string | null;
  created_at: string;
  updated_at: string;
}

export interface AutomationLog {
  id: string;
  automation_id: string;
  user_id: string;
  status: string;
  message: string | null;
  metadata: unknown;
  started_at: string;
  completed_at: string | null;
  created_at: string;
}

// ============ AI API (Placeholder) ============
export const aiApi = {
  async analyzeWebsite(url: string) {
    // This would call an edge function
    const { data, error } = await supabase.functions.invoke('analyze-website', {
      body: { url },
    });

    return { data, error: error ? new Error(error.message) : null };
  },
};

// ============ PROXY API (Placeholder) ============
export const proxyApi = {
  async fetchPreview(url: string) {
    // For now return a placeholder - would need edge function
    return { 
      data: { success: false, error: 'Proxy not available' }, 
      error: null 
    };
  },
};

// ============ STRIPE API ============
export const stripeApi = {
  async createSubscriptionCheckout(
    planId: string, 
    billingCycle: 'monthly' | 'yearly', 
    successUrl: string, 
    cancelUrl: string
  ) {
    const { data, error } = await supabase.functions.invoke('stripe-checkout', {
      body: {
        type: 'subscription',
        itemId: planId,
        billingCycle,
        successUrl,
        cancelUrl,
      },
    });

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data, error: null };
  },

  async createCreditsCheckout(packId: string, successUrl: string, cancelUrl: string) {
    const { data, error } = await supabase.functions.invoke('stripe-checkout', {
      body: {
        type: 'credits',
        itemId: packId,
        successUrl,
        cancelUrl,
      },
    });

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data, error: null };
  },

  async createPortalSession(returnUrl: string) {
    const { data, error } = await supabase.functions.invoke('stripe-portal', {
      body: { returnUrl },
    });

    if (error) {
      return { data: null, error: new Error(error.message) };
    }

    return { data, error: null };
  },
};
