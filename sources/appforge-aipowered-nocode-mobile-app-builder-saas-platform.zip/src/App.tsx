import { lazy, Suspense, useState, useEffect, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider, useAuth } from "@/contexts/AuthContext";
import { ThemeProvider } from "@/components/ThemeProvider";
import CookieConsent from "@/components/CookieConsent";
import { LoadingSpinner } from "@/components/ui/loading-spinner";
import { useSetupCheck } from "@/hooks/useSetupCheck";
import { useSystemSettings } from "@/hooks/useSystemSettings";
import Maintenance from "@/pages/Maintenance";
import CustomCSSInjector from "@/components/CustomCSSInjector";


// Lazy load all pages for code splitting
const Index = lazy(() => import("./pages/Index"));
const AppBuilder = lazy(() => import("./pages/AppBuilder"));
const Auth = lazy(() => import("./pages/Auth"));
const Dashboard = lazy(() => import("./pages/Dashboard"));
const Settings = lazy(() => import("./pages/Settings"));
const Subscription = lazy(() => import("./pages/Subscription"));
const Privacy = lazy(() => import("./pages/Privacy"));
const Terms = lazy(() => import("./pages/Terms"));
const Install = lazy(() => import("./pages/Install"));
const Admin = lazy(() => import("./pages/Admin"));
const AdminSetup = lazy(() => import("./pages/AdminSetup"));
const StyleGuide = lazy(() => import("./pages/StyleGuide"));
const BuildHistory = lazy(() => import("./pages/BuildHistory"));
const PaymentHistory = lazy(() => import("./pages/PaymentHistory"));
const Help = lazy(() => import("./pages/Help"));
const NotFound = lazy(() => import("./pages/NotFound"));

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
    },
  },
});

interface RouteGuardProps {
  children: ReactNode;
  needsSetup: boolean | null;
  setupLoading: boolean;
}

const ProtectedRoute = ({ children, needsSetup, setupLoading }: RouteGuardProps) => {
  const { user, session, loading } = useAuth();

  if (loading || setupLoading) {
    return <LoadingSpinner fullScreen />;
  }

  if (needsSetup) {
    return <Navigate to="/setup" replace />;
  }

  if (!user || !session) {
    return <Navigate to="/auth" replace />;
  }

  return <>{children}</>;
};

const PublicRoute = ({ children, needsSetup, setupLoading }: RouteGuardProps) => {
  if (setupLoading) {
    return <LoadingSpinner fullScreen />;
  }

  if (needsSetup) {
    return <Navigate to="/setup" replace />;
  }

  return <>{children}</>;
};

const SetupRoute = ({ children, needsSetup, setupLoading }: RouteGuardProps) => {
  if (setupLoading) {
    return <LoadingSpinner fullScreen />;
  }

  if (needsSetup === false) {
    return <Navigate to="/auth" replace />;
  }

  return <>{children}</>;
};

const AppRoutes = () => {
  const { needsSetup, loading: setupLoading } = useSetupCheck();
  const { settings, loaded: settingsLoaded } = useSystemSettings();
  const { user } = useAuth();
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    if (!user) {
      setIsAdmin(false);
      return;
    }

    supabase.rpc("get_user_role", { _user_id: user.id }).then(({ data }) => {
      setIsAdmin(data === "admin");
    });
  }, [user]);

  if (settingsLoaded && settings.maintenance_mode && !isAdmin) {
    return <Maintenance />;
  }

  return (
    <Suspense fallback={<LoadingSpinner fullScreen />}>
      <Routes>
        <Route
          path="/"
          element={
            <PublicRoute needsSetup={needsSetup} setupLoading={setupLoading}>
              <Index />
            </PublicRoute>
          }
        />
        <Route
          path="/auth"
          element={
            <PublicRoute needsSetup={needsSetup} setupLoading={setupLoading}>
              <Auth />
            </PublicRoute>
          }
        />

        <Route path="/privacy" element={<Privacy />} />
        <Route path="/terms" element={<Terms />} />
        <Route path="/install" element={<Install />} />
        <Route
          path="/setup"
          element={
            <SetupRoute needsSetup={needsSetup} setupLoading={setupLoading}>
              <AdminSetup />
            </SetupRoute>
          }
        />
        <Route
          path="/dashboard"
          element={
            <ProtectedRoute needsSetup={needsSetup} setupLoading={setupLoading}>
              <Dashboard />
            </ProtectedRoute>
          }
        />
        <Route
          path="/builder"
          element={
            <ProtectedRoute needsSetup={needsSetup} setupLoading={setupLoading}>
              <AppBuilder />
            </ProtectedRoute>
          }
        />
        <Route
          path="/settings"
          element={
            <ProtectedRoute needsSetup={needsSetup} setupLoading={setupLoading}>
              <Settings />
            </ProtectedRoute>
          }
        />
        <Route
          path="/subscription"
          element={
            <ProtectedRoute needsSetup={needsSetup} setupLoading={setupLoading}>
              <Subscription />
            </ProtectedRoute>
          }
        />
        <Route
          path="/admin"
          element={
            <ProtectedRoute needsSetup={needsSetup} setupLoading={setupLoading}>
              <Admin />
            </ProtectedRoute>
          }
        />
        <Route path="/style-guide" element={<StyleGuide />} />
        <Route
          path="/build-history"
          element={
            <ProtectedRoute needsSetup={needsSetup} setupLoading={setupLoading}>
              <BuildHistory />
            </ProtectedRoute>
          }
        />
        <Route
          path="/payment-history"
          element={
            <ProtectedRoute needsSetup={needsSetup} setupLoading={setupLoading}>
              <PaymentHistory />
            </ProtectedRoute>
          }
        />
        <Route path="/help" element={<Help />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </Suspense>
  );
};

const App = () => (
  <ThemeProvider>
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <CustomCSSInjector />
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <AuthProvider>
            <AppRoutes />
            
            <CookieConsent />
          </AuthProvider>
        </BrowserRouter>
      </TooltipProvider>
    </QueryClientProvider>
  </ThemeProvider>
);

export default App;

