export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.1"
  }
  public: {
    Tables: {
      api_configurations: {
        Row: {
          api_key_masked: string | null
          config: Json
          created_at: string
          id: string
          is_active: boolean
          last_used_at: string | null
          name: string
          provider: string
          rate_limit: number | null
          updated_at: string
          usage_count: number | null
        }
        Insert: {
          api_key_masked?: string | null
          config?: Json
          created_at?: string
          id?: string
          is_active?: boolean
          last_used_at?: string | null
          name: string
          provider: string
          rate_limit?: number | null
          updated_at?: string
          usage_count?: number | null
        }
        Update: {
          api_key_masked?: string | null
          config?: Json
          created_at?: string
          id?: string
          is_active?: boolean
          last_used_at?: string | null
          name?: string
          provider?: string
          rate_limit?: number | null
          updated_at?: string
          usage_count?: number | null
        }
        Relationships: []
      }
      app_builds: {
        Row: {
          app_name: string
          artifact_url: string | null
          cloud_build_id: string | null
          cloud_provider: string | null
          config: Json
          created_at: string
          download_url: string | null
          error_message: string | null
          file_size_bytes: number | null
          id: string
          package_name: string
          progress: number
          project_id: string | null
          status: string
          updated_at: string
          user_id: string
          website_url: string
        }
        Insert: {
          app_name: string
          artifact_url?: string | null
          cloud_build_id?: string | null
          cloud_provider?: string | null
          config?: Json
          created_at?: string
          download_url?: string | null
          error_message?: string | null
          file_size_bytes?: number | null
          id?: string
          package_name: string
          progress?: number
          project_id?: string | null
          status?: string
          updated_at?: string
          user_id: string
          website_url: string
        }
        Update: {
          app_name?: string
          artifact_url?: string | null
          cloud_build_id?: string | null
          cloud_provider?: string | null
          config?: Json
          created_at?: string
          download_url?: string | null
          error_message?: string | null
          file_size_bytes?: number | null
          id?: string
          package_name?: string
          progress?: number
          project_id?: string | null
          status?: string
          updated_at?: string
          user_id?: string
          website_url?: string
        }
        Relationships: [
          {
            foreignKeyName: "app_builds_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "app_projects"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "app_builds_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      app_projects: {
        Row: {
          accent_color: string | null
          app_category: string | null
          app_name: string
          build_status: string | null
          codemagic_connected: boolean
          created_at: string
          description: string | null
          features: string[] | null
          github_connected: boolean
          icon_style: string | null
          id: string
          navigation_style: string | null
          primary_color: string | null
          splash_screen_style: string | null
          updated_at: string
          user_id: string
          website_url: string
        }
        Insert: {
          accent_color?: string | null
          app_category?: string | null
          app_name: string
          build_status?: string | null
          codemagic_connected?: boolean
          created_at?: string
          description?: string | null
          features?: string[] | null
          github_connected?: boolean
          icon_style?: string | null
          id?: string
          navigation_style?: string | null
          primary_color?: string | null
          splash_screen_style?: string | null
          updated_at?: string
          user_id: string
          website_url: string
        }
        Update: {
          accent_color?: string | null
          app_category?: string | null
          app_name?: string
          build_status?: string | null
          codemagic_connected?: boolean
          created_at?: string
          description?: string | null
          features?: string[] | null
          github_connected?: boolean
          icon_style?: string | null
          id?: string
          navigation_style?: string | null
          primary_color?: string | null
          splash_screen_style?: string | null
          updated_at?: string
          user_id?: string
          website_url?: string
        }
        Relationships: [
          {
            foreignKeyName: "app_projects_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      app_templates: {
        Row: {
          config: Json
          created_at: string
          description: string | null
          id: string
          name: string
          updated_at: string
          user_id: string
        }
        Insert: {
          config: Json
          created_at?: string
          description?: string | null
          id?: string
          name: string
          updated_at?: string
          user_id: string
        }
        Update: {
          config?: Json
          created_at?: string
          description?: string | null
          id?: string
          name?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      automation_configs: {
        Row: {
          config: Json
          created_at: string
          id: string
          is_enabled: boolean
          last_run_at: string | null
          next_run_at: string | null
          project_id: string
          run_count: number
          updated_at: string
          user_id: string
          workflow_type: string
        }
        Insert: {
          config?: Json
          created_at?: string
          id?: string
          is_enabled?: boolean
          last_run_at?: string | null
          next_run_at?: string | null
          project_id: string
          run_count?: number
          updated_at?: string
          user_id: string
          workflow_type: string
        }
        Update: {
          config?: Json
          created_at?: string
          id?: string
          is_enabled?: boolean
          last_run_at?: string | null
          next_run_at?: string | null
          project_id?: string
          run_count?: number
          updated_at?: string
          user_id?: string
          workflow_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "automation_configs_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "app_projects"
            referencedColumns: ["id"]
          },
        ]
      }
      automation_logs: {
        Row: {
          automation_id: string
          completed_at: string | null
          created_at: string
          id: string
          message: string | null
          metadata: Json | null
          started_at: string
          status: string
          user_id: string
        }
        Insert: {
          automation_id: string
          completed_at?: string | null
          created_at?: string
          id?: string
          message?: string | null
          metadata?: Json | null
          started_at?: string
          status?: string
          user_id: string
        }
        Update: {
          automation_id?: string
          completed_at?: string | null
          created_at?: string
          id?: string
          message?: string | null
          metadata?: Json | null
          started_at?: string
          status?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "automation_logs_automation_id_fkey"
            columns: ["automation_id"]
            isOneToOne: false
            referencedRelation: "automation_configs"
            referencedColumns: ["id"]
          },
        ]
      }
      bank_transfer_requests: {
        Row: {
          admin_notes: string | null
          amount: number
          created_at: string
          credit_pack_id: string | null
          currency: string
          id: string
          plan_id: string | null
          proof_of_payment_url: string | null
          status: string
          transaction_id: string | null
          updated_at: string
          user_id: string
        }
        Insert: {
          admin_notes?: string | null
          amount: number
          created_at?: string
          credit_pack_id?: string | null
          currency?: string
          id?: string
          plan_id?: string | null
          proof_of_payment_url?: string | null
          status?: string
          transaction_id?: string | null
          updated_at?: string
          user_id: string
        }
        Update: {
          admin_notes?: string | null
          amount?: number
          created_at?: string
          credit_pack_id?: string | null
          currency?: string
          id?: string
          plan_id?: string | null
          proof_of_payment_url?: string | null
          status?: string
          transaction_id?: string | null
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "bank_transfer_requests_credit_pack_id_fkey"
            columns: ["credit_pack_id"]
            isOneToOne: false
            referencedRelation: "credit_packs"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bank_transfer_requests_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "bank_transfer_requests_transaction_id_fkey"
            columns: ["transaction_id"]
            isOneToOne: false
            referencedRelation: "payment_transactions"
            referencedColumns: ["id"]
          },
        ]
      }
      chat_messages: {
        Row: {
          content: string
          created_at: string
          id: string
          project_id: string | null
          role: string
          user_id: string
        }
        Insert: {
          content: string
          created_at?: string
          id?: string
          project_id?: string | null
          role: string
          user_id: string
        }
        Update: {
          content?: string
          created_at?: string
          id?: string
          project_id?: string | null
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "chat_messages_project_id_fkey"
            columns: ["project_id"]
            isOneToOne: false
            referencedRelation: "app_projects"
            referencedColumns: ["id"]
          },
        ]
      }
      consent_records: {
        Row: {
          consent_type: string
          consented: boolean
          created_at: string
          email: string | null
          id: string
          ip_address: string | null
          updated_at: string
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          consent_type: string
          consented?: boolean
          created_at?: string
          email?: string | null
          id?: string
          ip_address?: string | null
          updated_at?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          consent_type?: string
          consented?: boolean
          created_at?: string
          email?: string | null
          id?: string
          ip_address?: string | null
          updated_at?: string
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      credit_packs: {
        Row: {
          created_at: string
          credits: number
          description: string | null
          id: string
          is_active: boolean
          name: string
          price: number
          stripe_price_id: string | null
        }
        Insert: {
          created_at?: string
          credits: number
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          price: number
          stripe_price_id?: string | null
        }
        Update: {
          created_at?: string
          credits?: number
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          price?: number
          stripe_price_id?: string | null
        }
        Relationships: []
      }
      credit_usage_history: {
        Row: {
          action_type: string
          amount: number
          created_at: string
          description: string | null
          id: string
          metadata: Json | null
          user_id: string
        }
        Insert: {
          action_type: string
          amount: number
          created_at?: string
          description?: string | null
          id?: string
          metadata?: Json | null
          user_id: string
        }
        Update: {
          action_type?: string
          amount?: number
          created_at?: string
          description?: string | null
          id?: string
          metadata?: Json | null
          user_id?: string
        }
        Relationships: []
      }
      email_templates: {
        Row: {
          created_at: string
          html_content: string
          id: string
          is_active: boolean
          name: string
          subject: string
          text_content: string | null
          updated_at: string
          variables: Json | null
        }
        Insert: {
          created_at?: string
          html_content: string
          id?: string
          is_active?: boolean
          name: string
          subject: string
          text_content?: string | null
          updated_at?: string
          variables?: Json | null
        }
        Update: {
          created_at?: string
          html_content?: string
          id?: string
          is_active?: boolean
          name?: string
          subject?: string
          text_content?: string | null
          updated_at?: string
          variables?: Json | null
        }
        Relationships: []
      }
      invoices: {
        Row: {
          amount: number
          created_at: string
          currency: string
          due_date: string | null
          id: string
          invoice_number: string
          items: Json
          notes: string | null
          paid_at: string | null
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          currency?: string
          due_date?: string | null
          id?: string
          invoice_number: string
          items?: Json
          notes?: string | null
          paid_at?: string | null
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          currency?: string
          due_date?: string | null
          id?: string
          invoice_number?: string
          items?: Json
          notes?: string | null
          paid_at?: string | null
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      payment_gateway_configs: {
        Row: {
          created_at: string
          gateway: string
          id: string
          is_enabled: boolean | null
          is_test_mode: boolean | null
          live_config: Json | null
          sandbox_config: Json | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          gateway: string
          id?: string
          is_enabled?: boolean | null
          is_test_mode?: boolean | null
          live_config?: Json | null
          sandbox_config?: Json | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          gateway?: string
          id?: string
          is_enabled?: boolean | null
          is_test_mode?: boolean | null
          live_config?: Json | null
          sandbox_config?: Json | null
          updated_at?: string
        }
        Relationships: []
      }
      payment_transactions: {
        Row: {
          amount: number
          created_at: string
          currency: string
          external_transaction_id: string | null
          id: string
          metadata: Json | null
          payment_method: Database["public"]["Enums"]["payment_method"]
          paypal_order_id: string | null
          paypal_subscription_id: string | null
          reference_id: string | null
          status: Database["public"]["Enums"]["transaction_status"]
          transaction_type: string
          updated_at: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          currency?: string
          external_transaction_id?: string | null
          id?: string
          metadata?: Json | null
          payment_method: Database["public"]["Enums"]["payment_method"]
          paypal_order_id?: string | null
          paypal_subscription_id?: string | null
          reference_id?: string | null
          status?: Database["public"]["Enums"]["transaction_status"]
          transaction_type: string
          updated_at?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          currency?: string
          external_transaction_id?: string | null
          id?: string
          metadata?: Json | null
          payment_method?: Database["public"]["Enums"]["payment_method"]
          paypal_order_id?: string | null
          paypal_subscription_id?: string | null
          reference_id?: string | null
          status?: Database["public"]["Enums"]["transaction_status"]
          transaction_type?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      plugins: {
        Row: {
          config: Json | null
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          name: string
          slug: string
          type: string
          updated_at: string
          version: string | null
        }
        Insert: {
          config?: Json | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name: string
          slug: string
          type: string
          updated_at?: string
          version?: string | null
        }
        Update: {
          config?: Json | null
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          name?: string
          slug?: string
          type?: string
          updated_at?: string
          version?: string | null
        }
        Relationships: []
      }
      profiles: {
        Row: {
          avatar_url: string | null
          company_name: string | null
          created_at: string
          display_name: string | null
          email: string | null
          id: string
          marketing_consent: boolean | null
          marketing_consent_date: string | null
          stripe_customer_id: string | null
          updated_at: string
        }
        Insert: {
          avatar_url?: string | null
          company_name?: string | null
          created_at?: string
          display_name?: string | null
          email?: string | null
          id: string
          marketing_consent?: boolean | null
          marketing_consent_date?: string | null
          stripe_customer_id?: string | null
          updated_at?: string
        }
        Update: {
          avatar_url?: string | null
          company_name?: string | null
          created_at?: string
          display_name?: string | null
          email?: string | null
          id?: string
          marketing_consent?: boolean | null
          marketing_consent_date?: string | null
          stripe_customer_id?: string | null
          updated_at?: string
        }
        Relationships: []
      }
      settings_audit_log: {
        Row: {
          change_type: string
          changed_by: string | null
          changed_by_email: string | null
          created_at: string
          id: string
          new_value: Json
          old_value: Json | null
          setting_id: string | null
          setting_key: string
        }
        Insert: {
          change_type?: string
          changed_by?: string | null
          changed_by_email?: string | null
          created_at?: string
          id?: string
          new_value: Json
          old_value?: Json | null
          setting_id?: string | null
          setting_key: string
        }
        Update: {
          change_type?: string
          changed_by?: string | null
          changed_by_email?: string | null
          created_at?: string
          id?: string
          new_value?: Json
          old_value?: Json | null
          setting_id?: string | null
          setting_key?: string
        }
        Relationships: [
          {
            foreignKeyName: "settings_audit_log_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "settings_audit_log_setting_id_fkey"
            columns: ["setting_id"]
            isOneToOne: false
            referencedRelation: "system_settings"
            referencedColumns: ["id"]
          },
        ]
      }
      subscription_plans: {
        Row: {
          created_at: string
          description: string | null
          features: Json
          id: string
          is_active: boolean
          monthly_credits: number
          name: string
          paypal_plan_id: string | null
          paypal_product_id: string | null
          paypal_yearly_plan_id: string | null
          price_monthly: number
          price_yearly: number
          stripe_price_id: string | null
          stripe_yearly_price_id: string | null
          tier: Database["public"]["Enums"]["subscription_tier"]
          updated_at: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          features?: Json
          id?: string
          is_active?: boolean
          monthly_credits?: number
          name: string
          paypal_plan_id?: string | null
          paypal_product_id?: string | null
          paypal_yearly_plan_id?: string | null
          price_monthly?: number
          price_yearly?: number
          stripe_price_id?: string | null
          stripe_yearly_price_id?: string | null
          tier: Database["public"]["Enums"]["subscription_tier"]
          updated_at?: string
        }
        Update: {
          created_at?: string
          description?: string | null
          features?: Json
          id?: string
          is_active?: boolean
          monthly_credits?: number
          name?: string
          paypal_plan_id?: string | null
          paypal_product_id?: string | null
          paypal_yearly_plan_id?: string | null
          price_monthly?: number
          price_yearly?: number
          stripe_price_id?: string | null
          stripe_yearly_price_id?: string | null
          tier?: Database["public"]["Enums"]["subscription_tier"]
          updated_at?: string
        }
        Relationships: []
      }
      system_settings: {
        Row: {
          category: string
          description: string | null
          id: string
          key: string
          updated_at: string
          updated_by: string | null
          value: Json
        }
        Insert: {
          category?: string
          description?: string | null
          id?: string
          key: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Update: {
          category?: string
          description?: string | null
          id?: string
          key?: string
          updated_at?: string
          updated_by?: string | null
          value?: Json
        }
        Relationships: []
      }
      user_credits: {
        Row: {
          bonus_credits: number
          created_at: string
          credits_reset_at: string | null
          id: string
          monthly_credits: number
          updated_at: string
          user_id: string
        }
        Insert: {
          bonus_credits?: number
          created_at?: string
          credits_reset_at?: string | null
          id?: string
          monthly_credits?: number
          updated_at?: string
          user_id: string
        }
        Update: {
          bonus_credits?: number
          created_at?: string
          credits_reset_at?: string | null
          id?: string
          monthly_credits?: number
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      user_subscriptions: {
        Row: {
          billing_cycle: string
          cancel_at_period_end: boolean
          created_at: string
          current_period_end: string
          current_period_start: string
          external_subscription_id: string | null
          id: string
          payment_method: Database["public"]["Enums"]["payment_method"] | null
          plan_id: string
          status: string
          updated_at: string
          user_id: string
        }
        Insert: {
          billing_cycle?: string
          cancel_at_period_end?: boolean
          created_at?: string
          current_period_end: string
          current_period_start?: string
          external_subscription_id?: string | null
          id?: string
          payment_method?: Database["public"]["Enums"]["payment_method"] | null
          plan_id: string
          status?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          billing_cycle?: string
          cancel_at_period_end?: boolean
          created_at?: string
          current_period_end?: string
          current_period_start?: string
          external_subscription_id?: string | null
          id?: string
          payment_method?: Database["public"]["Enums"]["payment_method"] | null
          plan_id?: string
          status?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_subscriptions_plan_id_fkey"
            columns: ["plan_id"]
            isOneToOne: false
            referencedRelation: "subscription_plans"
            referencedColumns: ["id"]
          },
        ]
      }
      webhook_event_logs: {
        Row: {
          created_at: string
          error_message: string | null
          event_id: string | null
          event_type: string
          gateway: string
          id: string
          payload: Json | null
          processing_time_ms: number | null
          response_status: number | null
          status: string
        }
        Insert: {
          created_at?: string
          error_message?: string | null
          event_id?: string | null
          event_type: string
          gateway: string
          id?: string
          payload?: Json | null
          processing_time_ms?: number | null
          response_status?: number | null
          status?: string
        }
        Update: {
          created_at?: string
          error_message?: string | null
          event_id?: string | null
          event_type?: string
          gateway?: string
          id?: string
          payload?: Json | null
          processing_time_ms?: number | null
          response_status?: number | null
          status?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      add_credits: {
        Args: {
          p_action_type?: string
          p_amount: number
          p_credit_type?: string
          p_description?: string
          p_user_id: string
        }
        Returns: boolean
      }
      get_user_role: {
        Args: { _user_id: string }
        Returns: Database["public"]["Enums"]["app_role"]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      no_admin_exists: { Args: never; Returns: boolean }
      use_credits:
        | { Args: { p_amount: number; p_user_id: string }; Returns: boolean }
        | {
            Args: {
              p_action_type?: string
              p_amount: number
              p_description?: string
              p_user_id: string
            }
            Returns: boolean
          }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      payment_method: "paypal" | "crypto" | "bank_transfer" | "stripe"
      subscription_tier: "free" | "pro" | "enterprise"
      transaction_status: "pending" | "completed" | "failed" | "refunded"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      payment_method: ["paypal", "crypto", "bank_transfer", "stripe"],
      subscription_tier: ["free", "pro", "enterprise"],
      transaction_status: ["pending", "completed", "failed", "refunded"],
    },
  },
} as const
