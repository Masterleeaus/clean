
-- Allow admins to manage credit packs (INSERT, UPDATE, DELETE)
CREATE POLICY "Admins can insert credit packs"
ON public.credit_packs
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update credit packs"
ON public.credit_packs
FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete credit packs"
ON public.credit_packs
FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));
