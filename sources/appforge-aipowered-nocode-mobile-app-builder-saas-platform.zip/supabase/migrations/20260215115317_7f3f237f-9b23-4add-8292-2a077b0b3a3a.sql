
CREATE POLICY "Admins can insert payment transactions"
ON public.payment_transactions
FOR INSERT
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update payment transactions"
ON public.payment_transactions
FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can delete payment transactions"
ON public.payment_transactions
FOR DELETE
USING (has_role(auth.uid(), 'admin'::app_role));
