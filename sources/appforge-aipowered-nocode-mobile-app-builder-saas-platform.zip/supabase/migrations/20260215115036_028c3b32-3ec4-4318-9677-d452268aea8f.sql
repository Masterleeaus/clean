-- Allow admins to view all payment transactions (needed for revenue stats)
CREATE POLICY "Admins can view all payment transactions"
ON public.payment_transactions
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to view all builds (needed for build stats)
CREATE POLICY "Admins can view all builds"
ON public.app_builds
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to view all user subscriptions (needed for MRR/subscriber stats)
CREATE POLICY "Admins can view all subscriptions"
ON public.user_subscriptions
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to view all user credits (needed for user management)
CREATE POLICY "Admins can view all user credits"
ON public.user_credits
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

-- Allow admins to view all projects (needed for project stats)
CREATE POLICY "Admins can view all projects"
ON public.app_projects
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));