
-- Drop any existing storage policies to avoid conflicts
DO $$
DECLARE
  pol RECORD;
BEGIN
  FOR pol IN 
    SELECT policyname FROM pg_policies WHERE tablename = 'objects' AND schemaname = 'storage'
  LOOP
    EXECUTE format('DROP POLICY IF EXISTS %I ON storage.objects', pol.policyname);
  END LOOP;
END $$;

-- Public buckets: anyone can read
CREATE POLICY "Public read access for avatars"
ON storage.objects FOR SELECT
USING (bucket_id = 'avatars');

CREATE POLICY "Public read access for app-icons"
ON storage.objects FOR SELECT
USING (bucket_id = 'app-icons');

CREATE POLICY "Public read access for splash-screens"
ON storage.objects FOR SELECT
USING (bucket_id = 'splash-screens');

CREATE POLICY "Public read access for apk-builds"
ON storage.objects FOR SELECT
USING (bucket_id = 'apk-builds');

-- Private bucket: owner read only
CREATE POLICY "Owner read access for project-assets"
ON storage.objects FOR SELECT
USING (bucket_id = 'project-assets' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Upload policies
CREATE POLICY "Users can upload avatars"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can upload app-icons"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'app-icons' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can upload splash-screens"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'splash-screens' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can upload apk-builds"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'apk-builds' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can upload project-assets"
ON storage.objects FOR INSERT
WITH CHECK (bucket_id = 'project-assets' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Update policies
CREATE POLICY "Users can update their own avatars"
ON storage.objects FOR UPDATE
USING (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their own app-icons"
ON storage.objects FOR UPDATE
USING (bucket_id = 'app-icons' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their own splash-screens"
ON storage.objects FOR UPDATE
USING (bucket_id = 'splash-screens' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their own apk-builds"
ON storage.objects FOR UPDATE
USING (bucket_id = 'apk-builds' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can update their own project-assets"
ON storage.objects FOR UPDATE
USING (bucket_id = 'project-assets' AND auth.uid()::text = (storage.foldername(name))[1]);

-- Delete policies
CREATE POLICY "Users can delete their own avatars"
ON storage.objects FOR DELETE
USING (bucket_id = 'avatars' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own app-icons"
ON storage.objects FOR DELETE
USING (bucket_id = 'app-icons' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own splash-screens"
ON storage.objects FOR DELETE
USING (bucket_id = 'splash-screens' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own apk-builds"
ON storage.objects FOR DELETE
USING (bucket_id = 'apk-builds' AND auth.uid()::text = (storage.foldername(name))[1]);

CREATE POLICY "Users can delete their own project-assets"
ON storage.objects FOR DELETE
USING (bucket_id = 'project-assets' AND auth.uid()::text = (storage.foldername(name))[1]);
