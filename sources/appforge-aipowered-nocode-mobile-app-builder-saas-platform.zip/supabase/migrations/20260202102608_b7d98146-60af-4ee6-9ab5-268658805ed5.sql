-- Add PayPal billing plan IDs to subscription_plans table
ALTER TABLE public.subscription_plans
ADD COLUMN IF NOT EXISTS paypal_plan_id TEXT,
ADD COLUMN IF NOT EXISTS paypal_yearly_plan_id TEXT,
ADD COLUMN IF NOT EXISTS paypal_product_id TEXT;

-- Add comments for documentation
COMMENT ON COLUMN public.subscription_plans.paypal_plan_id IS 'PayPal billing plan ID for monthly subscriptions';
COMMENT ON COLUMN public.subscription_plans.paypal_yearly_plan_id IS 'PayPal billing plan ID for yearly subscriptions';
COMMENT ON COLUMN public.subscription_plans.paypal_product_id IS 'PayPal product ID linked to this subscription plan';