-- Add Stripe-related columns to profiles table
ALTER TABLE public.profiles 
ADD COLUMN IF NOT EXISTS stripe_customer_id TEXT UNIQUE;

-- Add Stripe price ID columns to subscription_plans table  
ALTER TABLE public.subscription_plans
ADD COLUMN IF NOT EXISTS stripe_price_id TEXT,
ADD COLUMN IF NOT EXISTS stripe_yearly_price_id TEXT;

-- Add Stripe price ID column to credit_packs table
ALTER TABLE public.credit_packs
ADD COLUMN IF NOT EXISTS stripe_price_id TEXT;

-- Create index on stripe_customer_id for faster lookups
CREATE INDEX IF NOT EXISTS idx_profiles_stripe_customer_id 
ON public.profiles(stripe_customer_id) WHERE stripe_customer_id IS NOT NULL;

-- Create index on external_subscription_id for webhook lookups
CREATE INDEX IF NOT EXISTS idx_user_subscriptions_external_id 
ON public.user_subscriptions(external_subscription_id) WHERE external_subscription_id IS NOT NULL;