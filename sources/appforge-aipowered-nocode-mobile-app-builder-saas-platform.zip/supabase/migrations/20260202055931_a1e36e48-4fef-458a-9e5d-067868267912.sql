-- Add RLS policies for admins to manage bank transfer requests
CREATE POLICY "Admins can view all bank transfer requests"
ON public.bank_transfer_requests
FOR SELECT
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins can update bank transfer requests"
ON public.bank_transfer_requests
FOR UPDATE
USING (has_role(auth.uid(), 'admin'::app_role));