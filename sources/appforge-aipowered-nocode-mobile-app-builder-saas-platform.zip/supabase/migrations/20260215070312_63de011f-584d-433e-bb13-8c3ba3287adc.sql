-- Allow admins to manage subscription plans
CREATE POLICY "Admins can insert subscription plans"
ON public.subscription_plans FOR INSERT
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update subscription plans"
ON public.subscription_plans FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete subscription plans"
ON public.subscription_plans FOR DELETE
USING (public.has_role(auth.uid(), 'admin'));

-- Also allow admins to view all plans (including inactive)
CREATE POLICY "Admins can view all subscription plans"
ON public.subscription_plans FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

-- Allow admins to view all credit packs (including inactive)
CREATE POLICY "Admins can view all credit packs"
ON public.credit_packs FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));