CREATE EXTENSION IF NOT EXISTS "pg_graphql";
CREATE EXTENSION IF NOT EXISTS "pg_stat_statements" WITH SCHEMA "extensions";
CREATE EXTENSION IF NOT EXISTS "pgcrypto" WITH SCHEMA "extensions";
CREATE EXTENSION IF NOT EXISTS "plpgsql";
CREATE EXTENSION IF NOT EXISTS "supabase_vault";
CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA "extensions";
BEGIN;

--
-- PostgreSQL database dump
--


-- Dumped from database version 17.6
-- Dumped by pg_dump version 18.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--



--
-- Name: app_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.app_role AS ENUM (
    'admin',
    'moderator',
    'user'
);


--
-- Name: payment_method; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.payment_method AS ENUM (
    'paypal',
    'crypto',
    'bank_transfer',
    'stripe'
);


--
-- Name: subscription_tier; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.subscription_tier AS ENUM (
    'free',
    'pro',
    'enterprise'
);


--
-- Name: transaction_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.transaction_status AS ENUM (
    'pending',
    'completed',
    'failed',
    'refunded'
);


--
-- Name: add_credits(uuid, integer, text, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.add_credits(p_user_id uuid, p_amount integer, p_credit_type text DEFAULT 'bonus'::text, p_action_type text DEFAULT 'purchase'::text, p_description text DEFAULT NULL::text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  IF p_credit_type = 'monthly' THEN
    UPDATE public.user_credits
    SET monthly_credits = monthly_credits + p_amount,
        updated_at = now()
    WHERE user_id = p_user_id;
  ELSE
    UPDATE public.user_credits
    SET bonus_credits = bonus_credits + p_amount,
        updated_at = now()
    WHERE user_id = p_user_id;
  END IF;
  
  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;
  
  -- Log the addition (negative amount indicates credit added)
  INSERT INTO public.credit_usage_history (user_id, amount, action_type, description)
  VALUES (p_user_id, -p_amount, p_action_type, p_description);
  
  RETURN TRUE;
END;
$$;


--
-- Name: get_user_role(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.get_user_role(_user_id uuid) RETURNS public.app_role
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT role
  FROM public.user_roles
  WHERE user_id = _user_id
  LIMIT 1
$$;


--
-- Name: handle_new_user(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name)
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data ->> 'display_name', split_part(NEW.email, '@', 1))
  );
  RETURN NEW;
END;
$$;


--
-- Name: handle_new_user_credits(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.handle_new_user_credits() RETURNS trigger
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  free_plan_id UUID;
BEGIN
  -- Get the free plan ID
  SELECT id INTO free_plan_id FROM public.subscription_plans WHERE tier = 'free' LIMIT 1;
  
  -- Create user credits record
  INSERT INTO public.user_credits (user_id, monthly_credits, bonus_credits, credits_reset_at)
  VALUES (NEW.id, 5, 0, now() + interval '1 month');
  
  -- Create default free subscription
  INSERT INTO public.user_subscriptions (user_id, plan_id, current_period_end)
  VALUES (NEW.id, free_plan_id, now() + interval '1 month');
  
  RETURN NEW;
END;
$$;


--
-- Name: has_role(uuid, public.app_role); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.has_role(_user_id uuid, _role public.app_role) RETURNS boolean
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.user_roles
    WHERE user_id = _user_id
      AND role = _role
  )
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'public'
    AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$;


--
-- Name: use_credits(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.use_credits(p_user_id uuid, p_amount integer) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  v_monthly INTEGER;
  v_bonus INTEGER;
  v_total INTEGER;
  v_remaining INTEGER;
BEGIN
  -- Get current credits
  SELECT monthly_credits, bonus_credits INTO v_monthly, v_bonus
  FROM public.user_credits
  WHERE user_id = p_user_id;
  
  v_total := COALESCE(v_monthly, 0) + COALESCE(v_bonus, 0);
  
  -- Check if enough credits
  IF v_total < p_amount THEN
    RETURN FALSE;
  END IF;
  
  v_remaining := p_amount;
  
  -- Use monthly credits first
  IF v_monthly >= v_remaining THEN
    UPDATE public.user_credits
    SET monthly_credits = monthly_credits - v_remaining,
        updated_at = now()
    WHERE user_id = p_user_id;
  ELSE
    -- Use all monthly credits, then bonus credits
    v_remaining := v_remaining - v_monthly;
    UPDATE public.user_credits
    SET monthly_credits = 0,
        bonus_credits = bonus_credits - v_remaining,
        updated_at = now()
    WHERE user_id = p_user_id;
  END IF;
  
  RETURN TRUE;
END;
$$;


--
-- Name: use_credits(uuid, integer, text, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.use_credits(p_user_id uuid, p_amount integer, p_action_type text DEFAULT 'app_build'::text, p_description text DEFAULT NULL::text) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
DECLARE
  v_total_credits INTEGER;
  v_monthly INTEGER;
  v_bonus INTEGER;
  v_remaining INTEGER;
BEGIN
  -- Get current credits
  SELECT monthly_credits, bonus_credits INTO v_monthly, v_bonus
  FROM public.user_credits
  WHERE user_id = p_user_id
  FOR UPDATE;
  
  IF NOT FOUND THEN
    RETURN FALSE;
  END IF;
  
  v_total_credits := v_monthly + v_bonus;
  
  IF v_total_credits < p_amount THEN
    RETURN FALSE;
  END IF;
  
  -- Deduct from bonus first, then monthly
  v_remaining := p_amount;
  
  IF v_bonus >= v_remaining THEN
    UPDATE public.user_credits
    SET bonus_credits = bonus_credits - v_remaining,
        updated_at = now()
    WHERE user_id = p_user_id;
  ELSE
    v_remaining := v_remaining - v_bonus;
    UPDATE public.user_credits
    SET bonus_credits = 0,
        monthly_credits = monthly_credits - v_remaining,
        updated_at = now()
    WHERE user_id = p_user_id;
  END IF;
  
  -- Log the usage
  INSERT INTO public.credit_usage_history (user_id, amount, action_type, description)
  VALUES (p_user_id, p_amount, p_action_type, p_description);
  
  RETURN TRUE;
END;
$$;


SET default_table_access_method = heap;

--
-- Name: api_configurations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_configurations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    provider text NOT NULL,
    api_key_masked text,
    is_active boolean DEFAULT false NOT NULL,
    rate_limit integer DEFAULT 1000,
    usage_count integer DEFAULT 0,
    last_used_at timestamp with time zone,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: app_builds; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_builds (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    project_id uuid,
    website_url text NOT NULL,
    app_name text NOT NULL,
    package_name text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    progress integer DEFAULT 0 NOT NULL,
    download_url text,
    file_size_bytes bigint,
    error_message text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT app_builds_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'building'::text, 'complete'::text, 'failed'::text])))
);


--
-- Name: app_projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_projects (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    website_url text NOT NULL,
    app_name text NOT NULL,
    primary_color text DEFAULT '#22D3EE'::text,
    accent_color text DEFAULT '#A855F7'::text,
    navigation_style text DEFAULT 'bottom-nav'::text,
    features text[] DEFAULT '{}'::text[],
    app_category text,
    description text,
    icon_style text DEFAULT 'modern'::text,
    splash_screen_style text DEFAULT 'centered-logo'::text,
    build_status text DEFAULT 'draft'::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: app_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.app_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    config jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: automation_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_configs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    project_id uuid NOT NULL,
    user_id uuid NOT NULL,
    workflow_type text NOT NULL,
    is_enabled boolean DEFAULT true NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_run_at timestamp with time zone,
    next_run_at timestamp with time zone,
    run_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.automation_configs REPLICA IDENTITY FULL;


--
-- Name: automation_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    automation_id uuid NOT NULL,
    user_id uuid NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    message text,
    metadata jsonb DEFAULT '{}'::jsonb,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.automation_logs REPLICA IDENTITY FULL;


--
-- Name: bank_transfer_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bank_transfer_requests (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    transaction_id uuid,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    plan_id uuid,
    credit_pack_id uuid,
    status text DEFAULT 'pending'::text NOT NULL,
    proof_of_payment_url text,
    admin_notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.chat_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    project_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT chat_messages_role_check CHECK ((role = ANY (ARRAY['user'::text, 'assistant'::text])))
);


--
-- Name: consent_records; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.consent_records (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid,
    email text,
    consent_type text NOT NULL,
    consented boolean DEFAULT false NOT NULL,
    ip_address text,
    user_agent text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: credit_packs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_packs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    credits integer NOT NULL,
    price numeric(10,2) NOT NULL,
    description text,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: credit_usage_history; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.credit_usage_history (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    amount integer NOT NULL,
    action_type text NOT NULL,
    description text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: email_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    subject text NOT NULL,
    html_content text NOT NULL,
    text_content text,
    variables jsonb DEFAULT '[]'::jsonb,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    invoice_number text NOT NULL,
    user_id uuid NOT NULL,
    amount numeric NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    due_date timestamp with time zone,
    paid_at timestamp with time zone,
    items jsonb DEFAULT '[]'::jsonb NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: payment_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.payment_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    amount numeric(10,2) NOT NULL,
    currency text DEFAULT 'USD'::text NOT NULL,
    payment_method public.payment_method NOT NULL,
    status public.transaction_status DEFAULT 'pending'::public.transaction_status NOT NULL,
    transaction_type text NOT NULL,
    reference_id text,
    external_transaction_id text,
    metadata jsonb DEFAULT '{}'::jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: plugins; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.plugins (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    type text NOT NULL,
    description text,
    config jsonb DEFAULT '{}'::jsonb,
    is_active boolean DEFAULT false NOT NULL,
    version text DEFAULT '1.0.0'::text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: profiles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.profiles (
    id uuid NOT NULL,
    email text,
    display_name text,
    avatar_url text,
    company_name text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    marketing_consent boolean DEFAULT false,
    marketing_consent_date timestamp with time zone
);


--
-- Name: settings_audit_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings_audit_log (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    setting_id uuid,
    setting_key text NOT NULL,
    old_value jsonb,
    new_value jsonb NOT NULL,
    changed_by uuid,
    changed_by_email text,
    change_type text DEFAULT 'update'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: subscription_plans; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.subscription_plans (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tier public.subscription_tier NOT NULL,
    name text NOT NULL,
    description text,
    price_monthly numeric(10,2) DEFAULT 0 NOT NULL,
    price_yearly numeric(10,2) DEFAULT 0 NOT NULL,
    monthly_credits integer DEFAULT 0 NOT NULL,
    features jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: system_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_settings (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    key text NOT NULL,
    value jsonb DEFAULT '{}'::jsonb NOT NULL,
    category text DEFAULT 'general'::text NOT NULL,
    description text,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_by uuid
);


--
-- Name: user_credits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_credits (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    monthly_credits integer DEFAULT 0 NOT NULL,
    bonus_credits integer DEFAULT 0 NOT NULL,
    credits_reset_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    role public.app_role NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: user_subscriptions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_subscriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    user_id uuid NOT NULL,
    plan_id uuid NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    billing_cycle text DEFAULT 'monthly'::text NOT NULL,
    current_period_start timestamp with time zone DEFAULT now() NOT NULL,
    current_period_end timestamp with time zone NOT NULL,
    cancel_at_period_end boolean DEFAULT false NOT NULL,
    payment_method public.payment_method,
    external_subscription_id text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: api_configurations api_configurations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_configurations
    ADD CONSTRAINT api_configurations_pkey PRIMARY KEY (id);


--
-- Name: app_builds app_builds_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_builds
    ADD CONSTRAINT app_builds_pkey PRIMARY KEY (id);


--
-- Name: app_projects app_projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_projects
    ADD CONSTRAINT app_projects_pkey PRIMARY KEY (id);


--
-- Name: app_projects app_projects_user_id_website_url_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_projects
    ADD CONSTRAINT app_projects_user_id_website_url_key UNIQUE (user_id, website_url);


--
-- Name: app_templates app_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_templates
    ADD CONSTRAINT app_templates_pkey PRIMARY KEY (id);


--
-- Name: automation_configs automation_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_configs
    ADD CONSTRAINT automation_configs_pkey PRIMARY KEY (id);


--
-- Name: automation_configs automation_configs_project_id_workflow_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_configs
    ADD CONSTRAINT automation_configs_project_id_workflow_type_key UNIQUE (project_id, workflow_type);


--
-- Name: automation_configs automation_configs_project_workflow_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_configs
    ADD CONSTRAINT automation_configs_project_workflow_key UNIQUE (project_id, workflow_type);


--
-- Name: automation_logs automation_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_logs
    ADD CONSTRAINT automation_logs_pkey PRIMARY KEY (id);


--
-- Name: bank_transfer_requests bank_transfer_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_transfer_requests
    ADD CONSTRAINT bank_transfer_requests_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: consent_records consent_records_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_records
    ADD CONSTRAINT consent_records_pkey PRIMARY KEY (id);


--
-- Name: credit_packs credit_packs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_packs
    ADD CONSTRAINT credit_packs_pkey PRIMARY KEY (id);


--
-- Name: credit_usage_history credit_usage_history_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.credit_usage_history
    ADD CONSTRAINT credit_usage_history_pkey PRIMARY KEY (id);


--
-- Name: email_templates email_templates_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_name_key UNIQUE (name);


--
-- Name: email_templates email_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_templates
    ADD CONSTRAINT email_templates_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_invoice_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_invoice_number_key UNIQUE (invoice_number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: payment_transactions payment_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_pkey PRIMARY KEY (id);


--
-- Name: plugins plugins_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_pkey PRIMARY KEY (id);


--
-- Name: plugins plugins_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.plugins
    ADD CONSTRAINT plugins_slug_key UNIQUE (slug);


--
-- Name: profiles profiles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_pkey PRIMARY KEY (id);


--
-- Name: settings_audit_log settings_audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings_audit_log
    ADD CONSTRAINT settings_audit_log_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_pkey PRIMARY KEY (id);


--
-- Name: subscription_plans subscription_plans_tier_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.subscription_plans
    ADD CONSTRAINT subscription_plans_tier_key UNIQUE (tier);


--
-- Name: system_settings system_settings_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_key_key UNIQUE (key);


--
-- Name: system_settings system_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_pkey PRIMARY KEY (id);


--
-- Name: user_credits user_credits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credits
    ADD CONSTRAINT user_credits_pkey PRIMARY KEY (id);


--
-- Name: user_credits user_credits_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credits
    ADD CONSTRAINT user_credits_user_id_key UNIQUE (user_id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_user_id_role_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_role_key UNIQUE (user_id, role);


--
-- Name: user_subscriptions user_subscriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_pkey PRIMARY KEY (id);


--
-- Name: user_subscriptions user_subscriptions_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_user_id_key UNIQUE (user_id);


--
-- Name: idx_automation_configs_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_automation_configs_project ON public.automation_configs USING btree (project_id);


--
-- Name: idx_automation_configs_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_automation_configs_type ON public.automation_configs USING btree (workflow_type);


--
-- Name: idx_automation_configs_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_automation_configs_user ON public.automation_configs USING btree (user_id);


--
-- Name: idx_automation_logs_automation; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_automation_logs_automation ON public.automation_logs USING btree (automation_id);


--
-- Name: idx_automation_logs_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_automation_logs_status ON public.automation_logs USING btree (status);


--
-- Name: idx_chat_messages_user_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_chat_messages_user_project ON public.chat_messages USING btree (user_id, project_id, created_at DESC);


--
-- Name: idx_consent_records_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_consent_records_email ON public.consent_records USING btree (email);


--
-- Name: idx_consent_records_user_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_consent_records_user_id ON public.consent_records USING btree (user_id);


--
-- Name: idx_credit_usage_action; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_usage_action ON public.credit_usage_history USING btree (action_type);


--
-- Name: idx_credit_usage_user_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_credit_usage_user_date ON public.credit_usage_history USING btree (user_id, created_at DESC);


--
-- Name: idx_settings_audit_log_created_at; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_settings_audit_log_created_at ON public.settings_audit_log USING btree (created_at DESC);


--
-- Name: idx_settings_audit_log_setting_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_settings_audit_log_setting_id ON public.settings_audit_log USING btree (setting_id);


--
-- Name: api_configurations update_api_configurations_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_api_configurations_updated_at BEFORE UPDATE ON public.api_configurations FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: app_builds update_app_builds_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_app_builds_updated_at BEFORE UPDATE ON public.app_builds FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: app_projects update_app_projects_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_app_projects_updated_at BEFORE UPDATE ON public.app_projects FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: app_templates update_app_templates_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_app_templates_updated_at BEFORE UPDATE ON public.app_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: automation_configs update_automation_configs_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_automation_configs_updated_at BEFORE UPDATE ON public.automation_configs FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: bank_transfer_requests update_bank_transfer_requests_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_bank_transfer_requests_updated_at BEFORE UPDATE ON public.bank_transfer_requests FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: consent_records update_consent_records_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_consent_records_updated_at BEFORE UPDATE ON public.consent_records FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: email_templates update_email_templates_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_email_templates_updated_at BEFORE UPDATE ON public.email_templates FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: invoices update_invoices_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_invoices_updated_at BEFORE UPDATE ON public.invoices FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: payment_transactions update_payment_transactions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_payment_transactions_updated_at BEFORE UPDATE ON public.payment_transactions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: plugins update_plugins_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_plugins_updated_at BEFORE UPDATE ON public.plugins FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: profiles update_profiles_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_profiles_updated_at BEFORE UPDATE ON public.profiles FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: subscription_plans update_subscription_plans_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_subscription_plans_updated_at BEFORE UPDATE ON public.subscription_plans FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: system_settings update_system_settings_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_system_settings_updated_at BEFORE UPDATE ON public.system_settings FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: user_credits update_user_credits_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_user_credits_updated_at BEFORE UPDATE ON public.user_credits FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: user_subscriptions update_user_subscriptions_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_user_subscriptions_updated_at BEFORE UPDATE ON public.user_subscriptions FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: app_builds app_builds_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_builds
    ADD CONSTRAINT app_builds_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.app_projects(id) ON DELETE SET NULL;


--
-- Name: app_builds app_builds_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_builds
    ADD CONSTRAINT app_builds_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: app_projects app_projects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.app_projects
    ADD CONSTRAINT app_projects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.profiles(id) ON DELETE CASCADE;


--
-- Name: automation_configs automation_configs_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_configs
    ADD CONSTRAINT automation_configs_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.app_projects(id) ON DELETE CASCADE;


--
-- Name: automation_logs automation_logs_automation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_logs
    ADD CONSTRAINT automation_logs_automation_id_fkey FOREIGN KEY (automation_id) REFERENCES public.automation_configs(id) ON DELETE CASCADE;


--
-- Name: bank_transfer_requests bank_transfer_requests_credit_pack_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_transfer_requests
    ADD CONSTRAINT bank_transfer_requests_credit_pack_id_fkey FOREIGN KEY (credit_pack_id) REFERENCES public.credit_packs(id);


--
-- Name: bank_transfer_requests bank_transfer_requests_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_transfer_requests
    ADD CONSTRAINT bank_transfer_requests_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.subscription_plans(id);


--
-- Name: bank_transfer_requests bank_transfer_requests_transaction_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_transfer_requests
    ADD CONSTRAINT bank_transfer_requests_transaction_id_fkey FOREIGN KEY (transaction_id) REFERENCES public.payment_transactions(id);


--
-- Name: bank_transfer_requests bank_transfer_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bank_transfer_requests
    ADD CONSTRAINT bank_transfer_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: chat_messages chat_messages_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.app_projects(id) ON DELETE CASCADE;


--
-- Name: consent_records consent_records_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.consent_records
    ADD CONSTRAINT consent_records_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: payment_transactions payment_transactions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.payment_transactions
    ADD CONSTRAINT payment_transactions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: profiles profiles_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.profiles
    ADD CONSTRAINT profiles_id_fkey FOREIGN KEY (id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: settings_audit_log settings_audit_log_changed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings_audit_log
    ADD CONSTRAINT settings_audit_log_changed_by_fkey FOREIGN KEY (changed_by) REFERENCES public.profiles(id) ON DELETE SET NULL;


--
-- Name: settings_audit_log settings_audit_log_setting_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings_audit_log
    ADD CONSTRAINT settings_audit_log_setting_id_fkey FOREIGN KEY (setting_id) REFERENCES public.system_settings(id) ON DELETE SET NULL;


--
-- Name: system_settings system_settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_settings
    ADD CONSTRAINT system_settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES auth.users(id);


--
-- Name: user_credits user_credits_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_credits
    ADD CONSTRAINT user_credits_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: user_subscriptions user_subscriptions_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.subscription_plans(id);


--
-- Name: user_subscriptions user_subscriptions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_subscriptions
    ADD CONSTRAINT user_subscriptions_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth.users(id) ON DELETE CASCADE;


--
-- Name: email_templates Admins can delete email templates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can delete email templates" ON public.email_templates FOR DELETE USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: user_roles Admins can delete roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can delete roles" ON public.user_roles FOR DELETE USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: settings_audit_log Admins can insert audit logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can insert audit logs" ON public.settings_audit_log FOR INSERT TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: email_templates Admins can insert email templates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can insert email templates" ON public.email_templates FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: user_roles Admins can insert roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can insert roles" ON public.user_roles FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: system_settings Admins can insert settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can insert settings" ON public.system_settings FOR INSERT WITH CHECK (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: api_configurations Admins can manage API configurations; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage API configurations" ON public.api_configurations USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: invoices Admins can manage all invoices; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage all invoices" ON public.invoices USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: plugins Admins can manage plugins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can manage plugins" ON public.plugins USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: email_templates Admins can update email templates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can update email templates" ON public.email_templates FOR UPDATE USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: user_roles Admins can update roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can update roles" ON public.user_roles FOR UPDATE USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: system_settings Admins can update settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can update settings" ON public.system_settings FOR UPDATE USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: automation_configs Admins can view all automation configs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all automation configs" ON public.automation_configs FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: automation_logs Admins can view all automation logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all automation logs" ON public.automation_logs FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: user_roles Admins can view all roles; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view all roles" ON public.user_roles FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: settings_audit_log Admins can view audit logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view audit logs" ON public.settings_audit_log FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: email_templates Admins can view email templates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view email templates" ON public.email_templates FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: plugins Admins can view plugins; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Admins can view plugins" ON public.plugins FOR SELECT USING (public.has_role(auth.uid(), 'admin'::public.app_role));


--
-- Name: credit_packs Anyone can view active credit packs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can view active credit packs" ON public.credit_packs FOR SELECT USING ((is_active = true));


--
-- Name: subscription_plans Anyone can view active subscription plans; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can view active subscription plans" ON public.subscription_plans FOR SELECT USING ((is_active = true));


--
-- Name: system_settings Anyone can view settings; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Anyone can view settings" ON public.system_settings FOR SELECT USING (true);


--
-- Name: automation_configs Users can create their own automation configs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can create their own automation configs" ON public.automation_configs FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: app_builds Users can create their own builds; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can create their own builds" ON public.app_builds FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: app_projects Users can create their own projects; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can create their own projects" ON public.app_projects FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: app_templates Users can create their own templates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can create their own templates" ON public.app_templates FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: automation_configs Users can delete their own automation configs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can delete their own automation configs" ON public.automation_configs FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: chat_messages Users can delete their own chat messages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can delete their own chat messages" ON public.chat_messages FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: app_projects Users can delete their own projects; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can delete their own projects" ON public.app_projects FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: app_templates Users can delete their own templates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can delete their own templates" ON public.app_templates FOR DELETE USING ((auth.uid() = user_id));


--
-- Name: bank_transfer_requests Users can insert their own bank transfer requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own bank transfer requests" ON public.bank_transfer_requests FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: chat_messages Users can insert their own chat messages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own chat messages" ON public.chat_messages FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: consent_records Users can insert their own consent records; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own consent records" ON public.consent_records FOR INSERT WITH CHECK (((auth.uid() = user_id) OR (user_id IS NULL)));


--
-- Name: user_credits Users can insert their own credits; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own credits" ON public.user_credits FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: profiles Users can insert their own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own profile" ON public.profiles FOR INSERT WITH CHECK ((auth.uid() = id));


--
-- Name: user_subscriptions Users can insert their own subscription; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own subscription" ON public.user_subscriptions FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: payment_transactions Users can insert their own transactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can insert their own transactions" ON public.payment_transactions FOR INSERT WITH CHECK ((auth.uid() = user_id));


--
-- Name: automation_configs Users can update their own automation configs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own automation configs" ON public.automation_configs FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: app_builds Users can update their own builds; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own builds" ON public.app_builds FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: consent_records Users can update their own consent records; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own consent records" ON public.consent_records FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: user_credits Users can update their own credits; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own credits" ON public.user_credits FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: bank_transfer_requests Users can update their own pending bank transfer requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own pending bank transfer requests" ON public.bank_transfer_requests FOR UPDATE USING (((auth.uid() = user_id) AND (status = 'pending'::text)));


--
-- Name: profiles Users can update their own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own profile" ON public.profiles FOR UPDATE USING ((auth.uid() = id));


--
-- Name: app_projects Users can update their own projects; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own projects" ON public.app_projects FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: user_subscriptions Users can update their own subscription; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own subscription" ON public.user_subscriptions FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: app_templates Users can update their own templates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can update their own templates" ON public.app_templates FOR UPDATE USING ((auth.uid() = user_id));


--
-- Name: automation_configs Users can view their own automation configs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own automation configs" ON public.automation_configs FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: automation_logs Users can view their own automation logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own automation logs" ON public.automation_logs FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: bank_transfer_requests Users can view their own bank transfer requests; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own bank transfer requests" ON public.bank_transfer_requests FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: app_builds Users can view their own builds; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own builds" ON public.app_builds FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: chat_messages Users can view their own chat messages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own chat messages" ON public.chat_messages FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: consent_records Users can view their own consent records; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own consent records" ON public.consent_records FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: credit_usage_history Users can view their own credit usage; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own credit usage" ON public.credit_usage_history FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: user_credits Users can view their own credits; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own credits" ON public.user_credits FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: invoices Users can view their own invoices; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own invoices" ON public.invoices FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: profiles Users can view their own profile; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own profile" ON public.profiles FOR SELECT USING ((auth.uid() = id));


--
-- Name: app_projects Users can view their own projects; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own projects" ON public.app_projects FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: user_roles Users can view their own role; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own role" ON public.user_roles FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: user_subscriptions Users can view their own subscription; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own subscription" ON public.user_subscriptions FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: app_templates Users can view their own templates; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own templates" ON public.app_templates FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: payment_transactions Users can view their own transactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY "Users can view their own transactions" ON public.payment_transactions FOR SELECT USING ((auth.uid() = user_id));


--
-- Name: api_configurations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.api_configurations ENABLE ROW LEVEL SECURITY;

--
-- Name: app_builds; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.app_builds ENABLE ROW LEVEL SECURITY;

--
-- Name: app_projects; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.app_projects ENABLE ROW LEVEL SECURITY;

--
-- Name: app_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.app_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: automation_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.automation_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: automation_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.automation_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: bank_transfer_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bank_transfer_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: chat_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.chat_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: consent_records; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.consent_records ENABLE ROW LEVEL SECURITY;

--
-- Name: credit_packs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.credit_packs ENABLE ROW LEVEL SECURITY;

--
-- Name: credit_usage_history; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.credit_usage_history ENABLE ROW LEVEL SECURITY;

--
-- Name: email_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.email_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: invoices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

--
-- Name: payment_transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.payment_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: plugins; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.plugins ENABLE ROW LEVEL SECURITY;

--
-- Name: profiles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

--
-- Name: settings_audit_log; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.settings_audit_log ENABLE ROW LEVEL SECURITY;

--
-- Name: subscription_plans; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.subscription_plans ENABLE ROW LEVEL SECURITY;

--
-- Name: system_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.system_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: user_credits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_credits ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: user_subscriptions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_subscriptions ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--




COMMIT;