
-- Enable realtime for key admin-monitored tables
ALTER PUBLICATION supabase_realtime ADD TABLE public.profiles;
ALTER PUBLICATION supabase_realtime ADD TABLE public.app_builds;
ALTER PUBLICATION supabase_realtime ADD TABLE public.payment_transactions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_subscriptions;
ALTER PUBLICATION supabase_realtime ADD TABLE public.system_settings;
ALTER PUBLICATION supabase_realtime ADD TABLE public.plugins;
ALTER PUBLICATION supabase_realtime ADD TABLE public.bank_transfer_requests;
ALTER PUBLICATION supabase_realtime ADD TABLE public.user_credits;
