
-- Admin policies for storage: allow admins full access to all buckets
CREATE POLICY "Admins can read all files"
ON storage.objects FOR SELECT
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can upload all files"
ON storage.objects FOR INSERT
WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can update all files"
ON storage.objects FOR UPDATE
USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins can delete all files"
ON storage.objects FOR DELETE
USING (public.has_role(auth.uid(), 'admin'));
