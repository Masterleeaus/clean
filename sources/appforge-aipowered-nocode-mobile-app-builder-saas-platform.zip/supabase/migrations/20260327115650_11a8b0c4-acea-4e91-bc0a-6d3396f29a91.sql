UPDATE public.app_builds 
SET status = 'failed', 
    error_message = 'Build timed out — no progress received from cloud provider.', 
    updated_at = now() 
WHERE status IN ('pending', 'building', 'queued') 
  AND updated_at < now() - interval '30 minutes';