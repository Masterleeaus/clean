-- Drop the restrictive SELECT policy and recreate as permissive
DROP POLICY IF EXISTS "Anyone can view settings" ON public.system_settings;

CREATE POLICY "Anyone can view settings"
ON public.system_settings
FOR SELECT
USING (true);