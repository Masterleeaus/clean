import { serve } from "https://deno.land/std@0.190.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.57.2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

const logStep = (step: string, details?: Record<string, unknown>) => {
  const detailsStr = details ? ` - ${JSON.stringify(details)}` : "";
  console.log(`[SEND-EMAIL] ${step}${detailsStr}`);
};

interface EmailRequest {
  to: string;
  templateName: string;
  variables?: Record<string, string>;
}

const replaceVariables = (
  template: string,
  variables: Record<string, string>
): string => {
  let result = template;
  for (const [key, value] of Object.entries(variables)) {
    const regex = new RegExp(`{{${key}}}`, "g");
    result = result.replace(regex, value);
  }
  return result;
};

// Send email using Resend API directly
async function sendEmailWithResend(
  apiKey: string,
  to: string,
  subject: string,
  htmlContent: string,
  fromAddress: string,
  textContent?: string
) {
  const response = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${apiKey}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      from: fromAddress,
      to: [to],
      subject,
      html: htmlContent,
      text: textContent,
    }),
  });

  if (!response.ok) {
    const error = await response.text();
    throw new Error(`Resend API error: ${error}`);
  }

  return await response.json();
}

interface ResendConfig {
  apiKey: string;
  fromEmail: string;
}

// Resolve the Resend config: env var first, then api_configurations, then system_settings (legacy)
async function resolveResendConfig(supabaseUrl: string, serviceRoleKey: string): Promise<ResendConfig | null> {
  // 1. Check environment variable
  const envKey = Deno.env.get("RESEND_API_KEY");
  if (envKey) {
    return { apiKey: envKey, fromEmail: Deno.env.get("RESEND_FROM_EMAIL") || "noreply@example.com" };
  }

  try {
    const supabase = createClient(supabaseUrl, serviceRoleKey);

    // 2. Check api_configurations table (Integrations Manager - primary source)
    const { data: apiConfig } = await supabase
      .from("api_configurations")
      .select("config")
      .eq("provider", "resend")
      .eq("is_active", true)
      .order("updated_at", { ascending: false })
      .limit(1)
      .maybeSingle();

    if (apiConfig?.config) {
      const cfg = apiConfig.config as Record<string, string>;
      const apiKey = cfg.api_key?.trim();
      if (apiKey && apiKey.length > 0) {
        const fromEmail = cfg.from_email?.trim() || "noreply@example.com";
        logStep("Resolved Resend config from api_configurations");
        return { apiKey, fromEmail };
      }
    }

    // 3. Legacy fallback: system_settings table
    const { data: legacyData } = await supabase
      .from("system_settings")
      .select("value")
      .eq("key", "resend_api_key")
      .maybeSingle();

    if (legacyData?.value) {
      const raw = legacyData.value;
      let key: string | null = null;
      if (typeof raw === "string" && raw.trim().length > 0) key = raw.trim();
      if (typeof raw === "object" && raw !== null) {
        const str = JSON.stringify(raw).replace(/^"|"$/g, "");
        if (str.trim().length > 0) key = str.trim();
      }
      if (key) {
        logStep("Resolved Resend API key from system_settings (legacy)");
        return { apiKey: key, fromEmail: "noreply@example.com" };
      }
    }
  } catch (err) {
    logStep("Failed to resolve Resend config", { error: String(err) });
  }

  return null;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
  const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;

  // Health check endpoint
  const url = new URL(req.url);
  if (url.searchParams.get("health") === "1" || req.method === "GET") {
    const resendConfig = await resolveResendConfig(supabaseUrl, serviceRoleKey);
    return new Response(
      JSON.stringify({
        status: "ok",
        function: "send-email",
        timestamp: new Date().toISOString(),
        env: {
          RESEND_API_KEY: !!resendConfig,
          SUPABASE_URL: !!supabaseUrl,
          SUPABASE_SERVICE_ROLE_KEY: !!serviceRoleKey,
        },
      }),
      { status: 200, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  try {
    const resendConfig = await resolveResendConfig(supabaseUrl, serviceRoleKey);
    if (!resendConfig) {
      logStep("Resend not configured (env, api_configurations, or system_settings)");
      return new Response(
        JSON.stringify({ success: false, message: "Email service not configured. Set the Resend API key in Admin → Integrations → Resend." }),
        {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    const supabase = createClient(supabaseUrl, serviceRoleKey);

    const { to, templateName, variables = {} }: EmailRequest = await req.json();

    if (!to || !templateName) {
      throw new Error("Missing required fields: to, templateName");
    }

    logStep("Fetching email template", { templateName });

    // Fetch the email template
    const { data: template, error: templateError } = await supabase
      .from("email_templates")
      .select("*")
      .eq("name", templateName)
      .eq("is_active", true)
      .single();

    if (templateError || !template) {
      logStep("Template not found or inactive", { templateName, error: templateError?.message });
      return new Response(
        JSON.stringify({ success: false, message: "Email template not found" }),
        {
          status: 200,
          headers: { ...corsHeaders, "Content-Type": "application/json" },
        }
      );
    }

    // Replace variables in subject and content
    const subject = replaceVariables(template.subject, variables);
    const htmlContent = replaceVariables(template.html_content, variables);
    const textContent = template.text_content
      ? replaceVariables(template.text_content, variables)
      : undefined;

    logStep("Sending email", { to, subject, from: resendConfig.fromEmail });

    // Send the email
    const emailResponse = await sendEmailWithResend(
      resendConfig.apiKey,
      to,
      subject,
      htmlContent,
      resendConfig.fromEmail,
      textContent
    );

    logStep("Email sent successfully", { emailId: emailResponse.id });

    return new Response(
      JSON.stringify({ success: true, emailId: emailResponse.id }),
      {
        status: 200,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  } catch (error: unknown) {
    const message = error instanceof Error ? error.message : "Unknown error";
    logStep("Error sending email", { error: message });
    return new Response(
      JSON.stringify({ success: false, error: message }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
