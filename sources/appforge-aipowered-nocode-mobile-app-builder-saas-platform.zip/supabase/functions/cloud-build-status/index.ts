import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnon = Deno.env.get("SUPABASE_ANON_KEY")!;

    const token = authHeader.replace("Bearer ", "");
    const anonClient = createClient(supabaseUrl, supabaseAnon);
    const { data: { user }, error: authError } = await anonClient.auth.getUser(token);
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const { buildId } = await req.json();
    if (!buildId) {
      return new Response(JSON.stringify({ error: "buildId is required" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    // Get the build record
    const { data: build, error: buildErr } = await adminClient
      .from("app_builds")
      .select("*")
      .eq("id", buildId)
      .single();

    if (buildErr || !build) {
      return new Response(JSON.stringify({ error: "Build not found" }), {
        status: 404,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const cloudBuildId = build.cloud_build_id;
    if (!cloudBuildId) {
      // No cloud build — return current status as-is
      return new Response(JSON.stringify(build), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Resolve Codemagic token, preferring runtime secrets over admin-configured rows
    const secretCodemagicToken = (Deno.env.get("CODEMAGIC_API_TOKEN") || "").trim();
    const secretCodemagicAppId = (Deno.env.get("CODEMAGIC_APP_ID") || "").trim();
    let codemagicToken = secretCodemagicToken;

    const { data: cmConfigs } = await adminClient
      .from("api_configurations")
      .select("config")
      .eq("provider", "codemagic")
      .eq("is_active", true)
      .order("updated_at", { ascending: false })
      .limit(1);

    const cmConfig = cmConfigs?.[0]?.config as Record<string, string> | undefined;
    const configToken = (cmConfig?.api_token || "").trim();
    const configAppId = (cmConfig?.app_id || "").trim();

    if (!codemagicToken && configToken) codemagicToken = configToken;

    if (configToken && (configToken === configAppId || configToken === secretCodemagicAppId)) {
      console.warn("Codemagic status check ignored a miswired saved api_token that matched an App ID.");
      if (!secretCodemagicToken) {
        codemagicToken = "";
      }
    }

    if (!codemagicToken) {
      return new Response(JSON.stringify(build), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Poll Codemagic for latest status
    const cmRes = await fetch(`https://api.codemagic.io/builds/${cloudBuildId}`, {
      headers: { "x-auth-token": codemagicToken },
    });

    if (!cmRes.ok) {
      console.warn("Codemagic status check failed:", cmRes.status);
      return new Response(JSON.stringify(build), {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const cmData = await cmRes.json();
    const cmBuild = cmData.build || cmData;
    const cmStatus = cmBuild.status;

    // Map Codemagic status to our status
    let newStatus = build.status;
    let newProgress = build.progress;
    let downloadUrl = build.download_url;
    let errorMessage = build.error_message;
    let fileSize = build.file_size_bytes;

    if (cmStatus === "building" || cmStatus === "queued" || cmStatus === "preparing") {
      newStatus = "building";
      // Estimate progress based on Codemagic status
      if (cmStatus === "queued") newProgress = 10;
      else if (cmStatus === "preparing") newProgress = 20;
      else newProgress = Math.min(85, (build.progress || 20) + 5);
    } else if (cmStatus === "finished") {
      // Check if build succeeded
      const artifacts = cmBuild.artefacts || cmBuild.artifacts || [];
      const apkArtifact = artifacts.find(
        (a: { type?: string; name?: string; url?: string }) =>
          a.type === "apk" || a.name?.endsWith(".apk") || a.url?.endsWith(".apk")
      );

      if (apkArtifact?.url) {
        newStatus = "complete";
        newProgress = 100;
        downloadUrl = apkArtifact.url;
        fileSize = apkArtifact.size || apkArtifact.versionSize || null;
      } else {
        // No APK artifact found — check if there's any downloadable artifact
        const anyArtifact = artifacts.find(
          (a: { url?: string }) => a.url
        );
        if (anyArtifact?.url) {
          newStatus = "complete";
          newProgress = 100;
          downloadUrl = anyArtifact.url;
          fileSize = anyArtifact.size || null;
        } else {
          newStatus = "failed";
          errorMessage = "Build finished but no downloadable artifact was produced.";
        }
      }
    } else if (cmStatus === "failed" || cmStatus === "canceled" || cmStatus === "cancelled") {
      newStatus = "failed";
      // Extract step-level failure details
      const steps = (cmBuild.steps || cmBuild.buildSteps || []) as Array<Record<string, unknown>>;
      const failedStep = Array.isArray(steps) ? steps.find((s: Record<string, unknown>) => s.status === "failed" || s.status === "error") : null;
      const stepName = (cmBuild.failedStepName || cmBuild.failed_step_name || (failedStep as Record<string, unknown> | null)?.name || null) as string | null;
      const stepMsg = (cmBuild.failedStepMessage || cmBuild.failed_step_message || (failedStep as Record<string, unknown> | null)?.message || cmBuild.message || cmBuild.error || `Codemagic build ${cmStatus}`) as string;

      // Extract log excerpt from failed step for CocoaPods / dependency diagnostics
      let logExcerpt: string | null = null;
      if (failedStep) {
        const rawLog = String((failedStep as Record<string, unknown>).log || (failedStep as Record<string, unknown>).output || "");
        if (rawLog) logExcerpt = rawLog.length > 2000 ? rawLog.slice(-2000) : rawLog;
      }

      // Detect CocoaPods-specific failures and provide actionable messages
      const allText = `${stepMsg} ${logExcerpt || ""}`.toLowerCase();
      let diagnosticHint = "";
      if (allText.includes("no `podfile'") || allText.includes("no podfile") || allText.includes("podfile not found")) {
        diagnosticHint = " [CocoaPods: No Podfile found. Ensure 'npx cap add ios' runs before 'pod install' in codemagic.yaml]";
      } else if (allText.includes("pod install") && (allText.includes("error") || allText.includes("failed"))) {
        diagnosticHint = " [CocoaPods: pod install failed. Check Podfile compatibility and CocoaPods version]";
      } else if (allText.includes("cocoapods") && allText.includes("not found")) {
        diagnosticHint = " [CocoaPods is not installed on the build machine. Add 'brew install cocoapods' or use --packagemanager Cocoapods in codemagic.yaml]";
      } else if (allText.includes("xcodebuild") && allText.includes("failed")) {
        diagnosticHint = " [Xcode build failed. Check signing, provisioning profiles, and target compatibility]";
      } else if (allText.includes("packagemanager") || allText.includes("spm") || allText.includes("swift package")) {
        diagnosticHint = " [Package manager conflict: ensure codemagic.yaml uses '--packagemanager Cocoapods' for Capacitor projects]";
      }

      const parts: string[] = [];
      if (stepName) parts.push(`Step: ${stepName}`);
      parts.push(stepMsg + diagnosticHint);
      errorMessage = parts.join(" — ");
    }

    // Update our build record if status changed
    if (newStatus !== build.status || newProgress !== build.progress || downloadUrl !== build.download_url) {
      const updateData: Record<string, unknown> = {
        status: newStatus,
        progress: newProgress,
      };
      if (downloadUrl) updateData.download_url = downloadUrl;
      if (fileSize) updateData.file_size_bytes = fileSize;
      if (errorMessage) updateData.error_message = errorMessage;

      await adminClient.from("app_builds").update(updateData).eq("id", buildId);
    }

    // Return updated build data
    return new Response(
      JSON.stringify({
        ...build,
        status: newStatus,
        progress: newProgress,
        download_url: downloadUrl,
        file_size_bytes: fileSize,
        error_message: errorMessage,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Cloud build status error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
