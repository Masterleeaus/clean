import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

type CodemagicAppSummary = {
  id: string;
  name: string | null;
  repositoryUrl: string | null;
};

const getCodemagicHeaders = (token: string) => ({
  "x-auth-token": token,
  "User-Agent": "WebToApp-CloudBuild",
});

const parseCodemagicApps = (payload: unknown): CodemagicAppSummary[] => {
  const rawApps = Array.isArray(payload)
    ? payload
    : typeof payload === "object" && payload !== null
      ? Array.isArray((payload as { applications?: unknown[] }).applications)
        ? (payload as { applications: unknown[] }).applications
        : Array.isArray((payload as { apps?: unknown[] }).apps)
          ? (payload as { apps: unknown[] }).apps
          : []
      : [];

  return rawApps
    .map((app) => {
      if (!app || typeof app !== "object") return null;

      const value = app as Record<string, unknown>;
      const repository = value.repository;
      const repositoryUrl =
        repository &&
        typeof repository === "object" &&
        typeof (repository as Record<string, unknown>).url === "string"
          ? ((repository as Record<string, unknown>).url as string)
          : null;

      const id = String(value._id || value.id || "").trim();
      if (!id) return null;

      return {
        id,
        name:
          typeof value.appName === "string"
            ? value.appName
            : typeof value.name === "string"
              ? value.name
              : null,
        repositoryUrl,
      };
    })
    .filter((app): app is CodemagicAppSummary => Boolean(app?.id));
};

const formatCodemagicAppLabel = (app: CodemagicAppSummary) =>
  [app.name, app.id].filter(Boolean).join(" (") + (app.name ? ")" : "");

const buildInvalidTokenResponse = (message: string, status: number) =>
  new Response(JSON.stringify({ error: message }), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization");
    if (!authHeader) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabaseAnon = Deno.env.get("SUPABASE_ANON_KEY")!;

    // Verify user
    const token = authHeader.replace("Bearer ", "");
    const anonClient = createClient(supabaseUrl, supabaseAnon);
    const { data: { user }, error: authError } = await anonClient.auth.getUser(token);
    if (authError || !user) {
      return new Response(JSON.stringify({ error: "Unauthorized" }), {
        status: 401,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const body = await req.json();
    const {
      buildId,
      websiteUrl,
      appName,
      platform = "android",
      packageName,
      config = {},
    } = body;

    if (!buildId || !websiteUrl || !appName) {
      return new Response(
        JSON.stringify({ error: "buildId, websiteUrl, and appName are required" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Determine workflow based on platform
    const isIos = platform === "ios";

    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    // Resolve Codemagic credentials, preferring runtime secrets over admin-configured rows
    const secretCodemagicToken = (Deno.env.get("CODEMAGIC_API_TOKEN") || "").trim();
    const secretCodemagicAppId = (Deno.env.get("CODEMAGIC_APP_ID") || "").trim();
    let codemagicToken = secretCodemagicToken;
    let codemagicAppId = secretCodemagicAppId;

    const { data: cmConfigs } = await adminClient
      .from("api_configurations")
      .select("config")
      .eq("provider", "codemagic")
      .eq("is_active", true)
      .order("updated_at", { ascending: false })
      .limit(1);

    const cmConfig = cmConfigs?.[0]?.config as Record<string, string> | undefined;
    const configToken = (cmConfig?.api_token || "").trim();
    const configAppId = (cmConfig?.app_id || "").trim();

    if (!codemagicToken && configToken) codemagicToken = configToken;
    if (!codemagicAppId && configAppId) codemagicAppId = configAppId;

    if (configToken && (configToken === configAppId || configToken === secretCodemagicAppId)) {
      console.warn("Codemagic configuration looks miswired: saved api_token matches an App ID. Preferring runtime secrets.");
      if (!secretCodemagicToken) {
        codemagicToken = "";
      }
    }

    console.log(
      "Using Codemagic token source:",
      codemagicToken && codemagicToken === secretCodemagicToken ? "secret" : configToken ? "api_configurations" : "missing"
    );
    console.log(
      "Using Codemagic app ID source:",
      codemagicAppId && codemagicAppId === secretCodemagicAppId ? "secret" : configAppId ? "api_configurations" : "auto-resolve"
    );
    console.log("Using Codemagic token:", codemagicToken ? `${codemagicToken.slice(0, 8)}...` : "NONE");
    console.log("Using Codemagic app ID:", codemagicAppId || "will auto-resolve");

    if (!codemagicToken) {
      // Update build as failed
      await adminClient.from("app_builds").update({
        status: "failed",
        error_message: "Codemagic API token is not configured. Go to Admin → Integrations → Codemagic to set it up.",
      }).eq("id", buildId);

      return new Response(
        JSON.stringify({
          error: "Codemagic API token not configured",
          details: "Admin must configure the Codemagic API token in Admin → Integrations.",
        }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    let appIdAutoResolved = false;

    if (codemagicAppId) {
      try {
        const appRes = await fetch(`https://api.codemagic.io/apps/${codemagicAppId}`, {
          headers: getCodemagicHeaders(codemagicToken),
        });

        if (appRes.status === 401) {
          const authErrMsg = "Codemagic API token is invalid or expired. Please update it in Admin → Integrations → Codemagic.";
          await adminClient.from("app_builds").update({
            status: "failed",
            error_message: authErrMsg,
          }).eq("id", buildId);
          return buildInvalidTokenResponse(authErrMsg, 401);
        }

        if ([400, 403, 404].includes(appRes.status)) {
          console.warn(
            `Configured Codemagic App ID ${codemagicAppId} is not accessible with the current token (HTTP ${appRes.status}). Falling back to accessible apps list.`
          );
          codemagicAppId = "";
        }
      } catch (e) {
        console.warn("Failed to validate configured Codemagic app ID:", e);
        codemagicAppId = "";
      }
    }

    // If no valid app ID is configured, try resolving from accessible Codemagic apps
    if (!codemagicAppId) {
      try {
        const appsRes = await fetch("https://api.codemagic.io/apps", {
          headers: getCodemagicHeaders(codemagicToken),
        });

        if (appsRes.status === 401) {
          const authErrMsg = "Codemagic API token is invalid or expired. Please update it in Admin → Integrations → Codemagic.";
          await adminClient.from("app_builds").update({
            status: "failed",
            error_message: authErrMsg,
          }).eq("id", buildId);
          return buildInvalidTokenResponse(authErrMsg, 401);
        }

        if (appsRes.ok) {
          const apps = parseCodemagicApps(await appsRes.json());

          if (apps.length === 1) {
            codemagicAppId = apps[0].id;
            appIdAutoResolved = true;
          } else if (apps.length > 1) {
            const options = apps.map(formatCodemagicAppLabel).join(", ");

            await adminClient.from("app_builds").update({
              status: "failed",
              error_message: `Configured Codemagic App ID is not accessible with this token, and multiple apps are available. Update Admin → Integrations → Codemagic with the correct App ID. Available apps: ${options}`,
            }).eq("id", buildId);

            return new Response(
              JSON.stringify({
                error: "Codemagic App ID is invalid or inaccessible for this token.",
                details: `Multiple accessible apps were found. Update Admin → Integrations → Codemagic with one of: ${options}`,
              }),
              { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
            );
          }
        }
      } catch (e) {
        console.warn("Failed to auto-resolve Codemagic app ID:", e);
      }
    }

    if (!codemagicAppId) {
      await adminClient.from("app_builds").update({
        status: "failed",
        error_message: "Codemagic App ID is not configured and could not be auto-resolved. Go to Admin → Integrations → Codemagic.",
      }).eq("id", buildId);

      return new Response(
        JSON.stringify({ error: "Codemagic App ID not configured" }),
        { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    if (appIdAutoResolved) {
      console.log("Auto-resolved Codemagic app ID from accessible apps list:", codemagicAppId);
    }

    // --- GitHub sync check ---
    // Resolve the GitHub repo URL from Codemagic app config so we can verify sync
    let repoOwner = "";
    let repoName = "";
    try {
      const appRes = await fetch(`https://api.codemagic.io/apps/${codemagicAppId}`, {
        headers: { "x-auth-token": codemagicToken },
      });
      if (appRes.ok) {
        const appData = await appRes.json();
        const repoUrl: string = appData?.application?.repository?.url || appData?.repository?.url || "";
        // Parse "https://github.com/owner/repo" or "git@github.com:owner/repo.git"
        const httpsMatch = repoUrl.match(/github\.com\/([^/]+)\/([^/.]+)/);
        const sshMatch = repoUrl.match(/github\.com:([^/]+)\/([^/.]+)/);
        const m = httpsMatch || sshMatch;
        if (m) {
          repoOwner = m[1];
          repoName = m[2];
        }
      }
    } catch (e) {
      console.warn("Could not resolve GitHub repo from Codemagic app:", e);
    }

    // If we know the repo, poll GitHub to make sure the latest commit is recent
    // (i.e. Lovable has finished syncing). We check the main branch HEAD date.
    if (repoOwner && repoName) {
      const MAX_WAIT_SECONDS = 60;
      const POLL_INTERVAL_MS = 5000;
      const MAX_COMMIT_AGE_MS = 5 * 60 * 1000; // accept commits pushed within last 5 min
      const started = Date.now();
      let synced = false;

      while (Date.now() - started < MAX_WAIT_SECONDS * 1000) {
        try {
          const ghRes = await fetch(
            `https://api.github.com/repos/${repoOwner}/${repoName}/commits/main`,
            { headers: { Accept: "application/vnd.github.v3+json", "User-Agent": "WebToApp-CloudBuild" } }
          );
          if (ghRes.ok) {
            const commit = await ghRes.json();
            const commitDate = new Date(commit?.commit?.committer?.date || commit?.commit?.author?.date || 0);
            const ageMs = Date.now() - commitDate.getTime();
            console.log(`GitHub main HEAD age: ${Math.round(ageMs / 1000)}s (commit ${commit.sha?.slice(0, 7)})`);
            if (ageMs < MAX_COMMIT_AGE_MS) {
              synced = true;
              break;
            }
          } else {
            console.warn(`GitHub API returned ${ghRes.status} – may be private repo, skipping sync check`);
            synced = true; // can't verify, proceed anyway
            break;
          }
        } catch (e) {
          console.warn("GitHub sync check fetch error:", e);
        }
        // Wait before next poll
        await new Promise((r) => setTimeout(r, POLL_INTERVAL_MS));
      }

      if (!synced) {
        console.warn("GitHub sync check timed out – proceeding with build anyway");
      }

      // Update build progress to show sync completed
      await adminClient.from("app_builds").update({ progress: 8 }).eq("id", buildId);
    }

    // Sanitize workflow ID — ignore if it looks like a webhook URL
    const defaultWorkflow = isIos ? "ios-build" : "android-build";
    const rawWorkflow = (config.workflowId as string) || defaultWorkflow;
    const workflowId = rawWorkflow.startsWith("http") ? defaultWorkflow : rawWorkflow;

    // Sanitize package name / bundle ID to valid format
    let safePkgName = (packageName as string) || "";
    if (!safePkgName || !/^[a-zA-Z][a-zA-Z0-9_]*(\.[a-zA-Z][a-zA-Z0-9_]*)+$/.test(safePkgName)) {
      const sanitized = (appName as string).toLowerCase().replace(/[^a-z0-9]/g, "") || "myapp";
      // Ensure segment starts with a letter
      const segment = /^[a-z]/.test(sanitized) ? sanitized : `app${sanitized}`;
      safePkgName = `com.app.${segment}`;
    }

    // Mark build as building
    await adminClient.from("app_builds").update({
      status: "building",
      progress: 5,
      error_message: null,
      cloud_provider: "codemagic",
      package_name: safePkgName,
    }).eq("id", buildId);

    // Build the webhook callback URL for Codemagic to push status updates
    const webhookUrl = `${supabaseUrl}/functions/v1/codemagic-webhook`;

    // Build environment variables — iOS uses BUNDLE_ID instead of PACKAGE_NAME
    const envVars: Record<string, string> = {
      WEBSITE_URL: websiteUrl,
      APP_NAME: appName,
      BUILD_ID: buildId,
      SUPABASE_URL: supabaseUrl,
      SUPABASE_SERVICE_ROLE_KEY: supabaseServiceKey,
      PRIMARY_COLOR: config.primaryColor || "#3B82F6",
      ACCENT_COLOR: config.accentColor || "#8B5CF6",
      CM_WEBHOOK_URL: webhookUrl,
    };

    if (isIos) {
      envVars.BUNDLE_ID = safePkgName;
    } else {
      envVars.PACKAGE_NAME = safePkgName;
    }

    // Validate token permissions before triggering build
    // A FORBIDDEN on /builds often means the token has read-only scope
    try {
        const permCheckRes = await fetch(`https://api.codemagic.io/apps/${codemagicAppId}`, {
         headers: getCodemagicHeaders(codemagicToken),
      });
      if (permCheckRes.status === 403) {
         const permErrMsg = "Codemagic rejected access to the selected app. Make sure the API token has 'Owner' or 'Builds' scope and that the configured App ID belongs to a project this token can access in Admin → Integrations → Codemagic.";
        console.error(permErrMsg);
        await adminClient.from("app_builds").update({
          status: "failed",
          error_message: permErrMsg,
        }).eq("id", buildId);
        return new Response(
          JSON.stringify({ error: permErrMsg }),
          { status: 403, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
      if (permCheckRes.status === 401) {
        const authErrMsg = "Codemagic API token is invalid or expired. Please update it in Admin → Integrations → Codemagic.";
        console.error(authErrMsg);
        await adminClient.from("app_builds").update({
          status: "failed",
          error_message: authErrMsg,
        }).eq("id", buildId);
        return new Response(
          JSON.stringify({ error: authErrMsg }),
          { status: 401, headers: { ...corsHeaders, "Content-Type": "application/json" } }
        );
      }
    } catch (permErr) {
      console.warn("Permission pre-check failed, proceeding with build attempt:", permErr);
    }

    // Trigger Codemagic build with webhook notification
    const cmResponse = await fetch("https://api.codemagic.io/builds", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-auth-token": codemagicToken,
      },
      body: JSON.stringify({
        appId: codemagicAppId,
        workflowId,
        branch: "main",
        environment: {
          variables: envVars,
        },
      }),
    });

    if (!cmResponse.ok) {
      const errText = await cmResponse.text();
      console.error("Codemagic API error:", cmResponse.status, errText);

      // Parse detailed error for better messaging
      let userFriendlyError = `Codemagic build trigger failed (HTTP ${cmResponse.status})`;
      try {
        const errJson = JSON.parse(errText);
        if (cmResponse.status === 403 || errJson.error === "FORBIDDEN") {
           userFriendlyError = "Codemagic rejected the build request. This usually means the API token is missing 'Owner' or 'Builds' scope, or the configured App ID is not accessible with this token. Recheck both values in Admin → Integrations → Codemagic.";
        } else if (cmResponse.status === 401) {
          userFriendlyError = "Codemagic API token is invalid or expired. Update it in Admin → Integrations → Codemagic.";
        } else if (cmResponse.status === 404) {
          userFriendlyError = `Codemagic app (${codemagicAppId}) or workflow (${workflowId}) not found. Verify your App ID and Workflow ID in Admin → Integrations → Codemagic.`;
        } else if (errJson.message) {
          userFriendlyError = `Codemagic: ${errJson.message}`;
        }
      } catch {
        userFriendlyError += `: ${errText.slice(0, 200)}`;
      }

      await adminClient.from("app_builds").update({
        status: "failed",
        error_message: userFriendlyError,
      }).eq("id", buildId);

      return new Response(
        JSON.stringify({ error: userFriendlyError }),
        { status: cmResponse.status >= 400 && cmResponse.status < 500 ? cmResponse.status : 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    const cmData = await cmResponse.json();
    const cloudBuildId = cmData.buildId || cmData._id || cmData.id;

    // Store cloud build ID for status polling
    await adminClient.from("app_builds").update({
      cloud_build_id: cloudBuildId,
      progress: 10,
      config: { ...config, platform, packageName: safePkgName, cloud_build_id: cloudBuildId },
    }).eq("id", buildId);

    return new Response(
      JSON.stringify({
        success: true,
        buildId,
        cloudBuildId,
        message: "Cloud build started via Codemagic",
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Cloud build error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
