import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const adminClient = createClient(supabaseUrl, supabaseServiceKey);

    const payload = await req.json();
    console.log("Codemagic webhook received:", JSON.stringify(payload).slice(0, 500));

    // Codemagic sends build data in various shapes
    const build = payload.build || payload;
    const cloudBuildId = build._id || build.buildId || build.id;
    const cmStatus = build.status;

    // Extract detailed failure info from Codemagic payload
    const extractFailureDetails = (buildPayload: Record<string, unknown>): { stepName: string | null; stepMessage: string | null; fullLog: string | null } => {
      let stepName: string | null = null;
      let stepMessage: string | null = null;
      let fullLog: string | null = null;

      // Codemagic may include failing step info
      if (buildPayload.failedStepName || buildPayload.failed_step_name) {
        stepName = (buildPayload.failedStepName || buildPayload.failed_step_name) as string;
      }
      if (buildPayload.failedStepMessage || buildPayload.failed_step_message) {
        stepMessage = (buildPayload.failedStepMessage || buildPayload.failed_step_message) as string;
      }

      // Check for step-level details in various payload shapes
      const steps = (buildPayload.steps || buildPayload.buildSteps || []) as Array<Record<string, unknown>>;
      if (Array.isArray(steps) && steps.length > 0) {
        const failedStep = steps.find((s) => s.status === "failed" || s.status === "error");
        if (failedStep) {
          stepName = stepName || (failedStep.name as string) || (failedStep.title as string) || null;
          stepMessage = stepMessage || (failedStep.message as string) || (failedStep.error as string) || null;
          if (failedStep.log || failedStep.output) {
            const rawLog = String(failedStep.log || failedStep.output || "");
            fullLog = rawLog.length > 2000 ? rawLog.slice(-2000) : rawLog;
          }
        }
      }

      // Also try the build-level message and error fields
      if (!stepMessage && buildPayload.message) {
        stepMessage = String(buildPayload.message);
      }
      if (!stepMessage && buildPayload.error) {
        stepMessage = String(buildPayload.error);
      }

      return { stepName, stepMessage, fullLog };
    };

    if (!cloudBuildId) {
      return new Response(JSON.stringify({ error: "No build ID in payload" }), {
        status: 400,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    // Find our build record by cloud_build_id
    const { data: appBuild, error: findErr } = await adminClient
      .from("app_builds")
      .select("*")
      .eq("cloud_build_id", cloudBuildId)
      .maybeSingle();

    if (findErr || !appBuild) {
      console.warn("Build not found for cloud_build_id:", cloudBuildId);
      return new Response(
        JSON.stringify({ error: "Build not found", cloudBuildId }),
        { status: 404, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    // Map Codemagic status
    let newStatus = appBuild.status;
    let newProgress = appBuild.progress;
    let downloadUrl = appBuild.download_url;
    let errorMessage = appBuild.error_message;
    let fileSize = appBuild.file_size_bytes;

    if (cmStatus === "building" || cmStatus === "queued" || cmStatus === "preparing" || cmStatus === "fetching") {
      newStatus = "building";
      if (cmStatus === "queued") newProgress = 10;
      else if (cmStatus === "fetching") newProgress = 15;
      else if (cmStatus === "preparing") newProgress = 20;
      else newProgress = Math.min(85, (appBuild.progress || 20) + 10);
    } else if (cmStatus === "finished" || cmStatus === "success") {
      const artifacts = build.artefacts || build.artifacts || [];
      const apkArtifact = artifacts.find(
        (a: { type?: string; name?: string; url?: string }) =>
          a.type === "apk" || a.name?.endsWith(".apk") || a.url?.endsWith(".apk")
      );

      if (apkArtifact?.url) {
        newStatus = "complete";
        newProgress = 100;
        downloadUrl = apkArtifact.url;
        fileSize = apkArtifact.size || apkArtifact.versionSize || null;
      } else {
        const anyArtifact = artifacts.find((a: { url?: string }) => a.url);
        if (anyArtifact?.url) {
          newStatus = "complete";
          newProgress = 100;
          downloadUrl = anyArtifact.url;
          fileSize = anyArtifact.size || null;
        } else {
          newStatus = "failed";
          errorMessage = "Build finished but no downloadable artifact was produced.";
        }
      }
    } else if (cmStatus === "failed" || cmStatus === "canceled" || cmStatus === "cancelled" || cmStatus === "error") {
      newStatus = "failed";
      const failureDetails = extractFailureDetails(build);
      
      // Detect CocoaPods-specific failures and provide actionable messages
      const allText = `${failureDetails.stepMessage || ""} ${failureDetails.fullLog || ""}`.toLowerCase();
      let diagnosticHint = "";
      if (allText.includes("no `podfile'") || allText.includes("no podfile") || allText.includes("podfile not found")) {
        diagnosticHint = " [CocoaPods: No Podfile found. Ensure 'npx cap add ios' runs before 'pod install' in codemagic.yaml]";
      } else if (allText.includes("pod install") && (allText.includes("error") || allText.includes("failed"))) {
        diagnosticHint = " [CocoaPods: pod install failed. Check Podfile compatibility and CocoaPods version]";
      } else if (allText.includes("cocoapods") && allText.includes("not found")) {
        diagnosticHint = " [CocoaPods not installed. Add 'brew install cocoapods' or use --packagemanager Cocoapods in codemagic.yaml]";
      } else if (allText.includes("xcodebuild") && allText.includes("failed")) {
        diagnosticHint = " [Xcode build failed. Check signing, provisioning profiles, and target compatibility]";
      } else if (allText.includes("packagemanager") || allText.includes("spm") || allText.includes("swift package")) {
        diagnosticHint = " [Package manager conflict: ensure codemagic.yaml uses '--packagemanager Cocoapods' for Capacitor projects]";
      }

      const parts: string[] = [];
      if (failureDetails.stepName) parts.push(`Step: ${failureDetails.stepName}`);
      if (failureDetails.stepMessage) parts.push(failureDetails.stepMessage + diagnosticHint);
      if (parts.length === 0) parts.push((build.message || build.error || `Codemagic build ${cmStatus}`) + diagnosticHint);
      errorMessage = parts.join(" — ");
    }

    // Update build record
    const updateData: Record<string, unknown> = {
      status: newStatus,
      progress: newProgress,
      updated_at: new Date().toISOString(),
    };
    if (downloadUrl) updateData.download_url = downloadUrl;
    if (fileSize) updateData.file_size_bytes = fileSize;
    if (errorMessage) updateData.error_message = errorMessage;

    // Store structured failure data in config for the details drawer
    if (newStatus === "failed") {
      const failureDetails = extractFailureDetails(build);
      const existingConfig = (appBuild.config || {}) as Record<string, unknown>;
      updateData.config = {
        ...existingConfig,
        failedStep: failureDetails.stepName,
        failedStepMessage: failureDetails.stepMessage,
        failedStepLog: failureDetails.fullLog,
        codemagicStatus: cmStatus,
      };
    }

    const { error: updateErr } = await adminClient
      .from("app_builds")
      .update(updateData)
      .eq("id", appBuild.id);

    if (updateErr) {
      console.error("Failed to update build:", updateErr);
      return new Response(
        JSON.stringify({ error: "Failed to update build record" }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    console.log(`Build ${appBuild.id} updated: ${appBuild.status} → ${newStatus} (${newProgress}%)`);

    return new Response(
      JSON.stringify({
        success: true,
        buildId: appBuild.id,
        status: newStatus,
        progress: newProgress,
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    console.error("Codemagic webhook error:", error);
    return new Response(
      JSON.stringify({ error: error instanceof Error ? error.message : "Unknown error" }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
