<?php

return [
    'name' => 'ServiceManagement'
];
