<?php
namespace Modules\TitanRewind\Models;
use Illuminate\Database\Eloquent\Model;
class RewindIntegrityCheck extends Model
{
    protected $table = 'titan_rewind_integrity_checks';
    protected $fillable = ['company_id','check_type','status','checked_by_id','events_checked','failures_count','result_json','started_at','finished_at'];
    protected $casts = ['result_json'=>'array','started_at'=>'datetime','finished_at'=>'datetime'];
}
