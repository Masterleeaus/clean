<?php
namespace Modules\TitanRewind\Models;
use Illuminate\Database\Eloquent\Model;
class RewindApproval extends Model
{
    protected $table = 'titan_rewind_approvals';
    protected $fillable = ['company_id','case_id','fix_id','action_type','status','approval_level','requested_by_type','requested_by_id','decided_by_type','decided_by_id','decided_at','decision_note','meta_json'];
    protected $casts = ['meta_json'=>'array','decided_at'=>'datetime'];
}
