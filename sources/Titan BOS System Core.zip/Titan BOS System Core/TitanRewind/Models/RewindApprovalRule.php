<?php
namespace Modules\TitanRewind\Models;

use Illuminate\Database\Eloquent\Model;

class RewindApprovalRule extends Model
{
    protected $table = 'titan_rewind_approval_rules';
    protected $fillable = ['company_id','name','action_type','risk_level','required_levels','role_names_json','conditions_json','is_active'];
    protected $casts = ['role_names_json'=>'array','conditions_json'=>'array','is_active'=>'boolean'];
}
