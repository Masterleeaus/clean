<?php
namespace Modules\TitanRewind\Models;
use Illuminate\Database\Eloquent\Model;
class RewindDependency extends Model
{
    protected $table = 'titan_rewind_dependencies';
    protected $fillable = ['company_id','case_id','event_id','source_entity_type','source_entity_id','target_entity_type','target_entity_id','relationship_type','risk_level','meta_json'];
    protected $casts = ['meta_json'=>'array'];
}
