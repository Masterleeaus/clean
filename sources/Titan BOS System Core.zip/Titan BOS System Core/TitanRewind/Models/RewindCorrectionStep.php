<?php
namespace Modules\TitanRewind\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class RewindCorrectionStep extends Model
{
    protected $table = 'titan_rewind_correction_steps';
    protected $fillable = ['company_id','fix_id','step_order','step_type','status','target_type','target_id','input_json','result_json','error_text','started_at','finished_at'];
    protected $casts = ['input_json'=>'array','result_json'=>'array','started_at'=>'datetime','finished_at'=>'datetime'];
    public function fix(): BelongsTo { return $this->belongsTo(RewindFix::class, 'fix_id'); }
}
