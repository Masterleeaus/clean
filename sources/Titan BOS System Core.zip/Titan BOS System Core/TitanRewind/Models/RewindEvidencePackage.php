<?php
namespace Modules\TitanRewind\Models;

use Illuminate\Database\Eloquent\Model;

class RewindEvidencePackage extends Model
{
    protected $table = 'titan_rewind_evidence_packages';
    protected $fillable = ['company_id','case_id','event_id','package_type','status','hash','manifest_json','payload_json','generated_at','generated_by_id'];
    protected $casts = ['manifest_json'=>'array','generated_at'=>'datetime'];
}
