<?php
namespace Modules\TitanRewind\Models;
use Illuminate\Database\Eloquent\Model;
class RewindDriftFinding extends Model
{
    protected $table = 'titan_rewind_drift_findings';
    protected $fillable = ['company_id','finding_type','severity','status','entity_type','entity_id','summary','evidence_json','remediation_json','detected_at','resolved_at'];
    protected $casts = ['evidence_json'=>'array','remediation_json'=>'array','detected_at'=>'datetime','resolved_at'=>'datetime'];
}
