<?php
namespace Modules\TitanRewind\Models;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class RewindEvent extends Model
{
    public $timestamps = false;
    protected $table = 'titan_rewind_events';
    protected $fillable = ['company_id','case_id','event_type','event_version','entity_type','entity_id','actor_type','actor_id','source_type','source_id','ip_address','user_agent','correlation_id','idempotency_key','payload_json','before_json','after_json','risk_level','ai_summary','analysis_json','event_hash','prev_event_hash','created_at'];
    protected $casts = ['payload_json'=>'array','before_json'=>'array','after_json'=>'array','analysis_json'=>'array','created_at'=>'datetime'];
    public function rewindCase(): BelongsTo { return $this->belongsTo(RewindCase::class, 'case_id'); }
}
