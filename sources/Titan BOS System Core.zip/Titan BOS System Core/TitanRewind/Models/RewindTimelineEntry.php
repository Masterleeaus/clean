<?php
namespace Modules\TitanRewind\Models;
use Illuminate\Database\Eloquent\Model;
class RewindTimelineEntry extends Model
{
    protected $table = 'titan_rewind_timeline_entries';
    protected $fillable = ['company_id','event_id','entity_type','entity_id','title','summary','risk_level','meta_json','occurred_at'];
    protected $casts = ['meta_json'=>'array','occurred_at'=>'datetime'];
}
