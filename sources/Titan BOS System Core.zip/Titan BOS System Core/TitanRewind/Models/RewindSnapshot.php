<?php
namespace Modules\TitanRewind\Models;
use Illuminate\Database\Eloquent\Model;
class RewindSnapshot extends Model
{
    protected $table = 'titan_rewind_snapshots';
    protected $fillable = ['company_id','entity_type','entity_id','snapshot_type','event_id','state_json','state_hash','size_bytes','captured_at'];
    protected $casts = ['state_json'=>'array','captured_at'=>'datetime'];
}
