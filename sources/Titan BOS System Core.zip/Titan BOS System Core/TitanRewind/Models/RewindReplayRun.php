<?php

namespace Modules\TitanRewind\Models;

use Illuminate\Database\Eloquent\Model;

class RewindReplayRun extends Model
{
    protected $table = 'titan_rewind_replay_runs';

    protected $fillable = [
        'company_id', 'case_id', 'mode', 'status', 'target_environment', 'requested_by_id',
        'input_json', 'result_json', 'error_text', 'started_at', 'finished_at',
    ];

    protected $casts = [
        'input_json' => 'array',
        'result_json' => 'array',
        'started_at' => 'datetime',
        'finished_at' => 'datetime',
    ];
}
