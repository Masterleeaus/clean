<?php

namespace Modules\TitanRewind\Console;

use Illuminate\Console\Command;
use Modules\TitanRewind\Database\Seeders\TitanRewindPermissionSeeder;

class ActivateTitanRewind extends Command
{
    protected $signature = 'titanrewind:activate';
    protected $description = 'Activate TitanRewind and seed WorkSuite permissions/defaults idempotently.';

    public function handle(): int
    {
        $this->call('migrate', ['--force' => true]);
        $this->call('db:seed', ['--class' => TitanRewindPermissionSeeder::class, '--force' => true]);
        $this->info('TitanRewind activated.');
        return self::SUCCESS;
    }
}
