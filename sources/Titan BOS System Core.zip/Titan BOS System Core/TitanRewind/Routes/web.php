<?php

use Illuminate\Support\Facades\Route;
use Modules\TitanRewind\Http\Controllers\RewindApprovalController;
use Modules\TitanRewind\Http\Controllers\RewindAuditController;
use Modules\TitanRewind\Http\Controllers\RewindComplianceController;
use Modules\TitanRewind\Http\Controllers\RewindAssistantController;
use Modules\TitanRewind\Http\Controllers\RewindDashboardController;
use Modules\TitanRewind\Http\Controllers\RewindEvidenceController;
use Modules\TitanRewind\Http\Controllers\RewindIntegrityController;
use Modules\TitanRewind\Http\Controllers\RewindRecoveryController;
use Modules\TitanRewind\Http\Controllers\RewindReplayController;
use Modules\TitanRewind\Http\Controllers\RewindTimelineController;

Route::middleware('titan-rewind.permission:view')->group(function () {
    Route::get('/', RewindDashboardController::class)->name('dashboard');
    Route::get('/timeline', [RewindTimelineController::class, 'index'])->name('timeline.index');
    Route::get('/audit-history', [RewindAuditController::class, 'index'])->name('audit.index');
    Route::get('/audit-history/{event}', [RewindAuditController::class, 'show'])->name('audit.show');
    Route::get('/recovery-cases', [RewindRecoveryController::class, 'cases'])->name('cases.index');
    Route::get('/correction-plans', [RewindRecoveryController::class, 'fixes'])->name('fixes.index');
    Route::get('/replay', [RewindReplayController::class, 'index'])->name('replay.index');
    Route::get('/ai-assistant', [RewindAssistantController::class, 'index'])->name('assistant.index');
    Route::post('/ai-assistant', [RewindAssistantController::class, 'ask'])->middleware('titan-rewind.permission:manage')->name('assistant.ask');
    Route::get('/approvals', [RewindApprovalController::class, 'index'])->middleware('titan-rewind.permission:approve')->name('approvals.index');
    Route::get('/evidence', [RewindEvidenceController::class, 'index'])->middleware('titan-rewind.permission:compliance')->name('evidence.index');
    Route::get('/analytics', fn () => redirect()->route('titan-rewind.dashboard'))->name('analytics.index');
    Route::get('/settings', fn () => view('titan-rewind::settings'))->middleware('titan-rewind.permission:settings')->name('settings.index');
});

Route::post('/cases/{case}/request-correction', [RewindRecoveryController::class, 'request'])->middleware('titan-rewind.permission:manage')->name('cases.request-correction');
Route::post('/fixes/{fix}/approve', [RewindRecoveryController::class, 'approve'])->middleware('titan-rewind.permission:approve')->name('fixes.approve');
Route::post('/fixes/{fix}/request-approval', [RewindApprovalController::class, 'request'])->middleware('titan-rewind.permission:manage')->name('fixes.request-approval');
Route::post('/approvals/{approval}/approve', [RewindApprovalController::class, 'approve'])->middleware('titan-rewind.permission:approve')->name('approvals.approve');
Route::post('/fixes/{fix}/apply', [RewindRecoveryController::class, 'apply'])->middleware('titan-rewind.permission:apply')->name('fixes.apply');
Route::post('/replay/{case}/dry-run', [RewindReplayController::class, 'dryRun'])->middleware('titan-rewind.permission:manage')->name('replay.dry-run');
Route::get('/integrity', [RewindIntegrityController::class, 'index'])->middleware('titan-rewind.permission:manage')->name('integrity.index');
Route::post('/integrity/scan', [RewindIntegrityController::class, 'scan'])->middleware('titan-rewind.permission:manage')->name('integrity.scan');
Route::post('/integrity/verify', [RewindIntegrityController::class, 'verify'])->middleware('titan-rewind.permission:manage')->name('integrity.verify');
Route::get('/compliance', [RewindComplianceController::class, 'index'])->middleware('titan-rewind.permission:compliance')->name('compliance.index');
Route::get('/compliance/export', [RewindComplianceController::class, 'export'])->middleware('titan-rewind.permission:export')->name('compliance.export');
Route::post('/evidence/cases/{case}/generate', [RewindEvidenceController::class, 'generate'])->middleware('titan-rewind.permission:compliance')->name('evidence.generate');
Route::get('/evidence/{package}/download', [RewindEvidenceController::class, 'download'])->middleware('titan-rewind.permission:export')->name('evidence.download');
Route::get('/health', static fn () => response('titan-rewind-web-ok'))->name('health');
