<?php

use Illuminate\Support\Facades\Route;
use Modules\TitanRewind\Http\Controllers\Api\AuditTrailController;
use Modules\TitanRewind\Http\Controllers\RewindComplianceController;
use Modules\TitanRewind\Http\Controllers\RewindReplayController;
use Modules\TitanRewind\Http\Controllers\RewindIntegrityController;

Route::get('/health', static fn () => response()->json(['status' => 'titan-rewind-api-ok']))->name('health');

Route::middleware('titan-rewind.permission:view')->group(function () {
    Route::get('/audit-trail', AuditTrailController::class)->name('audit-trail.index');
    Route::post('/replay/{case}/dry-run', [RewindReplayController::class, 'dryRun'])->middleware('titan-rewind.permission:manage')->name('replay.dry-run');
});

Route::post('/integrity/scan', [RewindIntegrityController::class, 'scan'])->middleware('titan-rewind.permission:manage')->name('integrity.scan');
Route::post('/integrity/verify', [RewindIntegrityController::class, 'verify'])->middleware('titan-rewind.permission:manage')->name('integrity.verify');

Route::get('/compliance/export', [RewindComplianceController::class, 'export'])->middleware('titan-rewind.permission:export')->name('compliance.export');
