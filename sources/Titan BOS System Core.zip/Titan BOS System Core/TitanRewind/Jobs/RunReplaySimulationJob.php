<?php

namespace Modules\TitanRewind\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Modules\TitanRewind\Models\RewindReplayRun;
use Modules\TitanRewind\Services\RewindReplayService;

class RunReplaySimulationJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    public int $tries = 2;
    public function __construct(public int $replayRunId) {}
    public function handle(RewindReplayService $replay): void
    {
        $run = RewindReplayRun::query()->find($this->replayRunId);
        if ($run) $replay->executeRun($run);
    }
}
