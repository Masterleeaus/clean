<?php

namespace Modules\TitanRewind\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Modules\TitanRewind\Models\RewindEvent;
use Modules\TitanRewind\Services\RewindSnapshotService;

class CaptureRewindSnapshotJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    public int $tries = 3;
    public function __construct(public int $eventId) {}
    public function handle(RewindSnapshotService $snapshots): void
    {
        $event = RewindEvent::query()->find($this->eventId);
        if ($event) $snapshots->captureEventAfterState($event);
    }
}
