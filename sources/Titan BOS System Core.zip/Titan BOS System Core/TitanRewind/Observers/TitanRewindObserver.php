<?php
namespace Modules\TitanRewind\Observers;
use Illuminate\Database\Eloquent\Model;
use Modules\TitanRewind\Services\RewindAuditService;
use Modules\TitanRewind\Services\RewindSnapshotService;
use Modules\TitanRewind\Services\RewindTenantService;
class TitanRewindObserver
{
    public function __construct(private readonly RewindAuditService $audit, private readonly RewindTenantService $tenant, private readonly RewindSnapshotService $snapshots) {}
    public function record(string $eventName, Model $model): void
    {
        if ($this->ignored($model)) return;
        $companyId = $this->tenant->modelCompanyId($model); if (! $companyId) return;
        $eventType = str($eventName)->after('eloquent.')->before(':')->toString();
        $before = $eventType === 'updated' ? array_intersect_key($model->getOriginal(), $model->getChanges()) : ($eventType === 'deleted' ? $model->getOriginal() : null);
        $after = in_array($eventType, ['created','updated','restored'], true) ? $model->attributesToArray() : null;
        $event = $this->audit->appendEvent(['company_id'=>$companyId,'case_key'=>$model::class.':'.$model->getKey(),'title'=>class_basename($model).' '.$eventType,'event_type'=>$eventType,'entity_type'=>$model::class,'entity_id'=>(string)$model->getKey(),'actor_type'=>$this->tenant->actor()['type'],'actor_id'=>$this->tenant->actor()['id'],'source_type'=>'eloquent','source_id'=>(string)$model->getKey(),'before_json'=>$before,'after_json'=>$after,'payload_json'=>['model'=>$model::class,'changes_count'=>count($model->getChanges()),'changes'=>array_keys($model->getChanges())]]);
        if (in_array($eventType, ['created','updated','restored'], true)) $this->snapshots->captureModel($model, $event);
    }
    private function ignored(Model $model): bool
    { foreach (config('titan-rewind.ignored_models', []) as $class) if ($model instanceof $class) return true; return str_starts_with($model->getTable(), 'titan_rewind_'); }
}
