<?php

namespace Modules\TitanRewind\Support;

use Illuminate\Support\Str;

class RewindEventContract
{
    public static function normalize(array $payload): array
    {
        return [
            'company_id' => $payload['company_id'] ?? null,
            'event_type' => $payload['event_type'] ?? 'business.event',
            'entity_type' => $payload['entity_type'] ?? null,
            'entity_id' => isset($payload['entity_id']) ? (string) $payload['entity_id'] : null,
            'actor_type' => $payload['actor_type'] ?? 'system',
            'actor_id' => $payload['actor_id'] ?? null,
            'source_type' => $payload['source_type'] ?? 'module_event',
            'source_id' => isset($payload['source_id']) ? (string) $payload['source_id'] : null,
            'correlation_id' => $payload['correlation_id'] ?? (string) Str::uuid(),
            'case_key' => $payload['case_key'] ?? null,
            'title' => $payload['title'] ?? 'Business event captured',
            'severity' => $payload['severity'] ?? 'medium',
            'risk_level' => $payload['risk_level'] ?? null,
            'before_json' => $payload['before_json'] ?? null,
            'after_json' => $payload['after_json'] ?? null,
            'payload_json' => $payload['payload_json'] ?? [],
            'created_at' => $payload['created_at'] ?? now(),
        ];
    }

    public static function stableIdempotencyKey(array $payload): string
    {
        $material = [
            'company_id' => $payload['company_id'] ?? null,
            'event_type' => $payload['event_type'] ?? null,
            'entity_type' => $payload['entity_type'] ?? null,
            'entity_id' => $payload['entity_id'] ?? null,
            'source_type' => $payload['source_type'] ?? null,
            'source_id' => $payload['source_id'] ?? null,
            'correlation_id' => $payload['correlation_id'] ?? null,
            'created_at' => (string) ($payload['created_at'] ?? ''),
            'before_json' => $payload['before_json'] ?? null,
            'after_json' => $payload['after_json'] ?? null,
        ];

        return hash('sha256', json_encode($material, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }
}
