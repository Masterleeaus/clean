<?php

use Modules\TitanRewind\Models\RewindAction;
use Modules\TitanRewind\Models\RewindCase;
use Modules\TitanRewind\Models\RewindEvent;
use Modules\TitanRewind\Models\RewindFix;
use Modules\TitanRewind\Models\RewindSnapshot;
use Modules\TitanRewind\Models\RewindApproval;
use Modules\TitanRewind\Models\RewindReplayRun;
use Modules\TitanRewind\Entities\TitanRewindSetting;

return [
    'name' => 'TitanRewind',
    'verification_required' => false,
    'envato_item_id' => null,
    'parent_envato_id' => 23263417,
    'parent_min_version' => '6.0.0',
    'parent_product_name' => 'worksuite-saas-new',
    'setting' => TitanRewindSetting::class,
    'queue' => env('TITAN_REWIND_QUEUE', 'default'),
    'security_log_channel' => env('TITAN_REWIND_SECURITY_LOG', 'stack'),
    'tracked_models' => [],
    'ignored_models' => [
        RewindCase::class,
        RewindEvent::class,
        RewindFix::class,
        RewindAction::class,
        RewindSnapshot::class,
        RewindApproval::class,
        RewindReplayRun::class,
        TitanRewindSetting::class,
    ],
    'event_contract_version' => 1,
    'hash_algorithm' => 'sha256',
    'sensitivity' => env('TITAN_REWIND_SENSITIVITY', 'medium'),
    'async' => [
        'timeline' => true,
        'snapshots' => true,
        'ai_analysis' => true,
        'analytics' => true,
        'replay' => true,
    ],
    'permissions' => [
        'view' => 'view_titan_rewind',
        'manage' => 'manage_titan_rewind',
        'approve' => 'approve_titan_rewind',
        'apply' => 'apply_titan_rewind',
        'export' => 'export_titan_rewind',
        'compliance' => 'manage_titan_rewind_compliance',
        'settings' => 'manage_titan_rewind_settings',
    ],
    'allowlisted_target_tables' => [
        'titan_rewind_cases',
    ],
    'suggestion_similarity' => [
        'min_matches' => 1,
    ],
    'business_event_names' => [
        'booking.created', 'booking.updated', 'invoice.updated', 'payment.recorded', 'workflow.executed',
    ],
    'redacted_keys' => [
        'password', 'remember_token', 'token', 'secret', 'api_key', 'private_key', 'card_number', 'cvv'
    ],
];
