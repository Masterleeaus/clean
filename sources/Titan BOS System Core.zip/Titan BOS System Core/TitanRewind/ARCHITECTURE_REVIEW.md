# TitanRewind WorkSuite Upgrade - Pass 1

## Architecture review
TitanRewind is now framed as a WorkSuite-native trust layer: immutable event store, timeline, snapshots, AI analysis fallback, recovery/correction planning, replay dry-runs, compliance exports and analytics.

## Existing code issues found
- Filament dependency remained in module.json and provider list.
- Web UI was only a health route.
- Event records lacked source metadata, IP/user-agent, correlation ID, risk level, before/after JSON, AI analysis JSON and timeline projection.
- Snapshots were stored only as event payloads, not as queryable point-in-time state records.
- Rollback/apply pathway only supported a narrow metadata update.
- Multi-tenant reads existed in some places but were not centralized.

## Security improvements
- Central RewindTenantService enforces company scoping.
- Event store is append-only by convention, hash-linked, idempotent and redacts sensitive keys.
- WorkSuite routes use web/auth and API routes use auth:sanctum.
- Corrections stay approval-gated and are recorded as new immutable audit events.

## Recovery architecture
Recovery cases group related audit events. Correction plans are stored separately from application actions. High-risk correction actions require approval before execution.

## Replay engine design
Replay is dry-run only in Pass 1. It returns deterministic ordered steps and does not mutate business data. This is the correct safe base before sandbox replay.

## AI integration
Aitools remains the intended runtime. Pass 1 adds AiAuditAnalysisService with rule fallback and analysis_json so later Aitools calls can drop in without schema change.

## Database changes
Added event metadata columns, snapshots, timeline entries and approvals.

## New services
RewindTenantService, RewindTimelineService, RewindSnapshotService, RewindDiffService, RewindReplayService, RewindRollbackService, AiAuditAnalysisService, DriftDetectionService, RewindAnalyticsService and ComplianceExportService.

## WorkSuite compatibility changes
Removed Filament from active module registration, added Blade/Bootstrap views, Reply helper use for mutations, company()/user() aware tenancy, WorkSuite style route prefix under account/titan-rewind.

## Remaining technical debt
- Add installer/menu/permission seeder based on the exact WorkSuite module installer convention used in target deployment.
- Replace AI fallback with direct Aitools service calls once the installed Aitools module contract is confirmed.
- Add queue jobs for snapshot compression, timeline projection, AI analysis and analytics aggregation.
- Expand rollback strategies for specific domain entities: invoices, bookings, payments, jobs, documents and workflows.
- Add legal hold and retention policy tables.

## Manual testing checklist
1. Install module and run migrations.
2. Log in as company A and mutate a tracked WorkSuite record.
3. Confirm audit event, snapshot and timeline entry are created for company A.
4. Log in as company B and verify company A event is inaccessible.
5. Open Audit History and event detail diff.
6. Request correction on a case.
7. Approve correction plan.
8. Apply correction and confirm a new immutable action event appears.
9. Run replay dry-run and verify no business data changed.
10. Export compliance evidence JSON.

## Future roadmap
- Full Aitools assistant routing.
- Sandbox replay environment.
- Entity-specific recovery handlers.
- Cross-module dependency graph.
- Hash verification command and tamper alerts.
- Retention/legal hold policy engine.
- Drift trend dashboard.
- What-if simulation and training mode.

## Pass 2 Additions

- Added WorkSuite installer compatibility fields to `Config/config.php`, including `parent_envato_id`, `parent_min_version`, `parent_product_name`, and `setting`.
- Added `TitanRewindSetting` entity and settings migration for per-company sensitivity, retention, legal hold, AI analysis and approval rules.
- Added idempotent activation command: `php artisan titanrewind:activate`.
- Added permission seeder for the TitanRewind permission matrix.
- Added route-level WorkSuite permission middleware for view, manage, approve, apply, export, compliance and settings actions.
- Added reusable business-event contract so future modules can emit audit events without hardcoding module names.
- Added queue jobs for timeline generation, AI analysis/suggestion generation, snapshots and replay simulation.
- Reworked event idempotency to use stable business-event material instead of microtime/UUID-only keys.
- Added replay-run persistence so dry-runs are traceable and auditable, not just transient JSON responses.
- Added composer metadata and translation scaffold to match the WorkSuite/Nwidart module packaging standard.

## Remaining Pass 3 Targets

- Add dedicated notification classes for high-risk drift and approval requests.
- Add policies for model-level authorization in addition to route middleware.
- Add dashboard widgets for replay runs, approval queues and integrity score trends.
- Add explicit integration examples for Booking, ZeroPay, EInvoice and CleanQuality event emission.
- Add stronger hash-chain verification UI and scheduled integrity verification command.

## Pass 3 additions

### Dependency and impact mapping
- Added `titan_rewind_dependencies` and `RewindDependencyService` so events can declare downstream affected entities without hardcoding module names.
- Audit events may now include `payload_json.dependencies[]`; TitanRewind persists the dependency graph after commit.
- Rollback/replay planning can now inspect direct and reverse entity relationships before suggesting corrective action.

### Drift and integrity layer
- Added `titan_rewind_drift_findings` and `DriftDetectionService` persistence.
- Added duplicate idempotency key detection, missing hash detection, and high-risk event spike findings.
- Added `titan_rewind_integrity_checks` and `RewindIntegrityService` for tenant-scoped hash-chain verification.
- Added WorkSuite UI and API endpoints for drift scan and integrity verification.

### Correction execution structure
- Added `titan_rewind_correction_steps` and `RewindCorrectionPlanService`.
- Correction plans are now materialised into ordered steps when generated by users or AI.
- Applying a correction updates step status from pending/running to completed or failed, creating clearer non-technical visibility.

### WorkSuite UI improvements
- Added `Integrity & Drift` navigation.
- Correction plan UI now shows approval/application state and ordered correction steps.

### Remaining work after Pass 3
- Replace the current allowlisted metadata correction executor with per-entity correction executors registered by module contracts.
- Add full dependency graph visualization.
- Add multi-level approval rule configuration UI.
- Add queue jobs for scheduled integrity scans and drift trend aggregation.
- Add full Feature tests inside a real WorkSuite install with seeded permissions and company context.

## Pass 4 Additions

### Approval hardening
- Added `titan_rewind_approval_rules` for company/global approval policies.
- Added `RewindApprovalPolicyService` with multi-level approval creation and progression.
- Added approval UI and routes so high-risk correction execution can be blocked until approval is complete.

### Safe execution gates
- Added `RewindSafeExecutionService` as the execution boundary for correction plans.
- Destructive steps are blocked by default.
- Correction steps now track start/finish timing and result JSON.
- Apply flow now returns a blocked response when approval is missing instead of silently applying a fix.

### Evidence packaging
- Added `titan_rewind_evidence_packages` and `RewindEvidencePackageService`.
- Evidence packages include case, events, fixes, timeline, snapshots, manifest counts, generated timestamp and SHA-256 hash.
- Added Evidence UI and downloadable JSON packages for compliance/dispute workflows.

### AI Recovery Assistant routing
- Added `RewindAssistantRouterService`.
- The visible assistant remains singular, while internally routing requests to Audit, Recovery, Compliance, Integrity, Timeline, Correction and Root Cause agents.
- Current implementation is deterministic and safe; Aitools runtime bridge can replace the response generation later without changing controller/UI contracts.

### Remaining debt after Pass 4
- Replace placeholder step execution with entity-specific reversible command handlers.
- Add role-aware approval-rule enforcement using WorkSuite role lookups.
- Store evidence packages in configured filesystem storage for large tenants.
- Add notification hooks for pending approvals and critical evidence generation.
- Add integration tests against a real WorkSuite install database.
