<?php

namespace Modules\TitanRewind\Entities;

use Illuminate\Database\Eloquent\Model;

class TitanRewindSetting extends Model
{
    protected $table = 'titan_rewind_settings';

    protected $fillable = [
        'company_id',
        'sensitivity',
        'retention_days',
        'legal_hold_enabled',
        'ai_analysis_enabled',
        'auto_snapshot_enabled',
        'require_approval_for_high_risk',
        'settings_json',
    ];

    protected $casts = [
        'settings_json' => 'array',
        'legal_hold_enabled' => 'boolean',
        'ai_analysis_enabled' => 'boolean',
        'auto_snapshot_enabled' => 'boolean',
        'require_approval_for_high_risk' => 'boolean',
    ];
}
