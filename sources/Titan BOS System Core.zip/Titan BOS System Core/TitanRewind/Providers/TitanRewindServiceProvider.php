<?php

namespace Modules\TitanRewind\Providers;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Event;
use Illuminate\Support\ServiceProvider;
use Modules\TitanRewind\Console\ActivateTitanRewind;
use Modules\TitanRewind\Contracts\AuditableBusinessEvent;
use Modules\TitanRewind\Http\Middleware\EnsureTitanRewindPermission;
use Modules\TitanRewind\Listeners\CaptureBusinessEventListener;
use Modules\TitanRewind\Observers\TitanRewindObserver;
use Modules\TitanRewind\Services\AiAuditAnalysisService;
use Modules\TitanRewind\Services\ComplianceExportService;
use Modules\TitanRewind\Services\DriftDetectionService;
use Modules\TitanRewind\Services\RewindAnalyticsService;
use Modules\TitanRewind\Services\RewindAuditService;
use Modules\TitanRewind\Services\RewindCaseService;
use Modules\TitanRewind\Services\RewindDiffService;
use Modules\TitanRewind\Services\RewindDependencyService;
use Modules\TitanRewind\Services\RewindIntegrityService;
use Modules\TitanRewind\Services\RewindCorrectionPlanService;
use Modules\TitanRewind\Services\RewindFixService;
use Modules\TitanRewind\Services\RewindReplayService;
use Modules\TitanRewind\Services\RewindRollbackService;
use Modules\TitanRewind\Services\RewindSnapshotService;
use Modules\TitanRewind\Services\RewindSuggestionService;
use Modules\TitanRewind\Services\RewindTenantService;
use Modules\TitanRewind\Services\RewindTimelineService;
use Modules\TitanRewind\Services\TitanPulseBridge;

class TitanRewindServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__.'/../Config/config.php', 'titan-rewind');

        foreach ([
            RewindTenantService::class,
            RewindCaseService::class,
            RewindAuditService::class,
            RewindSnapshotService::class,
            RewindTimelineService::class,
            RewindDiffService::class,
            RewindReplayService::class,
            RewindRollbackService::class,
            RewindDependencyService::class,
            RewindIntegrityService::class,
            RewindCorrectionPlanService::class,
            RewindFixService::class,
            RewindSuggestionService::class,
            AiAuditAnalysisService::class,
            DriftDetectionService::class,
            RewindAnalyticsService::class,
            ComplianceExportService::class,
            TitanPulseBridge::class,
            TitanRewindObserver::class,
            CaptureBusinessEventListener::class,
        ] as $service) {
            $this->app->singleton($service);
        }
    }

    public function boot(): void
    {
        $this->loadMigrationsFrom(module_path('TitanRewind', 'Database/Migrations'));
        $this->loadViewsFrom(module_path('TitanRewind', 'Resources/views'), 'titan-rewind');
        $this->loadTranslationsFrom(module_path('TitanRewind', 'Resources/lang'), 'titan-rewind');

        $router = $this->app['router'];
        $router->aliasMiddleware('titan-rewind.permission', EnsureTitanRewindPermission::class);

        if ($this->app->runningInConsole()) {
            $this->commands([ActivateTitanRewind::class]);
        }

        Event::listen([
            'eloquent.created: *',
            'eloquent.updated: *',
            'eloquent.deleted: *',
            'eloquent.restored: *',
        ], function (string $eventName, array $data): void {
            $model = $data[0] ?? null;

            if ($model instanceof Model) {
                $this->app->make(TitanRewindObserver::class)->record($eventName, $model);
            }
        });

        foreach (config('titan-rewind.business_event_names', []) as $eventName) {
            Event::listen($eventName, [CaptureBusinessEventListener::class, 'handle']);
        }

        Event::listen(AuditableBusinessEvent::class, [CaptureBusinessEventListener::class, 'handle']);
    }
}
