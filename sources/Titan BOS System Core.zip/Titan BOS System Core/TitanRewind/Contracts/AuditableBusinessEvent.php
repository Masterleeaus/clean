<?php

namespace Modules\TitanRewind\Contracts;

interface AuditableBusinessEvent
{
    public function rewindPayload(): array;
}
