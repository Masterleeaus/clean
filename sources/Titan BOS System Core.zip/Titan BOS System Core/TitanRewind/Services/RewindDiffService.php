<?php
namespace Modules\TitanRewind\Services;
class RewindDiffService
{
    public function compare(?array $before, ?array $after): array
    {
        $before = $before ?? []; $after = $after ?? [];
        $added = array_diff_key($after, $before);
        $removed = array_diff_key($before, $after);
        $modified = [];
        foreach (array_intersect_key($after, $before) as $key => $value) {
            if (($before[$key] ?? null) != $value) $modified[$key] = ['before'=>$before[$key] ?? null, 'after'=>$value];
        }
        return ['added'=>$added,'removed'=>$removed,'modified'=>$modified,'count'=>count($added)+count($removed)+count($modified),'risk'=>$this->risk($modified, $removed)];
    }
    private function risk(array $modified, array $removed): string
    { $critical=['total','amount','price','status','company_id','user_id','role_id','permission','deleted_at']; foreach (array_keys($modified + $removed) as $key) if (in_array($key,$critical,true) || str_contains($key,'payment')) return 'high'; return count($modified) > 5 ? 'medium' : 'low'; }
}
