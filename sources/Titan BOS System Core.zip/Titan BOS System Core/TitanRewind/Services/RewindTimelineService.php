<?php
namespace Modules\TitanRewind\Services;
use Modules\TitanRewind\Models\RewindEvent;
use Modules\TitanRewind\Models\RewindTimelineEntry;
class RewindTimelineService
{
    public function record(RewindEvent $event): RewindTimelineEntry
    {
        return RewindTimelineEntry::query()->firstOrCreate(
            ['company_id'=>$event->company_id, 'event_id'=>$event->id],
            ['entity_type'=>$event->entity_type,'entity_id'=>$event->entity_id,'title'=>$this->title($event),'summary'=>$this->summary($event),'risk_level'=>$event->risk_level ?? 'low','meta_json'=>['actor_type'=>$event->actor_type,'actor_id'=>$event->actor_id,'source_type'=>$event->source_type,'correlation_id'=>$event->correlation_id],'occurred_at'=>$event->created_at]
        );
    }
    public function forEntity(int $companyId, string $type, string $id, int $limit=100)
    {
        return RewindTimelineEntry::query()->where('company_id',$companyId)->where('entity_type',$type)->where('entity_id',$id)->latest('occurred_at')->limit($limit)->get();
    }
    private function title(RewindEvent $event): string { return trim(str_replace('_',' ', ucfirst($event->event_type)).' • '.class_basename((string)$event->entity_type).' #'.$event->entity_id); }
    private function summary(RewindEvent $event): string { $count = is_array($event->before_json) && is_array($event->after_json) ? count(array_diff_assoc($event->after_json, $event->before_json)) : ($event->payload_json['changes_count'] ?? 0); return $count ? $count.' tracked field change(s).' : 'Tracked event captured.'; }
}
