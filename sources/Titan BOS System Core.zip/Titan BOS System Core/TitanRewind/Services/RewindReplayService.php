<?php

namespace Modules\TitanRewind\Services;

use Modules\TitanRewind\Jobs\RunReplaySimulationJob;
use Modules\TitanRewind\Models\RewindCase;
use Modules\TitanRewind\Models\RewindReplayRun;

class RewindReplayService
{
    public function queueDryRun(RewindCase $case, ?int $requestedById = null, array $input = []): RewindReplayRun
    {
        $run = RewindReplayRun::query()->create([
            'company_id' => $case->company_id,
            'case_id' => $case->id,
            'mode' => 'dry_run',
            'status' => 'queued',
            'requested_by_id' => $requestedById,
            'input_json' => $input,
        ]);

        RunReplaySimulationJob::dispatch($run->id)->onQueue(config('titan-rewind.queue', 'default'));

        return $run;
    }

    public function executeRun(RewindReplayRun $run): RewindReplayRun
    {
        $run->update(['status' => 'running', 'started_at' => now()]);

        try {
            $case = RewindCase::query()->where('company_id', $run->company_id)->findOrFail($run->case_id);
            $result = $this->dryRun($case);
            $run->update(['status' => 'completed', 'result_json' => $result, 'finished_at' => now()]);
        } catch (\Throwable $e) {
            $run->update(['status' => 'failed', 'error_text' => $e->getMessage(), 'finished_at' => now()]);
        }

        return $run->refresh();
    }

    public function dryRun(RewindCase $case): array
    {
        $events = $case->events()->orderBy('created_at')->get();

        return [
            'mode' => 'dry_run',
            'case_id' => $case->id,
            'events' => $events->count(),
            'deterministic' => true,
            'would_apply' => false,
            'dependency_count' => $events->pluck('entity_type')->filter()->unique()->count(),
            'steps' => $events->map(fn ($e) => [
                'event_id' => $e->id,
                'event_type' => $e->event_type,
                'entity_type' => $e->entity_type,
                'entity_id' => $e->entity_id,
                'risk' => $e->risk_level,
                'result' => 'simulated_only',
            ])->values()->all(),
        ];
    }
}
