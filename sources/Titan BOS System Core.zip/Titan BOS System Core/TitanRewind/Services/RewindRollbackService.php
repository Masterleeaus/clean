<?php
namespace Modules\TitanRewind\Services;
use Modules\TitanRewind\Models\RewindEvent;
class RewindRollbackService
{
    public function planFromEvent(RewindEvent $event): array
    {
        $diff = app(RewindDiffService::class)->compare($event->before_json, $event->after_json);
        return ['event_id'=>$event->id,'safe_to_auto_apply'=>false,'requires_approval'=>true,'risk'=>$diff['risk'],'strategy'=>'correction_plan_not_blind_overwrite','steps'=>['Verify current entity still belongs to same company','Compare current state with audited after-state','Reverse only changed fields without overwriting newer valid data','Record correction as a new immutable event'] ,'diff'=>$diff];
    }
}
