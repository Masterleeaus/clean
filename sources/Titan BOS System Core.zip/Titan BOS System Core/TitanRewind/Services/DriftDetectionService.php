<?php
namespace Modules\TitanRewind\Services;
use Modules\TitanRewind\Models\RewindDriftFinding;
use Modules\TitanRewind\Models\RewindEvent;
class DriftDetectionService
{
    public function scan(int $companyId): array
    {
        $high = RewindEvent::query()->where('company_id',$companyId)->where('risk_level','high')->where('created_at','>=',now()->subDays(7))->count();
        $missingHashes = RewindEvent::query()->where('company_id',$companyId)->whereNull('event_hash')->count();
        $duplicateKeys = RewindEvent::query()->selectRaw('idempotency_key, COUNT(*) as c')->where('company_id',$companyId)->whereNotNull('idempotency_key')->groupBy('idempotency_key')->havingRaw('COUNT(*) > 1')->limit(25)->get();
        $findings = [];
        if ($missingHashes > 0) { $findings[] = $this->upsertFinding($companyId, 'missing_event_hash', 'critical', 'Audit events missing hash integrity data.', ['count'=>$missingHashes]); }
        if ($high > 0) { $findings[] = $this->upsertFinding($companyId, 'high_risk_spike', 'high', 'High-risk events occurred in the last seven days.', ['count'=>$high]); }
        if ($duplicateKeys->count() > 0) { $findings[] = $this->upsertFinding($companyId, 'duplicate_idempotency_key', 'medium', 'Duplicate idempotency keys detected.', ['duplicates'=>$duplicateKeys->toArray()]); }
        return ['company_id'=>$companyId,'critical_alerts'=>$high + $missingHashes,'high_risk_events_7d'=>$high,'missing_hash_events'=>$missingHashes,'duplicate_idempotency_keys'=>$duplicateKeys->count(),'findings_created_or_open'=>count($findings),'status'=>($high+$missingHashes+$duplicateKeys->count())>0?'review':'clear'];
    }
    private function upsertFinding(int $companyId, string $type, string $severity, string $summary, array $evidence): RewindDriftFinding
    {
        return RewindDriftFinding::query()->updateOrCreate(['company_id'=>$companyId,'finding_type'=>$type,'status'=>'open'], ['severity'=>$severity,'summary'=>$summary,'evidence_json'=>$evidence,'remediation_json'=>['recommendation'=>'Review affected records, simulate correction, and approve only reversible fixes.'],'detected_at'=>now()]);
    }
}
