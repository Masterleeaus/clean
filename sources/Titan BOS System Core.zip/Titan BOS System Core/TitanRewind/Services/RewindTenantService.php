<?php

namespace Modules\TitanRewind\Services;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Model;

class RewindTenantService
{
    public function currentCompanyId(): ?int
    {
        if (function_exists('company') && company()) {
            return (int) company()->id;
        }

        if (function_exists('user') && user()?->company_id) {
            return (int) user()->company_id;
        }

        return auth()->user()?->company_id ? (int) auth()->user()->company_id : null;
    }

    public function actor(): array
    {
        $user = function_exists('user') ? user() : auth()->user();

        return [
            'type' => $user ? 'user' : 'system',
            'id' => $user?->id,
            'company_id' => $this->currentCompanyId(),
        ];
    }

    public function assertCompany(?int $recordCompanyId): int
    {
        $companyId = $this->currentCompanyId();

        if ($companyId === null || $recordCompanyId === null || (int) $recordCompanyId !== $companyId) {
            abort(403, 'TitanRewind company boundary violation.');
        }

        return $companyId;
    }

    public function scope(Builder $query): Builder
    {
        $companyId = $this->currentCompanyId();

        return $companyId ? $query->where('company_id', $companyId) : $query->whereRaw('1 = 0');
    }

    public function modelCompanyId(Model $model): ?int
    {
        if (isset($model->company_id)) {
            return (int) $model->company_id;
        }

        if (function_exists('company') && company()) {
            return (int) company()->id;
        }

        return auth()->user()?->company_id ? (int) auth()->user()->company_id : null;
    }
}
