<?php
namespace Modules\TitanRewind\Services;
use Modules\TitanRewind\Models\RewindCase; use Modules\TitanRewind\Models\RewindEvent; use Modules\TitanRewind\Models\RewindFix;
class RewindAnalyticsService
{
    public function dashboard(int $companyId): array
    { return ['events'=>RewindEvent::where('company_id',$companyId)->count(),'cases_open'=>RewindCase::where('company_id',$companyId)->where('status','open')->count(),'high_risk_events'=>RewindEvent::where('company_id',$companyId)->where('risk_level','high')->count(),'pending_fixes'=>RewindFix::where('company_id',$companyId)->whereIn('status',['proposed','confirmed'])->count(),'integrity_score'=>$this->integrityScore($companyId)]; }
    private function integrityScore(int $companyId): int { $total=RewindEvent::where('company_id',$companyId)->count(); if (!$total) return 100; $bad=RewindEvent::where('company_id',$companyId)->whereNull('event_hash')->count(); return max(0, 100 - (int)round(($bad/$total)*100)); }
}
