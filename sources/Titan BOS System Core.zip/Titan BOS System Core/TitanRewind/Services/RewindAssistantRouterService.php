<?php
namespace Modules\TitanRewind\Services;

use Modules\TitanRewind\Models\RewindCase;

class RewindAssistantRouterService
{
    public function route(string $message, ?RewindCase $case = null): array
    {
        $text = strtolower($message);
        $agent = 'Audit Agent';
        if (str_contains($text, 'rollback') || str_contains($text, 'restore')) {
            $agent = 'Recovery Agent';
        } elseif (str_contains($text, 'compliance') || str_contains($text, 'export') || str_contains($text, 'evidence')) {
            $agent = 'Compliance Agent';
        } elseif (str_contains($text, 'drift') || str_contains($text, 'integrity') || str_contains($text, 'hash')) {
            $agent = 'Integrity Agent';
        } elseif (str_contains($text, 'timeline') || str_contains($text, 'who changed') || str_contains($text, 'when')) {
            $agent = 'Timeline Agent';
        } elseif (str_contains($text, 'fix') || str_contains($text, 'correct')) {
            $agent = 'Correction Agent';
        } elseif (str_contains($text, 'why') || str_contains($text, 'cause')) {
            $agent = 'Root Cause Agent';
        }

        return [
            'agent' => $agent,
            'mode' => 'guided',
            'case_id' => $case?->id,
            'recommendation' => $this->recommendation($agent),
            'next_actions' => $this->nextActions($agent),
        ];
    }

    protected function recommendation(string $agent): string
    {
        return match ($agent) {
            'Recovery Agent' => 'Create a dry-run recovery plan first. Do not overwrite newer valid data.',
            'Compliance Agent' => 'Generate an evidence package and verify the event hash chain before export.',
            'Integrity Agent' => 'Run integrity verification, then create drift findings for any broken sequence.',
            'Timeline Agent' => 'Filter the entity timeline by company, entity type, and correlation ID.',
            'Correction Agent' => 'Prefer a reversible correction plan over direct mutation.',
            'Root Cause Agent' => 'Compare before/after snapshots and downstream dependency records.',
            default => 'Review the audit event, timeline entry, actor, source, and risk metadata.',
        };
    }

    protected function nextActions(string $agent): array
    {
        return match ($agent) {
            'Recovery Agent' => ['create_replay_dry_run', 'calculate_dependencies', 'request_approval'],
            'Compliance Agent' => ['verify_hash_chain', 'generate_evidence_package', 'export_audit_bundle'],
            'Integrity Agent' => ['scan_drift', 'verify_integrity', 'review_critical_findings'],
            'Correction Agent' => ['materialise_steps', 'request_approval', 'execute_safe_steps'],
            default => ['open_timeline', 'inspect_event', 'compare_snapshots'],
        };
    }
}
