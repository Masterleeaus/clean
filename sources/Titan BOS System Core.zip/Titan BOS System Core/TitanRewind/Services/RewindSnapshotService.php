<?php

namespace Modules\TitanRewind\Services;

use Illuminate\Database\Eloquent\Model;
use Modules\TitanRewind\Models\RewindEvent;
use Modules\TitanRewind\Models\RewindSnapshot;

class RewindSnapshotService
{
    public function captureModel(Model $model, ?RewindEvent $event = null, string $type = 'full'): ?RewindSnapshot
    {
        $companyId = app(RewindTenantService::class)->modelCompanyId($model);
        if (! $companyId) return null;

        return $this->store($companyId, $model::class, (string) $model->getKey(), $type, $model->attributesToArray(), $event?->id);
    }

    public function captureEventAfterState(RewindEvent $event, string $type = 'event_after'): ?RewindSnapshot
    {
        if (! is_array($event->after_json) || ! $event->entity_type || ! $event->entity_id) {
            return null;
        }

        return $this->store((int) $event->company_id, $event->entity_type, (string) $event->entity_id, $type, $event->after_json, $event->id);
    }

    public function store(int $companyId, string $entityType, string $entityId, string $snapshotType, array $state, ?int $eventId = null): RewindSnapshot
    {
        $json = json_encode($state, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

        return RewindSnapshot::query()->create([
            'company_id' => $companyId,
            'entity_type' => $entityType,
            'entity_id' => $entityId,
            'snapshot_type' => $snapshotType,
            'event_id' => $eventId,
            'state_json' => $state,
            'state_hash' => hash('sha256', $json ?: ''),
            'size_bytes' => strlen($json ?: ''),
            'captured_at' => now(),
        ]);
    }

    public function latest(int $companyId, string $type, string $id): ?RewindSnapshot
    {
        return RewindSnapshot::query()->where('company_id', $companyId)->where('entity_type', $type)->where('entity_id', $id)->latest('captured_at')->first();
    }
}
