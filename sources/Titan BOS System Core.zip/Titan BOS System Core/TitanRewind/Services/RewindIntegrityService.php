<?php
namespace Modules\TitanRewind\Services;
use Modules\TitanRewind\Models\RewindEvent;
use Modules\TitanRewind\Models\RewindIntegrityCheck;
class RewindIntegrityService
{
    public function verifyHashChain(?int $companyId = null, ?int $checkedById = null): RewindIntegrityCheck
    {
        $check = RewindIntegrityCheck::query()->create(['company_id'=>$companyId,'check_type'=>'hash_chain','status'=>'running','checked_by_id'=>$checkedById,'started_at'=>now()]);
        $query = RewindEvent::query()->orderBy('id');
        if ($companyId) { $query->where('company_id',$companyId); }
        $previousByCompany = [];
        $failures = [];
        $count = 0;
        $audit = app(RewindAuditService::class);
        foreach ($query->cursor() as $event) {
            $count++;
            $row = $event->getAttributes();
            $expectedHash = $audit->hashEvent($row);
            $expectedPrev = $previousByCompany[$event->company_id] ?? null;
            if ($event->event_hash !== $expectedHash || $event->prev_event_hash !== $expectedPrev) {
                $failures[] = ['event_id'=>$event->id,'hash_ok'=>$event->event_hash === $expectedHash,'prev_hash_ok'=>$event->prev_event_hash === $expectedPrev];
            }
            $previousByCompany[$event->company_id] = $event->event_hash;
        }
        $check->update(['status'=>count($failures) ? 'failed' : 'passed','events_checked'=>$count,'failures_count'=>count($failures),'result_json'=>['failures'=>array_slice($failures,0,50)],'finished_at'=>now()]);
        return $check->refresh();
    }
}
