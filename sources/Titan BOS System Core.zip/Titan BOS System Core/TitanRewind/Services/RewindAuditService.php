<?php

namespace Modules\TitanRewind\Services;

use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Modules\TitanRewind\Jobs\AnalyseRewindEventJob;
use Modules\TitanRewind\Jobs\RecordTimelineEntryJob;
use Modules\TitanRewind\Models\RewindEvent;
use Modules\TitanRewind\Support\RewindEventContract;

class RewindAuditService
{
    public function __construct(
        private readonly RewindCaseService $cases,
        private readonly RewindSuggestionService $suggestions,
        private readonly AiAuditAnalysisService $ai,
        private readonly RewindTimelineService $timeline,
        private readonly RewindDependencyService $dependencies,
    ) {}

    public function appendBusinessEvent(array $data): RewindEvent
    {
        $data = RewindEventContract::normalize($data);
        $data['idempotency_key'] = $data['idempotency_key'] ?? RewindEventContract::stableIdempotencyKey($data);

        return $this->appendEvent($data);
    }

    public function appendEvent(array $data): RewindEvent
    {
        $companyId = (int) ($data['company_id'] ?? 0);
        if ($companyId <= 0) {
            throw new \InvalidArgumentException('TitanRewind event requires company_id.');
        }

        $case = $data['case'] ?? $this->cases->findOrOpenCase([
            'company_id' => $companyId,
            'case_key' => $data['case_key'] ?? null,
            'title' => $data['title'] ?? 'Tracked business mutation detected',
            'severity' => $data['severity'] ?? 'medium',
            'source_type' => $data['source_type'] ?? 'audit',
            'source_id' => $data['source_id'] ?? null,
            'entity_type' => $data['entity_type'] ?? null,
            'entity_id' => $data['entity_id'] ?? null,
            'detected_at' => $data['created_at'] ?? now(),
            'meta_json' => $data['case_meta_json'] ?? [],
        ]);

        return DB::transaction(function () use ($case, $data, $companyId) {
            $idempotencyKey = $data['idempotency_key'] ?? $this->makeIdempotencyKey($data);

            $existing = RewindEvent::query()
                ->where('company_id', $companyId)
                ->where('idempotency_key', $idempotencyKey)
                ->first();

            if ($existing) {
                return $existing;
            }

            $previous = RewindEvent::query()->where('company_id', $companyId)->latest('id')->first();

            $payload = $this->redact($data['payload_json'] ?? []);
            $row = [
                'company_id' => $companyId,
                'case_id' => $case->id,
                'event_type' => $data['event_type'] ?? 'updated',
                'event_version' => (int) config('titan-rewind.event_contract_version', 1),
                'entity_type' => $data['entity_type'] ?? null,
                'entity_id' => isset($data['entity_id']) ? (string) $data['entity_id'] : null,
                'actor_type' => $data['actor_type'] ?? 'system',
                'actor_id' => $data['actor_id'] ?? null,
                'source_type' => $data['source_type'] ?? 'audit',
                'source_id' => isset($data['source_id']) ? (string) $data['source_id'] : null,
                'ip_address' => request()?->ip(),
                'user_agent' => substr((string) request()?->userAgent(), 0, 500),
                'correlation_id' => $data['correlation_id'] ?? request()?->headers->get('X-Correlation-ID') ?? (string) Str::uuid(),
                'idempotency_key' => $idempotencyKey,
                'payload_json' => $payload,
                'before_json' => $this->redact($data['before_json'] ?? ($payload['before'] ?? null)),
                'after_json' => $this->redact($data['after_json'] ?? ($payload['after'] ?? null)),
                'risk_level' => $data['risk_level'] ?? $this->riskFor($data['event_type'] ?? 'updated', is_array($payload) ? $payload : []),
                'ai_summary' => $data['ai_summary'] ?? null,
                'prev_event_hash' => $previous?->event_hash,
                'created_at' => $data['created_at'] ?? now(),
            ];

            $row['event_hash'] = $this->hashEvent($row);

            $event = RewindEvent::query()->create($row);
            $this->afterCommit($event);

            return $event->refresh();
        });
    }

    public function hashEvent(array $row): string
    {
        $material = $row;
        unset($material['event_hash']);

        return hash((string) config('titan-rewind.hash_algorithm', 'sha256'), json_encode($material, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }

    private function afterCommit(RewindEvent $event): void
    {
        DB::afterCommit(function () use ($event): void {
            $this->dependencies->recordFromEvent($event);
            if (config('titan-rewind.async.timeline', true)) {
                RecordTimelineEntryJob::dispatch($event->id)->onQueue(config('titan-rewind.queue', 'default'));
            } else {
                $this->timeline->record($event);
            }

            if (config('titan-rewind.async.ai_analysis', true)) {
                AnalyseRewindEventJob::dispatch($event->id)->onQueue(config('titan-rewind.queue', 'default'));
            } else {
                $this->ai->analyse($event);
                $this->suggestions->suggestForEvent($event);
            }
        });
    }

    private function makeIdempotencyKey(array $data): string
    {
        return RewindEventContract::stableIdempotencyKey($data + ['correlation_id' => $data['correlation_id'] ?? request()?->headers->get('X-Correlation-ID')]);
    }

    private function riskFor(string $eventType, array $payload): string
    {
        $eventType = strtolower($eventType);
        if (str_contains($eventType, 'delete') || str_contains($eventType, 'payment') || str_contains($eventType, 'permission') || str_contains($eventType, 'rollback')) {
            return 'high';
        }
        if (($payload['changes_count'] ?? 0) > 10) {
            return 'medium';
        }
        return 'low';
    }

    private function redact(mixed $value): mixed
    {
        if (! is_array($value)) {
            return $value;
        }

        $redacted = [];
        $keys = array_map('strtolower', config('titan-rewind.redacted_keys', []));
        foreach ($value as $key => $item) {
            $redacted[$key] = in_array(strtolower((string) $key), $keys, true) ? '[redacted]' : $this->redact($item);
        }

        return $redacted;
    }
}
