<?php
namespace Modules\TitanRewind\Services;
use Illuminate\Support\Arr;
use Modules\TitanRewind\Models\RewindCorrectionStep;
use Modules\TitanRewind\Models\RewindFix;
class RewindCorrectionPlanService
{
    public function materialiseSteps(RewindFix $fix): array
    {
        if (RewindCorrectionStep::query()->where('fix_id',$fix->id)->exists()) {
            return RewindCorrectionStep::query()->where('fix_id',$fix->id)->orderBy('step_order')->get()->all();
        }
        $proposal = $fix->proposal_json ?? [];
        $steps = $proposal['steps'] ?? [
            ['step_type'=>'validate_current_state','target_type'=>Arr::get($proposal,'target_table'),'target_id'=>Arr::get($proposal,'target_id')],
            ['step_type'=>'apply_metadata_correction','target_type'=>Arr::get($proposal,'target_table'),'target_id'=>Arr::get($proposal,'target_id')],
            ['step_type'=>'record_follow_up_audit','target_type'=>RewindFix::class,'target_id'=>$fix->id],
        ];
        $created = [];
        foreach (array_values($steps) as $idx => $step) {
            $created[] = RewindCorrectionStep::query()->create([
                'company_id'=>$fix->company_id,
                'fix_id'=>$fix->id,
                'step_order'=>$idx+1,
                'step_type'=>(string)($step['step_type'] ?? 'manual_review'),
                'target_type'=>$step['target_type'] ?? null,
                'target_id'=>isset($step['target_id']) ? (string)$step['target_id'] : null,
                'input_json'=>$step,
            ]);
        }
        return $created;
    }
}
