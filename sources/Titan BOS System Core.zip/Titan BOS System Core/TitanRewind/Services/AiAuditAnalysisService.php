<?php
namespace Modules\TitanRewind\Services;
use Modules\TitanRewind\Models\RewindEvent;
class AiAuditAnalysisService
{
    public function analyse(RewindEvent $event): void
    {
        $analysis = ['provider'=>'aitools','status'=>'queued_or_rule_fallback','sensitivity'=>config('titan-rewind.sensitivity'),'risk_level'=>$event->risk_level,'signals'=>$this->signals($event),'confidence'=>0.55];
        $summary = $analysis['signals'] ? 'Potential issue: '.implode(', ', $analysis['signals']) : 'No immediate audit anomaly detected.';
        $event->forceFill(['analysis_json'=>$analysis,'ai_summary'=>$summary])->save();
    }
    private function signals(RewindEvent $event): array
    { $s=[]; if (($event->risk_level ?? 'low')==='high') $s[]='high-risk business change'; if (str_contains((string)$event->event_type,'delete')) $s[]='destructive action'; if (($event->payload_json['changes_count'] ?? 0) > 10) $s[]='large change set'; if (($event->before_json['company_id'] ?? null) && ($event->after_json['company_id'] ?? null) && $event->before_json['company_id'] != $event->after_json['company_id']) $s[]='tenant boundary drift'; return $s; }
}
