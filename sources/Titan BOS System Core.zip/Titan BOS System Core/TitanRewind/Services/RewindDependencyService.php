<?php
namespace Modules\TitanRewind\Services;
use Modules\TitanRewind\Models\RewindDependency;
use Modules\TitanRewind\Models\RewindEvent;
class RewindDependencyService
{
    public function recordFromEvent(RewindEvent $event): array
    {
        $deps = [];
        $payload = $event->payload_json ?? [];
        foreach ((array)($payload['dependencies'] ?? []) as $dependency) {
            if (! is_array($dependency) || empty($dependency['target_entity_type'])) { continue; }
            $deps[] = RewindDependency::query()->firstOrCreate([
                'company_id' => $event->company_id,
                'event_id' => $event->id,
                'source_entity_type' => (string)($dependency['source_entity_type'] ?? $event->entity_type ?? 'unknown'),
                'source_entity_id' => isset($dependency['source_entity_id']) ? (string)$dependency['source_entity_id'] : $event->entity_id,
                'target_entity_type' => (string)$dependency['target_entity_type'],
                'target_entity_id' => isset($dependency['target_entity_id']) ? (string)$dependency['target_entity_id'] : null,
            ], [
                'case_id' => $event->case_id,
                'relationship_type' => (string)($dependency['relationship_type'] ?? 'related'),
                'risk_level' => (string)($dependency['risk_level'] ?? $event->risk_level ?? 'low'),
                'meta_json' => $dependency['meta_json'] ?? [],
            ]);
        }
        return $deps;
    }

    public function impactForEntity(int $companyId, ?string $entityType, ?string $entityId): array
    {
        if (! $entityType) { return ['direct'=>[], 'reverse'=>[], 'count'=>0]; }
        $direct = RewindDependency::query()->where('company_id',$companyId)->where('source_entity_type',$entityType)->when($entityId, fn($q)=>$q->where('source_entity_id',$entityId))->limit(100)->get();
        $reverse = RewindDependency::query()->where('company_id',$companyId)->where('target_entity_type',$entityType)->when($entityId, fn($q)=>$q->where('target_entity_id',$entityId))->limit(100)->get();
        return ['direct'=>$direct->toArray(), 'reverse'=>$reverse->toArray(), 'count'=>$direct->count()+$reverse->count()];
    }
}
