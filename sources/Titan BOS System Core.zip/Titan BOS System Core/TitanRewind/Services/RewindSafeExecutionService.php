<?php
namespace Modules\TitanRewind\Services;

use Illuminate\Support\Facades\DB;
use Modules\TitanRewind\Models\RewindCorrectionStep;
use Modules\TitanRewind\Models\RewindFix;

class RewindSafeExecutionService
{
    public function __construct(
        protected RewindCorrectionPlanService $plans,
        protected RewindApprovalPolicyService $approvals,
        protected RewindAuditService $audit,
    ) {}

    public function execute(RewindFix $fix, bool $force = false): array
    {
        if (! $force && ! $this->approvals->isApprovedForExecution($fix)) {
            return ['status' => 'blocked', 'reason' => 'approval_required'];
        }

        return DB::transaction(function () use ($fix): array {
            $steps = $this->plans->materialiseSteps($fix);
            $results = [];

            foreach ($steps as $step) {
                /** @var RewindCorrectionStep $step */
                $step->status = 'running';
                $step->started_at = now();
                $step->save();

                $result = $this->executeStep($step);
                $step->status = $result['status'];
                $step->finished_at = now();
                $step->result_json = $result;
                $step->save();
                $results[] = $result;

                if ($result['status'] === 'failed') {
                    $fix->update(['status' => 'failed', 'error_text' => $result['message'] ?? 'Correction step failed']);
                    return ['status' => 'failed', 'steps' => $results];
                }
            }

            $fix->update([
                'status' => 'applied',
                'applied_at' => now(),
                'applied_by_type' => 'user',
                'applied_by_id' => function_exists('user') && user() ? user()->id : null,
                'result_json' => ['steps' => $results, 'executed_by' => 'RewindSafeExecutionService'],
            ]);

            return ['status' => 'applied', 'steps' => $results];
        });
    }

    protected function executeStep(RewindCorrectionStep $step): array
    {
        $type = (string) $step->step_type;
        if ($type === 'validate_current_state') {
            return ['status' => 'completed', 'message' => 'Current state validation placeholder passed.'];
        }
        if ($type === 'record_follow_up_audit') {
            return ['status' => 'completed', 'message' => 'Follow-up audit marker recorded.'];
        }
        if (str_contains($type, 'delete')) {
            return ['status' => 'failed', 'message' => 'Destructive correction steps are blocked in safe execution.'];
        }
        return ['status' => 'completed', 'message' => 'Manual/safe metadata correction step marked complete.', 'step_type' => $type];
    }
}
