<?php
namespace Modules\TitanRewind\Services;

use Illuminate\Support\Facades\DB;
use Modules\TitanRewind\Models\RewindApproval;
use Modules\TitanRewind\Models\RewindApprovalRule;
use Modules\TitanRewind\Models\RewindFix;

class RewindApprovalPolicyService
{
    public function requiredLevels(string $actionType, string $riskLevel = 'medium', ?int $companyId = null): int
    {
        $rule = RewindApprovalRule::query()
            ->where('action_type', $actionType)
            ->where('is_active', true)
            ->where(function ($query) use ($companyId): void {
                $query->whereNull('company_id');
                if ($companyId) {
                    $query->orWhere('company_id', $companyId);
                }
            })
            ->orderByRaw('company_id is null')
            ->orderByDesc('required_levels')
            ->first();

        if ($rule) {
            return max(1, (int) $rule->required_levels);
        }

        return in_array($riskLevel, ['critical','high'], true) ? 2 : 1;
    }

    public function openApproval(RewindFix $fix, string $actionType = 'apply_correction', string $riskLevel = 'medium'): RewindApproval
    {
        $required = $this->requiredLevels($actionType, $riskLevel, $fix->company_id ? (int) $fix->company_id : null);

        return RewindApproval::query()->firstOrCreate([
            'company_id' => $fix->company_id,
            'case_id' => $fix->case_id,
            'fix_id' => $fix->id,
            'action_type' => $actionType,
            'approval_level' => 1,
        ], [
            'status' => 'pending',
            'requested_by_type' => 'user',
            'requested_by_id' => function_exists('user') && user() ? user()->id : null,
            'meta_json' => ['required_levels' => $required, 'risk_level' => $riskLevel],
        ]);
    }

    public function approve(RewindApproval $approval, ?string $note = null): RewindApproval
    {
        return DB::transaction(function () use ($approval, $note): RewindApproval {
            $meta = $approval->meta_json ?? [];
            $required = (int) ($meta['required_levels'] ?? 1);
            $currentLevel = (int) $approval->approval_level;

            $approval->fill([
                'status' => $currentLevel >= $required ? 'approved' : 'pending',
                'decided_by_type' => 'user',
                'decided_by_id' => function_exists('user') && user() ? user()->id : null,
                'decided_at' => now(),
                'decision_note' => $note,
            ])->save();

            if ($currentLevel < $required) {
                RewindApproval::query()->firstOrCreate([
                    'company_id' => $approval->company_id,
                    'case_id' => $approval->case_id,
                    'fix_id' => $approval->fix_id,
                    'action_type' => $approval->action_type,
                    'approval_level' => $currentLevel + 1,
                ], [
                    'status' => 'pending',
                    'requested_by_type' => 'system',
                    'meta_json' => $meta,
                ]);
            }

            return $approval->refresh();
        });
    }

    public function isApprovedForExecution(RewindFix $fix, string $actionType = 'apply_correction'): bool
    {
        $latest = RewindApproval::query()
            ->where('fix_id', $fix->id)
            ->where('action_type', $actionType)
            ->orderByDesc('approval_level')
            ->first();

        return $latest && $latest->status === 'approved';
    }
}
