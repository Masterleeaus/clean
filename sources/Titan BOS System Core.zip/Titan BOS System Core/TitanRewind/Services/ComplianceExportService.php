<?php
namespace Modules\TitanRewind\Services;
use Modules\TitanRewind\Models\RewindEvent;
class ComplianceExportService
{
    public function evidencePackage(int $companyId, ?string $entityType=null, ?string $entityId=null): array
    { $q=RewindEvent::where('company_id',$companyId); if($entityType) $q->where('entity_type',$entityType); if($entityId) $q->where('entity_id',$entityId); return ['generated_at'=>now()->toISOString(),'company_id'=>$companyId,'immutable'=>true,'events'=>$q->latest('id')->limit(500)->get()->toArray()]; }
}
