<?php
namespace Modules\TitanRewind\Services;

use Modules\TitanRewind\Models\RewindCase;
use Modules\TitanRewind\Models\RewindEvent;
use Modules\TitanRewind\Models\RewindEvidencePackage;
use Modules\TitanRewind\Models\RewindFix;
use Modules\TitanRewind\Models\RewindSnapshot;
use Modules\TitanRewind\Models\RewindTimelineEntry;

class RewindEvidencePackageService
{
    public function forCase(RewindCase $case, string $type = 'compliance'): RewindEvidencePackage
    {
        $events = RewindEvent::query()->where('company_id', $case->company_id)->where('case_id', $case->id)->get()->toArray();
        $fixes = RewindFix::query()->where('company_id', $case->company_id)->where('case_id', $case->id)->get()->toArray();
        $timeline = RewindTimelineEntry::query()->where('company_id', $case->company_id)->where('meta_json->case_id', $case->id)->get()->toArray();
        $snapshots = RewindSnapshot::query()->where('company_id', $case->company_id)->where('entity_id', (string) $case->id)->get()->toArray();

        $payload = [
            'case' => $case->toArray(),
            'events' => $events,
            'fixes' => $fixes,
            'timeline' => $timeline,
            'snapshots' => $snapshots,
            'generated_at' => now()->toIso8601String(),
        ];
        $encoded = json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $hash = hash('sha256', (string) $encoded);

        return RewindEvidencePackage::query()->create([
            'company_id' => $case->company_id,
            'case_id' => $case->id,
            'package_type' => $type,
            'status' => 'ready',
            'hash' => $hash,
            'manifest_json' => [
                'hash_algorithm' => 'sha256',
                'event_count' => count($events),
                'fix_count' => count($fixes),
                'timeline_count' => count($timeline),
                'snapshot_count' => count($snapshots),
            ],
            'payload_json' => $encoded,
            'generated_at' => now(),
            'generated_by_id' => function_exists('user') && user() ? user()->id : null,
        ]);
    }
}
