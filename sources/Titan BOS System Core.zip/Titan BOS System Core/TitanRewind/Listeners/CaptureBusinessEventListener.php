<?php

namespace Modules\TitanRewind\Listeners;

use Modules\TitanRewind\Contracts\AuditableBusinessEvent;
use Modules\TitanRewind\Services\RewindAuditService;
use Modules\TitanRewind\Support\RewindEventContract;

class CaptureBusinessEventListener
{
    public function __construct(private readonly RewindAuditService $audit) {}

    public function handle(object|array $event): void
    {
        $payload = null;

        if ($event instanceof AuditableBusinessEvent) {
            $payload = $event->rewindPayload();
        } elseif (is_array($event) && isset($event['rewind'])) {
            $payload = $event['rewind'];
        } elseif (method_exists($event, 'rewindPayload')) {
            $payload = $event->rewindPayload();
        }

        if (! is_array($payload)) {
            return;
        }

        $this->audit->appendBusinessEvent(RewindEventContract::normalize($payload));
    }
}
