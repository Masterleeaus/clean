# Security Module Restore Package

This is the full `Modules/Security` module rebuilt from the latest patched TitanPro tree.

## Included fixes
- Security migrations updated for Laravel 12 / SQLite-safe reruns.
- Permission seed migration modernized for current permission schema.
- `guard_name` support added where required.
- `display_name` writes guarded by schema checks.
- `modules`, `permissions`, and `module_permissions` compatibility handling added.
- Table/column creation guarded with `Schema::hasTable()` and `Schema::hasColumn()`.

## Install
Extract this ZIP at the project root so it restores:

`Modules/Security`

Then run:

```bash
php artisan optimize:clear
php artisan migrate --force
```
