@extends('approvals::layouts.master')

@section('content')
    <h1>Hello World</h1>

    <p>Module: {!! config('approvals.name') !!}</p>
@endsection
