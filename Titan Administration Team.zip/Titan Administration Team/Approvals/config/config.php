<?php

return [
    'name' => 'Approvals',
];
