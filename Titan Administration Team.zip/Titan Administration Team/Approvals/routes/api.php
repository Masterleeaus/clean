<?php

use Illuminate\Support\Facades\Route;
use Modules\Approvals\app\Http\Controllers\Api\ApprovalApiController;
use Stancl\Tenancy\Middleware\InitializeTenancyByDomain;
use Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains;

/*
 *--------------------------------------------------------------------------
 * API Routes
 *--------------------------------------------------------------------------
 *
 * Here is where you can register API routes for your application. These
 * routes are loaded by the RouteServiceProvider within a group which
 * is assigned the "api" middleware group. Enjoy building your API!
 *
*/

Route::middleware([
  'api',
  InitializeTenancyByDomain::class,
  PreventAccessFromCentralDomains::class,
])->group(function () {
  Route::middleware('auth:api')->group(function () {
    Route::group(['prefix' => 'V1'], function () {
      Route::group([
        'middleware' => 'api',
        'as' => 'api.',
      ], function () {

      Route::get('approvals/leaveRequests', [ApprovalApiController::class, 'getLeaveRequests'])->name('approvals.leaveRequests');
      Route::get('approvals/expenseRequests', [ApprovalApiController::class, 'getExpenseRequests'])->name('approvals.expenseRequests');

      Route::post('approvals/leaveAction', [ApprovalApiController::class, 'leaveAction'])->name('approvals.leaveAction');
      Route::post('approvals/expenseAction', [ApprovalApiController::class, 'expenseAction'])->name('approvals.expenseAction');
      });
    });
  });
});
