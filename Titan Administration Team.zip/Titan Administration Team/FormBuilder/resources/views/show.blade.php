@extends('layouts.layoutMaster')

@section('title', $form->name . ' - ' . __('Form Details'))

@section('vendor-style')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
  'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
])
@endsection

@section('vendor-script')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
  'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
])
@endsection

@section('content')
@php
  $breadcrumbs = [
    ['name' => __('Form Builder'), 'url' => route('formbuilder.index')]
  ];
@endphp

<x-breadcrumb
  :title="$form->name"
  :breadcrumbs="$breadcrumbs"
  :homeUrl="route('dashboard')"
/>

<!-- Form Details Card -->
<div class="row">
  <div class="col-md-8">
    <div class="card mb-4">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">{{ __('Form Details') }}</h5>
        <div>
          <a href="{{ route('formbuilder.edit', $form->id) }}" class="btn btn-outline-primary btn-sm">
            <i class="bx bx-edit me-1"></i>{{ __('Edit Form') }}
          </a>
          <a href="{{ route('formbuilder.submissions', $form->id) }}" class="btn btn-outline-info btn-sm">
            <i class="bx bx-list-ul me-1"></i>{{ __('View All Submissions') }}
          </a>
        </div>
      </div>
      <div class="card-body">
        <div class="row mb-3">
          <div class="col-sm-3">
            <strong>{{ __('Name') }}:</strong>
          </div>
          <div class="col-sm-9">
            {{ $form->name }}
          </div>
        </div>

        @if($form->description)
        <div class="row mb-3">
          <div class="col-sm-3">
            <strong>{{ __('Description') }}:</strong>
          </div>
          <div class="col-sm-9">
            {{ $form->description }}
          </div>
        </div>
        @endif

        <div class="row mb-3">
          <div class="col-sm-3">
            <strong>{{ __('Status') }}:</strong>
          </div>
          <div class="col-sm-9">
            <span class="badge bg-label-{{ $form->is_active ? 'success' : 'secondary' }}">
              {{ $form->is_active ? __('Active') : __('Inactive') }}
            </span>
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-sm-3">
            <strong>{{ __('Public Access') }}:</strong>
          </div>
          <div class="col-sm-9">
            <span class="badge bg-label-{{ $form->is_public ? 'info' : 'warning' }}">
              {{ $form->is_public ? __('Public') : __('Private') }}
            </span>
          </div>
        </div>

        @if($form->is_public && $form->public_url)
        <div class="row mb-3">
          <div class="col-sm-3">
            <strong>{{ __('Public URL') }}:</strong>
          </div>
          <div class="col-sm-9">
            <div class="input-group">
              <input type="text" class="form-control" value="{{ $form->public_url }}" readonly id="publicUrl">
              <button class="btn btn-outline-secondary" type="button" onclick="copyToClipboard()">
                <i class="bx bx-copy"></i>
              </button>
              <a href="{{ $form->public_url }}" target="_blank" class="btn btn-outline-primary">
                <i class="bx bx-link-external"></i>
              </a>
            </div>
          </div>
        </div>
        @endif

        @if($form->expires_at)
        <div class="row mb-3">
          <div class="col-sm-3">
            <strong>{{ __('Expires At') }}:</strong>
          </div>
          <div class="col-sm-9">
            {{ $form->expires_at->format('M d, Y H:i') }}
            @if($form->expires_at->isPast())
              <span class="badge bg-label-danger ms-2">{{ __('Expired') }}</span>
            @endif
          </div>
        </div>
        @endif

        <div class="row mb-3">
          <div class="col-sm-3">
            <strong>{{ __('Created By') }}:</strong>
          </div>
          <div class="col-sm-9">
            {{ $form->createdBy->name ?? __('Unknown') }}
          </div>
        </div>

        <div class="row mb-3">
          <div class="col-sm-3">
            <strong>{{ __('Created Date') }}:</strong>
          </div>
          <div class="col-sm-9">
            {{ $form->created_at->format('M d, Y H:i') }}
          </div>
        </div>

        @if($form->updated_at != $form->created_at)
        <div class="row mb-3">
          <div class="col-sm-3">
            <strong>{{ __('Last Updated') }}:</strong>
          </div>
          <div class="col-sm-9">
            {{ $form->updated_at->format('M d, Y H:i') }}
          </div>
        </div>
        @endif
      </div>
    </div>
  </div>

  <!-- Stats Card -->
  <div class="col-md-4">
    <div class="card mb-4">
      <div class="card-header">
        <h5 class="mb-0">{{ __('Submission Statistics') }}</h5>
      </div>
      <div class="card-body">
        <div class="d-flex justify-content-between align-items-center mb-3">
          <div>
            <h6 class="mb-0">{{ __('Total Submissions') }}</h6>
          </div>
          <div>
            <span class="badge bg-primary rounded-pill">{{ $submissionsStats['total'] }}</span>
          </div>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-3">
          <div>
            <h6 class="mb-0">{{ __('This Week') }}</h6>
          </div>
          <div>
            <span class="badge bg-info rounded-pill">{{ $submissionsStats['this_week'] }}</span>
          </div>
        </div>

        <div class="d-flex justify-content-between align-items-center mb-3">
          <div>
            <h6 class="mb-0">{{ __('This Month') }}</h6>
          </div>
          <div>
            <span class="badge bg-success rounded-pill">{{ $submissionsStats['this_month'] }}</span>
          </div>
        </div>

        @if($submissionsStats['total'] > 0)
        <div class="mt-3">
          <a href="{{ route('formbuilder.submissions', $form->id) }}" class="btn btn-primary w-100">
            <i class="bx bx-list-ul me-1"></i>{{ __('View All Submissions') }}
          </a>
        </div>
        @endif
      </div>
    </div>
  </div>
</div>

<!-- Form Structure -->
<div class="card">
  <div class="card-header">
    <h5 class="mb-0">{{ __('Form Structure') }}</h5>
  </div>
  <div class="card-body">
    @if(!empty($form->fields))
      <div class="table-responsive">
        <table class="table table-striped">
          <thead>
            <tr>
              <th>{{ __('Field Name') }}</th>
              <th>{{ __('Field Label') }}</th>
              <th>{{ __('Type') }}</th>
              <th>{{ __('Required') }}</th>
              <th>{{ __('Options') }}</th>
            </tr>
          </thead>
          <tbody>
            @foreach($form->fields as $field)
            <tr>
              <td><code>{{ $field['name'] ?? '' }}</code></td>
              <td>{{ $field['label'] ?? '' }}</td>
              <td>
                <span class="badge bg-label-secondary">{{ $field['type'] ?? '' }}</span>
              </td>
              <td>
                @if(isset($field['required']) && $field['required'])
                  <span class="badge bg-label-danger">{{ __('Required') }}</span>
                @else
                  <span class="badge bg-label-secondary">{{ __('Optional') }}</span>
                @endif
              </td>
              <td>
                @if(isset($field['options']) && !empty($field['options']))
                  @if(is_array($field['options']))
                    @php
                      $optionTexts = [];
                      foreach($field['options'] as $option) {
                        if(is_array($option) && isset($option['label'])) {
                          $optionTexts[] = $option['label'];
                        } else {
                          $optionTexts[] = (string)$option;
                        }
                      }
                    @endphp
                    <small class="text-muted">{{ implode(', ', $optionTexts) }}</small>
                  @else
                    <small class="text-muted">{{ $field['options'] }}</small>
                  @endif
                @else
                  -
                @endif
              </td>
            </tr>
            @endforeach
          </tbody>
        </table>
      </div>
    @else
      <div class="text-center py-4">
        <i class="bx bx-info-circle bx-lg text-muted"></i>
        <p class="text-muted mt-2">{{ __('No fields configured for this form.') }}</p>
      </div>
    @endif
  </div>
</div>
@endsection

@section('page-script')
<script>
const pageData = {
  labels: {
    success: @json(__('Success')),
    urlCopied: @json(__('URL copied to clipboard!'))
  }
};

function copyToClipboard() {
  const urlInput = document.getElementById('publicUrl');
  urlInput.select();
  urlInput.setSelectionRange(0, 99999);

  navigator.clipboard.writeText(urlInput.value).then(function() {
    Swal.fire({
      title: pageData.labels.success,
      text: pageData.labels.urlCopied,
      icon: 'success',
      timer: 2000,
      showConfirmButton: false,
      customClass: {
        confirmButton: 'btn btn-success'
      },
      buttonsStyling: false
    });
  });
}
</script>
@endsection
