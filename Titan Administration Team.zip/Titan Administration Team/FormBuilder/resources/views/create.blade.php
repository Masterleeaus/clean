@extends('layouts.layoutMaster')

@section('title', __('Create Form'))

@section('page-style')
@vite([
  'resources/assets/vendor/libs/select2/select2.scss',
  'resources/assets/vendor/libs/flatpickr/flatpickr.scss'
])
<style>
  .form-builder-container {
    display: flex;
    height: calc(100vh - 200px);
    gap: 20px;
  }

  .field-palette {
    width: 280px;
    background: var(--bs-card-bg);
    border: 1px solid var(--bs-border-color);
    border-radius: 8px;
    padding: 15px;
    overflow-y: auto;
  }

  .form-canvas {
    flex: 1;
    background: var(--bs-card-bg);
    border: 1px solid var(--bs-border-color);
    border-radius: 8px;
    padding: 20px;
    overflow-y: auto;
    min-height: 500px;
  }

  .properties-panel {
    width: 320px;
    background: var(--bs-card-bg);
    border: 1px solid var(--bs-border-color);
    border-radius: 8px;
    padding: 15px;
    overflow-y: auto;
  }

  .field-item {
    display: flex;
    align-items: center;
    padding: 12px;
    margin-bottom: 8px;
    background: var(--bs-gray-100);
    border: 1px solid var(--bs-border-color);
    border-radius: 6px;
    cursor: grab;
    transition: all 0.2s;
  }

  [data-bs-theme="dark"] .field-item {
    background: rgba(255, 255, 255, 0.05);
  }

  .field-item:hover {
    background: rgba(33, 150, 243, 0.1);
    border-color: var(--bs-primary);
  }

  .field-item .icon {
    width: 24px;
    height: 24px;
    margin-right: 10px;
    color: var(--bs-body-color);
  }

  .field-item.dragging {
    opacity: 0.5;
    transform: rotate(5deg);
  }

  .form-field {
    background: var(--bs-body-bg);
    border: 2px dashed var(--bs-border-color);
    border-radius: 8px;
    padding: 15px;
    margin-bottom: 15px;
    position: relative;
    transition: all 0.2s;
  }

  .form-field:hover {
    border-color: var(--bs-primary);
    background: var(--bs-gray-100);
  }

  [data-bs-theme="dark"] .form-field:hover {
    background: rgba(255, 255, 255, 0.05);
  }

  .form-field.selected {
    border-color: var(--bs-primary);
    border-style: solid;
    background: rgba(33, 150, 243, 0.1);
  }

  .form-field .field-controls {
    position: absolute;
    top: -10px;
    right: -10px;
    display: none;
  }

  .form-field:hover .field-controls,
  .form-field.selected .field-controls {
    display: flex;
  }

  .field-controls .btn {
    width: 30px;
    height: 30px;
    padding: 0;
    margin-left: 5px;
    border-radius: 50%;
  }

  .drop-zone {
    min-height: 100px;
    border: 2px dashed var(--bs-secondary);
    border-radius: 8px;
    display: flex;
    align-items: center;
    justify-content: center;
    color: var(--bs-secondary-color);
    font-style: italic;
    margin: 10px 0;
    background: var(--bs-body-bg);
  }

  .drop-zone.drag-over {
    border-color: var(--bs-primary);
    background: rgba(33, 150, 243, 0.1);
    color: var(--bs-primary);
  }

  .form-preview {
    border: 1px solid var(--bs-border-color);
    border-radius: 8px;
    padding: 20px;
    background: var(--bs-card-bg);
  }

  .field-group {
    margin-bottom: 15px;
  }

  .sortable-ghost {
    opacity: 0.4;
  }

  .sortable-chosen {
    background: rgba(33, 150, 243, 0.15) !important;
  }

  /* Dark mode specific text color fixes */
  [data-bs-theme="dark"] .field-palette h6,
  [data-bs-theme="dark"] .form-canvas h6,
  [data-bs-theme="dark"] .properties-panel h6 {
    color: var(--bs-heading-color);
  }

  [data-bs-theme="dark"] .field-item .fw-semibold {
    color: var(--bs-body-color);
  }

  [data-bs-theme="dark"] .text-muted {
    color: var(--bs-secondary-color) !important;
  }
</style>
@endsection

@section('content')
@php
  $breadcrumbs = [
    ['name' => __('Form Builder'), 'url' => route('formbuilder.index')]
  ];
@endphp

<x-breadcrumb
  :title="__('Create New Form')"
  :breadcrumbs="$breadcrumbs"
  :homeUrl="route('dashboard')"
/>

<div class="row mb-4">
  <div class="col-12">
    <div class="card">
      <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">{{ __('Form Details') }}</h5>
        <div>
          <button type="button" class="btn btn-outline-secondary me-2" id="previewFormBtn">
            <i class="bx bx-show me-1"></i>{{ __('Preview') }}
          </button>
          <button type="button" class="btn btn-primary" id="saveFormBtn">
            <i class="bx bx-save me-1"></i>{{ __('Save Form') }}
          </button>
        </div>
      </div>
      <div class="card-body">
        <form id="formDetailsForm">
          <div class="row">
            <div class="col-md-6">
              <div class="mb-3">
                <label class="form-label">{{ __('Form Name') }} <span class="text-danger">*</span></label>
                <input type="text" class="form-control" id="formName" name="name" required>
              </div>
            </div>
            <div class="col-md-6">
              <div class="mb-3">
                <label class="form-label">{{ __('Form Description') }}</label>
                <input type="text" class="form-control" id="formDescription" name="description">
              </div>
            </div>
          </div>
          <div class="row">
            <div class="col-md-4">
              <div class="mb-3">
                <div class="form-check">
                  <input type="hidden" name="is_public" value="0">
                  <input class="form-check-input" type="checkbox" id="isPublic" name="is_public" value="1">
                  <label class="form-check-label" for="isPublic">
                    {{ __('Make this form publicly accessible') }}
                  </label>
                </div>
              </div>
            </div>
            <div class="col-md-4">
              <div class="mb-3">
                <label class="form-label">{{ __('Expiration Date') }}</label>
                <input type="text" class="form-control flatpickr-datetime" id="expiresAt" name="expires_at">
              </div>
            </div>
          </div>
        </form>
      </div>
    </div>
  </div>
</div>

<div class="form-builder-container">
  <!-- Field Palette -->
  <div class="field-palette">
    <h6 class="mb-3">{{ __('Form Fields') }}</h6>
    <div id="fieldPalette">
      @foreach($fieldTypes as $fieldType)
      <div class="field-item" data-field-type="{{ $fieldType->type }}" data-field-config="{{ json_encode($fieldType->default_config) }}">
        <i class="{{ $fieldType->icon }} icon"></i>
        <div>
          <div class="fw-semibold">{{ $fieldType->name }}</div>
          <small class="text-muted">{{ $fieldType->description }}</small>
        </div>
      </div>
      @endforeach
    </div>
  </div>

  <!-- Form Canvas -->
  <div class="form-canvas">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h6 class="mb-0">{{ __('Form Builder') }}</h6>
      <div>
        <button type="button" class="btn btn-sm btn-outline-secondary" id="clearFormBtn">
          <i class="bx bx-trash me-1"></i>{{ __('Clear All') }}
        </button>
      </div>
    </div>

    <div id="formCanvas">
      <div class="drop-zone" id="mainDropZone">
        <div class="text-center">
          <i class="bx bx-plus-circle bx-lg mb-2"></i>
          <div>{{ __('Drag fields from the left panel to build your form') }}</div>
        </div>
      </div>
    </div>
  </div>

  <!-- Properties Panel -->
  <div class="properties-panel">
    <h6 class="mb-3">{{ __('Field Properties') }}</h6>
    <div id="propertiesPanel">
      <div class="text-center text-muted">
        <i class="bx bx-settings bx-lg mb-2"></i>
        <div>{{ __('Select a field to edit its properties') }}</div>
      </div>
    </div>
  </div>
</div>

<!-- Preview Modal -->
<div class="modal fade" id="previewModal" tabindex="-1">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">{{ __('Form Preview') }}</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body">
        <div id="formPreview" class="form-preview"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">{{ __('Close') }}</button>
      </div>
    </div>
  </div>
</div>
@endsection

@section('page-script')
@vite([
  'resources/assets/vendor/libs/select2/select2.js',
  'resources/assets/vendor/libs/flatpickr/flatpickr.js',
  'resources/assets/vendor/libs/sortablejs/sortable.js'
])
@vite(['Modules/FormBuilder/resources/assets/js/formbuilder-create.js'])

<script>
const pageData = {
  urls: {
    formStore: @json(route('formbuilder.store')),
    formIndex: @json(route('formbuilder.index'))
  },
  fieldTypes: @json($fieldTypes),
  labels: {
    success: @json(__('Success')),
    error: @json(__('Error')),
    formSaved: @json(__('Form saved successfully')),
    errorOccurred: @json(__('An error occurred')),
    confirmClear: @json(__('Are you sure you want to clear all fields?')),
    confirmDelete: @json(__('Are you sure?')),
    yes: @json(__('Yes')),
    no: @json(__('No')),
    fieldLabel: @json(__('Field Label')),
    fieldName: @json(__('Field Name')),
    placeholder: @json(__('Placeholder')),
    required: @json(__('Required')),
    options: @json(__('Options')),
    addOption: @json(__('Add Option')),
    removeOption: @json(__('Remove Option')),
    optionLabel: @json(__('Option Label')),
    optionValue: @json(__('Option Value')),
    minLength: @json(__('Minimum Length')),
    maxLength: @json(__('Maximum Length')),
    minValue: @json(__('Minimum Value')),
    maxValue: @json(__('Maximum Value')),
    step: @json(__('Step')),
    rows: @json(__('Rows')),
    accept: @json(__('Accepted File Types')),
    maxSize: @json(__('Maximum File Size (KB)')),
    multiple: @json(__('Allow Multiple Files')),
    content: @json(__('Content')),
    headingLevel: @json(__('Heading Level')),
    alignment: @json(__('Alignment')),
    left: @json(__('Left')),
    center: @json(__('Center')),
    right: @json(__('Right')),
    selectFieldToEdit: @json(__('Select a field to edit its properties')),
    pleaseAddField: @json(__('Please add at least one field to the form')),
    pleaseEnterFormName: @json(__('Please enter a form name')),
    // Field type labels
    textInput: @json(__('Text Input')),
    textArea: @json(__('Text Area')),
    emailAddress: @json(__('Email Address')),
    number: @json(__('Number')),
    phoneNumber: @json(__('Phone Number')),
    websiteUrl: @json(__('Website URL')),
    password: @json(__('Password')),
    date: @json(__('Date')),
    time: @json(__('Time')),
    dateTime: @json(__('Date & Time')),
    selectOption: @json(__('Select Option')),
    radioChoice: @json(__('Radio Choice')),
    checkboxes: @json(__('Checkboxes')),
    fileUpload: @json(__('File Upload')),
    rangeSlider: @json(__('Range Slider')),
    colorPicker: @json(__('Color Picker')),
    hiddenField: @json(__('Hidden Field')),
    htmlContent: @json(__('HTML Content')),
    heading: @json(__('Heading')),
    divider: @json(__('Divider')),
    rating: @json(__('Rating')),
    formStep: @json(__('Form Step')),
    field: @json(__('Field')),
    // Property labels
    defaultValue: @json(__('Default Value')),
    defaultColor: @json(__('Default Color')),
    hiddenValue: @json(__('Hidden Value')),
    headingText: @json(__('Heading Text')),
    borderStyle: @json(__('Border Style')),
    borderColor: @json(__('Border Color')),
    solid: @json(__('Solid')),
    dashed: @json(__('Dashed')),
    dotted: @json(__('Dotted')),
    maximumRating: @json(__('Maximum Rating')),
    stepTitle: @json(__('Step Title')),
    stepDescription: @json(__('Step Description')),
    // Other labels
    dragFieldsMessage: @json(__('Drag fields from the left panel to build your form')),
    submitForm: @json(__('Submit Form'))
  }
};
</script>
@endsection
