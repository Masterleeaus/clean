@extends('layouts.layoutMaster')

@section('title', __('Form Builder'))

@section('page-style')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss'])
@endsection

@section('content')
@php
  $breadcrumbs = [];
@endphp

<x-breadcrumb
  :title="__('Form Builder')"
  :breadcrumbs="$breadcrumbs"
  :homeUrl="route('dashboard')"
/>

<!-- Stats Cards -->
<div class="row g-3 mb-4">
  <div class="col-sm-6 col-lg-3">
    <div class="card">
      <div class="card-body">
        <div class="d-flex align-items-center">
          <div class="avatar">
            <div class="avatar-initial bg-label-primary rounded">
              <i class="bx bx-file"></i>
            </div>
          </div>
          <div class="ms-3">
            <h5 class="mb-0">{{ $stats['total_forms'] }}</h5>
            <small class="text-muted">{{ __('Total Forms') }}</small>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-sm-6 col-lg-3">
    <div class="card">
      <div class="card-body">
        <div class="d-flex align-items-center">
          <div class="avatar">
            <div class="avatar-initial bg-label-success rounded">
              <i class="bx bx-check-square"></i>
            </div>
          </div>
          <div class="ms-3">
            <h5 class="mb-0">{{ $stats['active_forms'] }}</h5>
            <small class="text-muted">{{ __('Active Forms') }}</small>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-sm-6 col-lg-3">
    <div class="card">
      <div class="card-body">
        <div class="d-flex align-items-center">
          <div class="avatar">
            <div class="avatar-initial bg-label-info rounded">
              <i class="bx bx-world"></i>
            </div>
          </div>
          <div class="ms-3">
            <h5 class="mb-0">{{ $stats['public_forms'] }}</h5>
            <small class="text-muted">{{ __('Public Forms') }}</small>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="col-sm-6 col-lg-3">
    <div class="card">
      <div class="card-body">
        <div class="d-flex align-items-center">
          <div class="avatar">
            <div class="avatar-initial bg-label-warning rounded">
              <i class="bx bx-envelope"></i>
            </div>
          </div>
          <div class="ms-3">
            <h5 class="mb-0">{{ $stats['total_submissions'] }}</h5>
            <small class="text-muted">{{ __('Total Submissions') }}</small>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Forms Table -->
<div class="card">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <h5 class="card-title mb-0">{{ __('All Forms') }}</h5>
      @can('formbuilder.create-forms')
        <a href="{{ route('formbuilder.create') }}" class="btn btn-primary">
          <i class="bx bx-plus-circle"></i> {{ __('Create New Form') }}
        </a>
      @endcan
    </div>
  </div>

  <div class="card-datatable table-responsive">
    <table class="table table-hover border-top datatables-forms">
      <thead>
        <tr>
          <th>{{ __('ID') }}</th>
          <th>{{ __('Name') }}</th>
          <th>{{ __('Description') }}</th>
          <th>{{ __('Active') }}</th>
          <th>{{ __('Public') }}</th>
          <th>{{ __('Submissions') }}</th>
          <th>{{ __('Created By') }}</th>
          <th>{{ __('Created Date') }}</th>
          <th>{{ __('Actions') }}</th>
        </tr>
      </thead>
    </table>
  </div>
</div>
@endsection

@section('page-script')
@vite(['resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js'])
@vite(['Modules/FormBuilder/resources/assets/js/formbuilder-list.js'])

<script>
const pageData = {
  urls: {
    formsData: @json(route('formbuilder.datatable')),
    formStore: @json(route('formbuilder.store')),
    formUpdate: @json(route('formbuilder.update', ['id' => '__ID__'])),
    formDelete: @json(route('formbuilder.destroy', ['id' => '__ID__'])),
    formDuplicate: @json(route('formbuilder.duplicate', ['id' => '__ID__'])),
    formToggleStatus: @json(route('formbuilder.toggle-status', ['id' => '__ID__'])),
    formGenerateLink: @json(route('formbuilder.generate-public-link', ['id' => '__ID__'])),
    formEdit: @json(route('formbuilder.edit', ['id' => '__ID__'])),
    formShow: @json(route('formbuilder.show', ['id' => '__ID__'])),
    formSubmissions: @json(route('formbuilder.submissions', ['id' => '__ID__']))
  },
  labels: {
    confirmDelete: @json(__('Are you sure you want to delete this form?')),
    confirmDuplicate: @json(__('Are you sure you want to duplicate this form?')),
    confirmToggleStatus: @json(__('Are you sure you want to change the status of this form?')),
    generatePublicLink: @json(__('Generate Public Link')),
    copyLink: @json(__('Copy Link')),
    linkCopied: @json(__('Link copied to clipboard!')),
    active: @json(__('Active')),
    inactive: @json(__('Inactive')),
    public: @json(__('Public')),
    private: @json(__('Private')),
    yes: @json(__('Yes')),
    no: @json(__('No')),
    view: @json(__('View')),
    edit: @json(__('Edit')),
    delete: @json(__('Delete')),
    duplicate: @json(__('Duplicate')),
    activate: @json(__('Activate')),
    deactivate: @json(__('Deactivate')),
    submissions: @json(__('Submissions')),
    success: @json(__('Success')),
    error: @json(__('Error')),
    errorOccurred: @json(__('An error occurred')),
    // DataTable language
    searchPlaceholder: @json(__('Search...')),
    emptyTable: @json(__('No data available')),
    processing: @json(__('Processing...'))
  }
};
</script>
@endsection
