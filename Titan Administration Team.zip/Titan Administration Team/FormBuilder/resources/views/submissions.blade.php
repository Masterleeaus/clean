@extends('layouts.layoutMaster')

@section('title', __('Form Submissions') . ' - ' . $form->name)

@section('vendor-style')
@vite([
  'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
  'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
  'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
])
@endsection

@section('vendor-script')
@vite([
  'resources/assets/vendor/libs/moment/moment.js',
  'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
  'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
])
@endsection

@section('content')
@php
  $breadcrumbs = [
    ['name' => __('Form Builder'), 'url' => route('formbuilder.index')],
    ['name' => $form->name, 'url' => route('formbuilder.show', $form->id)]
  ];
@endphp

<x-breadcrumb
  :title="__('Submissions')"
  :breadcrumbs="$breadcrumbs"
  :homeUrl="route('dashboard')"
/>

<!-- Form Info Card -->
<div class="card mb-4">
  <div class="card-body">
    <div class="row">
      <div class="col-md-8">
        <h5 class="card-title mb-2">{{ $form->name }}</h5>
        @if($form->description)
          <p class="text-muted mb-2">{{ $form->description }}</p>
        @endif
        <div class="d-flex gap-2">
          <span class="badge bg-label-{{ $form->is_active ? 'success' : 'secondary' }}">
            {{ $form->is_active ? __('Active') : __('Inactive') }}
          </span>
          <span class="badge bg-label-{{ $form->is_public ? 'info' : 'warning' }}">
            {{ $form->is_public ? __('Public') : __('Private') }}
          </span>
        </div>
      </div>
      <div class="col-md-4 text-end">
        <div class="mb-2">
          <strong>{{ __('Total Submissions:') }}</strong>
          <span class="badge bg-primary">{{ $stats['total_submissions'] }}</span>
        </div>
        @if($form->is_public && $form->public_url)
          <div class="mb-2">
            <a href="{{ $form->public_url }}" target="_blank" class="btn btn-sm btn-outline-primary">
              <i class="bx bx-link me-1"></i>
              {{ __('View Public Form') }}
            </a>
          </div>
        @endif
        <div>
          @can('formbuilder.edit-forms')
            <a href="{{ route('formbuilder.edit', $form->id) }}" class="btn btn-sm btn-outline-secondary">
              <i class="bx bx-edit me-1"></i>
              {{ __('Edit Form') }}
            </a>
          @endcan
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Submissions Card -->
<div class="card">
  <div class="card-header">
    <div class="d-flex justify-content-between align-items-center">
      <h5 class="card-title mb-0">{{ __('All Submissions') }}</h5>
      <div class="d-flex gap-2">
        @can('formbuilder.export-submissions')
          <button type="button" class="btn btn-sm btn-outline-primary" id="exportBtn">
            <i class="bx bx-download"></i> {{ __('Export CSV') }}
          </button>
        @endcan
        @can('formbuilder.delete-all-submissions')
          @if($stats['total_submissions'] > 0)
            <button type="button" class="btn btn-sm btn-outline-danger" id="deleteAllBtn">
              <i class="bx bx-trash"></i> {{ __('Delete All') }}
            </button>
          @endif
        @endcan
      </div>
    </div>
  </div>

  <div class="card-datatable table-responsive">
    <table class="table table-hover border-top datatables-submissions">
      <thead>
        <tr>
          <th>{{ __('ID') }}</th>
          <th>{{ __('Submission Date') }}</th>
          <th>{{ __('User') }}</th>
          <th>{{ __('IP Address') }}</th>
          <th>{{ __('Data Preview') }}</th>
          <th>{{ __('Actions') }}</th>
        </tr>
      </thead>
    </table>
  </div>
</div>

<!-- Submission Detail Modal -->
<div class="modal fade" id="submissionModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-lg">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title">{{ __('Submission Details') }}</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="{{ __('Close') }}"></button>
      </div>
      <div class="modal-body">
        <div id="submissionContent">
          <!-- Content will be loaded here -->
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">{{ __('Close') }}</button>
        <button type="button" class="btn btn-danger" id="deleteSubmissionBtn">
          <i class="bx bx-trash me-1"></i>
          {{ __('Delete Submission') }}
        </button>
      </div>
    </div>
  </div>
</div>
@endsection

@section('page-script')
<script>
  const pageData = {
    urls: {
      submissionsData: @json(route('formbuilder.submissions.data', $form->id)),
      submissionView: @json(route('formbuilder.submissions.show', ['id' => $form->id, 'submission' => '__SUBMISSION_ID__'])),
      submissionDelete: @json(route('formbuilder.submissions.destroy', ['id' => $form->id, 'submission' => '__SUBMISSION_ID__'])),
      submissionsExport: @json(route('formbuilder.submissions.export', $form->id)),
      submissionsDeleteAll: @json(route('formbuilder.submissions.deleteAll', $form->id))
    },
    labels: {
      view: @json(__('View')),
      delete: @json(__('Delete')),
      confirmDelete: @json(__('Are you sure you want to delete this submission?')),
      confirmDeleteAll: @json(__('Are you sure you want to delete all submissions? This action cannot be undone.')),
      success: @json(__('Success')),
      error: @json(__('Error')),
      submissionDeleted: @json(__('Submission deleted successfully')),
      allSubmissionsDeleted: @json(__('All submissions deleted successfully')),
      loading: @json(__('Loading...')),
      noData: @json(__('No data available')),
      anonymous: @json(__('Anonymous')),
      yes: @json(__('Yes')),
      no: @json(__('No')),
      yesDelete: @json(__('Yes, delete it!')),
      cancel: @json(__('Cancel')),
      errorOccurred: @json(__('An error occurred')),
      // DataTable language
      searchPlaceholder: @json(__('Search...')),
      emptyTable: @json(__('No data available')),
      processing: @json(__('Processing...')),
      // Modal labels
      formData: @json(__('Form Data')),
      submissionId: @json(__('Submission ID')),
      submittedAt: @json(__('Submitted At')),
      submittedBy: @json(__('Submitted By')),
      ipAddress: @json(__('IP Address')),
      userAgent: @json(__('User Agent')),
      noValue: @json(__('No value'))
    }
  };
</script>
@vite(['Modules/FormBuilder/resources/assets/js/formbuilder-submissions.js'])
@endsection
