<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('fb_forms', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->json('fields'); // Store form fields as JSON
            $table->json('settings')->nullable(); // Form settings like notifications, redirects
            $table->boolean('is_active')->default(true);
            $table->boolean('is_public')->default(false);
            $table->string('public_token')->nullable()->unique();
            $table->timestamp('expires_at')->nullable();
            $table->unsignedBigInteger('created_by_id');
            $table->unsignedBigInteger('updated_by_id')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['is_active', 'is_public']);
            $table->index(['public_token']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('fb_forms');
    }
};
