<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('fb_form_submissions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('form_id');
            $table->json('data'); // Store form submission data as JSON
            $table->string('submission_token')->unique();
            $table->string('ip_address')->nullable();
            $table->string('user_agent')->nullable();
            $table->unsignedBigInteger('user_id')->nullable(); // If submitted by logged-in user
            $table->timestamps();

            $table->index(['form_id', 'created_at']);
            $table->index(['submission_token']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('fb_form_submissions');
    }
};
