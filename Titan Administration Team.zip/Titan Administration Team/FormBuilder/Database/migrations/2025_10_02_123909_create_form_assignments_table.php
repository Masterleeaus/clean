<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up()
    {
        Schema::create('fb_form_assignments', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('form_id');
            $table->unsignedBigInteger('user_id');
            $table->unsignedBigInteger('assigned_by_id');
            $table->timestamp('due_date')->nullable();
            $table->string('status')->default('pending'); // pending, submitted, overdue
            $table->timestamps();

            // Indexes
            $table->index(['form_id', 'user_id']);
            $table->index(['user_id', 'status']);
            $table->index(['due_date']);
        });
    }

    public function down()
    {
        Schema::dropIfExists('fb_form_assignments');
    }
};
