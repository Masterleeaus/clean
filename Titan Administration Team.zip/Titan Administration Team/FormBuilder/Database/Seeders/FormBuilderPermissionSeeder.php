<?php

namespace Modules\FormBuilder\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class FormBuilderPermissionSeeder extends Seeder
{
    /**
     * FormBuilder module permissions organized by category
     */
    protected $permissions = [];

    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Reset cached roles and permissions
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        // Start transaction
        DB::beginTransaction();

        try {
            // Define all FormBuilder permissions
            $this->definePermissions();

            // Create/update permissions
            $this->createPermissions();

            // Update existing roles with FormBuilder permissions
            $this->updateRolePermissions();

            DB::commit();
            $this->command->info('FormBuilder permissions seeded successfully!');
        } catch (\Exception $e) {
            DB::rollBack();
            $this->command->error('Error seeding FormBuilder permissions: '.$e->getMessage());
        }
    }

    /**
     * Define all FormBuilder permissions by category
     */
    protected function definePermissions(): void
    {
        $this->permissions = [
            // Form Management
            'Form Management' => [
                ['name' => 'formbuilder.view-forms', 'description' => 'View all forms'],
                ['name' => 'formbuilder.view-own-forms', 'description' => 'View own created forms'],
                ['name' => 'formbuilder.create-forms', 'description' => 'Create new forms'],
                ['name' => 'formbuilder.edit-forms', 'description' => 'Edit forms'],
                ['name' => 'formbuilder.delete-forms', 'description' => 'Delete forms'],
                ['name' => 'formbuilder.duplicate-forms', 'description' => 'Duplicate forms'],
                ['name' => 'formbuilder.toggle-form-status', 'description' => 'Toggle form active/inactive status'],
                ['name' => 'formbuilder.manage-public-forms', 'description' => 'Manage public form settings and links'],
                ['name' => 'formbuilder.generate-public-links', 'description' => 'Generate public form links'],
                ['name' => 'formbuilder.view-form-details', 'description' => 'View detailed form information'],
            ],

            // Form Submission Management
            'Form Submission Management' => [
                ['name' => 'formbuilder.view-submissions', 'description' => 'View all form submissions'],
                ['name' => 'formbuilder.view-own-submissions', 'description' => 'View submissions of own forms'],
                ['name' => 'formbuilder.view-submission-details', 'description' => 'View detailed submission information'],
                ['name' => 'formbuilder.delete-submissions', 'description' => 'Delete individual submissions'],
                ['name' => 'formbuilder.delete-all-submissions', 'description' => 'Delete all submissions from a form'],
                ['name' => 'formbuilder.export-submissions', 'description' => 'Export form submissions to CSV'],
                ['name' => 'formbuilder.view-submission-statistics', 'description' => 'View submission statistics and analytics'],
            ],

            // Public Form Access
            'Public Form Access' => [
                ['name' => 'formbuilder.access-public-forms', 'description' => 'Access and submit public forms'],
                ['name' => 'formbuilder.submit-forms', 'description' => 'Submit form responses'],
                ['name' => 'formbuilder.view-submission-success', 'description' => 'View form submission success page'],
            ],

            // Field Types Management
            'Field Types Management' => [
                ['name' => 'formbuilder.view-field-types', 'description' => 'View available form field types'],
                ['name' => 'formbuilder.manage-field-types', 'description' => 'Manage custom form field types'],
            ],

            // Form Settings & Configuration
            'Form Settings & Configuration' => [
                ['name' => 'formbuilder.manage-form-settings', 'description' => 'Manage form configuration and settings'],
                ['name' => 'formbuilder.manage-notifications', 'description' => 'Manage form notification settings'],
                ['name' => 'formbuilder.manage-webhooks', 'description' => 'Manage form webhook integrations'],
                ['name' => 'formbuilder.manage-auto-responses', 'description' => 'Manage form auto-response emails'],
            ],

            // Form Analytics & Reports
            'Form Analytics & Reports' => [
                ['name' => 'formbuilder.view-analytics', 'description' => 'View form analytics and reports'],
                ['name' => 'formbuilder.view-form-statistics', 'description' => 'View form usage statistics'],
                ['name' => 'formbuilder.generate-reports', 'description' => 'Generate form and submission reports'],
                ['name' => 'formbuilder.export-form-data', 'description' => 'Export form and submission data'],
            ],
        ];
    }

    /**
     * Create all permissions in the database
     */
    protected function createPermissions(): void
    {
        $sortOrder = 2000; // Start from 2000 to avoid conflicts with existing permissions

        foreach ($this->permissions as $category => $categoryPermissions) {
            foreach ($categoryPermissions as $permission) {
                Permission::updateOrCreate(
                    [
                        'name' => $permission['name'],
                        'guard_name' => 'web',
                    ],
                    [
                        'module' => 'FormBuilder',
                        'description' => $permission['description'].' ('.$category.')',
                        'sort_order' => $sortOrder++,
                    ]
                );

                $this->command->info("Created/Updated permission: {$permission['name']} (FormBuilder - {$category})");
            }
        }
    }

    /**
     * Update existing roles with appropriate FormBuilder permissions
     */
    protected function updateRolePermissions(): void
    {
        // Admin roles get full access
        $this->updateAdminPermissions();

        // HR Manager gets full form management access
        $this->updateHRManagerPermissions();

        // HR Executive gets form management access
        $this->updateHRExecutivePermissions();

        // Team Leader gets basic form access
        $this->updateTeamLeaderPermissions();

        // Employee gets basic form access
        $this->updateEmployeePermissions();

        // Field Employee gets basic form access
        $this->updateFieldEmployeePermissions();
    }

    protected function updateAdminPermissions(): void
    {
        // Super Admin gets all permissions
        $superAdmin = Role::where('name', 'super_admin')->first();
        if ($superAdmin) {
            $superAdmin->syncPermissions(Permission::all());
            $this->command->info('Updated Super Admin role with all permissions');
        }

        // Admin gets all FormBuilder permissions
        $admin = Role::where('name', 'admin')->first();
        if ($admin) {
            $formBuilderPermissions = Permission::where('module', 'FormBuilder')->pluck('name')->toArray();
            $existingPermissions = $admin->permissions()
                ->whereNotIn('module', ['FormBuilder'])
                ->pluck('name')
                ->toArray();

            $admin->syncPermissions(array_merge($formBuilderPermissions, $existingPermissions));
            $this->command->info('Updated Admin role with all FormBuilder permissions');
        }
    }

    protected function updateHRManagerPermissions(): void
    {
        $role = Role::where('name', 'hr_manager')->first();
        if (! $role) {
            return;
        }

        $permissions = [
            // Full form management access
            'formbuilder.view-forms',
            'formbuilder.create-forms',
            'formbuilder.edit-forms',
            'formbuilder.delete-forms',
            'formbuilder.duplicate-forms',
            'formbuilder.toggle-form-status',
            'formbuilder.manage-public-forms',
            'formbuilder.generate-public-links',
            'formbuilder.view-form-details',

            // Full submission management
            'formbuilder.view-submissions',
            'formbuilder.view-submission-details',
            'formbuilder.delete-submissions',
            'formbuilder.delete-all-submissions',
            'formbuilder.export-submissions',
            'formbuilder.view-submission-statistics',

            // Field types and settings
            'formbuilder.view-field-types',
            'formbuilder.manage-field-types',
            'formbuilder.manage-form-settings',
            'formbuilder.manage-notifications',
            'formbuilder.manage-webhooks',
            'formbuilder.manage-auto-responses',

            // Analytics and reports
            'formbuilder.view-analytics',
            'formbuilder.view-form-statistics',
            'formbuilder.generate-reports',
            'formbuilder.export-form-data',

            // Public form access
            'formbuilder.access-public-forms',
            'formbuilder.submit-forms',
            'formbuilder.view-submission-success',
        ];

        // Add existing non-FormBuilder permissions
        $existingPermissions = $role->permissions()
            ->whereNotIn('module', ['FormBuilder'])
            ->pluck('name')
            ->toArray();

        $role->syncPermissions(array_merge($permissions, $existingPermissions));
        $this->command->info('Updated HR Manager role with full FormBuilder permissions');
    }

    protected function updateHRExecutivePermissions(): void
    {
        $role = Role::where('name', 'hr_executive')->first();
        if (! $role) {
            return;
        }

        $permissions = [
            // Form management - can create and edit
            'formbuilder.view-forms',
            'formbuilder.create-forms',
            'formbuilder.edit-forms',
            'formbuilder.duplicate-forms',
            'formbuilder.toggle-form-status',
            'formbuilder.manage-public-forms',
            'formbuilder.generate-public-links',
            'formbuilder.view-form-details',

            // Submission management
            'formbuilder.view-submissions',
            'formbuilder.view-submission-details',
            'formbuilder.export-submissions',
            'formbuilder.view-submission-statistics',

            // Basic settings
            'formbuilder.view-field-types',
            'formbuilder.manage-form-settings',
            'formbuilder.manage-notifications',

            // Basic analytics
            'formbuilder.view-form-statistics',
            'formbuilder.generate-reports',

            // Public form access
            'formbuilder.access-public-forms',
            'formbuilder.submit-forms',
            'formbuilder.view-submission-success',
        ];

        // Add existing non-FormBuilder permissions
        $existingPermissions = $role->permissions()
            ->whereNotIn('module', ['FormBuilder'])
            ->pluck('name')
            ->toArray();

        $role->syncPermissions(array_merge($permissions, $existingPermissions));
        $this->command->info('Updated HR Executive role with FormBuilder permissions');
    }

    protected function updateTeamLeaderPermissions(): void
    {
        $role = Role::where('name', 'team_leader')->first();
        if (! $role) {
            return;
        }

        $permissions = [
            // Basic form access
            'formbuilder.view-own-forms',
            'formbuilder.create-forms',
            'formbuilder.edit-forms',
            'formbuilder.view-form-details',
            'formbuilder.toggle-form-status',
            'formbuilder.manage-public-forms',
            'formbuilder.generate-public-links',

            // Own submission management
            'formbuilder.view-own-submissions',
            'formbuilder.view-submission-details',
            'formbuilder.export-submissions',
            'formbuilder.view-submission-statistics',

            // Basic field types
            'formbuilder.view-field-types',

            // Public form access
            'formbuilder.access-public-forms',
            'formbuilder.submit-forms',
            'formbuilder.view-submission-success',
        ];

        // Add existing non-FormBuilder permissions
        $existingPermissions = $role->permissions()
            ->whereNotIn('module', ['FormBuilder'])
            ->pluck('name')
            ->toArray();

        $role->syncPermissions(array_merge($permissions, $existingPermissions));
        $this->command->info('Updated Team Leader role with basic FormBuilder permissions');
    }

    protected function updateEmployeePermissions(): void
    {
        $role = Role::where('name', 'employee')->first();
        if (! $role) {
            return;
        }

        $permissions = [
            // Basic form access for employee surveys/feedback
            'formbuilder.view-own-forms',
            'formbuilder.view-form-details',

            // Own submission management
            'formbuilder.view-own-submissions',
            'formbuilder.view-submission-details',

            // Public form access (for surveys, feedback, etc.)
            'formbuilder.access-public-forms',
            'formbuilder.submit-forms',
            'formbuilder.view-submission-success',
        ];

        // Add existing non-FormBuilder permissions
        $existingPermissions = $role->permissions()
            ->whereNotIn('module', ['FormBuilder'])
            ->pluck('name')
            ->toArray();

        $role->syncPermissions(array_merge($permissions, $existingPermissions));
        $this->command->info('Updated Employee role with basic FormBuilder access');
    }

    protected function updateFieldEmployeePermissions(): void
    {
        $role = Role::where('name', 'field_employee')->first();
        if (! $role) {
            return;
        }

        $permissions = [
            // Basic public form access for field surveys/reports
            'formbuilder.access-public-forms',
            'formbuilder.submit-forms',
            'formbuilder.view-submission-success',
        ];

        // Add existing non-FormBuilder permissions
        $existingPermissions = $role->permissions()
            ->whereNotIn('module', ['FormBuilder'])
            ->pluck('name')
            ->toArray();

        $role->syncPermissions(array_merge($permissions, $existingPermissions));
        $this->command->info('Updated Field Employee role with basic FormBuilder access');
    }
}
