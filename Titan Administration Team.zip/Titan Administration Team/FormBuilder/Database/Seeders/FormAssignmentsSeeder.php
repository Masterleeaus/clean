<?php

namespace Modules\FormBuilder\Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Modules\FormBuilder\App\Models\Form;
use Modules\FormBuilder\App\Models\FormAssignment;
use Modules\FormBuilder\App\Models\FormSubmission;

class FormAssignmentsSeeder extends Seeder
{
    public function run(): void
    {
        // Truncate existing assignments and related submissions
        FormAssignment::truncate();

        // Get available forms and users
        $forms = Form::where('is_active', true)->get();
        $users = User::limit(10)->get();

        if ($forms->isEmpty() || $users->isEmpty()) {
            $this->command->warn('No forms or users found. Please run SampleFormsSeeder first.');

            return;
        }

        // Create assignments with various statuses
        $this->createPendingAssignments($forms, $users);
        $this->createSubmittedAssignments($forms, $users);
        $this->createOverdueAssignments($forms, $users);
        $this->createFutureAssignments($forms, $users);

        $this->command->info('Form assignments created successfully.');
    }

    private function createPendingAssignments($forms, $users): void
    {
        // Create 3 pending assignments with future due dates
        for ($i = 0; $i < 3; $i++) {
            $form = $forms->random();
            $user = $users->random();
            $otherUsers = $users->where('id', '!=', $user->id);
            $assignedBy = $otherUsers->isNotEmpty() ? $otherUsers->random() : $user;

            FormAssignment::create([
                'form_id' => $form->id,
                'user_id' => $user->id,
                'assigned_by_id' => $assignedBy->id,
                'due_date' => now()->addDays(rand(3, 14)),
                'status' => 'pending',
            ]);
        }
    }

    private function createSubmittedAssignments($forms, $users): void
    {
        // Create 5 submitted assignments with corresponding submissions
        for ($i = 0; $i < 5; $i++) {
            $form = $forms->random();
            $user = $users->random();
            $otherUsers = $users->where('id', '!=', $user->id);
            $assignedBy = $otherUsers->isNotEmpty() ? $otherUsers->random() : $user;

            $assignment = FormAssignment::create([
                'form_id' => $form->id,
                'user_id' => $user->id,
                'assigned_by_id' => $assignedBy->id,
                'due_date' => now()->addDays(rand(5, 20)),
                'status' => 'submitted',
                'created_at' => now()->subDays(rand(1, 10)),
            ]);

            // Create corresponding submission
            $this->createSubmissionForAssignment($assignment, $form, $user);
        }
    }

    private function createOverdueAssignments($forms, $users): void
    {
        // Create 4 overdue assignments (pending with past due dates)
        for ($i = 0; $i < 4; $i++) {
            $form = $forms->random();
            $user = $users->random();
            $otherUsers = $users->where('id', '!=', $user->id);
            $assignedBy = $otherUsers->isNotEmpty() ? $otherUsers->random() : $user;

            FormAssignment::create([
                'form_id' => $form->id,
                'user_id' => $user->id,
                'assigned_by_id' => $assignedBy->id,
                'due_date' => now()->subDays(rand(1, 7)),
                'status' => 'pending',
                'created_at' => now()->subDays(rand(8, 20)),
            ]);
        }
    }

    private function createFutureAssignments($forms, $users): void
    {
        // Create 3 pending assignments with far future due dates
        for ($i = 0; $i < 3; $i++) {
            $form = $forms->random();
            $user = $users->random();
            $otherUsers = $users->where('id', '!=', $user->id);
            $assignedBy = $otherUsers->isNotEmpty() ? $otherUsers->random() : $user;

            FormAssignment::create([
                'form_id' => $form->id,
                'user_id' => $user->id,
                'assigned_by_id' => $assignedBy->id,
                'due_date' => now()->addDays(rand(15, 60)),
                'status' => 'pending',
            ]);
        }
    }

    private function createSubmissionForAssignment($assignment, $form, $user): void
    {
        // Generate appropriate sample data based on form type
        $data = $this->generateSampleDataForForm($form);

        FormSubmission::create([
            'form_id' => $form->id,
            'user_id' => $user->id,
            'data' => $data,
            'ip_address' => '192.168.1.'.rand(1, 254),
            'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
            'created_at' => $assignment->created_at->addDays(rand(1, 3)),
        ]);
    }

    private function generateSampleDataForForm($form): array
    {
        $data = [];
        $fields = $form->fields ?? [];

        foreach ($fields as $field) {
            $fieldName = $field['name'] ?? $field['id'];

            // Generate sample data based on field type
            $data[$fieldName] = match ($field['type']) {
                'text' => 'Sample text for '.$field['label'],
                'email' => 'user'.rand(100, 999).'@example.com',
                'number' => (string) rand(1, 100),
                'textarea' => 'This is a sample response for the '.$field['label'].' field.',
                'select' => $field['options'][0]['value'] ?? 'option1',
                'radio' => $field['options'][0]['value'] ?? 'option1',
                'checkbox' => array_slice(
                    array_column($field['options'] ?? [], 'value'),
                    0,
                    rand(1, min(3, count($field['options'] ?? [1])))
                ),
                'date' => now()->format('Y-m-d'),
                'datetime' => now()->format('Y-m-d H:i:s'),
                'file' => 'sample-file.pdf',
                default => 'Sample value',
            };
        }

        return $data;
    }
}
