<?php

namespace Modules\FormBuilder\Database\Seeders;

use Illuminate\Database\Seeder;

class FormBuilderDatabaseSeeder extends Seeder
{
    public function run()
    {
        // Essential seeders - always run
        $this->call([
            FormBuilderPermissionSeeder::class,
            FormFieldTypesSeeder::class,
        ]);

        // Only run demo seeders in local/demo/testing environment
        if (app()->environment(['local', 'demo', 'testing'])) {
            $this->call([
                SampleFormsSeeder::class,
                FormAssignmentsSeeder::class,
            ]);
        }
    }
}
