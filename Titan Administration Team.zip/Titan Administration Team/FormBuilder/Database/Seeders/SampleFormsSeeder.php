<?php

namespace Modules\FormBuilder\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Str;
use Modules\FormBuilder\App\Models\Form;
use Modules\FormBuilder\App\Models\FormSubmission;

class SampleFormsSeeder extends Seeder
{
    public function run()
    {

        // truncate all forms and submissions
        Form::truncate();
        FormSubmission::truncate();

        // Contact Us Form
        Form::firstOrCreate([
            'name' => 'Contact Us',
        ], [
            'description' => 'Get in touch with us for any inquiries or support.',
            'fields' => [
                [
                    'id' => 'field_1',
                    'type' => 'text',
                    'name' => 'full_name',
                    'label' => 'Full Name',
                    'required' => true,
                    'placeholder' => 'Enter your full name',
                    'description' => '',
                    'order' => 1,
                ],
                [
                    'id' => 'field_2',
                    'type' => 'email',
                    'name' => 'email',
                    'label' => 'Email Address',
                    'required' => true,
                    'placeholder' => 'Enter your email address',
                    'description' => 'We will use this to get back to you',
                    'order' => 2,
                ],
                [
                    'id' => 'field_3',
                    'type' => 'text',
                    'name' => 'phone',
                    'label' => 'Phone Number',
                    'required' => false,
                    'placeholder' => 'Enter your phone number',
                    'description' => 'Optional',
                    'order' => 3,
                ],
                [
                    'id' => 'field_4',
                    'type' => 'select',
                    'name' => 'subject',
                    'label' => 'Subject',
                    'required' => true,
                    'options' => [
                        ['label' => 'General Inquiry', 'value' => 'general'],
                        ['label' => 'Technical Support', 'value' => 'support'],
                        ['label' => 'Sales Question', 'value' => 'sales'],
                        ['label' => 'Partnership', 'value' => 'partnership'],
                        ['label' => 'Other', 'value' => 'other'],
                    ],
                    'description' => '',
                    'order' => 4,
                ],
                [
                    'id' => 'field_5',
                    'type' => 'textarea',
                    'name' => 'message',
                    'label' => 'Message',
                    'required' => true,
                    'placeholder' => 'Enter your message',
                    'description' => 'Please provide details about your inquiry',
                    'rows' => 5,
                    'order' => 5,
                ],
            ],
            'settings' => [
                'submit_button_text' => 'Send Message',
                'success_message' => 'Thank you for contacting us! We will get back to you within 24 hours.',
                'notify_emails' => ['admin@company.com'],
                'auto_response' => true,
                'auto_response_subject' => 'Thank you for contacting us',
                'auto_response_message' => 'We have received your message and will respond shortly.',
            ],
            'is_active' => true,
            'is_public' => true,
            'public_token' => Str::random(32),
            'created_by_id' => 1,
            'updated_by_id' => 1,
        ]);

        // Job Application Form
        Form::firstOrCreate([
            'name' => 'Job Application',
        ], [
            'description' => 'Apply for open positions at our company.',
            'fields' => [
                [
                    'id' => 'field_1',
                    'type' => 'text',
                    'name' => 'first_name',
                    'label' => 'First Name',
                    'required' => true,
                    'placeholder' => 'Enter your first name',
                    'description' => '',
                    'order' => 1,
                ],
                [
                    'id' => 'field_2',
                    'type' => 'text',
                    'name' => 'last_name',
                    'label' => 'Last Name',
                    'required' => true,
                    'placeholder' => 'Enter your last name',
                    'description' => '',
                    'order' => 2,
                ],
                [
                    'id' => 'field_3',
                    'type' => 'email',
                    'name' => 'email',
                    'label' => 'Email Address',
                    'required' => true,
                    'placeholder' => 'Enter your email address',
                    'description' => '',
                    'order' => 3,
                ],
                [
                    'id' => 'field_4',
                    'type' => 'text',
                    'name' => 'phone',
                    'label' => 'Phone Number',
                    'required' => true,
                    'placeholder' => 'Enter your phone number',
                    'description' => '',
                    'order' => 4,
                ],
                [
                    'id' => 'field_5',
                    'type' => 'select',
                    'name' => 'position',
                    'label' => 'Position Applied For',
                    'required' => true,
                    'options' => [
                        ['label' => 'Software Engineer', 'value' => 'software_engineer'],
                        ['label' => 'Project Manager', 'value' => 'project_manager'],
                        ['label' => 'UI/UX Designer', 'value' => 'ui_ux_designer'],
                        ['label' => 'Sales Representative', 'value' => 'sales_rep'],
                        ['label' => 'Marketing Specialist', 'value' => 'marketing_specialist'],
                    ],
                    'description' => '',
                    'order' => 5,
                ],
                [
                    'id' => 'field_6',
                    'type' => 'number',
                    'name' => 'experience_years',
                    'label' => 'Years of Experience',
                    'required' => true,
                    'placeholder' => '0',
                    'description' => 'Total years of relevant work experience',
                    'min' => 0,
                    'max' => 50,
                    'order' => 6,
                ],
                [
                    'id' => 'field_7',
                    'type' => 'file',
                    'name' => 'resume',
                    'label' => 'Resume/CV',
                    'required' => true,
                    'description' => 'Upload your resume in PDF or DOC format',
                    'accept' => '.pdf,.doc,.docx',
                    'maxSize' => 5120,
                    'order' => 7,
                ],
                [
                    'id' => 'field_8',
                    'type' => 'textarea',
                    'name' => 'cover_letter',
                    'label' => 'Cover Letter',
                    'required' => false,
                    'placeholder' => 'Tell us why you are interested in this position...',
                    'description' => 'Optional but recommended',
                    'rows' => 6,
                    'order' => 8,
                ],
                [
                    'id' => 'field_9',
                    'type' => 'checkbox',
                    'name' => 'availability',
                    'label' => 'Availability',
                    'required' => false,
                    'options' => [
                        ['label' => 'Available immediately', 'value' => 'immediate'],
                        ['label' => 'Available within 2 weeks', 'value' => '2_weeks'],
                        ['label' => 'Available within 1 month', 'value' => '1_month'],
                        ['label' => 'Open to remote work', 'value' => 'remote'],
                        ['label' => 'Open to relocation', 'value' => 'relocate'],
                    ],
                    'description' => 'Select all that apply',
                    'order' => 9,
                ],
            ],
            'settings' => [
                'submit_button_text' => 'Submit Application',
                'success_message' => 'Thank you for your application! We will review it and contact you if you are selected for an interview.',
                'notify_emails' => ['hr@company.com', 'hiring@company.com'],
                'auto_response' => true,
                'auto_response_subject' => 'Application Received',
                'auto_response_message' => 'We have received your job application and will review it carefully.',
            ],
            'is_active' => true,
            'is_public' => true,
            'public_token' => Str::random(32),
            'created_by_id' => 1,
            'updated_by_id' => 1,
        ]);

        // Event Registration Form
        Form::firstOrCreate([
            'name' => 'Event Registration',
        ], [
            'description' => 'Register for our upcoming events and workshops.',
            'fields' => [
                [
                    'id' => 'field_1',
                    'type' => 'text',
                    'name' => 'full_name',
                    'label' => 'Full Name',
                    'required' => true,
                    'placeholder' => 'Enter your full name',
                    'description' => '',
                    'order' => 1,
                ],
                [
                    'id' => 'field_2',
                    'type' => 'email',
                    'name' => 'email',
                    'label' => 'Email Address',
                    'required' => true,
                    'placeholder' => 'Enter your email address',
                    'description' => 'We will send event details and updates to this email',
                    'order' => 2,
                ],
                [
                    'id' => 'field_3',
                    'type' => 'text',
                    'name' => 'company',
                    'label' => 'Company/Organization',
                    'required' => false,
                    'placeholder' => 'Enter your company name',
                    'description' => 'Optional',
                    'order' => 3,
                ],
                [
                    'id' => 'field_4',
                    'type' => 'text',
                    'name' => 'job_title',
                    'label' => 'Job Title',
                    'required' => false,
                    'placeholder' => 'Enter your job title',
                    'description' => 'Optional',
                    'order' => 4,
                ],
                [
                    'id' => 'field_5',
                    'type' => 'radio',
                    'name' => 'event_type',
                    'label' => 'Event Type',
                    'required' => true,
                    'options' => [
                        ['label' => 'Workshop: Digital Marketing Strategies', 'value' => 'workshop_marketing'],
                        ['label' => 'Seminar: Future of Technology', 'value' => 'seminar_tech'],
                        ['label' => 'Conference: Business Innovation', 'value' => 'conference_business'],
                        ['label' => 'Networking Event', 'value' => 'networking'],
                    ],
                    'description' => 'Select the event you want to attend',
                    'order' => 5,
                ],
                [
                    'id' => 'field_6',
                    'type' => 'select',
                    'name' => 'ticket_type',
                    'label' => 'Ticket Type',
                    'required' => true,
                    'options' => [
                        ['label' => 'Early Bird - $50', 'value' => 'early_bird'],
                        ['label' => 'Regular - $75', 'value' => 'regular'],
                        ['label' => 'Student - $25', 'value' => 'student'],
                        ['label' => 'Group (5+) - $40 each', 'value' => 'group'],
                    ],
                    'description' => '',
                    'order' => 6,
                ],
                [
                    'id' => 'field_7',
                    'type' => 'checkbox',
                    'name' => 'dietary_requirements',
                    'label' => 'Dietary Requirements',
                    'required' => false,
                    'options' => [
                        ['label' => 'Vegetarian', 'value' => 'vegetarian'],
                        ['label' => 'Vegan', 'value' => 'vegan'],
                        ['label' => 'Gluten-free', 'value' => 'gluten_free'],
                        ['label' => 'Halal', 'value' => 'halal'],
                        ['label' => 'No dietary restrictions', 'value' => 'none'],
                    ],
                    'description' => 'Select all that apply for catering purposes',
                    'order' => 7,
                ],
                [
                    'id' => 'field_8',
                    'type' => 'textarea',
                    'name' => 'special_requirements',
                    'label' => 'Special Requirements or Comments',
                    'required' => false,
                    'placeholder' => 'Any accessibility needs or special requests...',
                    'description' => 'Please let us know if you have any special requirements',
                    'rows' => 4,
                    'order' => 8,
                ],
            ],
            'settings' => [
                'submit_button_text' => 'Register Now',
                'success_message' => 'Thank you for registering! You will receive a confirmation email with event details shortly.',
                'notify_emails' => ['events@company.com'],
                'auto_response' => true,
                'auto_response_subject' => 'Event Registration Confirmed',
                'auto_response_message' => 'Your registration has been confirmed. We look forward to seeing you at the event!',
            ],
            'is_active' => true,
            'is_public' => true,
            'public_token' => Str::random(32),
            'created_by_id' => 1,
            'updated_by_id' => 1,
        ]);

        // Customer Feedback Survey
        Form::firstOrCreate([
            'name' => 'Customer Feedback Survey',
        ], [
            'description' => 'Help us improve our services by sharing your feedback.',
            'fields' => [
                [
                    'id' => 'field_1',
                    'type' => 'text',
                    'name' => 'customer_name',
                    'label' => 'Your Name',
                    'required' => false,
                    'placeholder' => 'Enter your name (optional)',
                    'description' => 'Optional - you can provide feedback anonymously',
                    'order' => 1,
                ],
                [
                    'id' => 'field_2',
                    'type' => 'email',
                    'name' => 'email',
                    'label' => 'Email Address',
                    'required' => false,
                    'placeholder' => 'Enter your email (optional)',
                    'description' => 'Optional - only if you want us to follow up',
                    'order' => 2,
                ],
                [
                    'id' => 'field_3',
                    'type' => 'radio',
                    'name' => 'overall_satisfaction',
                    'label' => 'Overall Satisfaction',
                    'required' => true,
                    'options' => [
                        ['label' => 'Very Satisfied', 'value' => 'very_satisfied'],
                        ['label' => 'Satisfied', 'value' => 'satisfied'],
                        ['label' => 'Neutral', 'value' => 'neutral'],
                        ['label' => 'Dissatisfied', 'value' => 'dissatisfied'],
                        ['label' => 'Very Dissatisfied', 'value' => 'very_dissatisfied'],
                    ],
                    'description' => 'How would you rate your overall experience?',
                    'order' => 3,
                ],
                [
                    'id' => 'field_4',
                    'type' => 'checkbox',
                    'name' => 'service_aspects',
                    'label' => 'Which aspects of our service did you find most valuable?',
                    'required' => false,
                    'options' => [
                        ['label' => 'Customer Support', 'value' => 'support'],
                        ['label' => 'Product Quality', 'value' => 'quality'],
                        ['label' => 'Pricing', 'value' => 'pricing'],
                        ['label' => 'Delivery Speed', 'value' => 'delivery'],
                        ['label' => 'User Interface', 'value' => 'ui'],
                        ['label' => 'Documentation', 'value' => 'docs'],
                    ],
                    'description' => 'Select all that apply',
                    'order' => 4,
                ],
                [
                    'id' => 'field_5',
                    'type' => 'number',
                    'name' => 'recommendation_score',
                    'label' => 'Recommendation Score',
                    'required' => true,
                    'placeholder' => '10',
                    'description' => 'On a scale of 1-10, how likely are you to recommend us to others?',
                    'min' => 1,
                    'max' => 10,
                    'order' => 5,
                ],
                [
                    'id' => 'field_6',
                    'type' => 'textarea',
                    'name' => 'improvement_suggestions',
                    'label' => 'Suggestions for Improvement',
                    'required' => false,
                    'placeholder' => 'What could we do better?',
                    'description' => 'Your suggestions help us improve our services',
                    'rows' => 4,
                    'order' => 6,
                ],
                [
                    'id' => 'field_7',
                    'type' => 'textarea',
                    'name' => 'additional_comments',
                    'label' => 'Additional Comments',
                    'required' => false,
                    'placeholder' => 'Any other feedback you would like to share?',
                    'description' => 'Optional',
                    'rows' => 3,
                    'order' => 7,
                ],
            ],
            'settings' => [
                'submit_button_text' => 'Submit Feedback',
                'success_message' => 'Thank you for your valuable feedback! We appreciate you taking the time to help us improve.',
                'notify_emails' => ['feedback@company.com', 'management@company.com'],
                'auto_response' => true,
                'auto_response_subject' => 'Thank you for your feedback',
                'auto_response_message' => 'We have received your feedback and truly appreciate your input.',
            ],
            'is_active' => true,
            'is_public' => true,
            'public_token' => Str::random(32),
            'created_by_id' => 1,
            'updated_by_id' => 1,
        ]);

        // Newsletter Subscription
        Form::firstOrCreate([
            'name' => 'Newsletter Subscription',
        ], [
            'description' => 'Subscribe to our newsletter for updates and exclusive content.',
            'fields' => [
                [
                    'id' => 'field_1',
                    'type' => 'text',
                    'name' => 'first_name',
                    'label' => 'First Name',
                    'required' => true,
                    'placeholder' => 'Enter your first name',
                    'description' => '',
                    'order' => 1,
                ],
                [
                    'id' => 'field_2',
                    'type' => 'email',
                    'name' => 'email',
                    'label' => 'Email Address',
                    'required' => true,
                    'placeholder' => 'Enter your email address',
                    'description' => 'We will never share your email with third parties',
                    'order' => 2,
                ],
                [
                    'id' => 'field_3',
                    'type' => 'checkbox',
                    'name' => 'interests',
                    'label' => 'Interests',
                    'required' => false,
                    'options' => [
                        ['label' => 'Technology Updates', 'value' => 'technology'],
                        ['label' => 'Product Announcements', 'value' => 'products'],
                        ['label' => 'Industry News', 'value' => 'industry'],
                        ['label' => 'Educational Content', 'value' => 'education'],
                        ['label' => 'Special Offers', 'value' => 'offers'],
                    ],
                    'description' => 'What topics interest you most?',
                    'order' => 3,
                ],
                [
                    'id' => 'field_4',
                    'type' => 'radio',
                    'name' => 'frequency',
                    'label' => 'Email Frequency',
                    'required' => true,
                    'options' => [
                        ['label' => 'Weekly', 'value' => 'weekly'],
                        ['label' => 'Bi-weekly', 'value' => 'biweekly'],
                        ['label' => 'Monthly', 'value' => 'monthly'],
                    ],
                    'description' => 'How often would you like to receive emails?',
                    'order' => 4,
                ],
            ],
            'settings' => [
                'submit_button_text' => 'Subscribe',
                'success_message' => 'Welcome to our newsletter! Please check your email to confirm your subscription.',
                'notify_emails' => ['newsletter@company.com'],
                'auto_response' => true,
                'auto_response_subject' => 'Confirm Your Newsletter Subscription',
                'auto_response_message' => 'Thank you for subscribing! Please confirm your subscription by clicking the link in this email.',
            ],
            'is_active' => true,
            'is_public' => true,
            'public_token' => Str::random(32),
            'created_by_id' => 1,
            'updated_by_id' => 1,
        ]);

        // Comprehensive Demo Form - All Field Types
        Form::firstOrCreate([
            'name' => 'Comprehensive Demo Form - All Field Types',
        ], [
            'description' => 'This form demonstrates all available field types in the Form Builder.',
            'fields' => [
                [
                    'id' => 'field_1',
                    'type' => 'heading',
                    'label' => 'Personal Information Section',
                    'text' => 'Personal Information',
                    'level' => 'h2',
                    'align' => 'left',
                    'order' => 1,
                ],
                [
                    'id' => 'field_2',
                    'type' => 'text',
                    'name' => 'full_name',
                    'label' => 'Full Name',
                    'required' => true,
                    'placeholder' => 'Enter your full name',
                    'minLength' => 2,
                    'maxLength' => 100,
                    'order' => 2,
                ],
                [
                    'id' => 'field_3',
                    'type' => 'email',
                    'name' => 'email',
                    'label' => 'Email Address',
                    'required' => true,
                    'placeholder' => 'your.email@example.com',
                    'order' => 3,
                ],
                [
                    'id' => 'field_4',
                    'type' => 'tel',
                    'name' => 'phone',
                    'label' => 'Phone Number',
                    'required' => false,
                    'placeholder' => '+1-234-567-8900',
                    'order' => 4,
                ],
                [
                    'id' => 'field_5',
                    'type' => 'url',
                    'name' => 'website',
                    'label' => 'Website',
                    'required' => false,
                    'placeholder' => 'https://www.example.com',
                    'order' => 5,
                ],
                [
                    'id' => 'field_6',
                    'type' => 'password',
                    'name' => 'password',
                    'label' => 'Password',
                    'required' => false,
                    'placeholder' => 'Enter a secure password',
                    'minLength' => 8,
                    'order' => 6,
                ],
                [
                    'id' => 'field_7',
                    'type' => 'divider',
                    'style' => 'solid',
                    'color' => '#007bff',
                    'order' => 7,
                ],
                [
                    'id' => 'field_8',
                    'type' => 'heading',
                    'label' => 'Date and Time Section',
                    'text' => 'Date and Time Information',
                    'level' => 'h2',
                    'align' => 'left',
                    'order' => 8,
                ],
                [
                    'id' => 'field_9',
                    'type' => 'date',
                    'name' => 'birth_date',
                    'label' => 'Date of Birth',
                    'required' => true,
                    'order' => 9,
                ],
                [
                    'id' => 'field_10',
                    'type' => 'time',
                    'name' => 'preferred_time',
                    'label' => 'Preferred Contact Time',
                    'required' => false,
                    'order' => 10,
                ],
                [
                    'id' => 'field_11',
                    'type' => 'datetime-local',
                    'name' => 'appointment',
                    'label' => 'Appointment Date & Time',
                    'required' => false,
                    'order' => 11,
                ],
                [
                    'id' => 'field_12',
                    'type' => 'divider',
                    'style' => 'dashed',
                    'color' => '#28a745',
                    'order' => 12,
                ],
                [
                    'id' => 'field_13',
                    'type' => 'heading',
                    'label' => 'Numbers and Ranges',
                    'text' => 'Numeric Values',
                    'level' => 'h2',
                    'align' => 'left',
                    'order' => 13,
                ],
                [
                    'id' => 'field_14',
                    'type' => 'number',
                    'name' => 'age',
                    'label' => 'Age',
                    'required' => true,
                    'placeholder' => '18',
                    'min' => 1,
                    'max' => 120,
                    'step' => 1,
                    'order' => 14,
                ],
                [
                    'id' => 'field_15',
                    'type' => 'range',
                    'name' => 'satisfaction_level',
                    'label' => 'Satisfaction Level',
                    'required' => false,
                    'min' => 0,
                    'max' => 100,
                    'step' => 10,
                    'value' => 50,
                    'order' => 15,
                ],
                [
                    'id' => 'field_16',
                    'type' => 'rating',
                    'name' => 'service_rating',
                    'label' => 'Rate Our Service',
                    'required' => true,
                    'max' => 5,
                    'order' => 16,
                ],
                [
                    'id' => 'field_17',
                    'type' => 'divider',
                    'style' => 'dotted',
                    'color' => '#ffc107',
                    'order' => 17,
                ],
                [
                    'id' => 'field_18',
                    'type' => 'heading',
                    'label' => 'Text and Selection Fields',
                    'text' => 'More Information',
                    'level' => 'h2',
                    'align' => 'left',
                    'order' => 18,
                ],
                [
                    'id' => 'field_19',
                    'type' => 'textarea',
                    'name' => 'comments',
                    'label' => 'Comments',
                    'required' => false,
                    'placeholder' => 'Share your thoughts...',
                    'rows' => 4,
                    'minLength' => 10,
                    'maxLength' => 500,
                    'order' => 19,
                ],
                [
                    'id' => 'field_20',
                    'type' => 'select',
                    'name' => 'country',
                    'label' => 'Country',
                    'required' => true,
                    'placeholder' => 'Select your country',
                    'options' => [
                        ['label' => 'United States', 'value' => 'us'],
                        ['label' => 'United Kingdom', 'value' => 'uk'],
                        ['label' => 'Canada', 'value' => 'ca'],
                        ['label' => 'Australia', 'value' => 'au'],
                        ['label' => 'Germany', 'value' => 'de'],
                        ['label' => 'France', 'value' => 'fr'],
                        ['label' => 'Other', 'value' => 'other'],
                    ],
                    'order' => 20,
                ],
                [
                    'id' => 'field_21',
                    'type' => 'radio',
                    'name' => 'gender',
                    'label' => 'Gender',
                    'required' => true,
                    'options' => [
                        ['label' => 'Male', 'value' => 'male'],
                        ['label' => 'Female', 'value' => 'female'],
                        ['label' => 'Non-binary', 'value' => 'non_binary'],
                        ['label' => 'Prefer not to say', 'value' => 'prefer_not_to_say'],
                    ],
                    'order' => 21,
                ],
                [
                    'id' => 'field_22',
                    'type' => 'checkbox',
                    'name' => 'hobbies',
                    'label' => 'Hobbies',
                    'required' => false,
                    'options' => [
                        ['label' => 'Reading', 'value' => 'reading'],
                        ['label' => 'Sports', 'value' => 'sports'],
                        ['label' => 'Music', 'value' => 'music'],
                        ['label' => 'Travel', 'value' => 'travel'],
                        ['label' => 'Gaming', 'value' => 'gaming'],
                        ['label' => 'Cooking', 'value' => 'cooking'],
                    ],
                    'order' => 22,
                ],
                [
                    'id' => 'field_23',
                    'type' => 'divider',
                    'style' => 'solid',
                    'color' => '#dc3545',
                    'order' => 23,
                ],
                [
                    'id' => 'field_24',
                    'type' => 'heading',
                    'label' => 'File and Visual Fields',
                    'text' => 'Uploads and Colors',
                    'level' => 'h2',
                    'align' => 'left',
                    'order' => 24,
                ],
                [
                    'id' => 'field_25',
                    'type' => 'file',
                    'name' => 'resume',
                    'label' => 'Upload Resume',
                    'required' => false,
                    'accept' => '.pdf,.doc,.docx',
                    'maxSize' => 5120,
                    'multiple' => false,
                    'order' => 25,
                ],
                [
                    'id' => 'field_26',
                    'type' => 'color',
                    'name' => 'favorite_color',
                    'label' => 'Favorite Color',
                    'required' => false,
                    'value' => '#3498db',
                    'order' => 26,
                ],
                [
                    'id' => 'field_27',
                    'type' => 'divider',
                    'style' => 'dashed',
                    'color' => '#6c757d',
                    'order' => 27,
                ],
                [
                    'id' => 'field_28',
                    'type' => 'heading',
                    'label' => 'Special Fields',
                    'text' => 'HTML Content and Hidden Fields',
                    'level' => 'h2',
                    'align' => 'left',
                    'order' => 28,
                ],
                [
                    'id' => 'field_29',
                    'type' => 'html',
                    'content' => '<div class="alert alert-info"><strong>Important Notice:</strong> This is an HTML content block that can contain any HTML markup including <em>formatted text</em>, <a href="#">links</a>, images, and more!</div>',
                    'order' => 29,
                ],
                [
                    'id' => 'field_30',
                    'type' => 'hidden',
                    'name' => 'form_source',
                    'label' => 'Form Source',
                    'value' => 'demo_form_all_fields',
                    'order' => 30,
                ],
                [
                    'id' => 'field_31',
                    'type' => 'hidden',
                    'name' => 'tracking_id',
                    'label' => 'Tracking ID',
                    'value' => 'TRACK-12345',
                    'order' => 31,
                ],
                [
                    'id' => 'field_32',
                    'type' => 'divider',
                    'style' => 'solid',
                    'color' => '#17a2b8',
                    'order' => 32,
                ],
                [
                    'id' => 'field_33',
                    'type' => 'heading',
                    'label' => 'Final Section',
                    'text' => 'Ready to Submit?',
                    'level' => 'h3',
                    'align' => 'center',
                    'order' => 33,
                ],
                [
                    'id' => 'field_34',
                    'type' => 'html',
                    'content' => '<p class="text-center text-muted">By submitting this form, you agree to our <a href="#">Terms of Service</a> and <a href="#">Privacy Policy</a>.</p>',
                    'order' => 34,
                ],
            ],
            'settings' => [
                'submit_button_text' => 'Submit Complete Form',
                'success_message' => 'Thank you! This demo form showcases all available field types in the Form Builder.',
                'notify_emails' => ['demo@company.com'],
                'auto_response' => false,
            ],
            'is_active' => true,
            'is_public' => true,
            'public_token' => Str::random(32),
            'created_by_id' => 1,
            'updated_by_id' => 1,
        ]);

        // Create sample submissions for each form
        $this->createSampleSubmissions();
    }

    private function createSampleSubmissions()
    {
        $forms = Form::all();

        foreach ($forms as $form) {
            switch ($form->name) {
                case 'Contact Us':
                    $this->createContactUsSubmissions($form);
                    break;
                case 'Job Application':
                    $this->createJobApplicationSubmissions($form);
                    break;
                case 'Event Registration':
                    $this->createEventRegistrationSubmissions($form);
                    break;
                case 'Customer Feedback Survey':
                    $this->createCustomerFeedbackSubmissions($form);
                    break;
                case 'Newsletter Subscription':
                    $this->createNewsletterSubmissions($form);
                    break;
            }
        }
    }

    private function createContactUsSubmissions($form)
    {
        $submissions = [
            [
                'full_name' => 'John Smith',
                'email' => 'john.smith@example.com',
                'phone' => '+1-555-0123',
                'subject' => 'general',
                'message' => 'Hello, I would like to know more about your services. Could you please provide me with additional information about your pricing and features?',
            ],
            [
                'full_name' => 'Sarah Johnson',
                'email' => 'sarah.j@email.com',
                'phone' => '+1-555-0456',
                'subject' => 'support',
                'message' => 'I am experiencing issues with my account login. Could you please help me reset my password?',
            ],
            [
                'full_name' => 'Michael Chen',
                'email' => 'mchen@business.com',
                'phone' => '',
                'subject' => 'sales',
                'message' => 'We are interested in your enterprise solution for our company of 200+ employees. Please contact us to discuss pricing.',
            ],
        ];

        foreach ($submissions as $data) {
            FormSubmission::create([
                'form_id' => $form->id,
                'data' => $data,
                'ip_address' => '192.168.1.'.rand(1, 254),
                'user_agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'created_at' => now()->subDays(rand(1, 7)),
            ]);
        }
    }

    private function createJobApplicationSubmissions($form)
    {
        $submissions = [
            [
                'first_name' => 'Emily',
                'last_name' => 'Davis',
                'email' => 'emily.davis@gmail.com',
                'phone' => '+1-555-0789',
                'position' => 'software_engineer',
                'experience_years' => '5',
                'cover_letter' => 'I am excited to apply for the Software Engineer position. With 5 years of experience in full-stack development...',
                'availability' => ['immediate', 'remote'],
            ],
            [
                'first_name' => 'Robert',
                'last_name' => 'Wilson',
                'email' => 'r.wilson@email.com',
                'phone' => '+1-555-0321',
                'position' => 'project_manager',
                'experience_years' => '8',
                'cover_letter' => 'As a seasoned project manager with 8 years of experience leading cross-functional teams...',
                'availability' => ['2_weeks'],
            ],
        ];

        foreach ($submissions as $data) {
            FormSubmission::create([
                'form_id' => $form->id,
                'data' => $data,
                'ip_address' => '192.168.1.'.rand(1, 254),
                'user_agent' => 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36',
                'created_at' => now()->subDays(rand(1, 10)),
            ]);
        }
    }

    private function createEventRegistrationSubmissions($form)
    {
        $submissions = [
            [
                'full_name' => 'Jennifer Lee',
                'email' => 'jennifer.lee@company.com',
                'company' => 'Tech Solutions Inc',
                'job_title' => 'Marketing Director',
                'event_type' => 'workshop_marketing',
                'ticket_type' => 'early_bird',
                'dietary_requirements' => ['vegetarian'],
                'special_requirements' => '',
            ],
            [
                'full_name' => 'David Rodriguez',
                'email' => 'david.r@startup.io',
                'company' => 'Startup Innovations',
                'job_title' => 'CTO',
                'event_type' => 'seminar_tech',
                'ticket_type' => 'regular',
                'dietary_requirements' => ['none'],
                'special_requirements' => 'Wheelchair accessible seating please',
            ],
            [
                'full_name' => 'Lisa Anderson',
                'email' => 'lisa.anderson@university.edu',
                'company' => 'State University',
                'job_title' => 'Professor',
                'event_type' => 'conference_business',
                'ticket_type' => 'student',
                'dietary_requirements' => ['gluten_free'],
                'special_requirements' => '',
            ],
        ];

        foreach ($submissions as $data) {
            FormSubmission::create([
                'form_id' => $form->id,
                'data' => $data,
                'ip_address' => '192.168.1.'.rand(1, 254),
                'user_agent' => 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36',
                'created_at' => now()->subDays(rand(1, 5)),
            ]);
        }
    }

    private function createCustomerFeedbackSubmissions($form)
    {
        $submissions = [
            [
                'customer_name' => 'Alex Thompson',
                'email' => 'alex.t@email.com',
                'overall_satisfaction' => 'very_satisfied',
                'service_aspects' => ['support', 'quality', 'ui'],
                'recommendation_score' => '9',
                'improvement_suggestions' => 'The mobile app could use some UI improvements.',
                'additional_comments' => 'Overall very happy with the service!',
            ],
            [
                'customer_name' => '',
                'email' => '',
                'overall_satisfaction' => 'satisfied',
                'service_aspects' => ['pricing', 'delivery'],
                'recommendation_score' => '7',
                'improvement_suggestions' => 'Faster customer support response times would be great.',
                'additional_comments' => '',
            ],
            [
                'customer_name' => 'Maria Garcia',
                'email' => 'm.garcia@business.com',
                'overall_satisfaction' => 'neutral',
                'service_aspects' => ['docs', 'support'],
                'recommendation_score' => '6',
                'improvement_suggestions' => 'More detailed documentation and video tutorials would help.',
                'additional_comments' => 'Good product but needs better onboarding.',
            ],
        ];

        foreach ($submissions as $data) {
            FormSubmission::create([
                'form_id' => $form->id,
                'data' => $data,
                'ip_address' => '192.168.1.'.rand(1, 254),
                'user_agent' => 'Mozilla/5.0 (iPhone; CPU iPhone OS 15_0 like Mac OS X)',
                'created_at' => now()->subDays(rand(1, 14)),
            ]);
        }
    }

    private function createNewsletterSubmissions($form)
    {
        $submissions = [
            [
                'first_name' => 'Chris',
                'email' => 'chris.martin@email.com',
                'interests' => ['technology', 'products'],
                'frequency' => 'weekly',
            ],
            [
                'first_name' => 'Amanda',
                'email' => 'amanda.white@gmail.com',
                'interests' => ['industry', 'education', 'offers'],
                'frequency' => 'monthly',
            ],
            [
                'first_name' => 'Kevin',
                'email' => 'kevin.brown@company.net',
                'interests' => ['technology', 'education'],
                'frequency' => 'biweekly',
            ],
            [
                'first_name' => 'Rachel',
                'email' => 'rachel.jones@business.org',
                'interests' => ['products', 'offers'],
                'frequency' => 'weekly',
            ],
        ];

        foreach ($submissions as $data) {
            FormSubmission::create([
                'form_id' => $form->id,
                'data' => $data,
                'ip_address' => '192.168.1.'.rand(1, 254),
                'user_agent' => 'Mozilla/5.0 (iPad; CPU OS 15_0 like Mac OS X)',
                'created_at' => now()->subDays(rand(1, 3)),
            ]);
        }
    }
}
