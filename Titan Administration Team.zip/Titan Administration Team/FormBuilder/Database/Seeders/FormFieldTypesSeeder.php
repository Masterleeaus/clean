<?php

namespace Modules\FormBuilder\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\FormBuilder\App\Models\FormFieldType;

class FormFieldTypesSeeder extends Seeder
{
    public function run()
    {
        $fieldTypes = [
            [
                'name' => 'Text Input',
                'type' => 'text',
                'icon' => 'bx bx-text',
                'description' => 'Single line text input field',
                'default_config' => [
                    'placeholder' => 'Enter text...',
                    'maxLength' => 255,
                    'required' => false,
                ],
                'sort_order' => 1,
            ],
            [
                'name' => 'Textarea',
                'type' => 'textarea',
                'icon' => 'bx bx-message-detail',
                'description' => 'Multi-line text input field',
                'default_config' => [
                    'placeholder' => 'Enter your message...',
                    'rows' => 4,
                    'maxLength' => 1000,
                    'required' => false,
                ],
                'sort_order' => 2,
            ],
            [
                'name' => 'Email',
                'type' => 'email',
                'icon' => 'bx bx-envelope',
                'description' => 'Email address input field',
                'default_config' => [
                    'placeholder' => 'Enter email address...',
                    'required' => false,
                ],
                'sort_order' => 3,
            ],
            [
                'name' => 'Number',
                'type' => 'number',
                'icon' => 'bx bx-hash',
                'description' => 'Numeric input field',
                'default_config' => [
                    'placeholder' => 'Enter number...',
                    'min' => null,
                    'max' => null,
                    'step' => 1,
                    'required' => false,
                ],
                'sort_order' => 4,
            ],
            [
                'name' => 'Phone',
                'type' => 'tel',
                'icon' => 'bx bx-phone',
                'description' => 'Phone number input field',
                'default_config' => [
                    'placeholder' => 'Enter phone number...',
                    'required' => false,
                ],
                'sort_order' => 5,
            ],
            [
                'name' => 'URL',
                'type' => 'url',
                'icon' => 'bx bx-link',
                'description' => 'URL/Website input field',
                'default_config' => [
                    'placeholder' => 'https://example.com',
                    'required' => false,
                ],
                'sort_order' => 6,
            ],
            [
                'name' => 'Password',
                'type' => 'password',
                'icon' => 'bx bx-lock',
                'description' => 'Password input field',
                'default_config' => [
                    'placeholder' => 'Enter password...',
                    'minLength' => 6,
                    'required' => false,
                ],
                'sort_order' => 7,
            ],
            [
                'name' => 'Date',
                'type' => 'date',
                'icon' => 'bx bx-calendar',
                'description' => 'Date picker field',
                'default_config' => [
                    'required' => false,
                    'min' => null,
                    'max' => null,
                ],
                'sort_order' => 8,
            ],
            [
                'name' => 'Time',
                'type' => 'time',
                'icon' => 'bx bx-time',
                'description' => 'Time picker field',
                'default_config' => [
                    'required' => false,
                ],
                'sort_order' => 9,
            ],
            [
                'name' => 'DateTime',
                'type' => 'datetime-local',
                'icon' => 'bx bx-calendar-event',
                'description' => 'Date and time picker field',
                'default_config' => [
                    'required' => false,
                ],
                'sort_order' => 10,
            ],
            [
                'name' => 'Dropdown/Select',
                'type' => 'select',
                'icon' => 'bx bx-list-ul',
                'description' => 'Dropdown selection field',
                'default_config' => [
                    'placeholder' => 'Select an option...',
                    'options' => [
                        ['label' => 'Option 1', 'value' => 'option1'],
                        ['label' => 'Option 2', 'value' => 'option2'],
                        ['label' => 'Option 3', 'value' => 'option3'],
                    ],
                    'required' => false,
                ],
                'sort_order' => 11,
            ],
            [
                'name' => 'Radio Buttons',
                'type' => 'radio',
                'icon' => 'bx bx-radio-circle',
                'description' => 'Single choice radio buttons',
                'default_config' => [
                    'options' => [
                        ['label' => 'Option 1', 'value' => 'option1'],
                        ['label' => 'Option 2', 'value' => 'option2'],
                        ['label' => 'Option 3', 'value' => 'option3'],
                    ],
                    'required' => false,
                ],
                'sort_order' => 12,
            ],
            [
                'name' => 'Checkboxes',
                'type' => 'checkbox',
                'icon' => 'bx bx-check-square',
                'description' => 'Multiple choice checkboxes',
                'default_config' => [
                    'options' => [
                        ['label' => 'Option 1', 'value' => 'option1'],
                        ['label' => 'Option 2', 'value' => 'option2'],
                        ['label' => 'Option 3', 'value' => 'option3'],
                    ],
                    'required' => false,
                ],
                'sort_order' => 13,
            ],
            [
                'name' => 'File Upload',
                'type' => 'file',
                'icon' => 'bx bx-cloud-upload',
                'description' => 'File upload field',
                'default_config' => [
                    'accept' => null,
                    'maxSize' => 5120, // 5MB in KB
                    'multiple' => false,
                    'required' => false,
                ],
                'sort_order' => 14,
            ],
            [
                'name' => 'Range/Slider',
                'type' => 'range',
                'icon' => 'bx bx-slider',
                'description' => 'Range slider input',
                'default_config' => [
                    'min' => 0,
                    'max' => 100,
                    'step' => 1,
                    'value' => 50,
                    'required' => false,
                ],
                'sort_order' => 15,
            ],
            [
                'name' => 'Color Picker',
                'type' => 'color',
                'icon' => 'bx bx-palette',
                'description' => 'Color selection field',
                'default_config' => [
                    'value' => '#000000',
                    'required' => false,
                ],
                'sort_order' => 16,
            ],
            [
                'name' => 'Hidden Field',
                'type' => 'hidden',
                'icon' => 'bx bx-hide',
                'description' => 'Hidden input field',
                'default_config' => [
                    'value' => '',
                ],
                'sort_order' => 17,
            ],
            [
                'name' => 'HTML Content',
                'type' => 'html',
                'icon' => 'bx bx-code',
                'description' => 'Static HTML content/text',
                'default_config' => [
                    'content' => '<p>Your HTML content here...</p>',
                ],
                'sort_order' => 18,
            ],
            [
                'name' => 'Heading',
                'type' => 'heading',
                'icon' => 'bx bx-heading',
                'description' => 'Section heading',
                'default_config' => [
                    'level' => 'h3',
                    'text' => 'Section Heading',
                    'align' => 'left',
                ],
                'sort_order' => 19,
            ],
            [
                'name' => 'Divider',
                'type' => 'divider',
                'icon' => 'bx bx-minus',
                'description' => 'Visual divider/separator',
                'default_config' => [
                    'style' => 'solid',
                    'color' => '#e0e0e0',
                ],
                'sort_order' => 20,
            ],
            [
                'name' => 'Rating',
                'type' => 'rating',
                'icon' => 'bx bx-star',
                'description' => 'Star rating field',
                'default_config' => [
                    'max' => 5,
                    'required' => false,
                ],
                'sort_order' => 21,
            ],
            [
                'name' => 'Multi-Step',
                'type' => 'step',
                'icon' => 'bx bx-list-ol',
                'description' => 'Multi-step form section',
                'default_config' => [
                    'title' => 'Step Title',
                    'description' => 'Step description...',
                ],
                'sort_order' => 22,
            ],
        ];

        foreach ($fieldTypes as $fieldType) {
            FormFieldType::firstOrCreate(
                ['type' => $fieldType['type']],
                $fieldType
            );
        }
    }
}
