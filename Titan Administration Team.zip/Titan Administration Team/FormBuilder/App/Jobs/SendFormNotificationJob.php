<?php

namespace Modules\FormBuilder\App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Modules\FormBuilder\App\Mail\FormSubmissionNotification;
use Modules\FormBuilder\App\Models\Form;
use Modules\FormBuilder\App\Models\FormSubmission;

class SendFormNotificationJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $form;

    protected $submission;

    protected $notifyEmails;

    /**
     * Create a new job instance.
     */
    public function __construct(Form $form, FormSubmission $submission, array $notifyEmails)
    {
        $this->form = $form;
        $this->submission = $submission;
        $this->notifyEmails = $notifyEmails;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        try {
            foreach ($this->notifyEmails as $email) {
                if (filter_var($email, FILTER_VALIDATE_EMAIL)) {
                    Mail::to($email)->send(new FormSubmissionNotification($this->form, $this->submission));
                }
            }
        } catch (\Exception $e) {
            Log::error('Failed to send form notification emails: '.$e->getMessage());
            throw $e;
        }
    }
}
