<?php

namespace Modules\FormBuilder\App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Mail;
use Modules\FormBuilder\App\Mail\FormAutoResponseMail;
use Modules\FormBuilder\App\Models\Form;
use Modules\FormBuilder\App\Models\FormSubmission;

class SendFormAutoResponseJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $form;

    protected $submission;

    protected $recipientEmail;

    /**
     * Create a new job instance.
     */
    public function __construct(Form $form, FormSubmission $submission, string $recipientEmail)
    {
        $this->form = $form;
        $this->submission = $submission;
        $this->recipientEmail = $recipientEmail;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        try {
            if (filter_var($this->recipientEmail, FILTER_VALIDATE_EMAIL)) {
                Mail::to($this->recipientEmail)->send(new FormAutoResponseMail($this->form, $this->submission));
            }
        } catch (\Exception $e) {
            Log::error('Failed to send auto-response email: '.$e->getMessage());
            throw $e;
        }
    }
}
