<?php

namespace Modules\FormBuilder\App\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;
use Modules\FormBuilder\App\Models\Form;
use Modules\FormBuilder\App\Models\FormSubmission;

class SendFormWebhookJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    protected $form;

    protected $submission;

    protected $webhookUrl;

    /**
     * Create a new job instance.
     */
    public function __construct(Form $form, FormSubmission $submission, string $webhookUrl)
    {
        $this->form = $form;
        $this->submission = $submission;
        $this->webhookUrl = $webhookUrl;
    }

    /**
     * Execute the job.
     */
    public function handle(): void
    {
        try {
            $payload = [
                'event' => 'form.submission',
                'form' => [
                    'id' => $this->form->id,
                    'title' => $this->form->title,
                    'public_token' => $this->form->public_token,
                ],
                'submission' => [
                    'id' => $this->submission->id,
                    'submission_token' => $this->submission->submission_token,
                    'data' => $this->submission->data,
                    'ip_address' => $this->submission->ip_address,
                    'submitted_at' => $this->submission->created_at->toISOString(),
                ],
                'timestamp' => now()->toISOString(),
            ];

            $response = Http::timeout(30)
                ->withHeaders([
                    'Content-Type' => 'application/json',
                    'User-Agent' => 'FormBuilder-Webhook/1.0',
                ])
                ->post($this->webhookUrl, $payload);

            if (! $response->successful()) {
                Log::warning('Webhook delivery failed', [
                    'url' => $this->webhookUrl,
                    'status' => $response->status(),
                    'response' => $response->body(),
                ]);
            }

        } catch (\Exception $e) {
            Log::error('Failed to send webhook: '.$e->getMessage(), [
                'url' => $this->webhookUrl,
                'form_id' => $this->form->id,
                'submission_id' => $this->submission->id,
            ]);
            throw $e;
        }
    }
}
