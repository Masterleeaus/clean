<?php

namespace Modules\FormBuilder\App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Mail\Mailables\Content;
use Illuminate\Mail\Mailables\Envelope;
use Illuminate\Queue\SerializesModels;
use Modules\FormBuilder\App\Models\Form;
use Modules\FormBuilder\App\Models\FormSubmission;

class FormAutoResponseMail extends Mailable
{
    use Queueable, SerializesModels;

    public $form;

    public $submission;

    /**
     * Create a new message instance.
     */
    public function __construct(Form $form, FormSubmission $submission)
    {
        $this->form = $form;
        $this->submission = $submission;
    }

    /**
     * Get the message envelope.
     */
    public function envelope(): Envelope
    {
        $subject = $this->form->settings['auto_response_subject'] ?? __('Thank you for your submission');

        return new Envelope(
            subject: $subject,
        );
    }

    /**
     * Get the message content definition.
     */
    public function content(): Content
    {
        return new Content(
            html: 'formbuilder::emails.form-auto-response',
        );
    }

    /**
     * Get the attachments for the message.
     *
     * @return array<int, \Illuminate\Mail\Mailables\Attachment>
     */
    public function attachments(): array
    {
        return [];
    }
}
