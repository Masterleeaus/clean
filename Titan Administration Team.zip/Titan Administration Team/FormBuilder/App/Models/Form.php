<?php

namespace Modules\FormBuilder\App\Models;

use App\Traits\UserActionsTrait;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Support\Str;
use OwenIt\Auditing\Auditable;
use OwenIt\Auditing\Contracts\Auditable as AuditableContract;

class Form extends Model implements AuditableContract
{
    use Auditable, HasFactory, SoftDeletes, UserActionsTrait;

    protected $table = 'fb_forms';

    protected $fillable = [
        'name',
        'slug',
        'description',
        'fields',
        'settings',
        'is_active',
        'is_public',
        'public_token',
        'expires_at',
        'created_by_id',
        'updated_by_id',
    ];

    protected $casts = [
        'fields' => 'array',
        'settings' => 'array',
        'is_active' => 'boolean',
        'is_public' => 'boolean',
        'expires_at' => 'datetime',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->slug)) {
                $model->slug = Str::slug($model->name);
            }

            if ($model->is_public && empty($model->public_token)) {
                $model->public_token = Str::random(32);
            }
        });

        static::updating(function ($model) {
            if ($model->isDirty('name') && empty($model->slug)) {
                $model->slug = Str::slug($model->name);
            }

            if ($model->isDirty('is_public') && $model->is_public && empty($model->public_token)) {
                $model->public_token = Str::random(32);
            }
        });
    }

    public function submissions(): HasMany
    {
        return $this->hasMany(FormSubmission::class);
    }

    public function assignments(): HasMany
    {
        return $this->hasMany(FormAssignment::class);
    }

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'created_by_id');
    }

    public function updatedBy(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class, 'updated_by_id');
    }

    public function getPublicUrlAttribute()
    {
        return $this->is_public && $this->public_token
          ? route('public.form.show', ['token' => $this->public_token])
          : null;
    }

    public function getSubmissionCountAttribute()
    {
        return $this->submissions()->count();
    }

    public function isExpired()
    {
        return $this->expires_at && $this->expires_at->isPast();
    }

    public function generatePublicToken()
    {
        $this->public_token = Str::random(32);
        $this->save();

        return $this->public_token;
    }

    public function assignmentForUser($userId)
    {
        return $this->assignments()->where('user_id', $userId)->first();
    }
}
