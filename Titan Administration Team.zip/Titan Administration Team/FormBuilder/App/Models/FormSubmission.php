<?php

namespace Modules\FormBuilder\App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Str;

class FormSubmission extends Model
{
    use HasFactory;

    protected $table = 'fb_form_submissions';

    protected $fillable = [
        'form_id',
        'data',
        'submission_token',
        'ip_address',
        'user_agent',
        'user_id',
    ];

    protected $casts = [
        'data' => 'array',
    ];

    protected static function boot()
    {
        parent::boot();

        static::creating(function ($model) {
            if (empty($model->submission_token)) {
                $model->submission_token = Str::random(32);
            }
        });
    }

    public function form(): BelongsTo
    {
        return $this->belongsTo(Form::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class);
    }

    public function getFormattedDataAttribute()
    {
        $formatted = [];
        $fields = $this->form->fields ?? [];

        foreach ($fields as $field) {
            $fieldName = $field['name'] ?? $field['id'];
            $fieldLabel = $field['label'] ?? $fieldName;
            $value = $this->data[$fieldName] ?? null;

            $formatted[] = [
                'label' => $fieldLabel,
                'value' => $value,
                'type' => $field['type'] ?? 'text',
            ];
        }

        return $formatted;
    }
}
