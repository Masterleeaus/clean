<?php

use Illuminate\Support\Facades\Route;
use Modules\FormBuilder\App\Http\Controllers\FormBuilderController;
use Modules\FormBuilder\App\Http\Controllers\PublicFormController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
*/

Route::group(['middleware' => 'auth'], function () {
    Route::prefix('forms')->name('formbuilder.')->group(function () {
        Route::get('/', [FormBuilderController::class, 'index'])->name('index');
        Route::get('/datatable', [FormBuilderController::class, 'indexAjax'])->name('datatable');
        Route::get('/data', [FormBuilderController::class, 'getDataAjax'])->name('data');
        Route::get('/create', [FormBuilderController::class, 'create'])->name('create');
        Route::post('/', [FormBuilderController::class, 'store'])->name('store');
        Route::get('/{id}', [FormBuilderController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [FormBuilderController::class, 'edit'])->name('edit');
        Route::put('/{id}', [FormBuilderController::class, 'update'])->name('update');
        Route::delete('/{id}', [FormBuilderController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/duplicate', [FormBuilderController::class, 'duplicate'])->name('duplicate');
        Route::post('/{id}/toggle-status', [FormBuilderController::class, 'toggleStatus'])->name('toggle-status');
        Route::post('/{id}/generate-public-link', [FormBuilderController::class, 'generatePublicLink'])->name('generate-public-link');
        Route::get('/{id}/submissions', [FormBuilderController::class, 'submissions'])->name('submissions');
        Route::get('/{id}/submissions/data', [FormBuilderController::class, 'getSubmissionsData'])->name('submissions.data');
        Route::get('/{id}/submissions/{submission}', [FormBuilderController::class, 'showSubmission'])->name('submissions.show');
        Route::delete('/{id}/submissions/{submission}', [FormBuilderController::class, 'destroySubmission'])->name('submissions.destroy');
        Route::get('/{id}/submissions-export', [FormBuilderController::class, 'exportSubmissions'])->name('submissions.export');
        Route::post('/{id}/submissions-delete-all', [FormBuilderController::class, 'deleteAllSubmissions'])->name('submissions.deleteAll');
    });
});

// Public form routes (no authentication required)
Route::prefix('public/forms')->name('public.form.')->group(function () {
    Route::get('/{token}', [PublicFormController::class, 'show'])->name('show');
    Route::post('/{token}', [PublicFormController::class, 'submit'])->name('submit');
    Route::get('/{token}/success', [PublicFormController::class, 'success'])->name('success');
});
