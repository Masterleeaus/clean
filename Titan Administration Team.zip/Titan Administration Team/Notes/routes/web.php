<?php

use Illuminate\Support\Facades\Route;
use Modules\Notes\App\Http\Controllers\NoteChecklistController;
use Modules\Notes\App\Http\Controllers\NotesController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::group(['middleware' => function ($request, $next) {
    $request->headers->set('addon', ModuleConstants::NOTES);

    return $next($request);
}], function () {

    Route::prefix('notes')->middleware(['auth'])->name('user.notes.')->group(function () {

        // Main page view
        Route::get('/', [NotesController::class, 'index'])->name('index');

        // DataTables AJAX source (Using GET is standard for DataTables source)
        Route::get('/data', [NotesController::class, 'getNotesData'])->name('getNotesData');

        // --- AJAX CRUD and Actions (Using POST as requested) ---

        // Create Note
        Route::post('/', [NotesController::class, 'store'])->name('store');

        // Get Note data for editing (Using GET here is RESTful, but can be POST if strictly required)
        // If using POST: Route::post('/{note}/edit-data', [NotesController::class, 'editData'])->name('editData');
        Route::get('/{note}/edit', [NotesController::class, 'edit'])->name('edit'); // Fetch data

        // Update Note
        Route::put('/{note}/update', [NotesController::class, 'update'])->name('update'); // POST for update

        // Delete Note (Soft Delete)
        Route::delete('/{note}/delete', [NotesController::class, 'destroy'])->name('destroy'); // POST for delete

        // Toggle Pin Status
        Route::post('/{note}/toggle-pin', [NotesController::class, 'togglePin'])->name('togglePin');

        // Toggle Archive Status
        Route::post('/{note}/toggle-archive', [NotesController::class, 'toggleArchive'])->name('toggleArchive');

        // Reorder
        Route::post('/reorder', [NotesController::class, 'reorder'])->name('reorder'); // POST for reordering

        // Store a new item for a specific note
        Route::post('/{note}/checklist-items', [NoteChecklistController::class, 'store'])->name('checklist.store');
        // Update an existing item's content or status (using POST)
        Route::post('/checklist-items/{item}/update', [NoteChecklistController::class, 'update'])->name('checklist.update'); // Uses {item} binding
        // Delete an item (using POST)
        Route::post('/checklist-items/{item}/delete', [NoteChecklistController::class, 'destroy'])->name('checklist.destroy'); // Uses {item} binding
        // Reorder items within a specific note
        Route::post('/{note}/checklist-items/reorder', [NoteChecklistController::class, 'reorder'])->name('checklist.reorder');

    });
});
