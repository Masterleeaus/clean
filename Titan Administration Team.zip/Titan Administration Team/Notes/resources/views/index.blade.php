@php
  $noteColors = [
       // Hex values for 6 fixed light colors + a default/no color option
       ''        => __('Default / None'),
       '#FFF59D' => __('Pale Yellow'),
       '#A5D6A7' => __('Mint Green'),
       '#90CAF9' => __('Sky Blue'),
       '#F48FB1' => __('Pastel Pink'),
       '#B39DDB' => __('Lavender'),
       '#FFCC80' => __('Peach')
   ];
@endphp
@extends('layouts.layoutMaster')

@section('title', __('My Notes'))

@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/animate-css/animate.scss',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
  ])
@endsection

@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
    // Masonry for grid layout (optional alternative to Bootstrap grid)
    // 'resources/assets/vendor/libs/masonry/masonry.js',
    // SortableJS
  ])
  <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.6/Sortable.min.js"></script>
@endsection

@section('page-style')
  <style>
    .note-card { margin-bottom: 1.5rem; transition: box-shadow 0.2s ease-in-out; border: 1px solid #eee; }
    .note-card:hover { box-shadow: 0 .125rem .25rem rgba(161, 172, 184, .4); }
    .note-card-content { white-space: pre-wrap; word-break: break-word; max-height: 200px; overflow-y: auto; font-size: 0.9rem; margin-bottom: 1rem;}
    .note-card-checklist { list-style: none; padding-left: 0; margin-bottom: 1rem; font-size: 0.9rem;}
    .note-card-checklist li { margin-bottom: 0.3rem; display: flex; align-items: center; }
    .note-card-checklist input[type="checkbox"] { margin-right: 0.5rem; width: 1rem; height: 1rem; cursor: pointer; }
    .note-card-checklist label { flex-grow: 1; }
    .note-card-checklist .completed label { text-decoration: line-through; color: #adb5bd; }
    .note-tag { display: inline-block; margin: 2px; padding: 0.2em 0.6em !important; font-size: 0.75em !important; }
    .note-actions { padding-top: 0.5rem; border-top: 1px solid #eee; }
    .note-actions .btn-icon { padding: 0.2rem 0.4rem; font-size: 0.9rem;}
    .note-card .card-body { padding: 1rem; }
    .note-card .card-title { margin-bottom: 0.5rem; display: flex; justify-content: space-between; align-items: center;}
    .note-card .card-title .pin-icon { color: #ffab00; /* Warning color for pin */ }
    .note-card.is-pinned { border-left: 3px solid #ffab00; } /* Highlight pinned notes */
    /* Ensure select2 dropdowns appear above offcanvas */
    .select2-container--open { z-index: 1090; }
    /* Style for sortable ghost element */
    .sortable-ghost { opacity: 0.4; background-color: #f0f0f0; }
    .sortable-chosen { /* Style for the item being dragged */ }
    /* New Checklist Repeater Styles */
    .checklist-repeater-item {
      display: flex;
      align-items: center;
      padding: 0.5rem 0;
      border-bottom: 1px dashed #eee;
    }
    .checklist-repeater-item:last-child {
      border-bottom: none;
    }
    .checklist-repeater-item .handle {
      cursor: move;
      color: #a1acb8;
      margin-right: 0.5rem;
      font-size: 1.2rem; /* Make handle visible */
    }
    .checklist-repeater-item .form-check-input {
      margin-top: 0; /* Align checkbox */
      margin-right: 0.5rem;
      width: 1.1em; /* Slightly larger checkbox */
      height: 1.1em;
    }
    .checklist-repeater-item .form-control {
      flex-grow: 1;
      border: none;
      padding: 0.25rem 0.5rem;
      box-shadow: none !important;
      background: transparent;
    }
    .checklist-repeater-item .form-control:focus {
      background: #f8f9fa;
    }
    .checklist-repeater-item .btn-remove-item {
      padding: 0.1rem 0.4rem;
      font-size: 0.9rem;
      line-height: 1;
      color: #ff3e1d;
    }
    /* Style completed items */
    .checklist-repeater-item.completed .form-control {
      text-decoration: line-through;
      color: #a1acb8;
    }

    /* Fixed Color Picker Styles (from calendar) */
    .color-radio-group .form-check-input { display: none; }
    .color-radio-group .form-check-label {
      display: inline-block; width: 28px; height: 28px; border-radius: 50%;
      cursor: pointer; border: 3px solid transparent; margin-right: 6px;
      transition: border-color 0.2s ease-in-out;
      box-shadow: 0 1px 3px rgba(0,0,0,0.1);
    }
    .color-radio-group .form-check-input:checked + .form-check-label {
      border-color: #fff; /* White border indicates selection */
      box-shadow: 0 0 0 2px #435971, 0 1px 3px rgba(0,0,0,0.1); /* Theme color outer border */
    }
    .color-radio-group .form-check-inline { margin-right: 0.2rem;} /* Adjust spacing */
    .color-radio-group .form-check-label.color-default { /* Style for default 'none' option */
      border: 1px dashed #ccc;
      background: linear-gradient(to top right, #ffffff 48%, #e9ecef 50%, #e9ecef 52%, #ffffff 54%);
    }
    .color-radio-group .form-check-input:checked + .form-check-label.color-default {
      border: 3px solid #fff;
      box-shadow: 0 0 0 2px #435971, 0 1px 3px rgba(0,0,0,0.1);
    }

  </style>
@endsection

@section('page-script')
  <script>
    // Pass initial data and URLs to JavaScript using pageData pattern
    const pageData = {
      urls: {
        getNotesData: @json(route('user.notes.getNotesData')),
        store: @json(route('user.notes.store')),
        base: @json(url('notes'))
      },
      labels: {
        myNotes: @json(__('My Notes')),
        addNote: @json(__('Add Note')),
        editNote: @json(__('Edit Note')),
        loading: @json(__('Loading...')),
        noNotes: @json(__('No notes found')),
        noNotesDesc: @json(__('Try adjusting filters or create a new note to get started!')),
        confirmDelete: @json(__('Delete Note?')),
        cannotBeUndone: @json(__('This action cannot be undone!')),
        confirmArchive: @json(__('Archive Note?')),
        confirmRestore: @json(__('Restore Note?')),
        confirmPin: @json(__('Toggle Pin?')),
        success: @json(__('Success!')),
        error: @json(__('Error')),
        validationError: @json(__('Please correct the validation errors.')),
        unexpectedError: @json(__('An unexpected error occurred. Please try again later.')),
        loadError: @json(__('Could not load notes. Please try again.')),
        pin: @json(__('Pin')),
        unpin: @json(__('Unpin')),
        archive: @json(__('Archive')),
        unarchive: @json(__('Unarchive')),
        edit: @json(__('Edit')),
        delete: @json(__('Delete')),
        pinned: @json(__('Pinned')),
        updated: @json(__('Updated')),
        submit: @json(__('Submit')),
        tags: @json(__('Select or type tags'))
      },
      userTags: @json($tags->map(fn($tag)=>(['id'=>(string)$tag->id, 'text'=>$tag->name]))->toArray())
    };
  </script>
  @vite(['Modules/Notes/resources/assets/js/notes.js'])
@endsection

@section('content')
  <div class="container-fluid flex-grow-1 container-p-y">

    {{-- Breadcrumb --}}
    <x-breadcrumb
      :title="__('My Notes')"
      :breadcrumbs="[
        ['name' => __('My Notes'), 'url' => '#']
      ]"
      :homeUrl="route('dashboard')"
    >
      <x-slot name="actions">
        <button type="button" class="btn btn-primary" id="addNoteBtn">
          <i class="bx bx-plus me-1"></i>
          <span class="d-none d-sm-inline-block">{{ __('Add New Note') }}</span>
        </button>
      </x-slot>
    </x-breadcrumb>

    {{-- Filters Card --}}
    <div class="card mb-4">
      <div class="card-body">
        <div class="row g-3 align-items-end">
          {{-- Search Input --}}
          <div class="col-md-4 col-sm-6 col-12">
            <label for="noteSearch" class="form-label">{{ __('Search Notes') }}</label>
            <input type="text" id="noteSearch" class="form-control" placeholder="{{ __('Search title or content...') }}">
          </div>
          {{-- Tag Filter --}}
          <div class="col-md-3 col-sm-6 col-12">
            <label for="filter_tag_id" class="form-label">{{ __('Filter by Tag') }}</label>
            <select id="filter_tag_id" class="form-select select2-basic">
              <option value="" selected>{{ __('All Tags') }}</option>
              @foreach ($tags as $tag)
                <option value="{{ $tag->id }}">{{ $tag->name }}</option>
              @endforeach
            </select>
          </div>
          {{-- View Filter (Active/Archived/Pinned) --}}
          <div class="col-md-3 col-sm-6 col-12">
            <label for="filter_view" class="form-label">{{ __('View') }}</label>
            <select id="filter_view" class="form-select select2-basic">
              <option value="active" selected>{{ __('Active') }}</option>
              <option value="pinned">{{ __('Pinned') }}</option>
              <option value="archived">{{ __('Archived') }}</option>
            </select>
          </div>
          {{-- Clear Filters Button --}}
          <div class="col-md-2 col-sm-6 col-12">
            <button type="button" class="btn btn-label-secondary w-100" id="clearFiltersBtn">
              <i class="bx bx-x me-1"></i>{{ __('Clear') }}
            </button>
          </div>
        </div>
      </div>
    </div>

    {{-- Notes Grid Container --}}
    <div class="row" id="notesGridContainer" data-masonry='{"percentPosition": true }'>
      {{-- Loading Indicator --}}
      <div id="notesLoadingIndicator" class="col-12 text-center py-5">
        <div class="spinner-border text-primary" role="status">
          <span class="visually-hidden">{{ __('Loading...') }}</span>
        </div>
        <p class="text-muted mt-3">{{ __('Loading your notes...') }}</p>
      </div>

      {{-- Empty State --}}
      <div id="noNotesMessage" class="col-12" style="display: none;">
        <div class="card">
          <div class="card-body text-center py-5">
            <div class="mb-4">
              <i class="bx bx-note" style="font-size: 4rem; color: #a1acb8;"></i>
            </div>
            <h5 class="mb-2">{{ __('No notes found') }}</h5>
            <p class="text-muted mb-4">
              {{ __('Try adjusting filters or create a new note to get started!') }}
            </p>
            <button type="button" class="btn btn-primary" onclick="document.getElementById('addNoteBtn').click()">
              <i class="bx bx-plus me-1"></i>{{ __('Create Your First Note') }}
            </button>
          </div>
        </div>
      </div>
    </div>



    {{-- Offcanvas for Add/Edit Note --}}
    <div class="offcanvas offcanvas-end" tabindex="-1" id="noteOffcanvas" aria-labelledby="noteOffcanvasLabel" style="width: 500px;">
      <div class="offcanvas-header">
        <h5 id="noteOffcanvasLabel" class="offcanvas-title">{{ __('Add Note') }}</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="{{ __('Close') }}"></button>
      </div>
      <div class="offcanvas-body mx-0 flex-grow-0">
        <form class="add-edit-note-form" id="noteForm" onsubmit="return false;">
          @csrf
          <input type="hidden" name="_method" id="noteMethod" value="POST">
          <input type="hidden" name="note_id" id="note_id" value="">

          {{-- Pinned Switch --}}
          <div class="mb-3">
            <label class="switch switch-primary">
              <input type="checkbox" class="switch-input" id="is_pinned" name="is_pinned" value="1">
              <span class="switch-toggle-slider"><span class="switch-on"><i class='bx bx-pin'></i></span><span class="switch-off"><i class='bx bx-pin'></i></span></span>
              <span class="switch-label">{{ __('Pin this note?') }}</span>
            </label>
            <input type="hidden" name="is_pinned" value="0">
          </div>

          {{-- Title --}}
          <div class="mb-3">
            <label class="form-label" for="noteTitle">{{ __('Title') }}</label>
            <input type="text" class="form-control" id="noteTitle" placeholder="{{ __('Note Title (Optional)') }}" name="title" />
            <div class="invalid-feedback"></div>
          </div>

          {{-- Content --}}
          <div class="mb-3">
            <label class="form-label" for="noteContent">{{ __('Content') }}</label>
            <textarea class="form-control" id="noteContent" name="content" rows="8" placeholder="{{ __('Enter your note details...') }}"></textarea>
            <div class="invalid-feedback"></div>
          </div>

          {{-- Checklist Input Area --}}

          {{-- START: Checklist Repeater Area --}}
          <div class="mb-3">
            <label class="form-label">{{ __('Checklist Items') }}</label>
            <div id="checklistRepeaterContainer">
              {{-- Checklist items will be added here by JS --}}
            </div>
            <button type="button" class="btn btn-sm btn-outline-secondary mt-2" id="addChecklistItemBtn">
              <i class="bx bx-plus"></i> {{ __('Add Item') }}
            </button>
            <div class="invalid-feedback" id="checklist-general-error"></div>
          </div>
          {{-- Template for new checklist item (hidden) --}}
          <template id="checklistItemTemplate">
            <div class="checklist-repeater-item">
              <i class="bx bx-grid-vertical handle me-2" title="{{ __('Drag to reorder') }}"></i>
              <input class="form-check-input mt-0 me-2 checklist-item-complete" type="checkbox" value="1" name="CHECKLIST_ITEM_COMPLETED_NAME">
              <input type="hidden" name="CHECKLIST_ITEM_COMPLETED_NAME_HIDDEN" value="0">
              <input type="hidden" name="CHECKLIST_ITEM_ID_NAME" value="">
              <input type="text" class="form-control form-control-sm checklist-item-content" placeholder="{{ __('New checklist item...') }}" name="CHECKLIST_ITEM_CONTENT_NAME" required>
              <button type="button" class="btn btn-sm btn-icon text-danger remove-checklist-item ms-2" title="{{ __('Remove Item') }}"><i class="bx bx-x"></i></button>
            </div>
          </template>
          {{-- END: Checklist Repeater Area --}}

          {{-- Tags Selector --}}
          <div class="mb-3">
            <label for="tags" class="form-label">{{ __('Tags') }}</label>
            <div id="select2-tags-wrapper">
              <select class="select2-tags form-select" id="tags" name="tags[]" multiple="multiple">
                @foreach ($tags as $tag)
                  <option value="{{ $tag->id }}">{{ $tag->name }}</option>
                @endforeach
              </select>
            </div>
            <div class="invalid-feedback"></div>
          </div>

          {{-- START: Fixed Color Picker --}}
          <div class="mb-3">
            <label class="form-label d-block">{{ __('Color') }}</label>
            <div class="d-flex flex-wrap color-radio-group">
              @foreach($noteColors as $hex => $label)
                <div class="form-check form-check-inline">
                  <input class="form-check-input" type="radio" name="color" id="color_{{ $loop->index }}" value="{{ $hex }}" @checked($loop->first)>
                  <label class="form-check-label {{ $hex == '' ? 'color-default' : '' }}"
                         for="color_{{ $loop->index }}"
                         style="{{ $hex != '' ? 'background-color: '.$hex.';' : '' }}"
                         title="{{ $label }}">
                  </label>
                </div>
              @endforeach
            </div>
            <div class="invalid-feedback"></div>
          </div>
          {{-- END: Fixed Color Picker --}}

          {{-- General Error Message Area --}}
          <div class="mb-3">
            <small class="text-danger" id="general-error"></small>
          </div>

          <div class="mt-4 d-flex gap-2">
            <button type="submit" class="btn btn-primary flex-fill data-submit" id="submitNoteBtn">{{ __('Submit') }}</button>
            <button type="reset" class="btn btn-label-secondary flex-fill" data-bs-dismiss="offcanvas">{{ __('Cancel') }}</button>
          </div>
        </form>
      </div>
    </div> {{-- End Offcanvas --}}

  </div>
@endsection
