<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('note_checklist_items', function (Blueprint $table) {
            $table->id();

            // Link to the parent note in the notes table
            $table->foreignId('note_id')
                ->constrained('notes') // Reference the corrected notes table name
                ->cascadeOnDelete();

            $table->text('content');
            $table->boolean('is_completed')->default(false)->index();
            $table->timestamp('completed_at')->nullable();
            $table->integer('order_column')->default(0)->index()->comment('Order within the note\'s checklist');

            $table->string('tenant_id', 191)->nullable()->index();
            $table->timestamps(); // created_at, updated_at
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('note_checklist_items');
    }
};
