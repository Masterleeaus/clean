<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('notes', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique()->nullable(); // Unique identifier

            $table->foreignId('user_id')
                ->comment('The user who owns this note')
                ->constrained('users') // Assumes your users table is 'users'
                ->cascadeOnDelete(); // Delete notes if user is deleted

            $table->string('title')->nullable()->index();
            $table->text('content')->nullable();
            $table->string('color', 7)->nullable()->comment('Hex color code like #RRGGBB');
            $table->boolean('is_pinned')->default(false)->index();
            $table->integer('order_column')->default(0)->index()->comment('For custom grid ordering by user');
            $table->dateTime('archived_at')->nullable();

            $table->string('tenant_id', 191)->nullable()->index();
            $table->timestamps(); // created_at, updated_at
            $table->softDeletes(); // deleted_at
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('notes');
    }
};
