<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('tags', function (Blueprint $table) {
            $table->id();

            $table->foreignId('user_id')
                ->comment('The user who owns this tag')
                ->constrained('users')
                ->cascadeOnDelete();

            $table->string('name');
            $table->string('color', 7)->nullable()->comment('Optional hex color');

            $table->string('tenant_id', 191)->nullable()->index();
            $table->timestamps();

            // Ensure tag names are unique per user within a tenant
            $table->unique(['user_id', 'name', 'tenant_id']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('tags');
    }
};
