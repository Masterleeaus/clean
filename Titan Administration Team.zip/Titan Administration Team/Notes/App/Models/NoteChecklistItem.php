<?php

namespace Modules\Notes\App\Models; // Default nwidart namespace

// Uncomment if using spatie/eloquent-sortable
// use Spatie\EloquentSortable\Sortable;
// use Spatie\EloquentSortable\SortableTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

// Add "implements Sortable" if using the sortable package
class NoteChecklistItem extends Model /* implements Sortable */
{
    // Apply necessary traits
    // Add SortableTrait if using spatie/eloquent-sortable

    /**
     * The table associated with the model.
     */
    protected $table = 'note_checklist_items'; // Corrected table name

    /**
     * Configuration for spatie/eloquent-sortable
     */
    /* // Uncomment if using spatie/eloquent-sortable
    public $sortable = [
        'order_column_name' => 'order_column',
        'sort_when_creating' => true,
        'group_by_column' => 'note_id', // Sorts within each note
    ];
    */

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'note_id',
        'content',
        'is_completed',
        'completed_at',
        'order_column',
    ];

    /**
     * The attributes that should be cast.
     */
    protected $casts = [
        'is_completed' => 'boolean',
        'completed_at' => 'datetime',
    ];

    /**
     * Get the note that the checklist item belongs to.
     */
    public function note(): BelongsTo
    {
        // Ensure correct related model namespace
        return $this->belongsTo(Note::class);
    }

    /**
     * Factory definition (optional).
     */
    // protected static function newFactory()
    // {
    //    // return \Modules\Notes\Database\factories\NoteChecklistItemFactory::new(); // Adjust path
    // }
}
