<?php

namespace Modules\Notes\App\Models; // Default nwidart namespace

use App\Models\User; // Assuming User model is in App\Models
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;

class Tag extends Model
{
    /**
     * The table associated with the model.
     */
    protected $table = 'tags'; // Corrected table name

    /**
     * The attributes that are mass assignable.
     */
    protected $fillable = [
        'user_id', // Link to the user who owns the tag
        'name',
        'color',
    ];

    /**
     * The notes that belong to the tag.
     */
    public function notes(): BelongsToMany
    {
        // Ensure correct related model namespace and pivot table name
        return $this->belongsToMany(Note::class, 'note_tag', 'tag_id', 'note_id');
    }

    /**
     * The user who owns the tag.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Factory definition (optional).
     */
    // protected static function newFactory()
    // {
    //    // return \Modules\Notes\Database\factories\TagFactory::new(); // Adjust path
    // }
}
