<?php

namespace Modules\Notes\App\Models;

use App\Models\User; // Assuming User model is in App\Models
// use App\Traits\UserActionsTrait; // Not needed as user_id is the owner/creator
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;

class Note extends Model
{
    // Apply necessary traits
    use HasUuids, SoftDeletes;

    /**
     * The table associated with the model.
     * Explicitly set if not inferred correctly.
     *
     * @var string
     */
    protected $table = 'notes'; // Use the corrected table name

    /**
     * The attributes that are mass assignable.
     *
     * @var array<int, string>
     */
    protected $fillable = [
        'uuid',
        'user_id', // Owner
        'title',
        'content',
        'color',
        'is_pinned',
        'order_column',
        'archived_at', // Removed based on final migration
        // created_by/updated_by not needed as user_id owns it
    ];

    /**
     * The attributes that should be cast.
     *
     * @var array<string, string>
     */
    protected $casts = [
        'is_pinned' => 'boolean',
        'archived_at' => 'datetime', // Removed
    ];

    /**
     * Get the columns that should receive a unique identifier.
     *
     * @return array<int, string>
     */
    public function uniqueIds(): array
    {
        return ['uuid'];
    }

    // Relationships

    /**
     * Get the user (owner) that owns the note.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Get the checklist items for the note.
     */
    public function checklistItems(): HasMany
    {
        // Ensure correct related model namespace
        return $this->hasMany(NoteChecklistItem::class)->orderBy('order_column');
    }

    /**
     * The tags that belong to the note.
     */
    public function tags(): BelongsToMany
    {
        // Ensure correct related model namespace and pivot table name
        return $this->belongsToMany(Tag::class, 'note_tag', 'note_id', 'tag_id');
    }

    /**
     * Factory definition (optional).
     */
    // protected static function newFactory()
    // {
    //    // return \Modules\Notes\Database\factories\NoteFactory::new(); // Adjust path
    // }
}
