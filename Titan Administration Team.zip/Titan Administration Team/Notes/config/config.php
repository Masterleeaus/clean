<?php

return [
    'name' => 'Notes',
];
