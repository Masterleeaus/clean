<?php

return [
    'name' => 'TitanDocs'
];
