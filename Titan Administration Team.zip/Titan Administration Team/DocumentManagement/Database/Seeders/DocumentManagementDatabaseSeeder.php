<?php

namespace Modules\DocumentManagement\Database\Seeders;

use Illuminate\Database\Seeder;

class DocumentManagementDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Essential seeders - always run
        $this->call([
            DocumentManagementPermissionsSeeder::class,
        ]);

        // Only run demo seeders in local/demo/testing environment
        if (app()->environment(['local', 'demo', 'testing'])) {
            $this->call([
                DocumentCategoriesSeeder::class,
                SampleEmployeeDocumentsSeeder::class,
            ]);
        }
    }
}
