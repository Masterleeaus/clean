<?php

namespace Modules\DocumentManagement\Database\Seeders;

use Illuminate\Database\Seeder;
use Modules\DocumentManagement\App\Models\DocumentCategory;

class DocumentCategoriesSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // International Document Types (commonly required for employees)
        $categories = [
            [
                'name' => 'Passport',
                'code' => 'PASS',
                'description' => 'Official international travel document',
                'requires_expiry_date' => true,
                'requires_verification' => true,
                'is_confidential' => true,
                'is_active' => true,
            ],
            [
                'name' => 'Work Visa',
                'code' => 'VISA',
                'description' => 'Employment authorization for non-citizens',
                'requires_expiry_date' => true,
                'requires_verification' => true,
                'is_confidential' => true,
                'is_active' => true,
            ],
            [
                'name' => 'Residence Permit',
                'code' => 'RESPMT',
                'description' => 'Legal authorization to live in a specific country',
                'requires_expiry_date' => true,
                'requires_verification' => true,
                'is_confidential' => true,
                'is_active' => true,
            ],
            [
                'name' => 'Work Permit',
                'code' => 'WRKPMT',
                'description' => 'Legal authorization to work in a specific country',
                'requires_expiry_date' => true,
                'requires_verification' => true,
                'is_confidential' => true,
                'is_active' => true,
            ],
            [
                'name' => 'National ID',
                'code' => 'NATID',
                'description' => 'Government-issued identification document',
                'requires_expiry_date' => true,
                'requires_verification' => true,
                'is_confidential' => true,
                'is_active' => true,
            ],
            [
                'name' => 'Driving License',
                'code' => 'DRVLIC',
                'description' => 'Official document permitting individual to drive motor vehicles',
                'requires_expiry_date' => true,
                'requires_verification' => false,
                'is_confidential' => false,
                'is_active' => true,
            ],
            [
                'name' => 'Employment Contract',
                'code' => 'EMPCNT',
                'description' => 'Legal agreement between employer and employee',
                'requires_expiry_date' => false,
                'requires_verification' => true,
                'is_confidential' => true,
                'is_active' => true,
            ],
            [
                'name' => 'Educational Certificates',
                'code' => 'EDUCRT',
                'description' => 'Official documents proving academic qualifications',
                'requires_expiry_date' => false,
                'requires_verification' => true,
                'is_confidential' => false,
                'is_active' => true,
            ],
            [
                'name' => 'Professional Licenses',
                'code' => 'PROLIC',
                'description' => 'Authorization to practice specific professions',
                'requires_expiry_date' => true,
                'requires_verification' => true,
                'is_confidential' => false,
                'is_active' => true,
            ],
            [
                'name' => 'Tax Documents',
                'code' => 'TAXDOC',
                'description' => 'Tax-related documents like tax ID, registration certificates',
                'requires_expiry_date' => false,
                'requires_verification' => true,
                'is_confidential' => true,
                'is_active' => true,
            ],
            [
                'name' => 'Health Insurance',
                'code' => 'HLTHINS',
                'description' => 'Insurance coverage for medical expenses',
                'requires_expiry_date' => true,
                'requires_verification' => false,
                'is_confidential' => false,
                'is_active' => true,
            ],
            [
                'name' => 'Medical Certificates',
                'code' => 'MEDCRT',
                'description' => 'Official health status documents',
                'requires_expiry_date' => true,
                'requires_verification' => true,
                'is_confidential' => true,
                'is_active' => true,
            ],
        ];

        foreach ($categories as $category) {
            DocumentCategory::firstOrCreate(
                ['code' => $category['code']],
                $category
            );
        }

        $this->command->info('Document categories seeded successfully!');
    }
}
