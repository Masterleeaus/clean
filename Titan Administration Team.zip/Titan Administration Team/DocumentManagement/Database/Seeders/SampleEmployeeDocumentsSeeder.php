<?php

namespace Modules\DocumentManagement\Database\Seeders;

use App\Models\User;
use Carbon\Carbon;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\File;
use Illuminate\Support\Facades\Storage;
use Modules\DocumentManagement\App\Models\DocumentCategory;
use Modules\DocumentManagement\App\Models\EmployeeDocument;

class SampleEmployeeDocumentsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        // Make sure we have some document categories
        if (DocumentCategory::count() === 0) {
            $this->command->info('No document categories found. Running DocumentCategoriesSeeder first...');
            $this->call(DocumentCategoriesSeeder::class);
        }

        // Get document categories
        $passportCategory = DocumentCategory::where('code', 'PASS')->first();
        $visaCategory = DocumentCategory::where('code', 'VISA')->first();
        $contractCategory = DocumentCategory::where('code', 'EMPCNT')->first();
        $idCategory = DocumentCategory::where('code', 'NATID')->first();
        $licenseCategory = DocumentCategory::where('code', 'DRVLIC')->first();
        $educationCategory = DocumentCategory::where('code', 'EDUCRT')->first();

        // Get some users (limit to 5 for demo)
        $users = User::take(5)->get();

        if ($users->isEmpty()) {
            $this->command->error('No users found. Please seed users first.');

            return;
        }

        // Ensure sample files directory exists
        $sampleFilesDir = storage_path('app/public/sample-documents');
        if (! File::exists($sampleFilesDir)) {
            File::makeDirectory($sampleFilesDir, 0755, true);

            // Create sample files
            $this->createSampleFiles($sampleFilesDir);
        }

        // Copy sample files to the storage directory
        $publicStoragePath = 'employee-documents';
        if (! Storage::disk('public')->exists($publicStoragePath)) {
            Storage::disk('public')->makeDirectory($publicStoragePath);
        }

        // Copy sample files to employee-documents directory if they don't exist
        $files = File::files($sampleFilesDir);
        foreach ($files as $file) {
            $filename = basename($file);
            $destination = "$publicStoragePath/$filename";

            if (! Storage::disk('public')->exists($destination)) {
                Storage::disk('public')->put($destination, File::get($file));
            }
        }

        // Array to track verification status distribution
        $verificationStatuses = ['pending', 'verified', 'rejected'];

        // Current date for calculating realistic dates
        $now = Carbon::now();

        // Demo documents for users
        $documentCounter = 0;
        foreach ($users as $index => $user) {
            $userDocuments = [];

            // Sample passport with predictable expiry dates for testing
            if ($passportCategory) {
                // Create different expiry scenarios for each user
                switch ($index % 5) {
                    case 0:
                        // Expiring in 3 days (critical)
                        $expiryDate = $now->copy()->addDays(3);
                        break;
                    case 1:
                        // Expiring in 10 days (warning)
                        $expiryDate = $now->copy()->addDays(10);
                        break;
                    case 2:
                        // Expiring in 25 days (info)
                        $expiryDate = $now->copy()->addDays(25);
                        break;
                    case 3:
                        // Expired 5 days ago
                        $expiryDate = $now->copy()->subDays(5);
                        break;
                    case 4:
                        // Valid for long time
                        $expiryDate = $now->copy()->addYears(2);
                        break;
                }

                $issuedDate = $expiryDate->copy()->subYears(10);

                $userDocuments[] = [
                    'user_id' => $user->id,
                    'document_category_id' => $passportCategory->id,
                    'document_title' => $user->name.'\'s Passport',
                    'document_number' => 'P'.strtoupper(substr(md5($user->name), 0, 8)),
                    'file_path' => 'employee-documents/sample-passport.jpg',
                    'mime_type' => 'image/jpeg',
                    'issue_date' => $issuedDate->format('Y-m-d'),
                    'expiry_date' => $expiryDate->format('Y-m-d'),
                    'issuing_authority' => 'Department of Immigration',
                    'issuing_country' => 'United States',
                    'issuing_place' => 'Washington DC',
                    'verification_status' => $verificationStatuses[$index % 3],
                    'verification_notes' => $verificationStatuses[$index % 3] === 'rejected' ? 'Document appears to be expired or invalid.' : null,
                    'verified_by' => $verificationStatuses[$index % 3] !== 'pending' ? 1 : null,
                    'verified_at' => $verificationStatuses[$index % 3] !== 'pending' ? $now->subDays(rand(1, 30)) : null,
                    'is_active' => true,
                    'notes' => 'Passport details checked and verified with immigration department.',
                ];
            }

            // Sample work visa with specific expiry conditions for testing
            if ($visaCategory) {
                // Create different expiry scenarios for each user
                switch ($index % 5) {
                    case 0:
                        // Expiring in 6 days (critical warning)
                        $expiryDate = $now->copy()->addDays(6);
                        break;
                    case 1:
                        // Expiring in 15 days (warning)
                        $expiryDate = $now->copy()->addDays(15);
                        break;
                    case 2:
                        // Expiring in 28 days (info)
                        $expiryDate = $now->copy()->addDays(28);
                        break;
                    case 3:
                        // Expired 20 days ago
                        $expiryDate = $now->copy()->subDays(20);
                        break;
                    case 4:
                        // Valid for 6 months
                        $expiryDate = $now->copy()->addMonths(6);
                        break;
                }

                $issuedDate = $expiryDate->copy()->subYears(2);

                $userDocuments[] = [
                    'user_id' => $user->id,
                    'document_category_id' => $visaCategory->id,
                    'document_title' => 'Work Visa',
                    'document_number' => 'WV'.rand(100000, 999999),
                    'file_path' => 'employee-documents/sample-visa.jpg',
                    'mime_type' => 'image/jpeg',
                    'issue_date' => $issuedDate->format('Y-m-d'),
                    'expiry_date' => $expiryDate->format('Y-m-d'),
                    'issuing_authority' => 'Immigration Services',
                    'issuing_country' => 'United States',
                    'issuing_place' => 'US Embassy',
                    'verification_status' => $verificationStatuses[($index + 1) % 3],
                    'verification_notes' => null,
                    'verified_by' => $verificationStatuses[($index + 1) % 3] !== 'pending' ? 1 : null,
                    'verified_at' => $verificationStatuses[($index + 1) % 3] !== 'pending' ? $now->subDays(rand(1, 30)) : null,
                    'is_active' => true,
                    'notes' => null,
                ];
            }

            // Employment contract
            if ($contractCategory) {
                $userDocuments[] = [
                    'user_id' => $user->id,
                    'document_category_id' => $contractCategory->id,
                    'document_title' => 'Employment Contract',
                    'document_number' => 'EC'.date('Y').'-'.$user->id,
                    'file_path' => 'employee-documents/sample-contract.pdf',
                    'mime_type' => 'application/pdf',
                    'issue_date' => $now->copy()->subMonths(rand(1, 24))->format('Y-m-d'),
                    'expiry_date' => null,
                    'issuing_authority' => 'HR Department',
                    'issuing_country' => 'United States',
                    'issuing_place' => 'Head Office',
                    'verification_status' => 'verified',
                    'verification_notes' => 'Contract approved by legal department',
                    'verified_by' => 1,
                    'verified_at' => $now->subDays(rand(1, 60)),
                    'is_active' => true,
                    'notes' => 'Standard employment contract with addendum for remote work policy.',
                ];
            }

            // Driver's License with specific expiry dates
            if ($licenseCategory) {
                // Create different expiry scenarios for each user
                switch ($index % 5) {
                    case 0:
                        // Expiring in 1 day (critical)
                        $expiryDate = $now->copy()->addDays(1);
                        break;
                    case 1:
                        // Expiring in 8 days (warning)
                        $expiryDate = $now->copy()->addDays(8);
                        break;
                    case 2:
                        // Expiring in 45 days
                        $expiryDate = $now->copy()->addDays(45);
                        break;
                    case 3:
                        // Expired 10 days ago
                        $expiryDate = $now->copy()->subDays(10);
                        break;
                    case 4:
                        // Valid for 1 year
                        $expiryDate = $now->copy()->addYear();
                        break;
                }

                $issuedDate = $expiryDate->copy()->subYears(5);

                $userDocuments[] = [
                    'user_id' => $user->id,
                    'document_category_id' => $licenseCategory->id,
                    'document_title' => 'Driver\'s License',
                    'document_number' => 'DL'.rand(10000000, 99999999),
                    'file_path' => 'employee-documents/sample-license.jpg',
                    'mime_type' => 'image/jpeg',
                    'issue_date' => $issuedDate->format('Y-m-d'),
                    'expiry_date' => $expiryDate->format('Y-m-d'),
                    'issuing_authority' => 'Department of Motor Vehicles',
                    'issuing_country' => 'United States',
                    'issuing_place' => 'State DMV Office',
                    'verification_status' => 'verified',
                    'verification_notes' => null,
                    'verified_by' => 1,
                    'verified_at' => $now->subDays(rand(1, 60)),
                    'is_active' => true,
                    'notes' => null,
                ];
            }

            // National ID card
            if ($idCategory) {
                $expiryDate = $now->copy()->addYears(rand(3, 8));
                $issuedDate = $expiryDate->copy()->subYears(10);

                $userDocuments[] = [
                    'user_id' => $user->id,
                    'document_category_id' => $idCategory->id,
                    'document_title' => 'National ID Card',
                    'document_number' => rand(1000000000, 9999999999),
                    'file_path' => 'employee-documents/sample-id.jpg',
                    'mime_type' => 'image/jpeg',
                    'issue_date' => $issuedDate->format('Y-m-d'),
                    'expiry_date' => $expiryDate->format('Y-m-d'),
                    'issuing_authority' => 'Department of Homeland Security',
                    'issuing_country' => 'United States',
                    'issuing_place' => 'Local Office',
                    'verification_status' => 'verified',
                    'verification_notes' => null,
                    'verified_by' => 1,
                    'verified_at' => $now->subDays(rand(1, 90)),
                    'is_active' => true,
                    'notes' => null,
                ];
            }

            // Add documents for the user
            foreach ($userDocuments as $document) {
                EmployeeDocument::firstOrCreate(
                    [
                        'user_id' => $document['user_id'],
                        'document_category_id' => $document['document_category_id'],
                        'document_number' => $document['document_number'],
                    ],
                    $document
                );
                $documentCounter++;
            }
        }

        $this->command->info("Successfully seeded $documentCounter sample employee documents for ".$users->count().' users.');
        $this->command->info('Sample documents include various expiry scenarios:');
        $this->command->info('  - Documents expiring in 1, 3, 6, 8, 10, 15, 25, 28, 45 days');
        $this->command->info('  - Expired documents (5, 10, 20 days ago)');
        $this->command->info('  - Valid documents with long expiry dates (6 months - 2 years)');
        $this->command->info('This helps test the "Days Left" calculations and color coding in the dashboard.');
    }

    /**
     * Create sample document files for demo purposes
     */
    private function createSampleFiles($directory)
    {
        // Sample passport
        $passportContent = "SAMPLE PASSPORT - FOR DEMO PURPOSES ONLY\n\nThis is a demo file and not a real passport.";
        File::put("$directory/sample-passport.jpg", $passportContent);

        // Sample visa
        $visaContent = "SAMPLE VISA - FOR DEMO PURPOSES ONLY\n\nThis is a demo file and not a real visa.";
        File::put("$directory/sample-visa.jpg", $visaContent);

        // Sample contract (simple PDF simulation)
        $contractContent = "%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n3 0 obj<</Type/Page/MediaBox[0 0 612 792]/Parent 2 0 R/Resources<<>>>>endobj\nxref\n0 4\n0000000000 65535 f\n0000000009 00000 n\n0000000052 00000 n\n0000000101 00000 n\ntrailer<</Size 4/Root 1 0 R>>\nstartxref\n178\n%%EOF";
        File::put("$directory/sample-contract.pdf", $contractContent);

        // Sample ID
        $idContent = "SAMPLE ID - FOR DEMO PURPOSES ONLY\n\nThis is a demo file and not a real ID.";
        File::put("$directory/sample-id.jpg", $idContent);

        // Sample license
        $licenseContent = "SAMPLE DRIVER'S LICENSE - FOR DEMO PURPOSES ONLY\n\nThis is a demo file and not a real driver's license.";
        File::put("$directory/sample-license.jpg", $licenseContent);

        // Sample education certificate
        $certificateContent = "SAMPLE CERTIFICATE - FOR DEMO PURPOSES ONLY\n\nThis is a demo file and not a real educational certificate.";
        File::put("$directory/sample-certificate.jpg", $certificateContent);
    }
}
