<?php

namespace Modules\DocumentManagement\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Spatie\Permission\Models\Permission;
use Spatie\Permission\Models\Role;

class DocumentManagementPermissionsSeeder extends Seeder
{
    /**
     * Document Management module permissions organized by category
     */
    protected $permissions = [];

    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Reset cached roles and permissions
        app()[\Spatie\Permission\PermissionRegistrar::class]->forgetCachedPermissions();

        // Start transaction
        DB::beginTransaction();

        try {
            // Define all Document Management permissions
            $this->definePermissions();

            // Create/update permissions
            $this->createPermissions();

            // Update existing roles with Document Management permissions
            $this->updateRolePermissions();

            DB::commit();
            $this->command->info('Document Management permissions seeded successfully!');
        } catch (\Exception $e) {
            DB::rollBack();
            $this->command->error('Error seeding Document Management permissions: '.$e->getMessage());
        }
    }

    /**
     * Define all Document Management permissions by category
     */
    protected function definePermissions(): void
    {
        $this->permissions = [
            // Document Categories Management
            'Document Categories' => [
                ['name' => 'documentmanagement.view-document-categories', 'description' => 'View document categories'],
                ['name' => 'documentmanagement.create-document-categories', 'description' => 'Create document categories'],
                ['name' => 'documentmanagement.edit-document-categories', 'description' => 'Edit document categories'],
                ['name' => 'documentmanagement.delete-document-categories', 'description' => 'Delete document categories'],
            ],

            // Document Types Management
            'Document Types' => [
                ['name' => 'documentmanagement.view-document-types', 'description' => 'View document types'],
                ['name' => 'documentmanagement.create-document-types', 'description' => 'Create document types'],
                ['name' => 'documentmanagement.edit-document-types', 'description' => 'Edit document types'],
                ['name' => 'documentmanagement.delete-document-types', 'description' => 'Delete document types'],
                ['name' => 'documentmanagement.manage-document-type-status', 'description' => 'Manage document type status'],
            ],

            // Employee Documents Management
            'Employee Documents' => [
                // View permissions
                ['name' => 'documentmanagement.view-employee-documents', 'description' => 'View all employee documents'],
                ['name' => 'documentmanagement.view-own-documents', 'description' => 'View own documents'],
                ['name' => 'documentmanagement.view-team-documents', 'description' => 'View team member documents'],
                ['name' => 'documentmanagement.view-confidential-documents', 'description' => 'View confidential documents'],

                // Create/Edit permissions
                ['name' => 'documentmanagement.create-employee-documents', 'description' => 'Create employee documents'],
                ['name' => 'documentmanagement.edit-employee-documents', 'description' => 'Edit employee documents'],
                ['name' => 'documentmanagement.edit-own-documents', 'description' => 'Edit own documents'],
                ['name' => 'documentmanagement.delete-employee-documents', 'description' => 'Delete employee documents'],

                // Document operations
                ['name' => 'documentmanagement.upload-documents', 'description' => 'Upload documents'],
                ['name' => 'documentmanagement.download-documents', 'description' => 'Download documents'],
                ['name' => 'documentmanagement.download-confidential-documents', 'description' => 'Download confidential documents'],
                ['name' => 'documentmanagement.verify-documents', 'description' => 'Verify employee documents'],
                ['name' => 'documentmanagement.reject-documents', 'description' => 'Reject employee documents'],

                // Document lifecycle
                ['name' => 'documentmanagement.manage-document-expiry', 'description' => 'Manage document expiry dates'],
                ['name' => 'documentmanagement.view-expiring-documents', 'description' => 'View expiring documents'],
            ],

            // Document Requests
            'Document Requests' => [
                ['name' => 'documentmanagement.view-document-requests', 'description' => 'View all document requests'],
                ['name' => 'documentmanagement.view-own-document-requests', 'description' => 'View own document requests'],
                ['name' => 'documentmanagement.create-document-requests', 'description' => 'Create document requests'],
                ['name' => 'documentmanagement.edit-document-requests', 'description' => 'Edit document requests'],
                ['name' => 'documentmanagement.delete-document-requests', 'description' => 'Delete document requests'],
                ['name' => 'documentmanagement.approve-document-requests', 'description' => 'Approve document requests'],
                ['name' => 'documentmanagement.reject-document-requests', 'description' => 'Reject document requests'],
                ['name' => 'documentmanagement.update-request-status', 'description' => 'Update document request status'],
            ],

            // Document Reports & Dashboard
            'Document Reports' => [
                ['name' => 'documentmanagement.view-document-dashboard', 'description' => 'View document management dashboard'],
                ['name' => 'documentmanagement.view-document-reports', 'description' => 'View document reports'],
                ['name' => 'documentmanagement.export-document-data', 'description' => 'Export document data'],
                ['name' => 'documentmanagement.generate-document-reports', 'description' => 'Generate document reports'],
            ],

            // Document Settings
            'Document Settings' => [
                ['name' => 'documentmanagement.manage-document-settings', 'description' => 'Manage document module settings'],
                ['name' => 'documentmanagement.manage-access-permissions', 'description' => 'Manage document access permissions'],
            ],
        ];
    }

    /**
     * Create all permissions in the database
     */
    protected function createPermissions(): void
    {
        $sortOrder = 2000; // Start from 2000 for Document Management module

        foreach ($this->permissions as $category => $categoryPermissions) {
            foreach ($categoryPermissions as $permission) {
                Permission::updateOrCreate(
                    [
                        'name' => $permission['name'],
                        'guard_name' => 'web',
                    ],
                    [
                        'module' => 'DocumentManagement',
                        'description' => $permission['description'].' ('.$category.')',
                        'sort_order' => $sortOrder++,
                    ]
                );

                $this->command->info("Created/Updated permission: {$permission['name']} (DocumentManagement - {$category})");
            }
        }
    }

    /**
     * Update existing roles with appropriate Document Management permissions
     */
    protected function updateRolePermissions(): void
    {
        // HR Manager - Full document management access
        $this->updateHRManagerPermissions();

        // HR Executive - Limited document access
        $this->updateHRExecutivePermissions();

        // Team Leader - Team document access
        $this->updateTeamLeaderPermissions();

        // Employee - Basic access to own documents
        $this->updateEmployeePermissions();

        // Field Employee - Mobile document access
        $this->updateFieldEmployeePermissions();

        // Admin roles
        $this->updateAdminPermissions();
    }

    protected function updateHRManagerPermissions(): void
    {
        $role = Role::where('name', 'hr_manager')->first();
        if (! $role) {
            return;
        }

        $permissions = [
            // Full access to all document management features
            'documentmanagement.view-document-categories',
            'documentmanagement.create-document-categories',
            'documentmanagement.edit-document-categories',
            'documentmanagement.delete-document-categories',

            'documentmanagement.view-document-types',
            'documentmanagement.create-document-types',
            'documentmanagement.edit-document-types',
            'documentmanagement.delete-document-types',
            'documentmanagement.manage-document-type-status',

            'documentmanagement.view-employee-documents',
            'documentmanagement.create-employee-documents',
            'documentmanagement.edit-employee-documents',
            'documentmanagement.delete-employee-documents',
            'documentmanagement.upload-documents',
            'documentmanagement.download-documents',
            'documentmanagement.download-confidential-documents',
            'documentmanagement.verify-documents',
            'documentmanagement.reject-documents',
            'documentmanagement.manage-document-expiry',
            'documentmanagement.view-expiring-documents',
            'documentmanagement.view-confidential-documents',

            'documentmanagement.view-document-requests',
            'documentmanagement.create-document-requests',
            'documentmanagement.edit-document-requests',
            'documentmanagement.delete-document-requests',
            'documentmanagement.approve-document-requests',
            'documentmanagement.reject-document-requests',
            'documentmanagement.update-request-status',

            'documentmanagement.view-document-dashboard',
            'documentmanagement.view-document-reports',
            'documentmanagement.export-document-data',
            'documentmanagement.generate-document-reports',

            'documentmanagement.manage-document-settings',
            'documentmanagement.manage-access-permissions',
        ];

        // Add existing non-Document Management permissions
        $existingPermissions = $role->permissions()
            ->whereNotIn('module', ['DocumentManagement'])
            ->pluck('name')
            ->toArray();

        $role->syncPermissions(array_merge($permissions, $existingPermissions));
        $this->command->info('Updated HR Manager role with Document Management permissions');
    }

    protected function updateHRExecutivePermissions(): void
    {
        $role = Role::where('name', 'hr_executive')->first();
        if (! $role) {
            return;
        }

        $permissions = [
            // Limited document management access
            'documentmanagement.view-document-categories',
            'documentmanagement.view-document-types',

            'documentmanagement.view-employee-documents',
            'documentmanagement.create-employee-documents',
            'documentmanagement.edit-employee-documents',
            'documentmanagement.upload-documents',
            'documentmanagement.download-documents',
            'documentmanagement.verify-documents',
            'documentmanagement.view-expiring-documents',

            'documentmanagement.view-document-requests',
            'documentmanagement.create-document-requests',
            'documentmanagement.edit-document-requests',

            'documentmanagement.view-document-dashboard',
            'documentmanagement.view-document-reports',
        ];

        // Add existing non-Document Management permissions
        $existingPermissions = $role->permissions()
            ->whereNotIn('module', ['DocumentManagement'])
            ->pluck('name')
            ->toArray();

        $role->syncPermissions(array_merge($permissions, $existingPermissions));
        $this->command->info('Updated HR Executive role with limited Document Management permissions');
    }

    protected function updateTeamLeaderPermissions(): void
    {
        $role = Role::where('name', 'team_leader')->first();
        if (! $role) {
            return;
        }

        $permissions = [
            // Team document management
            'documentmanagement.view-team-documents',
            'documentmanagement.view-document-categories',
            'documentmanagement.view-document-types',
            'documentmanagement.download-documents',

            // Own document access
            'documentmanagement.view-own-documents',
            'documentmanagement.edit-own-documents',
            'documentmanagement.view-own-document-requests',
            'documentmanagement.create-document-requests',
        ];

        // Add existing non-Document Management permissions
        $existingPermissions = $role->permissions()
            ->whereNotIn('module', ['DocumentManagement'])
            ->pluck('name')
            ->toArray();

        $role->syncPermissions(array_merge($permissions, $existingPermissions));
        $this->command->info('Updated Team Leader role with team document permissions');
    }

    protected function updateEmployeePermissions(): void
    {
        $role = Role::where('name', 'employee')->first();
        if (! $role) {
            return;
        }

        $permissions = [
            // Basic employee document permissions
            'documentmanagement.view-own-documents',
            'documentmanagement.edit-own-documents',
            'documentmanagement.upload-documents',
            'documentmanagement.download-documents',
            'documentmanagement.view-document-categories',
            'documentmanagement.view-document-types',
            'documentmanagement.view-own-document-requests',
            'documentmanagement.create-document-requests',
        ];

        // Add existing non-Document Management permissions
        $existingPermissions = $role->permissions()
            ->whereNotIn('module', ['DocumentManagement'])
            ->pluck('name')
            ->toArray();

        $role->syncPermissions(array_merge($permissions, $existingPermissions));
        $this->command->info('Updated Employee role with basic document permissions');
    }

    protected function updateFieldEmployeePermissions(): void
    {
        $role = Role::where('name', 'field_employee')->first();
        if (! $role) {
            return;
        }

        $permissions = [
            // Field employee document permissions (mobile-friendly)
            'documentmanagement.view-own-documents',
            'documentmanagement.upload-documents',
            'documentmanagement.download-documents',
            'documentmanagement.view-document-categories',
            'documentmanagement.view-own-document-requests',
            'documentmanagement.create-document-requests',
        ];

        // Add existing non-Document Management permissions
        $existingPermissions = $role->permissions()
            ->whereNotIn('module', ['DocumentManagement'])
            ->pluck('name')
            ->toArray();

        $role->syncPermissions(array_merge($permissions, $existingPermissions));
        $this->command->info('Updated Field Employee role with mobile document permissions');
    }

    protected function updateAdminPermissions(): void
    {
        // Super Admin gets all permissions
        $superAdmin = Role::where('name', 'super_admin')->first();
        if ($superAdmin) {
            $superAdmin->syncPermissions(Permission::all());
            $this->command->info('Updated Super Admin role with all permissions');
        }

        // Admin gets all Document Management permissions
        $admin = Role::where('name', 'admin')->first();
        if ($admin) {
            $docPermissions = Permission::where('module', 'DocumentManagement')->pluck('name')->toArray();
            $existingPermissions = $admin->permissions()
                ->whereNotIn('module', ['DocumentManagement'])
                ->pluck('name')
                ->toArray();

            $admin->syncPermissions(array_merge($docPermissions, $existingPermissions));
            $this->command->info('Updated Admin role with all Document Management permissions');
        }
    }
}
