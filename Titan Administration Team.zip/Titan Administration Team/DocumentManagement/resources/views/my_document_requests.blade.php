@php
use App\Config\Constants;
    $breadcrumbs = [
        ['name' => __('Self Service'), 'url' => route('hrcore.my.profile')],
    ];
@endphp

@extends('layouts.layoutMaster')

@section('title', __('My Document Requests'))

@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/select2/select2.scss'
  ])
@endsection

@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
    'resources/assets/vendor/libs/select2/select2.js'
  ])
@endsection

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <x-breadcrumb
        :title="__('My Document Requests')"
        :breadcrumbs="$breadcrumbs"
        :homeUrl="route('dashboard')"
    />

    <!-- Info Alert -->
    <div class="alert alert-info d-flex align-items-center" role="alert">
        <i class="bx bx-info-circle fs-4 me-2"></i>
        <div>
            {{ __('Track your document requests here. You can request official documents like employment certificates, salary letters, etc. from the HR department.') }}
        </div>
    </div>

    <!-- Filter Card -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-4">
                    <label for="filter_document_type" class="form-label">{{ __('Document Type') }}</label>
                    <select id="filter_document_type" class="select2 form-select">
                        <option value="">{{ __('All Document Types') }}</option>
                        @foreach($documentTypes as $type)
                            <option value="{{ $type->id }}">{{ $type->name }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-4">
                    <label for="filter_status" class="form-label">{{ __('Status') }}</label>
                    <select id="filter_status" class="form-select">
                        <option value="">{{ __('All Statuses') }}</option>
                        <option value="pending">{{ __('Pending') }}</option>
                        <option value="approved">{{ __('Approved') }}</option>
                        <option value="rejected">{{ __('Rejected') }}</option>
                        <option value="generated">{{ __('Generated') }}</option>
                        <option value="cancelled">{{ __('Cancelled') }}</option>
                    </select>
                </div>

                <div class="col-md-4 d-flex align-items-end">
                    <button type="button" id="btn_reset_filters" class="btn btn-outline-secondary w-100">
                        <i class="bx bx-reset me-1"></i>{{ __('Reset Filters') }}
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Document Requests Table Card -->
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0">{{ __('My Document Requests') }}</h5>
            <a href="{{ route('documentmanagement.document-requests.create', ['source' => 'ess']) }}" class="btn btn-primary btn-sm">
                <i class="bx bx-plus me-1"></i>{{ __('New Request') }}
            </a>
        </div>

        <div class="card-datatable table-responsive">
            <table class="datatables-requests table border-top" id="requestsTable">
                <thead>
                    <tr>
                        <th>{{ __('Document Type') }}</th>
                        <th>{{ __('Requested Date') }}</th>
                        <th>{{ __('Status') }}</th>
                        <th>{{ __('Actions') }}</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>
@endsection

@section('page-script')
<script>
const pageData = {
    urls: {
        datatable: '{{ route("documentmanagement.document-requests.my-requests.datatable") }}',
        downloadDocument: '{{ url("storage/" . Constants::BaseFolderUserDocumentRequest) }}'
    },
    labels: {
        pending: @json(__('Pending')),
        approved: @json(__('Approved')),
        rejected: @json(__('Rejected')),
        generated: @json(__('Generated')),
        cancelled: @json(__('Cancelled')),
        downloadDocument: @json(__('Download Document')),
        viewDetails: @json(__('View Details')),
        selectOption: @json(__('Select an option')),
        searchPlaceholder: @json(__('Search requests...'))
    }
};
</script>
@vite(['Modules/DocumentManagement/resources/assets/js/my-document-requests.js'])
@endsection
