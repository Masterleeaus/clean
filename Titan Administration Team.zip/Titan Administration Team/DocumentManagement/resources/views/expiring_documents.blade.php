@php
    $breadcrumbs = [
        ['name' => __('Document Management'), 'url' => route('documentmanagement.dashboard')]
    ];
@endphp

@extends('layouts.layoutMaster')

@section('title', __('Expiring Documents'))

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <x-breadcrumb
        :title="__('Expiring Documents')"
        :breadcrumbs="$breadcrumbs"
        :homeUrl="route('dashboard')"
    />

    <!-- Filter Card -->
    <div class="card mb-4">
        <div class="card-body">
            <form action="{{ route('documentmanagement.expiring-documents') }}" method="GET" class="row g-3">
                <div class="col-md-4">
                    <label for="days" class="form-label">{{ __('Expiring Within (Days)') }}</label>
                    <select id="days" name="days" class="form-select">
                        <option value="7" {{ $days == 7 ? 'selected' : '' }}>{{ __('7 days') }}</option>
                        <option value="15" {{ $days == 15 ? 'selected' : '' }}>{{ __('15 days') }}</option>
                        <option value="30" {{ $days == 30 ? 'selected' : '' }}>{{ __('30 days') }}</option>
                        <option value="60" {{ $days == 60 ? 'selected' : '' }}>{{ __('60 days') }}</option>
                        <option value="90" {{ $days == 90 ? 'selected' : '' }}>{{ __('90 days') }}</option>
                    </select>
                </div>
                <div class="col-md-3 d-flex align-items-end">
                    <button type="submit" class="btn btn-primary">{{ __('Apply Filter') }}</button>
                </div>
            </form>
        </div>
    </div>

    <!-- Documents List -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">{{ __('Documents Expiring Within') }} {{ $days }} {{ __('Days') }}</h5>
            </div>
        </div>
        <div class="card-body">
            <div class="table-responsive text-nowrap">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th>{{ __('Document') }}</th>
                            <th>{{ __('Category') }}</th>
                            <th>{{ __('Employee') }}</th>
                            <th>{{ __('Issue Date') }}</th>
                            <th>{{ __('Expiry Date') }}</th>
                            <th>{{ __('Days Left') }}</th>
                            <th>{{ __('Actions') }}</th>
                        </tr>
                    </thead>
                    <tbody class="table-border-bottom-0">
                        @forelse($documents as $document)
                            <tr>
                                <td>
                                    <strong>{{ $document->document_title }}</strong>
                                    @if($document->document_number)
                                        <div class="small text-muted">{{ __('No.') }} {{ $document->document_number }}</div>
                                    @endif
                                </td>
                                <td>{{ $document->category->name }}</td>
                                <td>
                                    <x-datatable-user
                                        :user="$document->employee"
                                        :showCode="true"
                                        :linkRoute="'employees.show'"
                                    />
                                </td>
                                <td>{{ $document->issue_date ? $document->issue_date->format('d M Y') : 'N/A' }}</td>
                                <td>{{ $document->expiry_date->format('d M Y') }}</td>
                                <td>
                                    @php
                                        $daysLeft = (int) now()->diffInDays($document->expiry_date, false);
                                    @endphp
                                    <span class="badge bg-label-{{ $daysLeft < 7 ? 'danger' : ($daysLeft < 15 ? 'warning' : 'info') }}">
                                        {{ max(0, $daysLeft) }} {{ __('days') }}
                                    </span>
                                </td>
                                <td>
                                    <div class="dropdown">
                                        <button type="button" class="btn p-0 dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                            <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>
                                        <div class="dropdown-menu">
                                            <a class="dropdown-item" href="{{ route('documentmanagement.employee-documents.show', $document) }}">
                                                <i class="bx bx-show me-1"></i> {{ __('View') }}
                                            </a>
                                                <a class="dropdown-item" href="{{ route('documentmanagement.employee-documents.edit', $document) }}">
                                                    <i class="bx bx-edit-alt me-1"></i> {{ __('Edit') }}
                                                </a>
                                                <a class="dropdown-item" href="{{ route('documentmanagement.employee-documents.download', $document) }}">
                                                    <i class="bx bx-download me-1"></i> {{ __('Download') }}
                                                </a>
                                                @if($document->verification_status === 'pending')
                                                    <a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#verifyModal-{{ $document->id }}">
                                                        <i class="bx bx-check me-1"></i> {{ __('Verify') }}
                                                    </a>
                                                @endif
                                                <a class="dropdown-item text-danger" href="#" data-bs-toggle="modal" data-bs-target="#deleteModal-{{ $document->id }}">
                                                    <i class="bx bx-trash me-1"></i> {{ __('Delete') }}
                                                </a>
                                        </div>
                                    </div>
                                </td>
                            </tr>

                            <!-- Verification Modal -->
                                @if($document->verification_status === 'pending')
                                    <div class="modal fade" id="verifyModal-{{ $document->id }}" tabindex="-1" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <form action="{{ route('documentmanagement.employee-documents.verify', $document) }}" method="POST">
                                                    @csrf
                                                    <div class="modal-header">
                                                        <h5 class="modal-title">{{ __('Verify Document') }}</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row mb-3">
                                                            <label class="form-label">{{ __('Verification Status') }}</label>
                                                            <div class="col-sm-12">
                                                                <div class="form-check form-check-inline mt-3">
                                                                    <input class="form-check-input" type="radio" name="verification_status" id="verified-{{ $document->id }}" value="verified" checked>
                                                                    <label class="form-check-label" for="verified-{{ $document->id }}">{{ __('Verified') }}</label>
                                                                </div>
                                                                <div class="form-check form-check-inline">
                                                                    <input class="form-check-input" type="radio" name="verification_status" id="rejected-{{ $document->id }}" value="rejected">
                                                                    <label class="form-check-label" for="rejected-{{ $document->id }}">{{ __('Rejected') }}</label>
                                                                </div>
                                                            </div>
                                                        </div>
                                                        <div class="row">
                                                            <div class="col-sm-12 mb-3">
                                                                <label for="verification_notes" class="form-label">{{ __('Notes') }}</label>
                                                                <textarea id="verification_notes" name="verification_notes" class="form-control" rows="3"></textarea>
                                                            </div>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">{{ __('Cancel') }}</button>
                                                        <button type="submit" class="btn btn-primary">{{ __('Submit') }}</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                @endif

                            <!-- Delete Confirmation Modal -->
                                <div class="modal fade" id="deleteModal-{{ $document->id }}" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-dialog-centered" role="document">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h5 class="modal-title">{{ __('Delete Document') }}</h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <p>{{ __('Are you sure you want to delete this document?') }}</p>
                                                <p><strong>{{ $document->document_title }}</strong></p>
                                                <p class="mb-0 text-danger">{{ __('This action cannot be undone.') }}</p>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">{{ __('Cancel') }}</button>
                                                <form action="{{ route('documentmanagement.employee-documents.destroy', $document) }}" method="POST">
                                                    @csrf
                                                    @method('DELETE')
                                                    <button type="submit" class="btn btn-danger">{{ __('Delete') }}</button>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center">{{ __('No documents expiring within the specified time frame.') }}</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>

            <div class="mt-3 d-flex justify-content-center">
                {{ $documents->withQueryString()->links() }}
            </div>
        </div>
    </div>
</div>
@endsection
