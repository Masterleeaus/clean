@php
    $breadcrumbs = [
        ['name' => __('Document Management'), 'url' => route('documentmanagement.dashboard')],
        ['name' => __('Document Requests'), 'url' => route('documentmanagement.document-requests.index')]
    ];
@endphp

@extends('layouts.layoutMaster')

@section('title', __('Document Request Details'))

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <x-breadcrumb
        :title="__('Document Request Details')"
        :breadcrumbs="$breadcrumbs"
        :homeUrl="route('dashboard')"
    />

    <div class="row">
        <!-- Request Details Card -->
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="mb-0">{{ __('Request Information') }}</h5>
                    <div>
                        <a href="{{ route('documentmanagement.document-requests.index') }}" class="btn btn-outline-secondary btn-sm">
                            <i class="bx bx-arrow-back me-1"></i> {{ __('Back to List') }}
                        </a>
                    </div>
                </div>
                <div class="card-body">
                    <div class="row mb-4">
                        <div class="col-md-6">
                            <h6 class="fw-semibold">{{ __('Request Details') }}</h6>
                            <div class="mb-2">
                                <strong>{{ __('Request ID') }}:</strong>
                                <span>#{{ $documentRequest->id }}</span>
                            </div>
                            <div class="mb-2">
                                <strong>{{ __('Document Type') }}:</strong>
                                <span>{{ $documentRequest->documentType->name ?? 'N/A' }}</span>
                            </div>
                            <div class="mb-2">
                                <strong>{{ __('Requested On') }}:</strong>
                                <span>{{ $documentRequest->created_at->format('d M Y H:i A') }}</span>
                            </div>
                            <div class="mb-2">
                                <strong>{{ __('Status') }}:</strong>
                                @if($documentRequest->status == 'pending')
                                    <span class="badge bg-label-warning">{{ __('Pending') }}</span>
                                @elseif($documentRequest->status == 'approved')
                                    <span class="badge bg-label-success">{{ __('Approved') }}</span>
                                @elseif($documentRequest->status == 'generated')
                                    <span class="badge bg-label-primary">{{ __('Generated') }}</span>
                                @elseif($documentRequest->status == 'cancelled')
                                    <span class="badge bg-label-secondary">{{ __('Cancelled') }}</span>
                                @else
                                    <span class="badge bg-label-danger">{{ __('Rejected') }}</span>
                                @endif
                            </div>
                        </div>

                        <div class="col-md-6">
                            <h6 class="fw-semibold">{{ __('Employee Information') }}</h6>
                            <div class="mb-3">
                                <x-datatable-user :user="$documentRequest->user" :showCode="false" avatarSize="lg" />
                            </div>
                        </div>
                    </div>

                    @if($documentRequest->remarks)
                        <div class="row mb-4">
                            <div class="col-12">
                                <h6 class="fw-semibold">{{ __('Remarks') }}</h6>
                                <p class="mb-0">{{ $documentRequest->remarks }}</p>
                            </div>
                        </div>
                    @endif

                    <!-- Action History -->
                    @if($documentRequest->status !== 'pending')
                        <div class="row mb-4">
                            <div class="col-12">
                                <h6 class="fw-semibold">{{ __('Action History') }}</h6>
                                <div class="mb-2">
                                    <strong>{{ __('Action Taken By') }}:</strong>
                                    <span>{{ $documentRequest->action_taken_by_id ? 'Admin' : __('N/A') }}</span>
                                </div>
                                <div class="mb-2">
                                    <strong>{{ __('Action Taken On') }}:</strong>
                                    <span>{{ $documentRequest->action_taken_at ? $documentRequest->action_taken_at->format('d M Y H:i A') : __('N/A') }}</span>
                                </div>
                            </div>
                        </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Actions Card -->
        <div class="col-md-4">
            @if($documentRequest->status == 'approved')
                <div class="card mb-4">
                    <h5 class="card-header">{{ __('Upload Document') }}</h5>
                    <div class="card-body">
                        <form action="{{ route('documentmanagement.document-requests.upload', $documentRequest->id) }}" method="POST" enctype="multipart/form-data">
                            @csrf

                            <div class="mb-3">
                                <label for="file" class="form-label">{{ __('Select File') }} <span class="text-danger">*</span></label>
                                <input type="file" id="file" name="file" class="form-control @error('file') is-invalid @enderror" required>
                                @error('file')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="text-muted">{{ __('Accepted formats: PDF, JPG, JPEG, PNG. Max size: 10MB') }}</small>
                            </div>

                            <button type="submit" class="btn btn-primary w-100">
                                <i class="bx bx-upload me-1"></i> {{ __('Upload Document') }}
                            </button>
                        </form>
                    </div>
                </div>
            @endif

            @if($documentRequest->status == 'generated')
                <div class="card mb-4">
                    <h5 class="card-header">{{ __('Generated Document') }}</h5>
                    <div class="card-body text-center">
                        <div class="mb-3">
                            <i class="bx bx-file bx-lg text-primary"></i>
                        </div>
                        <p class="mb-3">{{ __('Document has been generated and is ready for download.') }}</p>
                        <a href="{{ asset('storage/' . Constants::BaseFolderUserDocumentRequest . $documentRequest->generated_file) }}"
                           target="_blank"
                           class="btn btn-primary w-100">
                            <i class="bx bx-download me-1"></i> {{ __('Download Document') }}
                        </a>
                    </div>
                </div>
            @endif

            <!-- Status Actions -->
            @if($documentRequest->status == 'pending')
                <div class="card">
                    <h5 class="card-header">{{ __('Actions') }}</h5>
                    <div class="card-body">
                        <div class="d-grid gap-2">
                            <button type="button" class="btn btn-success w-100" onclick="updateStatus({{ $documentRequest->id }}, 'approve')">
                                <i class="bx bx-check me-1"></i> {{ __('Approve Request') }}
                            </button>

                            <button type="button" class="btn btn-danger w-100" onclick="updateStatus({{ $documentRequest->id }}, 'reject')">
                                <i class="bx bx-x me-1"></i> {{ __('Reject Request') }}
                            </button>
                        </div>
                    </div>
                </div>
            @endif
        </div>
    </div>
</div>
@endsection

@section('page-script')
<script>
// Page data for JavaScript
window.pageData = {
    urls: {
        updateStatus: function(id) { return '/document-management/document-requests/' + id + '/update-status'; }
    },
    labels: {
        confirmApprove: @json(__('Are you sure you want to approve this request?')),
        confirmReject: @json(__('Are you sure you want to reject this request?')),
        processing: @json(__('Processing...'))
    }
};
</script>
@vite(['Modules/DocumentManagement/resources/assets/js/document-request-show.js'])
@endsection
