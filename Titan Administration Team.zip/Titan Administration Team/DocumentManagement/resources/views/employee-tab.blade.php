<div class="row g-4">
    {{-- Document Statistics Cards --}}
    <div class="col-12">
        <div class="row g-3">
            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-start justify-content-between">
                            <div class="content-left">
                                <span class="text-heading">{{ __('Total Documents') }}</span>
                                <div class="d-flex align-items-center my-1">
                                    <h4 class="mb-0 me-2">{{ $stats['totalDocuments'] }}</h4>
                                </div>
                                <small class="mb-0">{{ __('Uploaded') }}</small>
                            </div>
                            <div class="avatar">
                                <span class="avatar-initial rounded bg-label-primary">
                                    <i class="bx bx-file bx-lg"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-start justify-content-between">
                            <div class="content-left">
                                <span class="text-heading">{{ __('Verified') }}</span>
                                <div class="d-flex align-items-center my-1">
                                    <h4 class="mb-0 me-2">{{ $stats['verifiedDocuments'] }}</h4>
                                </div>
                                <small class="mb-0">{{ __('Documents') }}</small>
                            </div>
                            <div class="avatar">
                                <span class="avatar-initial rounded bg-label-success">
                                    <i class="bx bx-check-circle bx-lg"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-start justify-content-between">
                            <div class="content-left">
                                <span class="text-heading">{{ __('Pending Verification') }}</span>
                                <div class="d-flex align-items-center my-1">
                                    <h4 class="mb-0 me-2">{{ $stats['pendingVerification'] }}</h4>
                                </div>
                                <small class="mb-0">{{ __('Documents') }}</small>
                            </div>
                            <div class="avatar">
                                <span class="avatar-initial rounded bg-label-warning">
                                    <i class="bx bx-time bx-lg"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-3 col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <div class="d-flex align-items-start justify-content-between">
                            <div class="content-left">
                                <span class="text-heading">{{ __('Expiring Soon') }}</span>
                                <div class="d-flex align-items-center my-1">
                                    <h4 class="mb-0 me-2">{{ $stats['expiringSoon'] }}</h4>
                                </div>
                                <small class="mb-0">{{ __('Within 30 days') }}</small>
                            </div>
                            <div class="avatar">
                                <span class="avatar-initial rounded bg-label-danger">
                                    <i class="bx bx-error-circle bx-lg"></i>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    {{-- Documents Table --}}
    <div class="col-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <h5 class="mb-0">{{ __('Employee Documents') }}</h5>
                <button type="button" class="btn btn-sm btn-primary" onclick="uploadDocument()">
                    <i class="bx bx-upload me-1"></i>{{ __('Upload Document') }}
                </button>
            </div>
            <div class="card-datatable table-responsive">
                <table class="datatables-documents table border-top" id="employeeDocumentsTable">
                    <thead>
                        <tr>
                            <th>{{ __('Document Type') }}</th>
                            <th>{{ __('Document Name') }}</th>
                            <th>{{ __('Issue Date') }}</th>
                            <th>{{ __('Expiry Date') }}</th>
                            <th>{{ __('Verified') }}</th>
                            <th>{{ __('Uploaded On') }}</th>
                            <th>{{ __('Actions') }}</th>
                        </tr>
                    </thead>
                    <tbody>
                        @forelse ($documents as $document)
                            <tr>
                                <td>{{ $document->documentType->name ?? __('N/A') }}</td>
                                <td>{{ $document->document_name ?? __('N/A') }}</td>
                                <td>{{ $document->issue_date ? \Carbon\Carbon::parse($document->issue_date)->format('d M Y') : __('N/A') }}</td>
                                <td>
                                    @if ($document->expiry_date)
                                        @php
                                            $expiryDate = \Carbon\Carbon::parse($document->expiry_date);
                                            $daysUntilExpiry = now()->diffInDays($expiryDate, false);
                                        @endphp
                                        {{ $expiryDate->format('d M Y') }}
                                        @if ($daysUntilExpiry > 0 && $daysUntilExpiry <= 30)
                                            <span class="badge bg-label-warning ms-1">{{ __('Expiring Soon') }}</span>
                                        @elseif ($daysUntilExpiry < 0)
                                            <span class="badge bg-label-danger ms-1">{{ __('Expired') }}</span>
                                        @endif
                                    @else
                                        <span class="text-muted">{{ __('No Expiry') }}</span>
                                    @endif
                                </td>
                                <td>
                                    @if ($document->is_verified)
                                        <span class="badge bg-label-success">{{ __('Verified') }}</span>
                                    @else
                                        <span class="badge bg-label-warning">{{ __('Pending') }}</span>
                                    @endif
                                </td>
                                <td>{{ $document->created_at ? $document->created_at->format('d M Y') : __('N/A') }}</td>
                                <td>
                                    <div class="dropdown">
                                        <button type="button" class="btn btn-sm btn-icon dropdown-toggle hide-arrow" data-bs-toggle="dropdown">
                                            <i class="bx bx-dots-vertical-rounded"></i>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li>
                                                <a class="dropdown-item" href="javascript:void(0);" onclick="viewDocument({{ $document->id }})">
                                                    <i class="bx bx-show me-1"></i>{{ __('View') }}
                                                </a>
                                            </li>
                                            <li>
                                                <a class="dropdown-item" href="javascript:void(0);" onclick="downloadDocument({{ $document->id }})">
                                                    <i class="bx bx-download me-1"></i>{{ __('Download') }}
                                                </a>
                                            </li>
                                        </ul>
                                    </div>
                                </td>
                            </tr>
                        @empty
                            <tr>
                                <td colspan="7" class="text-center">{{ __('No documents found') }}</td>
                            </tr>
                        @endforelse
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

{{-- Upload Document Modal --}}
<div class="modal fade" id="uploadDocumentModal" tabindex="-1" aria-labelledby="uploadDocumentModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="uploadDocumentModalLabel">{{ __('Upload Document') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="{{ __('Close') }}"></button>
            </div>
            <form id="uploadDocumentForm" enctype="multipart/form-data">
                @csrf
                <div class="modal-body">
                    <div class="row g-3">
                        <div class="col-md-6">
                            <label for="documentTypeSelect" class="form-label">{{ __('Document Type') }} <span class="text-danger">*</span></label>
                            <select class="form-select" id="documentTypeSelect" name="document_type_id" required>
                                <option value="">{{ __('Select Document Type') }}</option>
                                @foreach(\Modules\DocumentManagement\App\Models\DocumentType::orderBy('name')->get() as $type)
                                    <option value="{{ $type->id }}">{{ $type->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-6">
                            <label for="documentCategorySelect" class="form-label">{{ __('Category') }}</label>
                            <select class="form-select" id="documentCategorySelect" name="document_category_id">
                                <option value="">{{ __('Select Category') }}</option>
                                @foreach(\Modules\DocumentManagement\App\Models\DocumentCategory::where('is_active', true)->orderBy('name')->get() as $category)
                                    <option value="{{ $category->id }}">{{ $category->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="col-md-12">
                            <label for="documentTitle" class="form-label">{{ __('Document Title') }} <span class="text-danger">*</span></label>
                            <input type="text" class="form-control" id="documentTitle" name="document_title" required>
                        </div>

                        <div class="col-md-6">
                            <label for="documentNumber" class="form-label">{{ __('Document Number') }}</label>
                            <input type="text" class="form-control" id="documentNumber" name="document_number">
                        </div>

                        <div class="col-md-6">
                            <label for="documentFile" class="form-label">{{ __('Document File') }} <span class="text-danger">*</span></label>
                            <input type="file" class="form-control" id="documentFile" name="file" required accept=".pdf,.doc,.docx,.jpg,.jpeg,.png">
                            <small class="text-muted">{{ __('Max size: 10MB. Allowed: PDF, DOC, DOCX, JPG, PNG') }}</small>
                        </div>

                        <div class="col-md-6">
                            <label for="issueDate" class="form-label">{{ __('Issue Date') }}</label>
                            <input type="text" class="form-control" id="issueDate" name="issue_date" placeholder="YYYY-MM-DD">
                        </div>

                        <div class="col-md-6">
                            <label for="expiryDate" class="form-label">{{ __('Expiry Date') }}</label>
                            <input type="text" class="form-control" id="expiryDate" name="expiry_date" placeholder="YYYY-MM-DD">
                        </div>

                        <div class="col-md-12">
                            <label for="documentNotes" class="form-label">{{ __('Notes') }}</label>
                            <textarea class="form-control" id="documentNotes" name="notes" rows="3"></textarea>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">{{ __('Cancel') }}</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bx bx-upload me-1"></i>{{ __('Upload') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

@push('page-scripts')
<script>
    // Merge pageData for documents tab
    window.pageData = window.pageData || {};
    window.pageData.urls = window.pageData.urls || {};
    window.pageData.labels = window.pageData.labels || {};

    // Document-specific URLs
    window.pageData.urls.documentsTab = '{{ route('documents.employee.tab', $user->id) }}';
    window.pageData.urls.uploadDocument = '{{ route('documentmanagement.employee-documents.store') }}';
    window.pageData.urls.viewDocument = '{{ route('documentmanagement.employee-documents.show', ':id') }}';
    window.pageData.urls.downloadDocument = '{{ route('documentmanagement.employee-documents.download', ':id') }}';
    window.pageData.urls.verifyDocument = '{{ route('documentmanagement.employee-documents.verify', ':id') }}';
    window.pageData.urls.deleteDocument = '{{ route('documentmanagement.employee-documents.destroy', ':id') }}';

    // Document-specific labels
    window.pageData.labels = Object.assign(window.pageData.labels, {
        search: @json(__('Search')),
        lengthMenu: @json(__('Show _MENU_ entries')),
        info: @json(__('Showing _START_ to _END_ of _TOTAL_ entries')),
        infoEmpty: @json(__('No entries available')),
        infoFiltered: @json(__('(filtered from _MAX_ total entries)')),
        first: @json(__('First')),
        last: @json(__('Last')),
        next: @json(__('Next')),
        previous: @json(__('Previous')),
        emptyTable: @json(__('No documents available')),
        selectDocumentType: @json(__('Select Document Type')),
        selectCategory: @json(__('Select Category')),
        chooseFile: @json(__('Choose file')),
        uploading: @json(__('Uploading...')),
        documentUploaded: @json(__('Document uploaded successfully')),
        uploadFailed: @json(__('Failed to upload document')),
        fileTooLarge: @json(__('File size must not exceed 10MB')),
        documentDetails: @json(__('Document Details')),
        documentType: @json(__('Document Type')),
        documentTitle: @json(__('Title')),
        documentNumber: @json(__('Number')),
        issueDate: @json(__('Issue Date')),
        expiryDate: @json(__('Expiry Date')),
        verified: @json(__('Verified')),
        notes: @json(__('Notes')),
        yes: @json(__('Yes')),
        no: @json(__('No')),
        close: @json(__('Close')),
        verify: @json(__('Verify')),
        unverify: @json(__('Unverify')),
        areYouSure: @json(__('Are you sure?')),
        confirmAction: @json(__('Do you want to {action} this document?')),
        cancel: @json(__('Cancel')),
        verificationUpdated: @json(__('Verification status updated')),
        verificationFailed: @json(__('Failed to update verification')),
        delete: @json(__('Delete')),
        deleteDocumentWarning: @json(__('This document will be moved to trash. You can restore it later.')),
        deleted: @json(__('Deleted')),
        documentDeleted: @json(__('Document deleted successfully')),
        deleteFailed: @json(__('Failed to delete document'))
    });
</script>

@vite('Modules/DocumentManagement/resources/assets/js/employee-tab.js')
@endpush
