@php
    $breadcrumbs = [
        ['name' => __('Self Service'), 'url' => route('hrcore.my.profile')],
    ];
@endphp

@extends('layouts.layoutMaster')

@section('title', __('My Documents'))

@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/select2/select2.scss'
  ])
@endsection

@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
    'resources/assets/vendor/libs/select2/select2.js'
  ])
@endsection

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <x-breadcrumb
        :title="__('My Documents')"
        :breadcrumbs="$breadcrumbs"
        :homeUrl="route('dashboard')"
    />

    <!-- Info Alert -->
    <div class="alert alert-info d-flex align-items-center" role="alert">
        <i class="bx bx-info-circle fs-4 me-2"></i>
        <div>
            {{ __('This section contains all your personal documents like passport, ID cards, certificates, etc. You can upload or update these documents as requested by the admin.') }}
        </div>
    </div>

    <!-- Filter Card -->
    <div class="card mb-4">
        <div class="card-body">
            <div class="row g-3">
                <div class="col-md-3">
                    <label for="filter_category" class="form-label">{{ __('Category') }}</label>
                    <select id="filter_category" class="select2 form-select">
                        <option value="">{{ __('All Categories') }}</option>
                        @foreach($categories as $category)
                            <option value="{{ $category->id }}">{{ $category->name }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="filter_status" class="form-label">{{ __('Verification Status') }}</label>
                    <select id="filter_status" class="form-select">
                        <option value="">{{ __('All Statuses') }}</option>
                        <option value="pending">{{ __('Pending') }}</option>
                        <option value="verified">{{ __('Verified') }}</option>
                        <option value="rejected">{{ __('Rejected') }}</option>
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="filter_expiry" class="form-label">{{ __('Expiry Status') }}</label>
                    <select id="filter_expiry" class="form-select">
                        <option value="">{{ __('All Documents') }}</option>
                        <option value="expired">{{ __('Expired') }}</option>
                        <option value="expiring_soon">{{ __('Expiring Soon') }}</option>
                    </select>
                </div>

                <div class="col-md-3 d-flex align-items-end">
                    <button type="button" id="btn_reset_filters" class="btn btn-outline-secondary w-100">
                        <i class="bx bx-reset me-1"></i>{{ __('Reset Filters') }}
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Documents Table Card -->
    <div class="card">
        <div class="card-header">
            <h5 class="card-title mb-0">{{ __('My Documents') }}</h5>
        </div>

        <div class="card-datatable table-responsive">
            <table class="datatables-documents table border-top" id="documentsTable">
                <thead>
                    <tr>
                        <th>{{ __('Document') }}</th>
                        <th>{{ __('Category') }}</th>
                        <th>{{ __('Issue / Expiry') }}</th>
                        <th>{{ __('Status') }}</th>
                        <th>{{ __('Actions') }}</th>
                    </tr>
                </thead>
            </table>
        </div>
    </div>
</div>

<!-- Upload/Update Modal -->
<div class="modal fade" id="uploadModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">{{ __('Upload Document') }}</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form id="uploadForm" enctype="multipart/form-data">
                <div class="modal-body">
                    <input type="hidden" name="document_id" id="upload_document_id">
                    <input type="hidden" id="requires_expiry_date" value="false">

                    <div class="mb-3">
                        <label class="form-label fw-semibold">{{ __('Document') }}</label>
                        <p class="text-muted mb-0" id="upload_document_title"></p>
                    </div>

                    <div class="mb-3">
                        <label for="document_file" class="form-label">{{ __('Document File') }} <span class="text-danger">*</span></label>
                        <input type="file" class="form-control" id="document_file" name="document_file" accept=".pdf,.jpg,.jpeg,.png" required>
                        <small class="text-muted">{{ __('Accepted formats: PDF, JPG, JPEG, PNG. Max size: 10MB') }}</small>
                    </div>

                    <div class="mb-3">
                        <label for="document_number" class="form-label">{{ __('Document Number') }}</label>
                        <input type="text" class="form-control" id="document_number" name="document_number" placeholder="{{ __('e.g., Passport Number, ID Number') }}">
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label for="issue_date" class="form-label">{{ __('Issue Date') }}</label>
                            <input type="date" class="form-control" id="issue_date" name="issue_date">
                        </div>

                        <div class="col-md-6 mb-3">
                            <label for="expiry_date" class="form-label">{{ __('Expiry Date') }} <span id="expiry_required_indicator" class="text-danger d-none">*</span></label>
                            <input type="date" class="form-control" id="expiry_date" name="expiry_date">
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="issuing_authority" class="form-label">{{ __('Issuing Authority') }}</label>
                            <input type="text" class="form-control" id="issuing_authority" name="issuing_authority" placeholder="{{ __('e.g., Govt. of India') }}">
                        </div>

                        <div class="col-md-4 mb-3">
                            <label for="issuing_country" class="form-label">{{ __('Issuing Country') }}</label>
                            <input type="text" class="form-control" id="issuing_country" name="issuing_country" placeholder="{{ __('e.g., India') }}">
                        </div>

                        <div class="col-md-4 mb-3">
                            <label for="issuing_place" class="form-label">{{ __('Issuing Place') }}</label>
                            <input type="text" class="form-control" id="issuing_place" name="issuing_place" placeholder="{{ __('e.g., Mumbai') }}">
                        </div>
                    </div>

                    <div class="mb-3">
                        <label for="notes" class="form-label">{{ __('Notes') }}</label>
                        <textarea class="form-control" id="notes" name="notes" rows="2" placeholder="{{ __('Any additional information...') }}"></textarea>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">{{ __('Cancel') }}</button>
                    <button type="submit" class="btn btn-primary">
                        <i class="bx bx-upload me-1"></i>{{ __('Upload') }}
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>
@endsection

@section('page-script')
<script>
const pageData = {
    urls: {
        datatable: '{{ route("documentmanagement.my.documents.datatable") }}',
        download: '{{ route("documentmanagement.my.documents.download", ":id") }}',
        upload: '{{ route("documentmanagement.my.documents.upload") }}'
    },
    labels: {
        pending: @json(__('Pending')),
        verified: @json(__('Verified')),
        rejected: @json(__('Rejected')),
        expired: @json(__('Expired')),
        daysLeft: @json(__('days left')),
        download: @json(__('Download')),
        upload: @json(__('Upload')),
        update: @json(__('Update')),
        selectOption: @json(__('Select an option')),
        searchPlaceholder: @json(__('Search documents...')),
        success: @json(__('Success!')),
        uploadSuccess: @json(__('Document uploaded successfully')),
        error: @json(__('Error!')),
        errorOccurred: @json(__('An error occurred'))
    }
};
</script>
@vite(['Modules/DocumentManagement/resources/assets/js/my-documents.js'])
@endsection
