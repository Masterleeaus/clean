@php
    // Determine if this is an employee self-service request
    // Check for source=ess parameter, referer, or user role
    $referer = request()->headers->get('referer', '');
    $isEmployeeSelfService = request()->query('source') === 'ess' ||
                             str_contains($referer, '/my-requests') ||
                             str_contains($referer, '/my/documents') ||
                             (!auth()->user()->hasRole(['super_admin', 'admin', 'hr', 'hr_manager', 'hr_executive']));

    if ($isEmployeeSelfService) {
        // Employee Self Service breadcrumbs - show only title
        $breadcrumbs = [];
        $cancelRoute = route('documentmanagement.document-requests.my-requests');
    } else {
        // Admin breadcrumbs
        $breadcrumbs = [
            ['name' => __('Document Management'), 'url' => route('documentmanagement.dashboard')],
            ['name' => __('Document Requests'), 'url' => route('documentmanagement.document-requests.index')]
        ];
        $cancelRoute = route('documentmanagement.document-requests.index');
    }
@endphp

@extends('layouts.layoutMaster')

@section('title', __('Request Document'))

@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/select2/select2.scss'
  ])
@endsection

@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/select2/select2.js'
  ])
@endsection

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <x-breadcrumb
        :title="__('Request Document')"
        :breadcrumbs="$breadcrumbs"
        :homeUrl="route('dashboard')"
    />

    <div class="row">
        <div class="col-md-8">
            <div class="card mb-4">
                <div class="card-header">
                    <h5 class="card-title mb-0">{{ __('Request Document') }}</h5>
                    <p class="text-muted mb-0">{{ __('Submit a request for official documents from HR department') }}</p>
                </div>

                <div class="card-body">
                    <form id="documentRequestForm" action="{{ route('documentmanagement.document-requests.store', request()->query('source') ? ['source' => request()->query('source')] : []) }}" method="POST">
                        @csrf

                        <div class="row g-3">
                            <!-- Document Type -->
                            <div class="col-md-12">
                                <label for="document_type_id" class="form-label">{{ __('Document Type') }} <span class="text-danger">*</span></label>
                                <select id="document_type_id" name="document_type_id" class="select2 form-select @error('document_type_id') is-invalid @enderror" required>
                                    <option value="">{{ __('Select Document Type') }}</option>
                                    @foreach($documentTypes as $type)
                                        <option value="{{ $type->id }}" {{ old('document_type_id') == $type->id ? 'selected' : '' }}>
                                            {{ $type->name }}
                                        </option>
                                    @endforeach
                                </select>
                                @error('document_type_id')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="text-muted">{{ __('Select the type of document you need') }}</small>
                            </div>

                            <!-- Remarks -->
                            <div class="col-md-12">
                                <label for="remarks" class="form-label">{{ __('Remarks') }}</label>
                                <textarea id="remarks" name="remarks" class="form-control @error('remarks') is-invalid @enderror" rows="4" placeholder="{{ __('Provide any additional details or special instructions...') }}">{{ old('remarks') }}</textarea>
                                @error('remarks')
                                    <div class="invalid-feedback">{{ $message }}</div>
                                @enderror
                                <small class="text-muted">{{ __('Optional: Add any specific requirements or details') }}</small>
                            </div>

                            <div class="col-12 mt-4">
                                <button type="submit" class="btn btn-primary me-2">
                                    <i class="bx bx-send me-1"></i>{{ __('Submit Request') }}
                                </button>
                                <a href="{{ $cancelRoute }}" class="btn btn-outline-secondary">
                                    <i class="bx bx-x me-1"></i>{{ __('Cancel') }}
                                </a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <div class="col-md-4">
            <div class="card bg-label-info">
                <div class="card-body">
                    <h5 class="card-title">
                        <i class="bx bx-info-circle me-1"></i>{{ __('Important Information') }}
                    </h5>
                    <ul class="mb-0">
                        <li>{{ __('Document requests are typically processed within 2-3 business days') }}</li>
                        <li>{{ __('You will receive a notification once your request is approved') }}</li>
                        <li>{{ __('Generated documents can be downloaded from your request history') }}</li>
                        <li>{{ __('For urgent requests, please contact HR department directly') }}</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('page-script')
<script>
const pageData = {
    labels: {
        selectOption: @json(__('Select an option'))
    }
};
</script>
@vite(['Modules/DocumentManagement/resources/assets/js/document-request.js'])
@endsection
