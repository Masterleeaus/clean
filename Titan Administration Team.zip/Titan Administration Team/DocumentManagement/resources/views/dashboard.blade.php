@php
    $breadcrumbs = [
        ['name' => __('Document Management'), 'url' => '#']
    ];
@endphp

@extends('layouts.layoutMaster')

@section('title', __('Document Management Dashboard'))

@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/apex-charts/apex-charts.scss'
  ])
@endsection

@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/apex-charts/apexcharts.js'
  ])
@endsection

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <x-breadcrumb
        :title="__('Dashboard')"
        :breadcrumbs="$breadcrumbs"
        :homeUrl="route('dashboard')"
    />

    <!-- Stats Cards -->
    <div class="row">
        <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div class="card-info">
                            <p class="card-text">{{ __('Total Documents') }}</p>
                            <div class="d-flex align-items-end mb-2">
                                <h4 class="card-title mb-0 me-2">{{ $stats['total_documents'] }}</h4>
                            </div>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-primary rounded p-2">
                                <i class="bx bx-file bx-sm"></i>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div class="card-info">
                            <p class="card-text">{{ __('Pending Verification') }}</p>
                            <div class="d-flex align-items-end mb-2">
                                <h4 class="card-title mb-0 me-2">{{ $stats['pending_verification'] }}</h4>
                            </div>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-warning rounded p-2">
                                <i class="bx bx-time bx-sm"></i>
                            </span>
                        </div>
                    </div>
                    <a href="{{ route('documentmanagement.employee-documents.index', ['status' => 'pending']) }}" class="small text-muted">{{ __('View all') }}</a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div class="card-info">
                            <p class="card-text">{{ __('Expired Documents') }}</p>
                            <div class="d-flex align-items-end mb-2">
                                <h4 class="card-title mb-0 me-2">{{ $stats['expired'] }}</h4>
                            </div>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-danger rounded p-2">
                                <i class="bx bx-calendar-x bx-sm"></i>
                            </span>
                        </div>
                    </div>
                    <a href="{{ route('documentmanagement.employee-documents.index', ['expiry' => 'expired']) }}" class="small text-muted">{{ __('View all') }}</a>
                </div>
            </div>
        </div>

        <div class="col-lg-3 col-md-6 col-sm-6 mb-4">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <div class="card-info">
                            <p class="card-text">{{ __('Expiring Soon') }}</p>
                            <div class="d-flex align-items-end mb-2">
                                <h4 class="card-title mb-0 me-2">{{ $stats['expiring_soon'] }}</h4>
                            </div>
                        </div>
                        <div class="card-icon">
                            <span class="badge bg-label-info rounded p-2">
                                <i class="bx bx-calendar-exclamation bx-sm"></i>
                            </span>
                        </div>
                    </div>
                    <a href="{{ route('documentmanagement.expiring-documents') }}" class="small text-muted">{{ __('View all') }}</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Documents Expiring Soon & Recent Documents -->
    <div class="row">
        <!-- Expiring Documents -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">{{ __('Documents Expiring Soon') }}</h5>
                    <a href="{{ route('documentmanagement.expiring-documents') }}" class="btn btn-sm btn-primary">
                        {{ __('View All') }}
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive text-nowrap">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>{{ __('Document') }}</th>
                                    <th>{{ __('Employee') }}</th>
                                    <th>{{ __('Expiry Date') }}</th>
                                    <th>{{ __('Days Left') }}</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                @forelse($expiringDocuments as $document)
                                    <tr>
                                        <td>
                                            <a href="{{ route('documentmanagement.employee-documents.show', $document) }}">
                                                {{ $document->document_title }}
                                            </a>
                                            <div class="small text-muted">{{ $document->category->name }}</div>
                                        </td>
                                        <td>
                                            <x-datatable-user
                                                :user="$document->user"
                                                :showCode="true"
                                                :linkRoute="'employees.show'"
                                            />
                                        </td>
                                        <td>{{ $document->expiry_date->format('d M Y') }}</td>
                                        <td>
                                            @php
                                                $daysLeft = (int) now()->diffInDays($document->expiry_date, false);
                                            @endphp
                                            <span class="badge bg-label-{{ $daysLeft < 7 ? 'danger' : 'warning' }}">
                                                {{ max(0, $daysLeft) }} {{ __('days') }}
                                            </span>
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="4" class="text-center">{{ __('No documents expiring soon') }}</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        <!-- Recent Documents -->
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">{{ __('Recently Added Documents') }}</h5>
                    <a href="{{ route('documentmanagement.employee-documents.index') }}" class="btn btn-sm btn-primary">
                        {{ __('View All') }}
                    </a>
                </div>
                <div class="card-body">
                    <div class="table-responsive text-nowrap">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>{{ __('Document') }}</th>
                                    <th>{{ __('Employee') }}</th>
                                    <th>{{ __('Added On') }}</th>
                                    <th>{{ __('Status') }}</th>
                                </tr>
                            </thead>
                            <tbody class="table-border-bottom-0">
                                @forelse($recentDocuments as $document)
                                    <tr>
                                        <td>
                                            <a href="{{ route('documentmanagement.employee-documents.show', $document) }}">
                                                {{ $document->document_title }}
                                            </a>
                                            <div class="small text-muted">{{ $document->category->name }}</div>
                                        </td>
                                        <td>
                                            <x-datatable-user
                                                :user="$document->user"
                                                :showCode="true"
                                                :linkRoute="'employees.show'"
                                            />
                                        </td>
                                        <td>{{ $document->created_at->format('d M Y') }}</td>
                                        <td>
                                            @if($document->verification_status === 'verified')
                                                <span class="badge bg-label-success">{{ __('Verified') }}</span>
                                            @elseif($document->verification_status === 'rejected')
                                                <span class="badge bg-label-danger">{{ __('Rejected') }}</span>
                                            @else
                                                <span class="badge bg-label-warning">{{ __('Pending') }}</span>
                                            @endif
                                        </td>
                                    </tr>
                                @empty
                                    <tr>
                                        <td colspan="4" class="text-center">{{ __('No recent documents') }}</td>
                                    </tr>
                                @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Documents by Category Chart -->
    <div class="row">
        <div class="col-12 mb-4">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">{{ __('Documents by Category') }}</h5>
                </div>
                <div class="card-body">
                    <div id="documentsByCategoryChart" style="height: 300px;"></div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection

@section('page-script')
<script>
// Dashboard data for JavaScript
window.documentsDashboardData = {
    categoryNames: @json($documentsByCategory->pluck('name')),
    categoryCounts: @json($documentsByCategory->pluck('employee_documents_count')),
    noDataLabel: @json(__('No data available'))
};
</script>
@vite(['Modules/DocumentManagement/resources/assets/js/dashboard.js'])
@endsection
