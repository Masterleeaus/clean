@php
    $breadcrumbs = [
        ['name' => __('Document Management'), 'url' => route('documentmanagement.dashboard')]
    ];
@endphp

@extends('layouts.layoutMaster')

@section('title', __('Document Requests'))

@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/select2/select2.scss'
  ])
@endsection

@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
    'resources/assets/vendor/libs/select2/select2.js'
  ])
@endsection

@section('content')
<div class="container-xxl flex-grow-1 container-p-y">
    <x-breadcrumb
        :title="__('Document Requests')"
        :breadcrumbs="$breadcrumbs"
        :homeUrl="route('dashboard')"
    />

    <!-- Filter Card -->
    <div class="card mb-4">
        <div class="card-body">
            <form class="row g-3">
                <div class="col-md-3">
                    <label for="employeeFilter" class="form-label">{{ __('Employee') }}</label>
                    <select id="employeeFilter" name="employeeFilter" class="select2 form-select" data-placeholder="{{ __('All Employees') }}">
                        <option value="">{{ __('All Employees') }}</option>
                        @foreach($employees as $employee)
                            <option value="{{ $employee->id }}">{{ $employee->first_name }} {{ $employee->last_name }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-3">
                    <label for="dateFilter" class="form-label">{{ __('Request Date') }}</label>
                    <input type="date" id="dateFilter" name="dateFilter" class="form-control">
                </div>

                <div class="col-md-3">
                    <label for="documentTypeFilter" class="form-label">{{ __('Document Type') }}</label>
                    <select id="documentTypeFilter" name="documentTypeFilter" class="select2 form-select" data-placeholder="{{ __('All Document Types') }}">
                        <option value="">{{ __('All Document Types') }}</option>
                        @foreach($documentTypes as $documentType)
                            <option value="{{ $documentType->id }}">{{ $documentType->name }}</option>
                        @endforeach
                    </select>
                </div>

                <div class="col-md-3 d-flex align-items-end">
                    <button type="button" class="btn btn-outline-secondary" id="resetFilters">
                        <i class="bx bx-reset me-1"></i> {{ __('Reset') }}
                    </button>
                </div>
            </form>
        </div>
    </div>

    <!-- Document Requests List -->
    <div class="card">
        <div class="card-header">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="card-title mb-0">{{ __('All Document Requests') }}</h5>
            </div>
        </div>
        <div class="card-datatable table-responsive">
            <table class="table table-bordered" id="documentRequestsTable">
                <thead>
                    <tr>
                        <th>{{ __('Sl.No') }}</th>
                        <th>{{ __('User') }}</th>
                        <th>{{ __('Document Type') }}</th>
                        <th>{{ __('Remarks') }}</th>
                        <th>{{ __('Status') }}</th>
                        <th>{{ __('Requested On') }}</th>
                        <th>{{ __('Actions') }}</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach($documentRequests as $item)
                        <tr data-employee="{{ $item->user_id }}" data-date="{{ $item->created_at->format('Y-m-d') }}" data-type="{{ $item->document_type_id }}">
                            <td>{{ $loop->iteration }}</td>
                            <td>
                                <x-datatable-user :user="$item->user" :showCode="false" />
                            </td>
                            <td>{{ $item->documentType->name ?? 'N/A' }}</td>
                            <td>{{ $item->remarks }}</td>
                            <td>
                                @if($item->status == 'pending')
                                    <span class="badge bg-label-warning">{{ __('Pending') }}</span>
                                @elseif($item->status == 'approved')
                                    <span class="badge bg-label-success">{{ __('Approved') }}</span>
                                @elseif($item->status == 'generated')
                                    <span class="badge bg-label-primary">{{ __('Generated') }}</span>
                                @elseif($item->status == 'cancelled')
                                    <span class="badge bg-label-secondary">{{ __('Cancelled') }}</span>
                                @else
                                    <span class="badge bg-label-danger">{{ __('Rejected') }}</span>
                                @endif
                            </td>
                            <td>{{ $item->created_at->format('d M Y H:i') }}</td>
                            <td>
                                <a href="{{ route('documentmanagement.document-requests.show', $item->id) }}" class="btn btn-sm btn-icon btn-text-secondary rounded-pill" title="{{ __('View Details') }}">
                                    <i class="bx bx-show"></i>
                                </a>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
</div>
@endsection

@section('page-script')
<script>
// Page data for JavaScript
window.pageData = {
    labels: {
        search: @json(__('Search:')),
        lengthMenu: @json(__('Show _MENU_ entries')),
        info: @json(__('Showing _START_ to _END_ of _TOTAL_ entries')),
        infoEmpty: @json(__('Showing 0 to 0 of 0 entries')),
        infoFiltered: @json(__('(filtered from _MAX_ total entries)')),
        loadingRecords: @json(__('Loading...')),
        zeroRecords: @json(__('No matching records found')),
        emptyTable: @json(__('No data available in table')),
        first: @json(__('First')),
        previous: @json(__('Previous')),
        next: @json(__('Next')),
        last: @json(__('Last'))
    }
};
</script>
@vite(['Modules/DocumentManagement/resources/assets/js/document-requests.js'])
@endsection
