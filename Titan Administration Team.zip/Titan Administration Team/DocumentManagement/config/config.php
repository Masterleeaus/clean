<?php

return [
    'name' => 'DocumentManagement',
];
