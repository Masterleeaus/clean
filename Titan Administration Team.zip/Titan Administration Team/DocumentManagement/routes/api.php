<?php

use Illuminate\Support\Facades\Route;
use Modules\DocumentManagement\App\Http\Controllers\Api\DocumentCategoryApiController;
use Modules\DocumentManagement\App\Http\Controllers\Api\DocumentRequestApiController;
use Modules\DocumentManagement\App\Http\Controllers\Api\DocumentTypeApiController;
use Modules\DocumentManagement\App\Http\Controllers\Api\EmployeeDocumentApiController;

/*
    |--------------------------------------------------------------------------
    | API Routes
    |--------------------------------------------------------------------------
    |
    | Here is where you can register API routes for your application. These
    | routes are loaded by the RouteServiceProvider within a group which
    | is assigned the "api" middleware group. Enjoy building your API!
    |
*/
Route::middleware([
    'api',
])->group(function () {
    Route::group(['prefix' => 'V1'], function () {
        Route::group([
            'middleware' => 'api',
            'as' => 'api.',
        ], function () {
            Route::middleware('auth:api')->group(function () {
                // Document Request Routes (Employee features only)
                Route::prefix('document-requests')->name('document-requests.')->group(function () {
                    Route::get('/', [DocumentRequestApiController::class, 'index'])->name('index'); // My requests
                    Route::get('/statistics', [DocumentRequestApiController::class, 'statistics'])->name('statistics'); // My statistics
                    Route::get('/document-types', [DocumentRequestApiController::class, 'documentTypes'])->name('document-types'); // Available types
                    Route::post('/', [DocumentRequestApiController::class, 'store'])->name('store'); // Request document
                    Route::get('/{id}', [DocumentRequestApiController::class, 'show'])->name('show'); // View my request
                    Route::post('/{id}/cancel', [DocumentRequestApiController::class, 'cancelRequest'])->name('cancel'); // Cancel my request
                    Route::get('/{id}/download', [DocumentRequestApiController::class, 'download'])->name('download'); // Download generated document
                });

                // Document Categories (Read-only for employees)
                Route::prefix('document-categories')->name('document-categories.')->group(function () {
                    Route::get('/active', [DocumentCategoryApiController::class, 'active'])->name('active'); // Active categories only
                });

                // Document Types (Read-only for employees)
                Route::prefix('document-types')->name('document-types.')->group(function () {
                    Route::get('/active', [DocumentTypeApiController::class, 'active'])->name('active'); // Active types only
                });

                // Employee Documents (My documents only)
                Route::prefix('my-documents')->name('my-documents.')->group(function () {
                    Route::get('/', [EmployeeDocumentApiController::class, 'myDocuments'])->name('index'); // My documents
                    Route::get('/statistics', [EmployeeDocumentApiController::class, 'myStatistics'])->name('statistics'); // My statistics
                    Route::get('/categories', [EmployeeDocumentApiController::class, 'categories'])->name('categories'); // Available categories
                    Route::get('/expiring', [EmployeeDocumentApiController::class, 'myExpiring'])->name('expiring'); // My expiring documents
                    Route::get('/expired', [EmployeeDocumentApiController::class, 'myExpired'])->name('expired'); // My expired documents
                    Route::get('/{id}', [EmployeeDocumentApiController::class, 'showMyDocument'])->name('show'); // View my document
                    Route::get('/{id}/download', [EmployeeDocumentApiController::class, 'downloadMyDocument'])->name('download'); // Download my document
                });
            });
        });
    });
});
