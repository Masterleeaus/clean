<?php

use Illuminate\Support\Facades\Route;
use Modules\DocumentManagement\App\Http\Controllers\DocumentCategoryController;
use Modules\DocumentManagement\App\Http\Controllers\DocumentRequestController;
use Modules\DocumentManagement\App\Http\Controllers\DocumentTypeController;
use Modules\DocumentManagement\App\Http\Controllers\EmployeeDocumentController;
use Modules\DocumentManagement\App\Http\Controllers\EmployeeTabController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Employee Tab
Route::middleware(['web', 'auth'])
    ->get('documents/employee/{user}/tab', [EmployeeTabController::class, 'show'])
    ->name('documents.employee.tab');

Route::prefix('document-management')->name('documentmanagement.')->middleware(['auth', 'web'])->group(function () {

    // Dashboard routes
    Route::get('/', [EmployeeDocumentController::class, 'dashboard'])->name('dashboard');
    Route::get('/expiring-documents', [EmployeeDocumentController::class, 'expiringDocuments'])
        ->name('expiring-documents');

    // Document Requests Routes
    Route::prefix('document-requests')->name('document-requests.')->group(function () {
        Route::get('/', [DocumentRequestController::class, 'index'])->name('index');
        Route::get('/datatable', [DocumentRequestController::class, 'indexAjax'])->name('datatable');
        Route::get('/create', [DocumentRequestController::class, 'create'])->name('create');
        Route::post('/', [DocumentRequestController::class, 'store'])->name('store');

        // My Document Requests (Self Service) - MUST be before {id} routes
        Route::get('/my-requests', [DocumentRequestController::class, 'myRequests'])->name('my-requests');
        Route::get('/my-requests/datatable', [DocumentRequestController::class, 'myRequestsAjax'])->name('my-requests.datatable');

        // Wildcard routes - MUST be after specific routes
        Route::get('/{id}', [DocumentRequestController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [DocumentRequestController::class, 'edit'])->name('edit');
        Route::put('/{id}', [DocumentRequestController::class, 'update'])->name('update');
        Route::delete('/{id}', [DocumentRequestController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/update-status', [DocumentRequestController::class, 'updateStatus'])->name('update-status');
        Route::post('/{id}/upload', [DocumentRequestController::class, 'upload'])->name('upload');
    });

    // Document Types Routes
    Route::prefix('document-types')->name('document-types.')->group(function () {
        Route::get('/', [DocumentTypeController::class, 'index'])->name('index');
        Route::get('/datatable', [DocumentTypeController::class, 'indexAjax'])->name('datatable');
        Route::get('/create', [DocumentTypeController::class, 'create'])->name('create');
        Route::post('/', [DocumentTypeController::class, 'store'])->name('store');
        Route::get('/{id}', [DocumentTypeController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [DocumentTypeController::class, 'edit'])->name('edit');
        Route::put('/{id}', [DocumentTypeController::class, 'update'])->name('update');
        Route::delete('/{id}', [DocumentTypeController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/change-status', [DocumentTypeController::class, 'changeStatus'])->name('change-status');
    });

    // Document Categories Routes
    Route::prefix('document-categories')->name('document-categories.')->group(function () {
        Route::get('/', [DocumentCategoryController::class, 'index'])->name('index');
        Route::get('/datatable', [DocumentCategoryController::class, 'indexAjax'])->name('datatable');
        Route::get('/create', [DocumentCategoryController::class, 'create'])->name('create');
        Route::post('/', [DocumentCategoryController::class, 'store'])->name('store');
        Route::get('/{documentCategory}', [DocumentCategoryController::class, 'show'])->name('show');
        Route::get('/{documentCategory}/edit', [DocumentCategoryController::class, 'edit'])->name('edit');
        Route::put('/{documentCategory}', [DocumentCategoryController::class, 'update'])->name('update');
        Route::delete('/{documentCategory}', [DocumentCategoryController::class, 'destroy'])->name('destroy');
    });

    // Employee Documents Routes
    Route::prefix('employee-documents')->name('employee-documents.')->group(function () {
        Route::get('/', [EmployeeDocumentController::class, 'index'])->name('index');
        Route::get('/datatable', [EmployeeDocumentController::class, 'indexAjax'])->name('datatable');
        Route::get('/create', [EmployeeDocumentController::class, 'create'])->name('create');
        Route::post('/', [EmployeeDocumentController::class, 'store'])->name('store');
        Route::get('/{employeeDocument}', [EmployeeDocumentController::class, 'show'])->name('show');
        Route::get('/{employeeDocument}/edit', [EmployeeDocumentController::class, 'edit'])->name('edit');
        Route::put('/{employeeDocument}', [EmployeeDocumentController::class, 'update'])->name('update');
        Route::delete('/{employeeDocument}', [EmployeeDocumentController::class, 'destroy'])->name('destroy');
        Route::get('/{employeeDocument}/download', [EmployeeDocumentController::class, 'download'])->name('download');
        Route::post('/{employeeDocument}/verify', [EmployeeDocumentController::class, 'verify'])->name('verify');
    });

    // My Documents Routes (Self Service)
    Route::prefix('my')->name('my.')->group(function () {
        Route::get('/documents', [EmployeeDocumentController::class, 'myDocuments'])->name('documents');
        Route::get('/documents/datatable', [EmployeeDocumentController::class, 'myDocumentsAjax'])->name('documents.datatable');
        Route::post('/documents/upload', [EmployeeDocumentController::class, 'myDocumentsUpload'])->name('documents.upload');
        Route::get('/documents/{employeeDocument}/download', [EmployeeDocumentController::class, 'myDocumentDownload'])->name('documents.download');
    });
});
