<?php

namespace Modules\DocumentManagement\App\Policies;

use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Modules\DocumentManagement\App\Models\EmployeeDocument;

class EmployeeDocumentPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any employee documents.
     */
    public function viewAny(User $user): bool
    {
        return $user->hasPermissionTo('documentmanagement.view-employee-documents');
    }

    /**
     * Determine whether the user can view the employee document.
     */
    public function view(User $user, EmployeeDocument $employeeDocument): bool
    {
        // If user has general permission to view all documents
        if ($user->hasPermissionTo('view employee documents')) {
            return true;
        }

        // If user is viewing their own document
        if ($employeeDocument->employee && $employeeDocument->employee->user_id === $user->id) {
            return true;
        }

        // If user has access to this document category
        if ($user->hasPermissionTo('documentmanagement.view-confidential-documents') &&
            $employeeDocument->category &&
            $employeeDocument->category->is_confidential) {
            return true;
        }

        return false;
    }

    /**
     * Determine whether the user can create employee documents.
     */
    public function create(User $user): bool
    {
        return $user->hasPermissionTo('documentmanagement.create-employee-documents');
    }

    /**
     * Determine whether the user can update the employee document.
     */
    public function update(User $user, EmployeeDocument $employeeDocument): bool
    {
        // Super admin or has general update permission
        if ($user->hasPermissionTo('documentmanagement.edit-employee-documents')) {
            return true;
        }

        // HR managers can update documents
        if ($user->hasRole('hr_manager')) {
            return true;
        }

        // User can update their own documents if they have this permission
        if ($user->hasPermissionTo('documentmanagement.edit-own-documents') &&
            $employeeDocument->employee &&
            $employeeDocument->employee->user_id === $user->id) {
            return true;
        }

        return false;
    }

    /**
     * Determine whether the user can delete the employee document.
     */
    public function delete(User $user, EmployeeDocument $employeeDocument): bool
    {
        return $user->hasPermissionTo('documentmanagement.delete-employee-documents');
    }

    /**
     * Determine whether the user can verify the employee document.
     */
    public function verify(User $user, EmployeeDocument $employeeDocument): bool
    {
        return $user->hasPermissionTo('documentmanagement.verify-documents');
    }

    /**
     * Determine whether the user can download the employee document.
     */
    public function download(User $user, EmployeeDocument $employeeDocument): bool
    {
        // If user has general permission to download documents
        if ($user->hasPermissionTo('documentmanagement.download-documents')) {
            return true;
        }

        // If user is downloading their own document
        if ($employeeDocument->employee && $employeeDocument->employee->user_id === $user->id) {
            return true;
        }

        // For confidential documents, require specific permission
        if ($employeeDocument->category && $employeeDocument->category->is_confidential) {
            return $user->hasPermissionTo('documentmanagement.download-confidential-documents');
        }

        return false;
    }
}
