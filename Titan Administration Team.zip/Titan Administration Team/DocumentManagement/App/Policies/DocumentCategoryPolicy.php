<?php

namespace Modules\DocumentManagement\App\Policies;

use App\Models\User;
use Illuminate\Auth\Access\HandlesAuthorization;
use Modules\DocumentManagement\App\Models\DocumentCategory;

class DocumentCategoryPolicy
{
    use HandlesAuthorization;

    /**
     * Determine whether the user can view any document categories.
     */
    public function viewAny(User $user): bool
    {
        return $user->hasPermissionTo('documentmanagement.view-document-categories');
    }

    /**
     * Determine whether the user can view the document category.
     */
    public function view(User $user, DocumentCategory $category): bool
    {
        return $user->hasPermissionTo('documentmanagement.view-document-categories');
    }

    /**
     * Determine whether the user can create document categories.
     */
    public function create(User $user): bool
    {
        return $user->hasPermissionTo('documentmanagement.create-document-categories');
    }

    /**
     * Determine whether the user can update the document category.
     */
    public function update(User $user, DocumentCategory $category): bool
    {
        return $user->hasPermissionTo('documentmanagement.edit-document-categories');
    }

    /**
     * Determine whether the user can delete the document category.
     */
    public function delete(User $user, DocumentCategory $category): bool
    {
        return $user->hasPermissionTo('documentmanagement.delete-document-categories');
    }
}
