<?php

namespace Modules\DocumentManagement\App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Modules\DocumentManagement\App\Models\DocumentType;

class DocumentTypeExport implements FromCollection, WithHeadings
{
    /**
     * Export data as a collection.
     *
     * @return Collection
     */
    public function collection()
    {
        return DocumentType::select(
            'id',
            'name',
            'code',
            'notes',
            'is_required',
            'status',
            'created_at',
            'updated_at'
        )->get();
    }

    /**
     * Define column headings.
     */
    public function headings(): array
    {
        return [
            'ID',
            'Name',
            'Code',
            'Notes',
            'Is Required',
            'Status',
            'Created At',
            'Updated At',
        ];
    }
}
