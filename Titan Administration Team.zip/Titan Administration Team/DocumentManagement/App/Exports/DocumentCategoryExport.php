<?php

namespace Modules\DocumentManagement\App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Modules\DocumentManagement\App\Models\DocumentCategory;

class DocumentCategoryExport implements FromCollection, WithHeadings
{
    /**
     * Export data as a collection.
     *
     * @return Collection
     */
    public function collection()
    {
        return DocumentCategory::select(
            'id',
            'name',
            'code',
            'description',
            'requires_expiry_date',
            'requires_verification',
            'is_confidential',
            'is_active',
            'created_at',
            'updated_at'
        )->get();
    }

    /**
     * Define column headings.
     */
    public function headings(): array
    {
        return [
            'ID',
            'Name',
            'Code',
            'Description',
            'Requires Expiry Date',
            'Requires Verification',
            'Is Confidential',
            'Is Active',
            'Created At',
            'Updated At',
        ];
    }
}
