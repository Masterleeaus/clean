<?php

namespace Modules\DocumentManagement\App\Imports;

use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Modules\DocumentManagement\App\Models\DocumentCategory;

class DocumentCategoryImport implements ToModel, WithHeadingRow
{
    /**
     * Create a new DocumentCategory instance for each row.
     *
     * @return DocumentCategory|null
     */
    public function model(array $row)
    {
        return new DocumentCategory([
            'name' => $row['name'],
            'code' => $row['code'],
            'description' => $row['description'] ?? null,
            'requires_expiry_date' => $row['requires_expiry_date'] ?? false,
            'requires_verification' => $row['requires_verification'] ?? false,
            'is_confidential' => $row['is_confidential'] ?? false,
            'is_active' => $row['is_active'] ?? true,
        ]);
    }
}
