<?php

namespace Modules\DocumentManagement\App\Imports;

use Illuminate\Support\Facades\Auth;
use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Modules\DocumentManagement\App\Models\DocumentType;

class DocumentTypeImport implements ToModel, WithHeadingRow
{
    /**
     * Create a new DocumentType instance for each row.
     *
     * @return DocumentType|null
     */
    public function model(array $row)
    {
        return new DocumentType([
            'name' => $row['name'],
            'code' => $row['code'],
            'notes' => $row['notes'] ?? null,
            'is_required' => $row['is_required'] ?? false,
            'status' => $row['status'] ?? 'active',
            'created_by_id' => Auth::id(),
            'updated_by_id' => Auth::id(),
        ]);
    }
}
