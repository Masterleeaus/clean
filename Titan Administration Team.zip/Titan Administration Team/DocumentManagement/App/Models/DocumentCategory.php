<?php

namespace Modules\DocumentManagement\App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class DocumentCategory extends Model
{
    protected $fillable = [
        'name',
        'code',
        'description',
        'requires_expiry_date',
        'requires_verification',
        'is_confidential',
        'is_active',
    ];

    protected $casts = [
        'requires_expiry_date' => 'boolean',
        'requires_verification' => 'boolean',
        'is_confidential' => 'boolean',
        'is_active' => 'boolean',
    ];

    /**
     * Get the employee documents for this category.
     */
    public function employeeDocuments(): HasMany
    {
        return $this->hasMany(EmployeeDocument::class);
    }
}
