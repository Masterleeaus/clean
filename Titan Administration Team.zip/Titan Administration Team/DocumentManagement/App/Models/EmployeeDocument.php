<?php

namespace Modules\DocumentManagement\App\Models;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class EmployeeDocument extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'user_id',
        'document_category_id',
        'document_number',
        'document_title',
        'file_path',
        'mime_type',
        'issue_date',
        'expiry_date',
        'issuing_authority',
        'issuing_country',
        'issuing_place',
        'verification_status',
        'verification_notes',
        'verified_by',
        'verified_at',
        'is_active',
        'notes',
    ];

    protected $casts = [
        'issue_date' => 'date',
        'expiry_date' => 'date',
        'verified_at' => 'datetime',
        'is_active' => 'boolean',
    ];

    /**
     * Get the employee that owns the document.
     */
    public function employee(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Alias for employee relationship (for consistency).
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    /**
     * Get the category of this document.
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(DocumentCategory::class, 'document_category_id');
    }

    /**
     * Alias for category relationship (for consistency with views expecting documentType).
     */
    public function documentType(): BelongsTo
    {
        return $this->belongsTo(DocumentCategory::class, 'document_category_id');
    }

    /**
     * Get the user who verified this document.
     */
    public function verifier(): BelongsTo
    {
        return $this->belongsTo(User::class, 'verified_by');
    }

    /**
     * Check if the document is expired.
     */
    public function isExpired(): bool
    {
        return $this->expiry_date && $this->expiry_date->isPast();
    }

    /**
     * Check if the document is about to expire.
     */
    public function isAboutToExpire(int $days = 30): bool
    {
        return $this->expiry_date &&
               ! $this->expiry_date->isPast() &&
               $this->expiry_date->diffInDays(now()) <= $days;
    }

    /**
     * Scope a query to only include documents that are expired.
     */
    public function scopeExpired($query)
    {
        return $query->whereNotNull('expiry_date')
            ->whereDate('expiry_date', '<', now());
    }

    /**
     * Scope a query to only include documents that are about to expire.
     */
    public function scopeAboutToExpire($query, int $days = 30)
    {
        $futureDate = now()->addDays($days);

        return $query->whereNotNull('expiry_date')
            ->whereDate('expiry_date', '>', now())
            ->whereDate('expiry_date', '<=', $futureDate);
    }

    /**
     * Scope a query to only include documents with a specific verification status.
     */
    public function scopeByVerificationStatus($query, string $status)
    {
        return $query->where('verification_status', $status);
    }
}
