<?php

namespace Modules\DocumentManagement\App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class DocumentAccessPermission extends Model
{
    protected $fillable = [
        'document_category_id',
        'role_id',
        'user_id',
        'can_view',
        'can_download',
        'can_verify',
    ];

    protected $casts = [
        'can_view' => 'boolean',
        'can_download' => 'boolean',
        'can_verify' => 'boolean',
    ];

    /**
     * Get the document category associated with the permission.
     */
    public function documentCategory(): BelongsTo
    {
        return $this->belongsTo(DocumentCategory::class);
    }

    /**
     * Get the user associated with the permission.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(\App\Models\User::class);
    }
}
