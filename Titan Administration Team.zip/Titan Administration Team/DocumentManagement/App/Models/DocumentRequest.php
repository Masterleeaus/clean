<?php

namespace Modules\DocumentManagement\App\Models;

use App\Models\User;
use App\Traits\UserActionsTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class DocumentRequest extends Model
{
    use SoftDeletes, UserActionsTrait;

    protected $table = 'document_requests';

    protected $fillable = [
        'remarks',
        'document_type_id',
        'user_id',
        'status',
        'admin_remarks',
        'generated_file',
        'action_taken_by_id',
        'action_taken_at',
        'created_by_id',
        'updated_by_id',
        'tenant_id',
    ];

    protected $casts = [
        'action_taken_at' => 'datetime',
    ];

    public function documentType(): BelongsTo
    {
        return $this->belongsTo(DocumentType::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the action taker user.
     */
    public function actionTakenBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'action_taken_by_id');
    }
}
