<?php

namespace Modules\DocumentManagement\App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Modules\DocumentManagement\App\Models\EmployeeDocument;

class DocumentVerificationNotification extends Notification implements ShouldQueue
{
    use Queueable;

    protected $document;

    protected $status;

    protected $notes;

    /**
     * Create a new notification instance.
     */
    public function __construct(EmployeeDocument $document, string $status, ?string $notes = null)
    {
        $this->document = $document;
        $this->status = $status;
        $this->notes = $notes;
    }

    /**
     * Get the notification's delivery channels.
     */
    public function via($notifiable): array
    {
        return ['mail', 'database'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail($notifiable): MailMessage
    {
        $employee = $this->document->employee;
        $documentType = $this->document->category->name;
        $statusText = ucfirst($this->status);

        $mail = (new MailMessage)
            ->subject("Document {$statusText}: {$documentType}")
            ->line("Your {$documentType} document has been {$this->status}.")
            ->line("Document: {$this->document->document_title}")
            ->line("Document Number: {$this->document->document_number}")
            ->action('View Document', url("/documentmanagement/employee-documents/{$this->document->id}"));

        if ($this->notes) {
            $mail->line("Notes: {$this->notes}");
        }

        return $mail;
    }

    /**
     * Get the array representation of the notification.
     */
    public function toArray($notifiable): array
    {
        return [
            'document_id' => $this->document->id,
            'document_type' => $this->document->category->name,
            'document_title' => $this->document->document_title,
            'status' => $this->status,
            'notes' => $this->notes,
        ];
    }
}
