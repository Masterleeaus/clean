<?php

namespace Modules\DocumentManagement\App\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;
use Modules\DocumentManagement\App\Models\EmployeeDocument;

class DocumentExpiryNotification extends Notification implements ShouldQueue
{
    use Queueable;

    protected $document;

    protected $daysRemaining;

    /**
     * Create a new notification instance.
     */
    public function __construct(EmployeeDocument $document, int $daysRemaining)
    {
        $this->document = $document;
        $this->daysRemaining = $daysRemaining;
    }

    /**
     * Get the notification's delivery channels.
     */
    public function via($notifiable): array
    {
        return ['mail', 'database'];
    }

    /**
     * Get the mail representation of the notification.
     */
    public function toMail($notifiable): MailMessage
    {
        $employee = $this->document->employee;
        $documentType = $this->document->category->name;

        return (new MailMessage)
            ->subject("Document Expiry Alert: {$documentType}")
            ->line("This is a reminder that {$employee->name}'s {$documentType} is expiring soon.")
            ->line("Document: {$this->document->document_title}")
            ->line("Document Number: {$this->document->document_number}")
            ->line("Expiry Date: {$this->document->expiry_date->format('d M Y')}")
            ->line("Days Remaining: {$this->daysRemaining}")
            ->action('View Document', url("/documentmanagement/employee-documents/{$this->document->id}"))
            ->line('Please ensure the document is renewed before it expires.');
    }

    /**
     * Get the array representation of the notification.
     */
    public function toArray($notifiable): array
    {
        $employee = $this->document->employee;

        return [
            'document_id' => $this->document->id,
            'employee_id' => $employee->id,
            'employee_name' => $employee->name,
            'document_type' => $this->document->category->name,
            'document_title' => $this->document->document_title,
            'expiry_date' => $this->document->expiry_date->format('Y-m-d'),
            'days_remaining' => $this->daysRemaining,
        ];
    }
}
