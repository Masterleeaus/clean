<?php

namespace Modules\NoticeBoard\App\Http\Controllers;

use App\ApiClasses\Error;
use App\ApiClasses\Success;
use App\Http\Controllers\Controller;
use App\Models\Team;
use App\Models\User;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Modules\NoticeBoard\App\Http\Requests\StoreNoticeBoardRequest;
use Modules\NoticeBoard\App\Http\Requests\UpdateNoticeBoardRequest;
use Modules\NoticeBoard\App\Models\Notice;
use Modules\NoticeBoard\App\Models\TeamNotice;
use Modules\NoticeBoard\App\Models\UserNotice;

class NoticeBoardController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        // Handle DataTable AJAX request
        if ($request->ajax()) {
            return $this->indexAjax($request);
        }

        $teams = Team::where('status', 'active')->get();
        $users = User::where('status', 'active')
            ->whereNotNull('shift_id')
            ->get();

        return view('noticeboard::index', compact('teams', 'users'));
    }

    /**
     * Get notices for DataTable
     */
    public function indexAjax(Request $request): JsonResponse
    {
        try {
            $query = Notice::with(['createdBy']);

            // Apply filters
            if ($request->filled('status')) {
                $query->where('status', $request->status);
            }

            if ($request->filled('notice_for')) {
                $query->where('notice_for', $request->notice_for);
            }

            if ($request->filled('date_from')) {
                $query->whereDate('expiry_date', '>=', $request->date_from);
            }

            // Search
            if ($request->filled('search.value')) {
                $search = $request->input('search.value');
                $query->where(function ($q) use ($search) {
                    $q->where('title', 'LIKE', "%{$search}%")
                        ->orWhere('description', 'LIKE', "%{$search}%");
                });
            }

            $totalData = $query->count();

            // Ordering
            $orderColumnIndex = $request->input('order.0.column', 0);
            $orderDirection = $request->input('order.0.dir', 'desc');
            $columns = ['id', 'title', 'description', 'notice_for', 'expiry_date', 'status', 'created_by_id', 'id'];

            if (isset($columns[$orderColumnIndex])) {
                $query->orderBy($columns[$orderColumnIndex], $orderDirection);
            }

            // Pagination
            $start = $request->input('start', 0);
            $length = $request->input('length', 10);

            $notices = $query->skip($start)->take($length)->get();

            $data = [];
            foreach ($notices as $index => $notice) {
                $row = [];
                $row['DT_RowIndex'] = $start + $index + 1;
                $row['title'] = '<span class="fw-medium">'.e($notice->title).'</span>';

                $description = e($notice->description);
                $truncated = mb_strlen($description) > 100 ? mb_substr($description, 0, 100).'...' : $description;
                $row['description'] = '<span class="text-muted">'.$truncated.'</span>';

                $badges = [
                    'all' => '<span class="badge bg-label-primary">'.__('All').'</span>',
                    'employees' => '<span class="badge bg-label-info">'.__('Employees').'</span>',
                    'teams' => '<span class="badge bg-label-success">'.__('Teams').'</span>',
                ];
                $row['notice_for'] = $badges[$notice->notice_for] ?? '<span class="badge bg-label-secondary">'.e($notice->notice_for).'</span>';

                if ($notice->expiry_date) {
                    $expiryDate = $notice->expiry_date->format('d M Y');
                    $isExpired = $notice->expiry_date->isPast();
                    $row['expiry_date'] = $isExpired
                        ? '<span class="text-danger">'.$expiryDate.' <i class="bx bx-error-circle"></i></span>'
                        : '<span class="text-muted">'.$expiryDate.'</span>';
                } else {
                    $row['expiry_date'] = '<span class="text-muted">'.__('No Expiry').'</span>';
                }

                $statusBadges = [
                    'active' => '<span class="badge bg-label-success">'.__('Active').'</span>',
                    'inactive' => '<span class="badge bg-label-secondary">'.__('Inactive').'</span>',
                ];
                $row['status'] = $statusBadges[$notice->status] ?? '<span class="badge bg-label-secondary">'.e($notice->status).'</span>';

                if ($notice->createdBy) {
                    $row['created_by'] = view('components.datatable-user', ['user' => $notice->createdBy])->render();
                } else {
                    $row['created_by'] = '<span class="text-muted">'.__('N/A').'</span>';
                }

                $row['actions'] = view('components.datatable-actions', [
                    'id' => $notice->id,
                    'actions' => [
                        ['label' => __('Edit'), 'icon' => 'bx bx-edit', 'onclick' => "editRecord({$notice->id})"],
                        ['label' => __('Delete'), 'icon' => 'bx bx-trash', 'onclick' => "deleteRecord({$notice->id})"],
                    ],
                ])->render();

                $data[] = $row;
            }

            return response()->json([
                'draw' => intval($request->input('draw')),
                'recordsTotal' => $totalData,
                'recordsFiltered' => $totalData,
                'data' => $data,
            ]);
        } catch (Exception $e) {
            Log::error('Error in indexAjax: '.$e->getMessage());

            return response()->json([
                'draw' => 0,
                'recordsTotal' => 0,
                'recordsFiltered' => 0,
                'data' => [],
            ]);
        }
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreNoticeBoardRequest $request): JsonResponse
    {
        try {
            DB::beginTransaction();

            $notice = new Notice;
            $notice->title = $request->input('title');
            $notice->description = $request->input('description');
            $notice->notice_for = $request->input('notice_for');
            $notice->expiry_date = $request->input('expiry_date');
            $notice->status = $request->input('status', 'active');
            $notice->created_by_id = auth()->id();
            $notice->save();

            // Handle employee-specific notices
            if ($request->input('notice_for') === 'employees' && $request->has('user_ids')) {
                foreach ($request->input('user_ids') as $userId) {
                    UserNotice::create([
                        'user_id' => $userId,
                        'notice_id' => $notice->id,
                    ]);
                }
            }

            // Handle team-specific notices
            if ($request->input('notice_for') === 'teams' && $request->has('team_ids')) {
                foreach ($request->input('team_ids') as $teamId) {
                    TeamNotice::create([
                        'team_id' => $teamId,
                        'notice_id' => $notice->id,
                    ]);
                }
            }

            DB::commit();

            return Success::response(__('Notice created successfully'));
        } catch (Exception $e) {
            DB::rollBack();
            Log::error('Error creating notice: '.$e->getMessage());

            return Error::response(__('Failed to create notice. Please try again.'));
        }
    }

    /**
     * Get notice by ID for editing
     */
    public function getByIdAjax($id): JsonResponse
    {
        try {
            $notice = Notice::with(['users', 'teams'])->findOrFail($id);

            $response = [
                'id' => $notice->id,
                'title' => $notice->title,
                'description' => $notice->description,
                'notice_for' => $notice->notice_for,
                'expiry_date' => $notice->expiry_date ? $notice->expiry_date->format('Y-m-d') : null,
                'status' => $notice->status,
                'user_ids' => $notice->users->pluck('id')->toArray(),
                'team_ids' => $notice->teams->pluck('id')->toArray(),
            ];

            return Success::response($response);
        } catch (Exception $e) {
            Log::error('Error fetching notice: '.$e->getMessage());

            return Error::response(__('Notice not found.'));
        }
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateNoticeBoardRequest $request, $id): JsonResponse
    {
        try {
            DB::beginTransaction();

            $notice = Notice::findOrFail($id);
            $notice->title = $request->input('title');
            $notice->description = $request->input('description');
            $notice->notice_for = $request->input('notice_for');
            $notice->expiry_date = $request->input('expiry_date');
            $notice->status = $request->input('status', $notice->status);
            $notice->updated_by_id = auth()->id();
            $notice->save();

            // Clear existing associations
            UserNotice::where('notice_id', $notice->id)->delete();
            TeamNotice::where('notice_id', $notice->id)->delete();

            // Handle employee-specific notices
            if ($request->input('notice_for') === 'employees' && $request->has('user_ids')) {
                foreach ($request->input('user_ids') as $userId) {
                    UserNotice::create([
                        'user_id' => $userId,
                        'notice_id' => $notice->id,
                    ]);
                }
            }

            // Handle team-specific notices
            if ($request->input('notice_for') === 'teams' && $request->has('team_ids')) {
                foreach ($request->input('team_ids') as $teamId) {
                    TeamNotice::create([
                        'team_id' => $teamId,
                        'notice_id' => $notice->id,
                    ]);
                }
            }

            DB::commit();

            return Success::response(__('Notice updated successfully'));
        } catch (Exception $e) {
            DB::rollBack();
            Log::error('Error updating notice: '.$e->getMessage());

            return Error::response(__('Failed to update notice. Please try again.'));
        }
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy($id): JsonResponse
    {
        try {
            DB::beginTransaction();

            $notice = Notice::findOrFail($id);

            // Delete associated records
            UserNotice::where('notice_id', $notice->id)->delete();
            TeamNotice::where('notice_id', $notice->id)->delete();

            $notice->delete();

            DB::commit();

            return Success::response(__('Notice deleted successfully'));
        } catch (Exception $e) {
            DB::rollBack();
            Log::error('Error deleting notice: '.$e->getMessage());

            return Error::response(__('Failed to delete notice. Please try again.'));
        }
    }

    /**
     * Toggle notice status (active/inactive)
     */
    public function toggleStatus(Request $request): JsonResponse
    {
        try {
            $notice = Notice::findOrFail($request->input('id'));

            $notice->status = $notice->status === 'active' ? 'inactive' : 'active';
            $notice->updated_by_id = auth()->id();
            $notice->save();

            return Success::response(__('Status updated successfully'));
        } catch (Exception $e) {
            Log::error('Error toggling notice status: '.$e->getMessage());

            return Error::response(__('Failed to update status. Please try again.'));
        }
    }

    /**
     * Display employee-friendly notice board (read-only, card-based view)
     */
    public function myNotices()
    {
        $userId = auth()->id();
        $userTeamId = auth()->user()->team_id;

        // Get active notices relevant to the employee
        $notices = Notice::with(['createdBy'])
            ->where('status', 'active')
            ->where(function ($q) use ($userId, $userTeamId) {
                // Show notices for all
                $q->where('notice_for', 'all')
                    // Or notices assigned to user's team
                    ->orWhere(function ($subQ) use ($userTeamId) {
                        if ($userTeamId) {
                            $subQ->where('notice_for', 'teams')
                                ->whereHas('teams', function ($teamQ) use ($userTeamId) {
                                    $teamQ->where('team_id', $userTeamId);
                                });
                        }
                    })
                    // Or notices specifically assigned to this user
                    ->orWhere(function ($subQ) use ($userId) {
                        $subQ->where('notice_for', 'employees')
                            ->whereHas('users', function ($userQ) use ($userId) {
                                $userQ->where('user_id', $userId);
                            });
                    });
            })
            // Filter out expired notices
            ->where(function ($q) {
                $q->whereNull('expiry_date')
                    ->orWhereDate('expiry_date', '>=', now());
            })
            ->orderBy('created_at', 'desc')
            ->get();

        return view('noticeboard::my-notices', compact('notices'));
    }
}
