<?php

namespace Modules\NoticeBoard\App\Http\Controllers;

use App\ApiClasses\Success;
use App\Http\Controllers\Controller;
use Modules\NoticeBoard\App\Models\Notice;
use Modules\NoticeBoard\App\Models\TeamNotice;
use Modules\NoticeBoard\App\Models\UserNotice;

class NoticeBoardApiController extends Controller
{
    public function getAll()
    {
        $user = auth()->user();

        // Retrieve user-specific notices with active status
        $userNotices = UserNotice::where('user_id', $user->id)
            ->whereHas('notice', function ($query) {
                $query->where('status', 'active');
            })
            ->with('notice')
            ->get()
            ->pluck('notice');

        // Retrieve team-specific notices with active status
        $teamNotices = TeamNotice::where('team_id', $user->team_id)
            ->whereHas('notice', function ($query) {
                $query->where('status', 'active');
            })
            ->with('notice')
            ->get()
            ->pluck('notice');

        // Retrieve general active notices
        $generalNotices = Notice::where('notice_for', 'all')
            ->where('status', 'active')
            ->get();

        // Merge all notices
        $allNotices = $userNotices->merge($teamNotices)->merge($generalNotices);

        // Transform the collection to the desired response format
        $response = $allNotices->map(function ($notice) {
            return [
                'id' => $notice->id,
                'title' => $notice->title,
                'contents' => $notice->description,
                'createdAt' => $notice->created_at->format('Y-m-d H:i:s'),
            ];
        });

        return Success::response($response);
    }
}
