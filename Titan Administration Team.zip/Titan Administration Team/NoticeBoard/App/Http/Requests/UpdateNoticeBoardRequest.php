<?php

namespace Modules\NoticeBoard\App\Http\Requests;

use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;

class UpdateNoticeBoardRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'title' => 'required|string|max:255',
            'description' => 'required|string|max:1000',
            'notice_for' => 'required|in:all,employees,teams',
            'expiry_date' => 'nullable|date',
            'status' => 'nullable|in:active,inactive',
            'user_ids' => 'required_if:notice_for,employees|array',
            'user_ids.*' => 'exists:users,id',
            'team_ids' => 'required_if:notice_for,teams|array',
            'team_ids.*' => 'exists:teams,id',
        ];
    }

    /**
     * Get custom messages for validator errors.
     */
    public function messages(): array
    {
        return [
            'title.required' => __('The title field is required.'),
            'title.max' => __('The title may not be greater than 255 characters.'),
            'description.required' => __('The description field is required.'),
            'description.max' => __('The description may not be greater than 1000 characters.'),
            'notice_for.required' => __('Please select who this notice is for.'),
            'notice_for.in' => __('Invalid notice recipient type.'),
            'expiry_date.date' => __('Please enter a valid date.'),
            'user_ids.required_if' => __('Please select at least one employee.'),
            'user_ids.array' => __('Invalid employee selection.'),
            'user_ids.*.exists' => __('One or more selected employees are invalid.'),
            'team_ids.required_if' => __('Please select at least one team.'),
            'team_ids.array' => __('Invalid team selection.'),
            'team_ids.*.exists' => __('One or more selected teams are invalid.'),
        ];
    }
}
