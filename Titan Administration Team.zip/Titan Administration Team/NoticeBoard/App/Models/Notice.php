<?php

namespace Modules\NoticeBoard\App\Models;

use App\Models\Team;
use App\Models\User;
use App\Traits\UserActionsTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use OwenIt\Auditing\Auditable;
use OwenIt\Auditing\Contracts\Auditable as AuditableContract;

class Notice extends Model implements AuditableContract
{
    use Auditable, SoftDeletes, UserActionsTrait;

    protected $table = 'notices';

    protected $fillable = [
        'title',
        'description',
        'expiry_date',
        'notice_for',
        'status',
        'created_by_id',
        'updated_by_id',
    ];

    protected $casts = [
        'expiry_date' => 'datetime',
    ];

    public function createdBy(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }

    public function users(): BelongsToMany
    {
        return $this->belongsToMany(User::class, 'user_notices', 'notice_id', 'user_id');
    }

    public function teams(): BelongsToMany
    {
        return $this->belongsToMany(Team::class, 'team_notices', 'notice_id', 'team_id');
    }
}
