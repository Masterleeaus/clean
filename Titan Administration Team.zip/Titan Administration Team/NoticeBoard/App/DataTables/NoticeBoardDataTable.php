<?php

namespace Modules\NoticeBoard\App\DataTables;

use Illuminate\Database\Eloquent\Builder as QueryBuilder;
use Modules\NoticeBoard\App\Models\Notice;
use Yajra\DataTables\DataTableAbstract;
use Yajra\DataTables\Services\DataTable;

class NoticeBoardDataTable extends DataTable
{
    /**
     * Build DataTable class.
     */
    public function dataTable(QueryBuilder $query): DataTableAbstract
    {
        return datatables()
            ->eloquent($query)
            ->addIndexColumn()
            ->addColumn('title', function ($model) {
                return '<span class="fw-medium">'.e($model->title).'</span>';
            })
            ->addColumn('description', function ($model) {
                $description = e($model->description);
                $truncated = mb_strlen($description) > 100 ? mb_substr($description, 0, 100).'...' : $description;

                return '<span class="text-muted">'.$truncated.'</span>';
            })
            ->addColumn('notice_for', function ($model) {
                $badges = [
                    'all' => '<span class="badge bg-label-primary">'.__('All').'</span>',
                    'employees' => '<span class="badge bg-label-info">'.__('Employees').'</span>',
                    'teams' => '<span class="badge bg-label-success">'.__('Teams').'</span>',
                ];

                return $badges[$model->notice_for] ?? '<span class="badge bg-label-secondary">'.e($model->notice_for).'</span>';
            })
            ->addColumn('expiry_date', function ($model) {
                if (! $model->expiry_date) {
                    return '<span class="text-muted">'.__('No Expiry').'</span>';
                }

                $expiryDate = $model->expiry_date->format('d M Y');
                $isExpired = $model->expiry_date->isPast();

                if ($isExpired) {
                    return '<span class="text-danger">'.$expiryDate.' <i class="bx bx-error-circle"></i></span>';
                }

                return '<span class="text-muted">'.$expiryDate.'</span>';
            })
            ->addColumn('status', function ($model) {
                $statusBadges = [
                    'active' => '<span class="badge bg-label-success">'.__('Active').'</span>',
                    'inactive' => '<span class="badge bg-label-secondary">'.__('Inactive').'</span>',
                ];

                return $statusBadges[$model->status] ?? '<span class="badge bg-label-secondary">'.e($model->status).'</span>';
            })
            ->addColumn('created_by', function ($model) {
                if ($model->createdBy) {
                    return view('components.datatable-user', ['user' => $model->createdBy])->render();
                }

                return '<span class="text-muted">'.__('N/A').'</span>';
            })
            ->addColumn('actions', function ($model) {
                return view('components.datatable-actions', [
                    'id' => $model->id,
                    'actions' => [
                        ['label' => __('Edit'), 'icon' => 'bx bx-edit', 'onclick' => "editRecord({$model->id})"],
                        ['label' => __('Delete'), 'icon' => 'bx bx-trash', 'onclick' => "deleteRecord({$model->id})"],
                    ],
                ])->render();
            })
            ->rawColumns(['title', 'description', 'notice_for', 'expiry_date', 'status', 'created_by', 'actions']);
    }

    /**
     * Get query source of dataTable.
     */
    public function query(Notice $model): QueryBuilder
    {
        $query = $model->newQuery()
            ->with(['createdBy']);

        // Status filter
        if (request()->has('status') && request('status') !== '') {
            $query->where('status', request('status'));
        }

        // Notice for filter
        if (request()->has('notice_for') && request('notice_for') !== '') {
            $query->where('notice_for', request('notice_for'));
        }

        // Date range filter (expiry date)
        if (request()->has('date_from') && request('date_from') !== '') {
            $query->whereDate('expiry_date', '>=', request('date_from'));
        }

        if (request()->has('date_to') && request('date_to') !== '') {
            $query->whereDate('expiry_date', '<=', request('date_to'));
        }

        return $query->orderBy('created_at', 'desc');
    }

    /**
     * Optional method if you want to use html builder.
     */
    public function html()
    {
        return $this->builder()
            ->setTableId('noticeBoardTable')
            ->columns($this->getColumns())
            ->minifiedAjax()
            ->orderBy(0, 'desc')
            ->selectStyleSingle()
            ->parameters([
                'dom' => '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
                'scrollX' => true,
                'buttons' => $this->getButtons(),
                'lengthMenu' => [10, 25, 50, 100],
                'pageLength' => 10,
                'language' => [
                    'search' => __('Search'),
                    'searchPlaceholder' => __('Search notices...'),
                    'processing' => __('Processing...'),
                    'lengthMenu' => __('Show _MENU_ entries'),
                    'info' => __('Showing _START_ to _END_ of _TOTAL_ entries'),
                    'infoEmpty' => __('Showing 0 to 0 of 0 entries'),
                    'emptyTable' => __('No notices available. Click "Create Notice" to add your first notice.'),
                    'zeroRecords' => __('No matching notices found'),
                    'paginate' => [
                        'first' => __('First'),
                        'last' => __('Last'),
                        'next' => __('Next'),
                        'previous' => __('Previous'),
                    ],
                ],
            ]);
    }

    /**
     * Get columns.
     */
    protected function getColumns(): array
    {
        return [
            ['data' => 'DT_RowIndex', 'name' => 'DT_RowIndex', 'title' => '#', 'orderable' => false, 'searchable' => false],
            ['data' => 'title', 'name' => 'title', 'title' => __('Title')],
            ['data' => 'description', 'name' => 'description', 'title' => __('Description'), 'orderable' => false],
            ['data' => 'notice_for', 'name' => 'notice_for', 'title' => __('Notice For')],
            ['data' => 'expiry_date', 'name' => 'expiry_date', 'title' => __('Expiry Date')],
            ['data' => 'status', 'name' => 'status', 'title' => __('Status')],
            ['data' => 'created_by', 'name' => 'created_by_id', 'title' => __('Created By'), 'orderable' => false],
            ['data' => 'actions', 'name' => 'actions', 'title' => __('Actions'), 'orderable' => false, 'searchable' => false],
        ];
    }

    /**
     * Get buttons for export.
     */
    protected function getButtons(): array
    {
        // Check if DataImportExport addon is active
        $addonService = app(\App\Services\AddonService\IAddonService::class);
        $isExportEnabled = $addonService->isAddonEnabled('DataImportExport');

        if (! $isExportEnabled) {
            return [];
        }

        return [
            'excel',
            'csv',
            'pdf',
        ];
    }

    /**
     * Get filename for export.
     */
    protected function filename(): string
    {
        return 'NoticeBoard_'.date('YmdHis');
    }
}
