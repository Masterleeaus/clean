<?php

return [
    'name' => 'NoticeBoard',
];
