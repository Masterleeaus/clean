$(function () {
  // CSRF Setup
  $.ajaxSetup({
    headers: {
      'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
  });

  const noticeFormOffcanvas = new bootstrap.Offcanvas(document.getElementById('noticeFormOffcanvas'));
  let isEditMode = false;
  let currentNoticeId = null;

  // Initialize Select2 for filters
  $('#statusFilter').select2();
  $('#noticeForFilter').select2();

  // Initialize Flatpickr for date filters
  flatpickr('#dateFromFilter', {
    dateFormat: 'Y-m-d',
    onChange: function() {
      if (dtNoticeBoard) {
        dtNoticeBoard.ajax.reload();
      }
    }
  });

  // Initialize Flatpickr for expiry date in form
  flatpickr('#expiryDate', {
    dateFormat: 'Y-m-d',
    minDate: 'today'
  });

  // Filter change handlers
  $('#statusFilter').on('change', function () {
    if (dtNoticeBoard) {
      dtNoticeBoard.ajax.reload();
    }
  });

  $('#noticeForFilter').on('change', function () {
    if (dtNoticeBoard) {
      dtNoticeBoard.ajax.reload();
    }
  });

  // Notice For dropdown change handler in form
  $('#noticeFor').on('change', function () {
    const value = $(this).val();

    $('#employeesDiv').hide();
    $('#teamsDiv').hide();
    $('#userIds').val(null).trigger('change');
    $('#teamIds').val(null).trigger('change');

    if (value === 'employees') {
      $('#employeesDiv').show();
    } else if (value === 'teams') {
      $('#teamsDiv').show();
    }
  });

  // Initialize Select2 for multi-select fields
  $('#userIds').select2({
    dropdownParent: $('#noticeFormOffcanvas'),
    placeholder: pageData.labels.employees,
    allowClear: true
  });

  $('#teamIds').select2({
    dropdownParent: $('#noticeFormOffcanvas'),
    placeholder: pageData.labels.teams,
    allowClear: true
  });

  $('#noticeFor').select2({
    dropdownParent: $('#noticeFormOffcanvas'),
    placeholder: pageData.labels.all,
    minimumResultsForSearch: -1
  });

  // Initialize DataTable
  var dtNoticeBoard = $('#noticeBoardTable').DataTable({
    processing: true,
    serverSide: true,
    ajax: {
      url: baseUrl + 'noticeboard',
      type: 'GET',
      data: function (d) {
        d.status = $('#statusFilter').val();
        d.notice_for = $('#noticeForFilter').val();
        d.date_from = $('#dateFromFilter').val();
      }
    },
    columns: [
      { data: 'DT_RowIndex', name: 'DT_RowIndex', orderable: false, searchable: false },
      { data: 'title', name: 'title' },
      { data: 'description', name: 'description', orderable: false },
      { data: 'notice_for', name: 'notice_for' },
      { data: 'expiry_date', name: 'expiry_date' },
      { data: 'status', name: 'status' },
      { data: 'created_by', name: 'created_by_id', orderable: false },
      { data: 'actions', name: 'actions', orderable: false, searchable: false }
    ],
    order: [[1, 'desc']],
    dom: '<"row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6 d-flex justify-content-center justify-content-md-end"f>>t<"row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
    lengthMenu: [10, 25, 50, 100],
    pageLength: 10,
    language: {
      search: pageData.labels.search,
      searchPlaceholder: 'Search notices...',
      processing: pageData.labels.processing,
      lengthMenu: pageData.labels.lengthMenu,
      info: pageData.labels.info,
      infoEmpty: pageData.labels.infoEmpty,
      emptyTable: pageData.labels.emptyTable,
      zeroRecords: pageData.labels.zeroRecords,
      paginate: pageData.labels.paginate
    }
  });

  // Create Notice Button
  $('#createNoticeBtn').on('click', function () {
    resetForm();
    isEditMode = false;
    currentNoticeId = null;
    $('#noticeFormOffcanvasLabel').text(pageData.labels.createNotice);
    $('#submitBtn').text(pageData.labels.save);
    noticeFormOffcanvas.show();
  });

  // Edit Record Function (called from DataTable actions)
  window.editRecord = function (id) {
    isEditMode = true;
    currentNoticeId = id;
    $('#noticeFormOffcanvasLabel').text(pageData.labels.updateNotice);
    $('#submitBtn').text(pageData.labels.update);

    // Fetch notice data
    const url = pageData.urls.getById.replace(':id', id);
    $.get(url, function (response) {
      if (response.status === 'success') {
        const data = response.data;

        $('#noticeId').val(data.id);
        $('#title').val(data.title);
        $('#description').val(data.description);
        $('#noticeFor').val(data.notice_for).trigger('change');
        $('#expiryDate').val(data.expiry_date);
        $('#status').val(data.status);

        // Set employees or teams based on notice_for
        if (data.notice_for === 'employees' && data.user_ids.length > 0) {
          $('#userIds').val(data.user_ids).trigger('change');
        } else if (data.notice_for === 'teams' && data.team_ids.length > 0) {
          $('#teamIds').val(data.team_ids).trigger('change');
        }

        noticeFormOffcanvas.show();
      } else {
        showErrorToast(response.message || pageData.labels.error);
      }
    }).fail(function () {
      showErrorToast(pageData.labels.error);
    });
  };

  // Delete Record Function (called from DataTable actions)
  window.deleteRecord = function (id) {
    Swal.fire({
      title: pageData.labels.confirmDelete,
      text: pageData.labels.confirmDeleteText,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: pageData.labels.yes,
      cancelButtonText: pageData.labels.no,
      customClass: {
        confirmButton: 'btn btn-primary me-3',
        cancelButton: 'btn btn-label-secondary'
      },
      buttonsStyling: false
    }).then(function (result) {
      if (result.isConfirmed) {
        const url = pageData.urls.destroy.replace(':id', id);
        $.ajax({
          url: url,
          type: 'DELETE',
          success: function (response) {
            if (response.status === 'success') {
              showSuccessToast(response.message || pageData.labels.noticeDeleted);
              dtNoticeBoard.ajax.reload();
            } else {
              showErrorToast(response.message || pageData.labels.error);
            }
          },
          error: function (xhr) {
            const message = xhr.responseJSON?.message || pageData.labels.error;
            showErrorToast(message);
          }
        });
      }
    });
  };

  // Form Submit Handler
  $('#noticeForm').on('submit', function (e) {
    e.preventDefault();

    // Clear previous errors
    clearFormErrors();

    const formData = new FormData(this);
    let url;

    if (isEditMode && currentNoticeId) {
      url = pageData.urls.update.replace(':id', currentNoticeId);
      formData.append('_method', 'PUT');
    } else {
      url = pageData.urls.store;
    }

    // Manually append multi-select values to ensure they're sent correctly
    formData.delete('user_ids[]');
    formData.delete('team_ids[]');

    const userIds = $('#userIds').val();
    const teamIds = $('#teamIds').val();

    if (userIds && userIds.length > 0) {
      userIds.forEach(function(id) {
        formData.append('user_ids[]', id);
      });
    }

    if (teamIds && teamIds.length > 0) {
      teamIds.forEach(function(id) {
        formData.append('team_ids[]', id);
      });
    }

    $.ajax({
      url: url,
      type: 'POST',
      data: formData,
      processData: false,
      contentType: false,
      success: function (response) {
        if (response.status === 'success') {
          showSuccessToast(response.message);
          noticeFormOffcanvas.hide();
          resetForm();
          dtNoticeBoard.ajax.reload();
        } else {
          showErrorToast(response.message || pageData.labels.error);
        }
      },
      error: function (xhr) {
        if (xhr.status === 422) {
          // Validation errors
          const errors = xhr.responseJSON.errors;
          displayFormErrors(errors);
        } else {
          const message = xhr.responseJSON?.message || pageData.labels.error;
          showErrorToast(message);
        }
      }
    });
  });

  // Helper Functions
  function resetForm() {
    $('#noticeForm')[0].reset();
    $('#noticeId').val('');
    $('#employeesDiv').hide();
    $('#teamsDiv').hide();
    $('#userIds').val(null).trigger('change');
    $('#teamIds').val(null).trigger('change');
    $('#noticeFor').val('').trigger('change');
    clearFormErrors();
  }

  function clearFormErrors() {
    $('.is-invalid').removeClass('is-invalid');
    $('.invalid-feedback').text('');
  }

  function displayFormErrors(errors) {
    clearFormErrors();

    for (const [field, messages] of Object.entries(errors)) {
      const fieldName = field.replace('.', '_');
      const input = $(`[name="${field}"], [name="${field}[]"]`);
      const errorDiv = $(`#${fieldName}-error`);

      if (input.length) {
        input.addClass('is-invalid');
      }

      if (errorDiv.length) {
        errorDiv.text(messages[0]);
      }
    }
  }

  function showSuccessToast(message) {
    if (typeof Swal !== 'undefined') {
      Swal.fire({
        icon: 'success',
        title: pageData.labels.success,
        text: message,
        customClass: {
          confirmButton: 'btn btn-primary'
        },
        buttonsStyling: false
      });
    }
  }

  function showErrorToast(message) {
    if (typeof Swal !== 'undefined') {
      Swal.fire({
        icon: 'error',
        title: pageData.labels.error,
        text: message,
        customClass: {
          confirmButton: 'btn btn-primary'
        },
        buttonsStyling: false
      });
    }
  }
});
