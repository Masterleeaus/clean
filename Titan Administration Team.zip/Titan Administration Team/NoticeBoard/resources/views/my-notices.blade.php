@extends('layouts/layoutMaster')

@section('title', __('Notice Board'))

@section('content')
  {{-- Breadcrumb Component --}}
  <x-breadcrumb
    :title="__('Notice Board')"
    :breadcrumbs="[
      ['name' => __('Notice Board'), 'url' => '#']
    ]"
    :homeUrl="url('/')"
  />

  <div class="row">
    <div class="col-12">
      @if($notices->isEmpty())
        <!-- Empty State -->
        <div class="card">
          <div class="card-body text-center py-5">
            <i class="bx bx-bell-off display-1 text-muted mb-3"></i>
            <h4 class="text-muted">{{ __('No Notices Available') }}</h4>
            <p class="text-muted">{{ __('There are currently no active notices to display.') }}</p>
          </div>
        </div>
      @else
        <!-- Notices Grid -->
        <div class="row g-4">
          @foreach($notices as $notice)
            <div class="col-12 col-md-6 col-lg-4">
              <div class="card h-100 hover-shadow">
                <div class="card-body d-flex flex-column">
                  <!-- Notice Header -->
                  <div class="d-flex justify-content-between align-items-start mb-3">
                    <h5 class="card-title mb-0">
                      <i class="bx bx-bell text-primary me-1"></i>
                      {{ $notice->title }}
                    </h5>

                    @if($notice->notice_for === 'all')
                      <span class="badge bg-label-primary">{{ __('All') }}</span>
                    @elseif($notice->notice_for === 'employees')
                      <span class="badge bg-label-info">{{ __('You') }}</span>
                    @elseif($notice->notice_for === 'teams')
                      <span class="badge bg-label-success">{{ __('Your Team') }}</span>
                    @endif
                  </div>

                  <!-- Notice Description -->
                  <div class="flex-grow-1 mb-3">
                    <p class="card-text text-muted">{{ $notice->description }}</p>
                  </div>

                  <!-- Notice Footer -->
                  <div class="border-top pt-3 mt-auto">
                    <div class="d-flex justify-content-between align-items-center">
                      <div class="d-flex align-items-center">
                        @if($notice->createdBy && $notice->createdBy->photo)
                          <img src="{{ asset('storage/' . $notice->createdBy->photo) }}"
                               alt="{{ $notice->createdBy->getFullName() }}"
                               class="rounded-circle me-2"
                               width="32"
                               height="32">
                        @else
                          <div class="avatar avatar-sm me-2">
                            <span class="avatar-initial rounded-circle bg-label-primary">
                              {{ $notice->createdBy ? strtoupper(substr($notice->createdBy->getFullName(), 0, 2)) : 'NA' }}
                            </span>
                          </div>
                        @endif
                        <div>
                          <small class="text-muted d-block">{{ __('Posted by') }}</small>
                          <small class="fw-medium">{{ $notice->createdBy ? $notice->createdBy->getFullName() : __('N/A') }}</small>
                        </div>
                      </div>

                      <div class="text-end">
                        <small class="text-muted d-block">{{ $notice->created_at->diffForHumans() }}</small>
                        @if($notice->expiry_date)
                          @php
                            $daysUntilExpiry = now()->diffInDays($notice->expiry_date, false);
                          @endphp
                          @if($daysUntilExpiry <= 3 && $daysUntilExpiry >= 0)
                            <small class="text-warning d-block">
                              <i class="bx bx-time-five"></i>
                              {{ __('Expires in') }} {{ ceil($daysUntilExpiry) }} {{ __('days') }}
                            </small>
                          @else
                            <small class="text-muted d-block">
                              <i class="bx bx-calendar"></i>
                              {{ __('Expires') }}: {{ $notice->expiry_date->format('M d, Y') }}
                            </small>
                          @endif
                        @endif
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          @endforeach
        </div>
      @endif
    </div>
  </div>

  <style>
    .hover-shadow {
      transition: box-shadow 0.3s ease;
    }
    .hover-shadow:hover {
      box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15) !important;
    }
    .card-title {
      font-size: 1.1rem;
      font-weight: 600;
      color: #566a7f;
    }
  </style>
@endsection
