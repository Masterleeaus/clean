@extends('layouts/layoutMaster')

@section('title', __('Notice Board'))

<!-- Vendor Styles -->
@section('vendor-style')
  @vite(['resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
 'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
 'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
 'resources/assets/vendor/libs/@form-validation/form-validation.scss',
  'resources/assets/vendor/libs/animate-css/animate.scss',
   'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss'])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
  @vite(['resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
 'resources/assets/vendor/libs/@form-validation/popular.js',
  'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
   'resources/assets/vendor/libs/@form-validation/auto-focus.js',
   'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js'])
@endsection

@section('page-script')
  @vite(['Modules/NoticeBoard/resources/assets/js/notice-board-index.js'])
@endsection


@section('content')
  {{-- Breadcrumb Component --}}
  <x-breadcrumb
    :title="__('Notice Board')"
    :breadcrumbs="[
      ['name' => __('Notice Board'), 'url' => '#']
    ]"
    :homeUrl="url('/')"
  />

  <!-- Filters Section -->
  <div class="card mb-4">
    <div class="card-body">
      <div class="row">
        <!-- Status Filter -->
        <div class="col-md-4 mb-3 mb-md-0">
          <label for="statusFilter" class="form-label">{{ __('Filter by Status') }}</label>
          <select id="statusFilter" name="statusFilter" class="form-select select2">
            <option value="">{{ __('All Statuses') }}</option>
            <option value="active">{{ __('Active') }}</option>
            <option value="inactive">{{ __('Inactive') }}</option>
          </select>
        </div>

        <!-- Notice For Filter -->
        <div class="col-md-4 mb-3 mb-md-0">
          <label for="noticeForFilter" class="form-label">{{ __('Filter by Recipient') }}</label>
          <select id="noticeForFilter" name="noticeForFilter" class="form-select select2">
            <option value="">{{ __('All Recipients') }}</option>
            <option value="all">{{ __('All') }}</option>
            <option value="employees">{{ __('Employees') }}</option>
            <option value="teams">{{ __('Teams') }}</option>
          </select>
        </div>

        <!-- Date Range Filter -->
        <div class="col-md-4 mb-3 mb-md-0">
          <label for="dateFromFilter" class="form-label">{{ __('Expiry Date From') }}</label>
          <input type="text" id="dateFromFilter" name="dateFromFilter" class="form-control flatpickr-input" placeholder="{{ __('Select date') }}">
        </div>
      </div>
    </div>
  </div>

  <!-- Notice Board table card -->
  <div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
      <h5 class="mb-0">{{ __('All Notices') }}</h5>
      <button type="button" class="btn btn-primary" id="createNoticeBtn">
        <i class="bx bx-plus me-1"></i>{{ __('Create Notice') }}
      </button>
    </div>
    <div class="card-datatable table-responsive">
      <table id="noticeBoardTable" class="datatables-notice-board table border-top">
        <thead>
          <tr>
            <th>{{ __('#') }}</th>
            <th>{{ __('Title') }}</th>
            <th>{{ __('Description') }}</th>
            <th>{{ __('Notice For') }}</th>
            <th>{{ __('Expiry Date') }}</th>
            <th>{{ __('Status') }}</th>
            <th>{{ __('Created By') }}</th>
            <th>{{ __('Actions') }}</th>
          </tr>
        </thead>
        <tbody></tbody>
      </table>
    </div>
  </div>

  <!-- Create/Edit Notice Offcanvas -->
  <div class="offcanvas offcanvas-end" tabindex="-1" id="noticeFormOffcanvas" aria-labelledby="noticeFormOffcanvasLabel">
    <div class="offcanvas-header">
      <h5 class="offcanvas-title" id="noticeFormOffcanvasLabel">{{ __('Create Notice') }}</h5>
      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body">
      <form id="noticeForm">
        <input type="hidden" id="noticeId" name="id">

        <!-- Title -->
        <div class="mb-3">
          <label for="title" class="form-label">{{ __('Title') }} <span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="title" name="title" required maxlength="255">
          <div class="invalid-feedback" id="title-error"></div>
        </div>

        <!-- Description -->
        <div class="mb-3">
          <label for="description" class="form-label">{{ __('Description') }} <span class="text-danger">*</span></label>
          <textarea class="form-control" id="description" name="description" rows="4" required maxlength="1000"></textarea>
          <div class="invalid-feedback" id="description-error"></div>
        </div>

        <!-- Notice For -->
        <div class="mb-3">
          <label for="noticeFor" class="form-label">{{ __('Notice For') }} <span class="text-danger">*</span></label>
          <select class="form-select select2" id="noticeFor" name="notice_for" required>
            <option value="">{{ __('Please select') }}</option>
            <option value="all">{{ __('All') }}</option>
            <option value="employees">{{ __('Employees') }}</option>
            <option value="teams">{{ __('Teams') }}</option>
          </select>
          <div class="invalid-feedback" id="notice_for-error"></div>
        </div>

        <!-- Employees Selection (hidden by default) -->
        <div class="mb-3" id="employeesDiv" style="display: none;">
          <label for="userIds" class="form-label">{{ __('Select Employees') }} <span class="text-danger">*</span></label>
          <select class="form-select select2" id="userIds" name="user_ids[]" multiple>
            @foreach($users as $user)
              <option value="{{ $user->id }}">{{ $user->getFullName() }} ({{ $user->code }})</option>
            @endforeach
          </select>
          <div class="invalid-feedback" id="user_ids-error"></div>
        </div>

        <!-- Teams Selection (hidden by default) -->
        <div class="mb-3" id="teamsDiv" style="display: none;">
          <label for="teamIds" class="form-label">{{ __('Select Teams') }} <span class="text-danger">*</span></label>
          <select class="form-select select2" id="teamIds" name="team_ids[]" multiple>
            @foreach($teams as $team)
              <option value="{{ $team->id }}">{{ $team->name }}</option>
            @endforeach
          </select>
          <div class="invalid-feedback" id="team_ids-error"></div>
        </div>

        <!-- Expiry Date -->
        <div class="mb-3">
          <label for="expiryDate" class="form-label">{{ __('Expiry Date') }}</label>
          <input type="text" class="form-control flatpickr-input" id="expiryDate" name="expiry_date" placeholder="{{ __('Select expiry date') }}">
          <div class="invalid-feedback" id="expiry_date-error"></div>
        </div>

        <!-- Status -->
        <div class="mb-3">
          <label for="status" class="form-label">{{ __('Status') }}</label>
          <select class="form-select" id="status" name="status">
            <option value="active">{{ __('Active') }}</option>
            <option value="inactive">{{ __('Inactive') }}</option>
          </select>
        </div>

        <!-- Action Buttons -->
        <div class="d-flex gap-2">
          <button type="submit" class="btn btn-primary flex-fill" id="submitBtn">{{ __('Save') }}</button>
          <button type="button" class="btn btn-label-secondary flex-fill" data-bs-dismiss="offcanvas">{{ __('Cancel') }}</button>
        </div>
      </form>
    </div>
  </div>

  {{-- Page Data for JavaScript --}}
  <script>
    const pageData = {
      urls: {
        datatable: @json(route('noticeboard.index')),
        store: @json(route('noticeboard.store')),
        update: @json(route('noticeboard.update', ':id')),
        destroy: @json(route('noticeboard.destroy', ':id')),
        getById: @json(route('noticeboard.getById', ':id')),
        toggleStatus: @json(route('noticeboard.toggleStatus')),
        employeeSearch: @json(route('employees.search'))
      },
      labels: {
        confirmDelete: @json(__('Are you sure?')),
        confirmDeleteText: @json(__('You will not be able to recover this notice!')),
        yes: @json(__('Yes, delete it!')),
        no: @json(__('Cancel')),
        deleted: @json(__('Deleted!')),
        noticeDeleted: @json(__('Notice has been deleted.')),
        error: @json(__('Error!')),
        success: @json(__('Success!')),
        createNotice: @json(__('Create Notice')),
        updateNotice: @json(__('Update Notice')),
        save: @json(__('Save')),
        update: @json(__('Update')),
        all: @json(__('All')),
        employees: @json(__('Employees')),
        teams: @json(__('Teams')),
        search: @json(__('Search')),
        processing: @json(__('Processing...')),
        lengthMenu: @json(__('Show _MENU_ entries')),
        info: @json(__('Showing _START_ to _END_ of _TOTAL_ entries')),
        infoEmpty: @json(__('Showing 0 to 0 of 0 entries')),
        emptyTable: @json(__('No notices available. Click "Create Notice" to add your first notice.')),
        zeroRecords: @json(__('No matching notices found')),
        paginate: {
          first: @json(__('First')),
          last: @json(__('Last')),
          next: @json(__('Next')),
          previous: @json(__('Previous'))
        }
      }
    };
  </script>
@endsection
