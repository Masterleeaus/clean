<?php

use Illuminate\Support\Facades\Route;
use Modules\NoticeBoard\App\Http\Controllers\NoticeBoardController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['web', 'auth'])->group(function () {
    // Employee view route (must come before {id} route)
    Route::get('noticeboard/my-notices', [NoticeBoardController::class, 'myNotices'])->name('noticeboard.my-notices');

    // Management index route
    Route::get('noticeboard', [NoticeBoardController::class, 'index'])->name('noticeboard.index');

    // Create and store routes
    Route::post('noticeboard', [NoticeBoardController::class, 'store'])->name('noticeboard.store');

    // Get by ID (for editing)
    Route::get('noticeboard/{id}', [NoticeBoardController::class, 'getByIdAjax'])->name('noticeboard.getById');

    // Update route
    Route::put('noticeboard/{id}', [NoticeBoardController::class, 'update'])->name('noticeboard.update');

    // Delete route
    Route::delete('noticeboard/{id}', [NoticeBoardController::class, 'destroy'])->name('noticeboard.destroy');

    // Toggle status route
    Route::post('noticeboard/toggle-status', [NoticeBoardController::class, 'toggleStatus'])->name('noticeboard.toggleStatus');
});
