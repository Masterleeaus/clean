<?php

return [
    'name' => 'Kontrak'
];
