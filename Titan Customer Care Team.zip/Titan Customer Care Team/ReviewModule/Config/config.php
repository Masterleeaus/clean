<?php

return [
    'name' => 'ReviewModule'
];
