<?php

namespace Modules\Biometric\Filament\Resources;

use Filament\Resources\Resource;
use Filament\Tables;
use Filament\Tables\Table;
use Modules\Biometric\Entities\BiometricDevice;
use Modules\Biometric\Filament\Resources\BiometricDeviceResource\Pages\ListBiometricDevices;

class BiometricDeviceResource extends Resource
{
    protected static ?string $model = BiometricDevice::class;
    protected static \BackedEnum|string|null $navigationIcon = 'heroicon-o-cpu-chip';
    protected static \UnitEnum|string|null $navigationGroup = 'Biometric';
    protected static ?int $navigationSort = 2;
    protected static ?string $navigationLabel = 'Devices';

    public static function table(Table $table): Table
    {
        return $table
            ->columns([
                Tables\Columns\TextColumn::make('device_name')->searchable()->sortable(),
                Tables\Columns\TextColumn::make('serial_number')->searchable(),
                Tables\Columns\TextColumn::make('device_ip')->label('IP')->toggleable(),
                Tables\Columns\TextColumn::make('status')
                    ->badge()
                    ->color(fn (string $state): string => match ($state) {
                        'online' => 'success',
                        'offline' => 'danger',
                        'pending' => 'warning',
                        default => 'gray',
                    }),
                Tables\Columns\TextColumn::make('last_online')->dateTime()->sortable(),
            ])
            ->defaultSort('updated_at', 'desc');
    }

    public static function getPages(): array
    {
        return [
            'index' => ListBiometricDevices::route('/'),
        ];
    }
}
