<?php

namespace Modules\LMS\App\Models; // Correct namespace

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class LessonCompletion extends Model
{
    protected $table = 'lms_lesson_completions';

    /**
     * Indicates if the model should be timestamped.
     * Set to false because we only care about completed_at.
     * Migration already doesn't have updated_at.
     *
     * @var bool
     */
    public $timestamps = false;

    protected $fillable = [
        'lms_enrollment_id',
        'lms_lesson_id',
        'user_id', // Included for easier querying
        'completed_at',
    ];

    protected $casts = [
        'completed_at' => 'datetime',
    ];

    // Relationships
    public function enrollment(): BelongsTo
    {
        return $this->belongsTo(CourseEnrollment::class, 'lms_enrollment_id');
    }

    public function lesson(): BelongsTo
    {
        return $this->belongsTo(Lesson::class, 'lms_lesson_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
