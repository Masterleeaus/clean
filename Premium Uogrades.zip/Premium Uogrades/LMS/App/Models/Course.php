<?php

namespace Modules\LMS\App\Models;

use App\Models\User;
use App\Traits\UserActionsTrait;
use Illuminate\Database\Eloquent\Concerns\HasUuids;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\SoftDeletes;
use Modules\LMS\App\Enums\LmsCourseStatus;

class Course extends Model
{
    use HasUuids, SoftDeletes, UserActionsTrait;

    protected $table = 'lms_courses';

    protected $fillable = [
        'uuid',
        'title',
        'description',
        'lms_course_category_id',
        'status',
        'estimated_duration',
        'thumbnail_path',
        'created_by_id',
        'updated_by_id',
    ];

    protected $casts = [
        'status' => LmsCourseStatus::class,
    ];

    public function uniqueIds(): array
    {
        return ['uuid'];
    }

    // Relationships
    public function category(): BelongsTo
    {
        return $this->belongsTo(CourseCategory::class, 'lms_course_category_id');
    }

    public function lessons(): HasMany
    {
        // Assuming SortableTrait might be added later for ordering
        return $this->hasMany(Lesson::class, 'lms_course_id')->orderBy('order_column');
    }

    public function enrollments(): HasMany
    {
        return $this->hasMany(CourseEnrollment::class, 'lms_course_id');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }

    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by_id');
    }
}
