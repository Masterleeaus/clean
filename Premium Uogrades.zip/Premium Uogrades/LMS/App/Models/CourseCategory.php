<?php

namespace Modules\LMS\App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class CourseCategory extends Model
{
    protected $table = 'lms_course_categories';

    protected $fillable = [
        'name',
        'description',
        'is_active',
    ];

    /**
     * Get the courses belonging to this category.
     */
    public function courses(): HasMany
    {
        return $this->hasMany(Course::class, 'lms_course_category_id'); // Explicit foreign key
    }
}
