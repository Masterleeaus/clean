<?php

namespace Modules\LMS\App\Models;

use App\Models\User;
use App\Traits\UserActionsTrait;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Modules\LMS\App\Enums\LmsContentType;

class Lesson extends Model
{
    use UserActionsTrait;

    protected $table = 'lms_lessons';

    protected $fillable = [
        'lms_course_id',
        'title',
        'content_type',
        'content_text',
        'content_file_path',
        'original_filename',
        'order_column',
        'created_by_id',
        'updated_by_id',
    ];

    protected $casts = [
        'content_type' => LmsContentType::class, // Cast to Enum
    ];

    // Relationships
    public function course(): BelongsTo
    {
        return $this->belongsTo(Course::class, 'lms_course_id');
    }

    public function completions(): HasMany
    {
        // Relationship to track which users completed this lesson
        return $this->hasMany(LessonCompletion::class, 'lms_lesson_id');
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by_id');
    }

    public function updater(): BelongsTo
    {
        return $this->belongsTo(User::class, 'updated_by_id');
    }
}
