<?php

namespace Modules\LMS\App\Models; // Correct namespace

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Modules\LMS\App\Enums\LmsEnrollmentStatus;

class CourseEnrollment extends Model
{
    protected $table = 'lms_course_enrollments';

    protected $fillable = [
        'lms_course_id',
        'user_id',
        'status',
        'enrolled_at',
        'started_at',
        'completed_at',
        'enrolled_by_id',
        'score',
    ];

    protected $casts = [
        'status' => LmsEnrollmentStatus::class, // Cast to Enum
        'enrolled_at' => 'datetime',
        'started_at' => 'datetime',
        'completed_at' => 'datetime',
        'score' => 'decimal:2', // Adjust precision if needed
    ];

    // Relationships
    public function course(): BelongsTo
    {
        return $this->belongsTo(Course::class, 'lms_course_id');
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the specific lesson completion records for this enrollment.
     */
    public function lessonCompletions(): HasMany
    {
        return $this->hasMany(LessonCompletion::class, 'lms_enrollment_id');
    }
}
