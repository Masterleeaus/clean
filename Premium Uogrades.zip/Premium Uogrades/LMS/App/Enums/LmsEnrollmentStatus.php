<?php

namespace Modules\LMS\App\Enums;

enum LmsEnrollmentStatus: string
{
    case NOT_STARTED = 'not_started';
    case IN_PROGRESS = 'in_progress';
    case COMPLETED = 'completed';
    // case FAILED = 'failed'; // Optional: If passing score required

    /**
     * Get a human-readable label for the status.
     */
    public function label(): string
    {
        return match ($this) {
            self::NOT_STARTED => 'Not Started',
            self::IN_PROGRESS => 'In Progress',
            self::COMPLETED => 'Completed',
            // self::FAILED => 'Failed',
        };
    }

    /**
     * Get a Bootstrap badge color class associated with the status.
     */
    public function colorClass(): string
    {
        return match ($this) {
            self::NOT_STARTED => 'bg-label-secondary',
            self::IN_PROGRESS => 'bg-label-info',
            self::COMPLETED => 'bg-label-success',
            // self::FAILED => 'bg-label-danger',
        };
    }
}
