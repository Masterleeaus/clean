<?php

namespace Modules\LMS\App\Enums;

enum LmsContentType: string
{
    case TEXT = 'text';             // Simple text/HTML content

    // Rich text/HTML content (WYSIWYG)
    case FILE_UPLOAD = 'file';      // Downloadable file (PDF, DOC, etc.)
    case VIDEO_EMBED = 'video_embed'; // Embed code (YouTube, Vimeo)
    case VIDEO_UPLOAD = 'video_file'; // Uploaded video file
    case EXTERNAL_LINK = 'link';      // URL to external resource
    // case QUIZ = 'quiz';           // Link/indicator for a quiz (implementation TBD)
    // case IMAGE = 'image';        // Optional: If specifically handling images
    // case SCORM = 'scorm';        // Optional: For SCORM packages (Advanced)

    /**
     * Get a human-readable label for the content type.
     */
    public function label(): string
    {
        return match ($this) {
            self::TEXT => 'Text Content',
            // self::TEXT_HTML => 'Rich Text / HTML',
            self::FILE_UPLOAD => 'File (Download)',
            self::VIDEO_EMBED => 'Video (Embed)',
            self::VIDEO_UPLOAD => 'Video (Upload)',
            self::EXTERNAL_LINK => 'External Link',
            // self::QUIZ => 'Quiz / Assessment',
            // self::IMAGE => 'Image',
            // self::SCORM => 'eLearning Package (SCORM)',
        };
    }

    /**
     * Get a suggested Boxicon icon class for the content type.
     */
    public function iconClass(): string
    {
        return match ($this) {
            self::TEXT => 'bx-text',
            // self::TEXT_HTML => 'bx-file-blank', // Or bx-file
            self::FILE_UPLOAD => 'bx-file-blank', // Or bx-download
            self::VIDEO_EMBED, self::VIDEO_UPLOAD => 'bx-video',
            self::EXTERNAL_LINK => 'bx-link-external',
            // self::QUIZ => 'bx-question-mark',
            // self::IMAGE => 'bx-image',
            default => 'bx-book-content',
        };
    }
}
