<?php

namespace Modules\LMS\App\Enums;

enum LmsCourseStatus: string
{
    case DRAFT = 'draft';
    case PUBLISHED = 'published';
    case ARCHIVED = 'archived';

    /**
     * Get a human-readable label for the status.
     */
    public function label(): string
    {
        return match ($this) {
            self::DRAFT => 'Draft',
            self::PUBLISHED => 'Published',
            self::ARCHIVED => 'Archived',
        };
    }

    /**
     * Get a Bootstrap badge color class associated with the status.
     */
    public function colorClass(): string
    {
        return match ($this) {
            self::DRAFT => 'bg-label-secondary',
            self::PUBLISHED => 'bg-label-success',
            self::ARCHIVED => 'bg-label-warning', // Or secondary if preferred
        };
    }
}
