<?php

namespace Modules\LMS\App\Http\Controllers; // Default nwidart namespace

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\JsonResponse; // Use model from module
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Enum as EnumRule;
use Illuminate\Validation\Rules\File as FileRule;
use Modules\LMS\App\Enums\LmsContentType;
use Modules\LMS\App\Models\Course;
use Modules\LMS\App\Models\CourseEnrollment;
use Modules\LMS\App\Models\Lesson;

class LmsLessonController extends Controller
{
    /**
     * Authorization helper: Check if user can manage lessons for the given course.
     * Replace with your actual permission/policy check.
     */
    private function authorizeCourseAccess(Course $course): bool
    {
        // Example: Check if user is creator or has specific permission
        // return $course->created_by_id === Auth::id() || Auth::user()->can('manage_lms_courses');
        return true; // Placeholder - IMPLEMENT REAL AUTH CHECK
    }

    /**
     * Authorization helper: Check if user can manage this specific lesson.
     */
    private function authorizeLessonAccess(Lesson $lesson): bool
    {
        $lesson->loadMissing('course'); // Ensure course relation is loaded

        return $lesson->course && $this->authorizeCourseAccess($lesson->course);
    }

    /**
     * Display the lesson management page for a specific course.
     * Route: GET /lms/courses/{course}/lessons
     * Name: lms.courses.lessons.index
     */
    public function index(Course $course) // Use Route Model Binding for course
    {
        if (! $this->authorizeCourseAccess($course)) {
            abort(403, 'Unauthorized');
        }

        // Eager load lessons for the view
        $lessons = $course->lessons()->orderBy('order_column', 'asc')->get();

        // Get content types for the form dropdown
        $contentTypes = LmsContentType::cases();

        return view('lms::lessons.index', compact('course', 'lessons', 'contentTypes'));
    }

    /**
     * Store a newly created lesson for a course.
     * Route: POST /lms/courses/{course}/lessons
     * Name: lms.courses.lessons.store
     */
    public function store(Request $request, Course $course): JsonResponse
    {
        if (! $this->authorizeCourseAccess($course)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $validator = Validator::make($request->all(), [
            'title' => [
                'required',
                'string',
                'max:255',
                Rule::unique(Lesson::class, 'title')->where(fn ($query) => $query->where('lms_course_id', $course->id)),
            ],
            'content_type' => ['required', new EnumRule(LmsContentType::class)],
            'content_text' => [
                'nullable',
                'string',
                'max:65535',
                Rule::requiredIf(fn () => in_array($request->input('content_type'), [
                    LmsContentType::TEXT->value,
                    LmsContentType::VIDEO_EMBED->value,
                    LmsContentType::EXTERNAL_LINK->value,
                ])),
            ],
            'lesson_file' => [
                'nullable',
                FileRule::types(['pdf', 'doc', 'docx', 'mp4', 'mov', 'avi', 'mp3', 'jpg', 'png', 'zip'])->max(100 * 1024),
                Rule::requiredIf(fn () => in_array($request->input('content_type'), [
                    LmsContentType::FILE_UPLOAD->value,
                    LmsContentType::VIDEO_UPLOAD->value,
                ])),
            ],
        ], [
            'title.unique' => 'A lesson with this title already exists in this course.',
            'content_text.required_if' => 'Content/Link/Embed code is required for the selected type.',
            'lesson_file.required_if' => 'A file upload is required for the selected type.',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        }
        $validated = $validator->validated();
        $contentType = LmsContentType::from($validated['content_type']); // Get Enum instance

        DB::beginTransaction();
        try {
            $filePath = null;
            $originalFilename = null;

            // Handle File Upload
            if (($contentType === LmsContentType::FILE_UPLOAD || $contentType === LmsContentType::VIDEO_UPLOAD) && $request->hasFile('lesson_file')) {
                $file = $request->file('lesson_file');
                $diskName = 'private'; // *** STORE LESSON FILES PRIVATELY ***
                $tenantId = Auth::user()->tenant_id;
                $directory = "lms/course_{$course->id}/lessons"; // Organize by course
                try {
                    $originalFilename = $file->getClientOriginalName();
                    $filePath = $file->store($directory, $diskName);
                    if (! $filePath) {
                        throw new Exception('Failed to store lesson file.');
                    }
                } catch (Exception $e) {
                    DB::rollBack();
                    Log::error('Lesson file upload error: '.$e->getMessage());

                    return response()->json(['success' => false, 'message' => 'Could not save lesson file.'], 500);
                }
            }

            // Get next order column value
            $maxOrder = $course->lessons()->max('order_column');

            $lesson = $course->lessons()->create([
                'title' => $validated['title'],
                'content_type' => $contentType, // Store Enum instance (will save value)
                'content_text' => ($contentType !== LmsContentType::FILE_UPLOAD && $contentType !== LmsContentType::VIDEO_UPLOAD) ? ($validated['content_text'] ?? null) : null,
                'content_file_path' => $filePath,
                'original_filename' => $originalFilename,
                'order_column' => ($maxOrder ?? -1) + 1,
            ]);

            DB::commit();
            Log::info("LMS Lesson created: ID {$lesson->id} for Course {$course->id} by User ".Auth::id());

            // Return data for the new item for JS to render dynamically
            return response()->json([
                'success' => true,
                'message' => 'Lesson added successfully.',
                'lesson' => [ // Return data needed by JS
                    'id' => $lesson->id,
                    'title' => $lesson->title,
                    'contentType' => $lesson->content_type->value,
                    'orderColumn' => $lesson->order_column,
                    // Add other potentially useful data like file URL if needed immediately
                ],
            ], 201);

        } catch (Exception $e) {
            DB::rollBack();
            // Clean up file if DB fails
            if (isset($filePath) && isset($diskName) && Storage::disk($diskName)->exists($filePath)) {
                Storage::disk($diskName)->delete($filePath);
            }
            Log::error("Error creating LMS lesson for course {$course->id}: ".$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to create lesson.'], 500);
        }
    }

    /**
     * Fetch data for editing a specific lesson.
     * Route: GET /lms/lessons/{lesson}/edit
     * Name: lms.lessons.edit
     */
    public function edit(Lesson $lesson): JsonResponse
    {
        if (! $this->authorizeLessonAccess($lesson)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        // Get file URL if applicable
        $fileUrl = null;
        $diskName = 'private';
        if ($lesson->content_file_path && Storage::disk($diskName)->exists($lesson->content_file_path)) {
            // Need a dedicated secure download route for private files
            // $fileUrl = route('lms.lessons.downloadFile', $lesson->id); // Example route
        }

        // Return data for the edit form
        return response()->json([
            'success' => true,
            'lesson' => [
                'id' => $lesson->id,
                'title' => $lesson->title,
                'content_type' => $lesson->content_type->value,
                'content_text' => $lesson->content_text, // Includes text, URL or embed code
                'current_file_name' => $lesson->original_filename, // Show current filename
                'current_file_url' => $fileUrl, // URL to view/download current file
            ],
        ]);
    }

    /**
     * Update the specified lesson in storage.
     * Route: PUT /lms/lessons/{lesson}
     * Name: lms.lessons.update
     */
    public function update(Request $request, Lesson $lesson): JsonResponse
    {
        if (! $this->authorizeLessonAccess($lesson)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $validator = Validator::make($request->all(), [
            'title' => [
                'required',
                'string',
                'max:255',
                Rule::unique(Lesson::class, 'title')
                    ->ignore($lesson->id)
                    ->where(fn ($query) => $query->where('lms_course_id', $lesson->lms_course_id)),
            ],
            'content_type' => ['required', new EnumRule(LmsContentType::class)],
            'content_text' => [
                'nullable',
                'string',
                'max:65535',
                Rule::requiredIf(fn () => in_array($request->input('content_type'), [
                    LmsContentType::TEXT->value,
                    LmsContentType::VIDEO_EMBED->value,
                    LmsContentType::EXTERNAL_LINK->value,
                ])),
            ],
            'lesson_file' => ['nullable', FileRule::types(['pdf', 'doc', 'docx', 'mp4', 'mov', 'avi', 'mp3', 'jpg', 'png', 'zip'])->max(100 * 1024)],
            'remove_file' => 'nullable|boolean',
        ], [
            'title.unique' => 'A lesson with this title already exists in this course.',
            'content_text.required_if' => 'Content/Link/Embed code is required for the selected type.',
            'lesson_file.required_if' => 'A file upload is required for the selected type.',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        }

        $validated = $validator->validated();
        $contentType = LmsContentType::from($validated['content_type']);

        DB::beginTransaction();
        try {
            $updateData = [
                'title' => $validated['title'],
                'content_type' => $contentType,
                'content_text' => ($contentType !== LmsContentType::FILE_UPLOAD && $contentType !== LmsContentType::VIDEO_UPLOAD) ? ($validated['content_text'] ?? null) : null,
            ];

            $diskName = 'private';
            $oldFilePath = $lesson->content_file_path;
            $newFilePath = null;
            $originalFilename = $lesson->original_filename;

            if (filter_var($request->input('remove_file', false), FILTER_VALIDATE_BOOLEAN)) {
                if ($oldFilePath && Storage::disk($diskName)->exists($oldFilePath)) {
                    Storage::disk($diskName)->delete($oldFilePath);
                }
                $updateData['content_file_path'] = null;
                $updateData['original_filename'] = null;
                $originalFilename = null;
            } elseif ($request->hasFile('lesson_file')) {
                $file = $request->file('lesson_file');
                $directory = "lms/course_{$lesson->lms_course_id}/lessons";
                try {
                    if ($oldFilePath && Storage::disk($diskName)->exists($oldFilePath)) {
                        Storage::disk($diskName)->delete($oldFilePath);
                    }
                    $originalFilename = $file->getClientOriginalName();
                    $newFilePath = $file->store($directory, $diskName);
                    if (! $newFilePath) {
                        throw new Exception('Failed to store new lesson file.');
                    }
                    $updateData['content_file_path'] = $newFilePath;
                    $updateData['original_filename'] = $originalFilename;
                    $updateData['content_text'] = null;
                } catch (Exception $e) {
                    DB::rollBack();
                    Log::error('Lesson file update error: '.$e->getMessage());

                    return response()->json(['success' => false, 'message' => 'Could not save new lesson file.'], 500);
                }
            } elseif ($contentType !== LmsContentType::FILE_UPLOAD && $contentType !== LmsContentType::VIDEO_UPLOAD && $oldFilePath && ! $request->hasFile('lesson_file')) {
                if (Storage::disk($diskName)->exists($oldFilePath)) {
                    Storage::disk($diskName)->delete($oldFilePath);
                }
                $updateData['content_file_path'] = null;
                $updateData['original_filename'] = null;
                $originalFilename = null;
            } elseif (($contentType === LmsContentType::TEXT || $contentType === LmsContentType::VIDEO_EMBED || $contentType === LmsContentType::EXTERNAL_LINK) && ! $request->hasFile('lesson_file')) {
                $updateData['content_file_path'] = null;
                $updateData['original_filename'] = null;
                $originalFilename = null;
            }

            $lesson->update($updateData);

            DB::commit();
            Log::info("LMS Lesson updated: ID {$lesson->id} by User ".Auth::id());

            return response()->json([
                'success' => true,
                'message' => 'Lesson updated successfully.',
                'lesson' => [
                    'id' => $lesson->id,
                    'title' => $lesson->title,
                    'contentType' => $lesson->content_type->value,
                    'currentFileName' => $originalFilename,
                ],
            ]);
        } catch (Exception $e) {
            DB::rollBack();
            if ($newFilePath && $newFilePath !== $oldFilePath && isset($diskName) && Storage::disk($diskName)->exists($newFilePath)) {
                Storage::disk($diskName)->delete($newFilePath);
            }
            Log::error("Error updating LMS lesson {$lesson->id}: ".$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to update lesson.'], 500);
        }
    }

    /**
     * Remove the specified lesson from storage.
     * Route: DELETE /lms/lessons/{lesson}
     * Name: lms.lessons.destroy
     */
    public function destroy(Lesson $lesson): JsonResponse
    {
        if (! $this->authorizeLessonAccess($lesson)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        DB::beginTransaction();
        try {
            $lessonId = $lesson->id;
            $filePath = $lesson->content_file_path;
            $diskName = 'private';

            // Optionally check for completions before deleting?
            // if ($lesson->completions()->exists()) { ... return error ... }

            // Delete the database record first
            $lesson->delete(); // This should cascade delete completions if FK is set up

            // Delete the associated file from storage
            if ($filePath && Storage::disk($diskName)->exists($filePath)) {
                Storage::disk($diskName)->delete($filePath);
            }

            DB::commit();
            Log::info("LMS Lesson deleted: ID {$lessonId} by User ".Auth::id());

            return response()->json(['success' => true, 'message' => 'Lesson deleted successfully.']);

        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Error deleting LMS lesson {$lesson->id}: ".$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to delete lesson.'], 500);
        }
    }

    /**
     * Update the order of lessons within a specific course.
     * Route: POST /lms/courses/{course}/lessons/reorder
     * Name: lms.courses.lessons.reorder
     */
    public function reorder(Request $request, Course $course): JsonResponse
    {
        if (! $this->authorizeCourseAccess($course)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        $validator = Validator::make($request->all(), [
            'orderedLessonIds' => 'required|array',
            'orderedLessonIds.*' => 'required|integer',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => 'Invalid data provided.'], 422);
        }

        $orderedLessonIds = $request->input('orderedLessonIds');

        DB::beginTransaction();
        try {
            // Fetch only lesson IDs belonging to this course for verification
            $lessonsMap = $course->lessons()->pluck('id')->flip();

            foreach ($orderedLessonIds as $index => $lessonId) {
                if ($lessonsMap->has($lessonId)) { // Update only if ID belongs to this course
                    Lesson::where('id', $lessonId)
                        ->update(['order_column' => $index]);
                }
            }
            DB::commit();
            Log::info("Lessons reordered for Course ID {$course->id} by User ".Auth::id());

            return response()->json(['success' => true, 'message' => 'Lesson order saved.']);

        } catch (\Exception $e) {
            DB::rollBack();
            Log::error("Error reordering lessons for course {$course->id}: ".$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to save lesson order.'], 500);
        }
    }

    /**
     * Handle secure download/streaming of lesson file content.
     * Route: GET /lms/lessons/{lesson}/content/download
     * Name: lms.lessons.downloadFile
     */
    public function downloadFile(Lesson $lesson) // Using Route Model Binding
    {
        $user = Auth::user();

        // 1. Authorization: Check if user is enrolled in the course for this lesson
        $isEnrolled = CourseEnrollment::where('user_id', $user->id)
            ->where('lms_course_id', $lesson->lms_course_id)
          // Optionally check if enrollment is active/not completed?
            ->exists();

        if (! $isEnrolled /* && !$user->can('preview_lms_lessons') */) { // Allow admins/previewers?
            Log::warning("Unauthorized attempt to download lesson file ID {$lesson->id} by User ID {$user->id}.");
            abort(403, 'You are not enrolled in this course or do not have permission to access this file.');
        }

        // 2. Check if lesson type is file/video and path exists
        $isFileType = in_array($lesson->content_type, [LmsContentType::FILE_UPLOAD, LmsContentType::VIDEO_UPLOAD]);
        $filePath = $lesson->content_file_path;
        $diskName = 'private'; // IMPORTANT: Use the correct private disk

        if (! $isFileType || ! $filePath) {
            Log::warning("Attempt to download non-file/video lesson or missing path. Lesson ID {$lesson->id}.");
            abort(404, 'File content not found for this lesson.');
        }

        // 3. Check if file exists on storage
        if (! Storage::disk($diskName)->exists($filePath)) {
            Log::error("Lesson file missing from storage. Lesson ID {$lesson->id}, Path: {$filePath}, Disk: {$diskName}");
            abort(404, 'File not found in storage.');
        }

        // 4. Serve the file
        try {
            $fileName = $lesson->original_filename ?? basename($filePath); // Use original name if available

            // For most files (PDF, DOCX, ZIP etc.), force download
            if ($lesson->content_type === LmsContentType::FILE_UPLOAD) {
                return Storage::disk($diskName)->download($filePath, $fileName);
            }

            // For video files, stream the response
            if ($lesson->content_type === LmsContentType::VIDEO_UPLOAD) {
                // Use response() for streaming with appropriate headers
                // Let browser handle playback
                return Storage::disk($diskName)->response($filePath);
            }

            // Fallback download for other potential file types
            return Storage::disk($diskName)->download($filePath, $fileName);

        } catch (Exception $e) {
            Log::error("Error serving lesson file {$filePath} for lesson {$lesson->id}: ".$e->getMessage());
            abort(500, 'Could not process file download.');
        }
    }
}
