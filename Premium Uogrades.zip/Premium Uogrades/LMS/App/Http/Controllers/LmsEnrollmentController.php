<?php

namespace Modules\LMS\App\Http\Controllers;

use App\Enums\UserAccountStatus;
use App\Http\Controllers\Controller;
use App\Models\Designation; // Use models from module
use App\Models\User;
use Carbon\Carbon; // Assuming User model is in App\Models
use Exception; // Assuming Designation model exists
use Illuminate\Http\JsonResponse; // Assuming User status enum exists
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Modules\LMS\App\Enums\LmsEnrollmentStatus;
use Modules\LMS\App\Models\Course;
use Modules\LMS\App\Models\CourseEnrollment;
use Yajra\DataTables\Facades\DataTables;

class LmsEnrollmentController extends Controller
{
    /**
     * Authorization helper (Placeholder)
     */
    private function authorizeCourseAccess(Course $course): bool
    {
        // TODO: Implement proper authorization check (policy or permission)
        return true;
    }

    /**
     * Authorization helper for specific enrollment (Placeholder)
     */
    private function authorizeEnrollmentAccess(CourseEnrollment $enrollment): bool
    {
        // TODO: Implement proper authorization check
        $enrollment->loadMissing('course');

        return $enrollment->course && $this->authorizeCourseAccess($enrollment->course);
    }

    /**
     * Handle enrollment creation for a specific course.
     * Accepts both direct user IDs and designation IDs.
     * Route: POST /lms/courses/{course}/enrollments
     * Name: lms.enrollments.store
     */
    public function store(Request $request, Course $course): JsonResponse
    {
        if (! $this->authorizeCourseAccess($course)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized'], 403);
        }

        // Custom validation rule to ensure at least one selection type is provided
        Validator::extend('require_at_least_one', function ($attribute, $value, $parameters, $validator) {
            $data = $validator->getData();
            foreach ($parameters as $param) {
                if (! empty($data[$param])) {
                    return true;
                }
            }

            return false;
        });

        $validator = Validator::make($request->all(), [
            'user_ids' => ['nullable', 'array', 'require_at_least_one:user_ids,designation_ids'],
            'user_ids.*' => ['required_with:user_ids', 'integer', 'distinct', Rule::exists('users', 'id')->where('status', UserAccountStatus::ACTIVE)],
            'designation_ids' => ['nullable', 'array', 'require_at_least_one:user_ids,designation_ids'],
            'designation_ids.*' => ['required_with:designation_ids', 'integer', 'distinct', Rule::exists('designations', 'id')],
        ], [
            'user_ids.require_at_least_one' => 'Please select at least one user or designation to enroll.',
            'designation_ids.require_at_least_one' => 'Please select at least one user or designation to enroll.',
            'user_ids.*.exists' => 'One or more selected users are invalid or inactive.',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        }

        DB::beginTransaction();
        try {
            $userIdsToEnroll = $request->input('user_ids', []);
            $designationIds = $request->input('designation_ids', []);
            $newlyEnrolledCount = 0;
            $dataToInsert = [];
            $now = Carbon::now();
            $loggedInUserId = Auth::id();

            // 1. Get users from selected designations
            if (! empty($designationIds)) {
                $designationUserIds = User::whereIn('designation_id', $designationIds)
                    ->where('status', UserAccountStatus::ACTIVE)
                    ->pluck('id')
                    ->toArray();
                // Merge and unique
                $userIdsToEnroll = array_unique(array_merge($userIdsToEnroll, $designationUserIds));
            }

            // 2. Exclude users already enrolled in this course
            if (! empty($userIdsToEnroll)) {
                $existingEnrollmentUserIds = $course->enrollments()
                    ->whereIn('user_id', $userIdsToEnroll)
                    ->pluck('user_id')
                    ->toArray();

                $newEnrollmentUserIds = array_diff($userIdsToEnroll, $existingEnrollmentUserIds);

                // 3. Prepare data for bulk insert
                foreach ($newEnrollmentUserIds as $userId) {
                    $dataToInsert[] = [
                        'lms_course_id' => $course->id,
                        'user_id' => $userId,
                        'status' => LmsEnrollmentStatus::NOT_STARTED->value, // Use Enum value
                        'enrolled_by_id' => $loggedInUserId,
                        'enrolled_at' => $now,
                        'created_at' => $now,
                        'updated_at' => $now,
                    ];
                }

                // 4. Perform bulk insert if there are new users to enroll
                if (! empty($dataToInsert)) {
                    CourseEnrollment::insert($dataToInsert);
                    $newlyEnrolledCount = count($dataToInsert);
                }
            }

            DB::commit();
            Log::info("{$newlyEnrolledCount} users enrolled in LMS Course ID {$course->id} by User {$loggedInUserId}.");
            $message = $newlyEnrolledCount > 0
              ? "Successfully enrolled {$newlyEnrolledCount} new user(s)."
              : 'No new users were enrolled (selected users might already be enrolled).';

            return response()->json(['success' => true, 'message' => $message, 'enrolled_count' => $newlyEnrolledCount]);

        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Error enrolling users in LMS course {$course->id}: ".$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to enroll users due to a server error.'], 500);
        }
    }

    /**
     * Handle DataTables AJAX request for enrollments of a specific course.
     * Route: GET /lms/courses/{course}/enrollments/list
     * Name: lms.enrollments.listAjax
     */
    public function listAjax(Request $request, Course $course): JsonResponse
    {
        if (! $this->authorizeCourseAccess($course)) {
            return response()->json(['data' => []]); // Return empty data on unauthorized
        }

        // Get total lesson count for progress calculation
        $totalLessons = $course->lessons()->count();

        $query = CourseEnrollment::where('lms_course_id', $course->id)
            ->with(['user:id,first_name,last_name,code'])
          // Eager load count of completed lessons for this enrollment
            ->withCount('lessonCompletions');

        return DataTables::eloquent($query)
            ->editColumn('user', function ($enrollment) {
                return view('_partials._profile-avatar', ['user' => $enrollment->user])->render();
            })
            ->editColumn('status', function ($enrollment) {
                $status = $enrollment->status; // Already cast to Enum
                $badgeClass = $status->colorClass(); // Use helper from Enum

                return '<span class="badge rounded-pill '.$badgeClass.'">'.$status->label().'</span>';
            })
            ->editColumn('enrolled_at', function ($enrollment) {
                return $enrollment->enrolled_at ? Carbon::parse($enrollment->enrolled_at)->format('d M Y') : '-';
            })
            ->editColumn('completed_at', function ($enrollment) {
                return $enrollment->completed_at ? Carbon::parse($enrollment->completed_at)->format('d M Y, H:i') : '-';
            })
            ->addColumn('progress', function ($enrollment) use ($totalLessons) { // New column for progress
                $completedCount = $enrollment->lesson_completions_count; // Use eager loaded count
                $progressPercent = ($totalLessons > 0) ? round(($completedCount / $totalLessons) * 100) : 0;

                $html = '<div class="d-flex align-items-center gap-2">';
                $html .= '<small>'.$completedCount.'/'.$totalLessons.'</small>';
                $html .= '<div class="progress w-100" style="height: 6px;">';
                $html .= '<div class="progress-bar bg-success" role="progressbar" style="width: '.$progressPercent.'%;" aria-valuenow="'.$progressPercent.'" aria-valuemin="0" aria-valuemax="100"></div>';
                $html .= '</div>';
                $html .= '</div>';

                return $html;
            })
            ->addColumn('actions', function ($enrollment) {
                $unenrollUrl = route('lms.courses.enrollments.destroy', ['course' => $enrollment->course->id, 'enrollment' => $enrollment->id]);
                $progressUrl = route('lms.courses.enrollments.progress', ['course' => $enrollment->course->id, 'enrollmentId' => $enrollment->id]);

                // View Progress Button (triggers JS modal)
                $progressButton = '<button class="btn btn-sm btn-icon me-1 view-enrollment-progress" data-id="'.$enrollment->id.'" data-url="'.$progressUrl.'" title="View Progress"><i class="bx bx-show text-info"></i></button>';
                // Unenroll Button
                $deleteButton = '<button class="btn btn-sm btn-icon text-danger delete-enrollment" data-id="'.$enrollment->id.'" data-url="'.$unenrollUrl.'" title="Unenroll User"><i class="bx bx-user-minus"></i></button>';

                return '<div class="d-flex justify-content-center">'.$progressButton.$deleteButton.'</div>';
            })
          // Specify raw columns
            ->rawColumns(['user_display', 'status', 'progress', 'actions', 'user'])
            ->make(true);
    }

    /**
     * Fetch detailed progress for a specific enrollment, including lesson completion status.
     * Route: GET /lms/enrollments/{enrollment}/progress
     * Name: lms.enrollments.progress
     */
    public function getProgressDetails($enrollmentId): JsonResponse
    {

        Log::info('Progress ID: '.$enrollmentId);

        $enrollment = CourseEnrollment::find($enrollmentId);

        if (! $enrollment) {
            return response()->json(['success' => false, 'message' => 'Enrollment record not found. '.$enrollmentId], 404);
        }

        try {
            $enrollment->load([
                'user:id,first_name,last_name,code',
                'course' => function ($q) {
                    // Load course with its lessons in order
                    $q->select('id', 'title')
                        ->with(['lessons' => function ($lq) {
                            $lq->select('id', 'lms_course_id', 'title', 'order_column')->orderBy('order_column');
                        }]);
                },
                'lessonCompletions:lms_enrollment_id,lms_lesson_id,completed_at', // Load completions for THIS enrollment
            ]);

            if (! $enrollment->course) {
                return response()->json(['success' => false, 'message' => 'Course not found for this enrollment.'], 404);
            }

            // Create a map of completed lesson IDs and completion dates for easy lookup
            $completedLessonsMap = $enrollment->lessonCompletions->keyBy('lms_lesson_id');

            // Map all course lessons, adding completion status for this enrollment
            $lessonProgress = $enrollment->course->lessons->map(function ($lesson) use ($completedLessonsMap) {
                $completion = $completedLessonsMap->get($lesson->id);

                return [
                    'id' => $lesson->id,
                    'title' => $lesson->title,
                    'isCompleted' => $completion !== null,
                    'completedAt' => $completion?->completed_at?->format('M d, Y H:i'), // Format date if completed
                ];
            });

            $totalLessons = $enrollment->course->lessons->count();
            $completedCount = $completedLessonsMap->count();
            $progressPercent = ($totalLessons > 0) ? round(($completedCount / $totalLessons) * 100) : 0;

            $data = [
                'userName' => $enrollment->user?->getFullName() ?? 'Unknown',
                'courseTitle' => $enrollment->course->title,
                'status' => $enrollment->status->label(), // Use label from Enum
                'statusClass' => $enrollment->status->colorClass(), // Use color from Enum
                'enrolledAt' => $enrollment->enrolled_at?->format('M d, Y'),
                'startedAt' => $enrollment->started_at?->format('M d, Y'),
                'completedAt' => $enrollment->completed_at?->format('M d, Y'),
                'progressPercent' => $progressPercent,
                'completedCount' => $completedCount,
                'totalLessons' => $totalLessons,
                'lessons' => $lessonProgress, // Array of lessons with completion status
            ];

            return response()->json(['success' => true, 'data' => $data]);

        } catch (Exception $e) {
            Log::error("Error fetching progress for enrollment {$enrollment->id}: ".$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to load progress details.'], 500);
        }
    }

    public function destroy($id): JsonResponse // Accept the ID directly
    {
        // Find the enrollment record manually
        try {
            // Use firstOrFail to automatically throw ModelNotFoundException (404) if ID invalid
            $enrollment = CourseEnrollment::findOrFail($id);
        } catch (\Illuminate\Database\Eloquent\ModelNotFoundException $e) {
            return response()->json(['success' => false, 'message' => 'Enrollment record not found.'], 404);
        }

        // Now perform authorization check on the found model
        if (! $this->authorizeEnrollmentAccess($enrollment)) {
            return response()->json(['success' => false, 'message' => 'Unauthorized action.'], 403);
        }

        // Proceed with deletion logic
        DB::beginTransaction();
        try {
            $userId = $enrollment->user_id;
            $courseId = $enrollment->lms_course_id;
            $loggedInUserId = Auth::id();
            $enrollmentId = $enrollment->id; // Get ID before deleting

            // Delete the enrollment record
            $enrollment->delete(); // cascadeOnDelete should handle lesson completions

            DB::commit();

            Log::info("User ID {$userId} unenrolled from LMS Course ID {$courseId} by User {$loggedInUserId}. (Enrollment ID: {$enrollmentId})");

            return response()->json(['success' => true, 'message' => 'User unenrolled successfully.']);

        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Error unenrolling user (Enrollment ID {$id}): ".$e->getMessage()); // Use $id from parameter in error

            return response()->json(['success' => false, 'message' => 'Failed to unenroll user.'], 500);
        }
    }
}
