<?php

namespace Modules\LMS\App\Http\Controllers; // API namespace within module

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Modules\LMS\App\Enums\LmsContentType;
use Modules\LMS\App\Enums\LmsEnrollmentStatus;
use Modules\LMS\App\Models\CourseEnrollment;
use Modules\LMS\App\Models\Lesson;
use Modules\LMS\App\Models\LessonCompletion;

class MyLmsApiController extends Controller
{
    /**
     * Mark a specific lesson as complete for the authenticated user.
     * Route: POST /lms/lessons/{lesson}/complete
     * Name: lms.api.lesson.complete
     */
    public function markLessonComplete(Lesson $lesson): JsonResponse // Route model binding for lesson
    {
        $user = Auth::user();
        $userId = $user->id;

        try {
            // Find the user's enrollment for the course this lesson belongs to
            $enrollment = CourseEnrollment::where('user_id', $userId)
                ->where('lms_course_id', $lesson->lms_course_id)
                ->first();

            if (! $enrollment) {
                return response()->json(['success' => false, 'message' => 'You are not enrolled in this course.'], 403);
            }

            DB::beginTransaction();

            // Create the completion record if it doesn't exist
            LessonCompletion::firstOrCreate(
                [
                    'lms_enrollment_id' => $enrollment->id,
                    'lms_lesson_id' => $lesson->id,
                    'user_id' => $userId, // Include user_id
                ],
                [
                    'completed_at' => now(),
                    // 'tenant_id' should be handled by trait or relationship
                ]
            );

            // Update enrollment status to In Progress if it was Not Started
            if ($enrollment->status == LmsEnrollmentStatus::NOT_STARTED) {
                $enrollment->status = LmsEnrollmentStatus::IN_PROGRESS;
                $enrollment->started_at = $enrollment->started_at ?? now(); // Set started_at if not already set
                $enrollment->save();
            }

            // Check if all lessons in the course are now complete for this enrollment
            $totalLessons = $enrollment->course->lessons()->count(); // Get total lessons count
            $completedLessons = $enrollment->lessonCompletions()->count(); // Get completed count for this enrollment

            $allComplete = ($totalLessons > 0 && $completedLessons >= $totalLessons);

            // Update overall course enrollment status if all lessons are complete
            if ($allComplete && $enrollment->status != LmsEnrollmentStatus::COMPLETED) {
                $enrollment->status = LmsEnrollmentStatus::COMPLETED;
                $enrollment->completed_at = now();
                $enrollment->save();
                Log::info("User {$userId} completed Course ID {$enrollment->lms_course_id}.");
                // TODO: Trigger certificate generation? Notification?
            }

            DB::commit();

            return response()->json([
                'success' => true,
                'message' => 'Lesson marked as complete.',
                'allComplete' => $allComplete, // Indicate if course is now complete
                'newStatus' => $enrollment->status->value, // Send back current enrollment status
            ]);

        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Error marking lesson {$lesson->id} complete for user {$userId}: ".$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to mark lesson complete.'], 500);
        }
    }

    /**
     * (Optional) Get content for a specific lesson.
     * Route: GET /lms/lessons/{lesson}/content
     * Name: lms.api.lesson.content
     */
    public function getLessonContent(Lesson $lesson): JsonResponse
    {
        $user = Auth::user();
        // 1. Check if user is enrolled in the course
        $isEnrolled = CourseEnrollment::where('user_id', $user->id)
            ->where('lms_course_id', $lesson->lms_course_id)
            ->exists();
        if (! $isEnrolled) {
            return response()->json(['success' => false, 'message' => 'Not enrolled in this course.'], 403);
        }

        // 2. Authorization passed, return lesson details
        // Maybe add secure URL generation for private files here if content_type is file/video
        $fileUrl = null;
        if (($lesson->content_type == LmsContentType::FILE_UPLOAD || $lesson->content_type == LmsContentType::VIDEO_UPLOAD) && $lesson->content_file_path) {
            // Generate temporary signed URL for private files if using S3 etc.
            // Or generate URL via a dedicated download route
            try {
                $fileUrl = Storage::disk('private')->url($lesson->content_file_path);
            } catch (\Exception $e) {
            } // Example, adjust disk/method
        }

        return response()->json([
            'success' => true,
            'lesson' => [
                'id' => $lesson->id,
                'title' => $lesson->title,
                'contentType' => $lesson->content_type->value,
                'contentText' => $lesson->content_text,
                'contentFilePath' => $lesson->content_file_path, // Path relative to disk root
                'originalFilename' => $lesson->original_filename,
                'contentUrl' => $fileUrl, // Secure URL for file/video if applicable
            ],
        ]);
    }
}
