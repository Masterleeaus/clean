<?php

namespace Modules\LMS\App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Modules\LMS\App\Enums\LmsContentType;
use Modules\LMS\App\Enums\LmsCourseStatus;
use Modules\LMS\App\Enums\LmsEnrollmentStatus;
use Modules\LMS\App\Models\CourseCategory;
use Modules\LMS\App\Models\CourseEnrollment;

class MyLmsWebController extends Controller
{
    /**
     * Display the "My Courses" page for the logged-in employee.
     * Route: GET /my-learning
     * Name: lms.my.courses
     */
    public function index()
    {
        $user = Auth::user();
        $userId = $user->id;

        try {
            // Get active enrollments for the user
            $enrollments = CourseEnrollment::where('user_id', $userId)
                ->with([
                    'course' => function ($query) {
                        // Select necessary course fields & category
                        $query->select('id', 'lms_course_category_id', 'title', 'description', 'estimated_duration', 'thumbnail_path', 'status')
                            ->where('status', LmsCourseStatus::PUBLISHED) // Only show published courses
                            ->with('category:id,name');
                    },
                    // Load completions to calculate progress
                    'lessonCompletions:id,lms_enrollment_id,lms_lesson_id',
                    // Load total lesson count for progress calculation
                    'course.lessons:id,lms_course_id', // Only need ID and course ID for count
                ])
                ->whereHas('course', function ($query) { // Ensure the course itself is published
                    $query->where('status', LmsCourseStatus::PUBLISHED);
                })
                ->orderBy('created_at', 'desc') // Order by enrollment date
                ->get();

            // Calculate progress for each enrollment
            $enrollments->each(function ($enrollment) {
                if ($enrollment->course) { // Check if course relationship loaded
                    $totalLessons = $enrollment->course->lessons->count();
                    $completedLessons = $enrollment->lessonCompletions->count();
                    $enrollment->progressPercent = ($totalLessons > 0) ? round(($completedLessons / $totalLessons) * 100) : 0;
                    // Determine overall status (might override DB status based on progress)
                    if ($enrollment->status != LmsEnrollmentStatus::COMPLETED && $completedLessons > 0 && $completedLessons < $totalLessons) {
                        $enrollment->derived_status = LmsEnrollmentStatus::IN_PROGRESS;
                    } elseif ($enrollment->status == LmsEnrollmentStatus::COMPLETED || ($totalLessons > 0 && $completedLessons >= $totalLessons)) {
                        $enrollment->derived_status = LmsEnrollmentStatus::COMPLETED;
                    } else {
                        $enrollment->derived_status = LmsEnrollmentStatus::NOT_STARTED;
                    }

                } else {
                    $enrollment->progressPercent = 0; // Handle case where course might be deleted/missing
                    $enrollment->derived_status = $enrollment->status; // Use original status
                }
            });

            // Get categories for filtering dropdown
            $categories = CourseCategory::where('is_active', true)
              // ->whereHas('courses.enrollments', fn($q) => $q->where('user_id', $userId)) // Only categories user is enrolled in?
                ->orderBy('name')->select('id', 'name')->get();

            return view('lms::my-courses.index', compact('enrollments', 'categories'));

        } catch (\Exception $e) {
            Log::error("Error fetching My Courses for user {$userId}: ".$e->getMessage());

            // Return view with error message or redirect
            return view('lms::my-courses.index')->withErrors(['load_error' => 'Could not load your courses. Please try again later.']);
        }
    }

    /**
     * Display the Course Player/Details page for a specific enrollment.
     * Route: GET /my-learning/course/{enrollment}
     * Name: lms.my.course.show
     */
    public function showCourse(CourseEnrollment $enrollment) // Route model binding
    {
        $user = Auth::user();

        // Authorization: Ensure the logged-in user owns this enrollment
        if ($enrollment->user_id !== $user->id) {
            Log::warning("User {$user->id} attempted to access enrollment {$enrollment->id} owned by user {$enrollment->user_id}.");
            abort(403, 'Access denied.');
        }

        try {
            // Eager load course details, all lessons (ordered), and this user's completions for THIS enrollment
            $enrollment->load([
                'course' => function ($query) {
                    $query->with('category:id,name') // Load category
                    // Optionally load instructor if relationship exists
                    // ->with('instructor:id,first_name,last_name')
                        ->select('id', 'lms_course_category_id', 'title', 'description', 'status', 'thumbnail_path', 'estimated_duration'); // Select needed course fields
                },
                'course.lessons' => function ($query) {
                    $query->select('id', 'lms_course_id', 'title', 'content_type', 'content_text', 'order_column', 'content_file_path', 'original_filename') // Select needed lesson fields
                        ->orderBy('order_column', 'asc');
                },
                'lessonCompletions:id,lms_enrollment_id,lms_lesson_id', // Load completions for THIS enrollment only
            ]);

            if (! $enrollment->course || $enrollment->course->status !== LmsCourseStatus::PUBLISHED) {
                // Course might have been unpublished/deleted after enrollment
                return redirect()->route('lms.my.courses')->with('error', 'This course is no longer available.');
            }

            // Create a simple Set of completed lesson IDs for easy checking in the view
            $completedLessonIds = $enrollment->lessonCompletions->pluck('lms_lesson_id')->flip(); // Using flip for O(1) lookup

            // Mark enrollment as 'in_progress' if it was 'not_started' and being viewed now
            if ($enrollment->status == LmsEnrollmentStatus::NOT_STARTED) {
                $enrollment->status = LmsEnrollmentStatus::IN_PROGRESS;
                $enrollment->started_at = now();
                $enrollment->save();
            }

            $lessons = $enrollment->course->lessons->map(function ($lesson) {
                $contentData = null;
                $contentType = $lesson->content_type; // Enum instance

                if ($contentType == LmsContentType::TEXT || $contentType == LmsContentType::VIDEO_EMBED || $contentType == LmsContentType::EXTERNAL_LINK) {
                    $contentData = $lesson->content_text;
                }
                // --- UPDATED PART ---
                elseif (($contentType == LmsContentType::FILE_UPLOAD || $contentType == LmsContentType::VIDEO_UPLOAD) && $lesson->content_file_path) {
                    // Generate the URL to the secure download route instead of using the path
                    try {
                        $contentData = route('lms.lessons.downloadFile', $lesson->id); // Use the named route
                    } catch (\Exception $e) {
                        Log::error("Could not generate download route for lesson {$lesson->id}: ".$e->getMessage());
                        $contentData = '#error-generating-url'; // Placeholder URL
                    }
                }
                // --- END UPDATED PART ---
                // Note: QUIZ content type is not yet implemented in LmsContentType enum
                // When QUIZ is added to the enum, handle it here:
                // elseif ($contentType == LmsContentType::QUIZ) {
                //     $contentData = 'quiz_placeholder';
                // }

                // Add the prepared data back to the lesson object (or create a new structure)
                // Adding as a temporary attribute is easy but not ideal. Creating DTOs is better.
                // For simplicity, let's pass it alongside the collection. We'll adjust Blade/JS.
                // Let's modify the structure slightly for clarity in Blade/JS:
                return [
                    'id' => $lesson->id,
                    'title' => $lesson->title,
                    'contentType' => $contentType->value,
                    'contentData' => $contentData, // This now holds text, embed code, EXTERNAL URL, or the DOWNLOAD URL
                    'originalFilename' => $lesson->original_filename, // Useful for file types
                    'orderColumn' => $lesson->order_column,
                    // Add other fields if needed by view, like duration
                ];

            })->toArray();

            return view('lms::my-courses.show',
                [
                    'enrollment' => $enrollment,
                    'course' => $enrollment->course, // Pass course directly
                    'lessons' => collect($lessons), // Pass lessons directly
                    'completedLessonIds' => $completedLessonIds, // Pass completed lesson IDs
                ]);

        } catch (\Exception $e) {
            Log::error("Error fetching course details for user {$user->id}, enrollment {$enrollment->id}: ".$e->getMessage());

            return redirect()->route('lms.my.courses')->with('error', 'Could not load the course. Please try again.');
        }
    }
}
