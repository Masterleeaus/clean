<?php

namespace Modules\LMS\App\Http\Controllers;

use App\Enums\UserAccountStatus;
use App\Http\Controllers\Controller;
use App\Models\Designation;
use App\Models\Role;
use App\Models\User;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Enum as EnumRule;
use Modules\LMS\App\Enums\LmsCourseStatus;
use Modules\LMS\App\Enums\LmsEnrollmentStatus;
use Modules\LMS\App\Models\Course;
use Modules\LMS\App\Models\CourseCategory;
use Yajra\DataTables\Facades\DataTables;

class LmsCourseController extends Controller
{
    /**
     * Display the courses management view.
     * Route: GET /lms/courses
     * Name: lms.courses.index
     */
    public function index()
    {
        // abort_if_cannot('view_lms_courses');

        // Data needed for filters and Add/Edit modal
        $categories = CourseCategory::where('is_active', true)->orderBy('name')->select('id', 'name')->get();
        $statuses = LmsCourseStatus::cases(); // Get all cases from the Enum

        return view('lms::courses.index', compact('categories', 'statuses')); // Point to module view
    }

    /**
     * Handle DataTables AJAX request for courses.
     * Route: GET /lms/courses/list
     * Name: lms.courses.listAjax
     */
    public function listAjax(Request $request): JsonResponse
    {
        // abort_if_cannot('view_lms_courses');

        $query = Course::with(['category:id,name']) // Eager load category name
            ->withCount(['lessons', 'enrollments']) // Count lessons and enrollments
            ->select('lms_courses.*'); // Select columns

        // --- Filtering ---
        if ($request->filled('filter_category_id')) {
            $query->where('lms_course_category_id', $request->input('filter_category_id'));
        }
        if ($request->filled('filter_status')) {
            $query->where('status', $request->input('filter_status'));
        }
        if ($request->filled('search.value')) {
            $searchValue = $request->input('search.value');
            $query->where(function ($q) use ($searchValue) {
                $q->where('title', 'LIKE', "%{$searchValue}%")
                    ->orWhere('description', 'LIKE', "%{$searchValue}%");
            });
        }
        // --- End Filtering ---

        return DataTables::eloquent($query)
            ->addColumn('category_name', function ($course) {
                return $course->category?->name ?? '<span class="text-muted">None</span>';
            })
            ->editColumn('status', function ($course) {
                $status = $course->status; // Already cast to Enum
                $badgeClass = $status->colorClass(); // Use helper from Enum

                return '<span class="badge '.$badgeClass.'">'.$status->label().'</span>';
            })
            ->addColumn('lessons_count_display', function ($course) {
                return $course->lessons()->count();
            })
            ->addColumn('enrollments_count_display', function ($course) {
                return $course->enrollments()->count();
            })
            ->addColumn('actions', function ($course) {
                $editUrl = route('lms.courses.edit', $course->id);
                $deleteUrl = route('lms.courses.destroy', $course->id);
                // Placeholder URL for managing lessons of this course
                $manageLessonsUrl = route('lms.courses.lessons.index', $course->id);

                $viewUrl = route('lms.courses.show', $course->id);

                $editButton = '<button class="btn btn-sm btn-icon me-1 edit-course" data-id="'.$course->id.'" data-url="'.$editUrl.'" title="Edit Course"><i class="bx bx-pencil"></i></button>';
                // Pass enrollment count for delete check
                $deleteButton = '<button class="btn btn-sm btn-icon text-danger delete-course" data-id="'.$course->id.'" data-url="'.$deleteUrl.'" title="Delete Course" data-enrollments="'.$course->enrollments_count.'"><i class="bx bx-trash"></i></button>';
                // Button to go to lesson management page (implement later)
                $lessonsButton = '<a href="'.$manageLessonsUrl.'" class="btn btn-sm btn-icon me-1" title="Manage Lessons"><i class="bx bx-list-ul"></i></a>';

                $viewButton = '<a href="'.$viewUrl.'" class="btn btn-sm btn-icon me-1" title="View Course"><i class="bx bx-show"></i></a>';

                return '<div class="d-flex justify-content-center">'.$viewButton.$lessonsButton.$editButton.$deleteButton.'</div>';
            })
            ->rawColumns(['category_name', 'status', 'actions'])
            ->make(true);
    }

    /**
     * Display the specified course details page.
     * Route: GET /lms/courses/{course}
     * Name: lms.courses.show
     */
    public function show(Course $course) // Route model binding
    {
        // abort_if_cannot('view_lms_courses');
        // Add tenant check if needed

        // Eager load necessary data for display and modals
        $course->loadCount(['lessons', 'enrollments']);
        $course->load(['category:id,name']);

        // Data needed for the "Enroll Users" modal
        $users = User::where('status', UserAccountStatus::ACTIVE)
            ->orderBy('first_name')
            ->select('id', 'first_name', 'last_name', 'code') // Include code for display
            ->get();

        // Get roles for potential role-based enrollment later
        $roles = Role::orderBy('name')->select('id', 'name')->get();

        $designations = Designation::orderBy('name')->select('id', 'name')->get();

        // Pass data to the view
        return view('lms::courses.show', compact(
            'course',
            'users', // For user selection modal
            'roles',
            'designations'
        ));
    }

    /**
     * Store a newly created course in storage.
     * Route: POST /lms/courses
     * Name: lms.courses.store
     */
    public function store(Request $request): JsonResponse
    {
        // abort_if_cannot('create_lms_courses');

        $validator = Validator::make($request->all(), [
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'lms_course_category_id' => 'nullable|exists:lms_course_categories,id',
            'status' => ['required', new EnumRule(LmsCourseStatus::class)],
            'estimated_duration' => 'nullable|string|max:50',
            'thumbnail' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'], // 2MB Max for thumbnail
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        }

        DB::beginTransaction();
        try {
            $validatedData = $validator->validated();
            $thumbnailPath = null;

            // Handle Thumbnail Upload
            if ($request->hasFile('thumbnail')) {
                $file = $request->file('thumbnail');
                $diskName = 'public'; // Use public for thumbnails if they need to be web accessible
                $tenantId = Auth::user()->tenant_id; // Assuming tenant context
                $directory = "lms/course_thumbnails/{$tenantId}";
                $thumbnailPath = $file->store($directory, $diskName);
                if (! $thumbnailPath) {
                    throw new Exception('Failed to store thumbnail.');
                }
            }

            $course = Course::create([
                'title' => $validatedData['title'],
                'description' => $validatedData['description'] ?? null,
                'lms_course_category_id' => $validatedData['lms_course_category_id'] ?? null,
                'status' => $validatedData['status'], // Already Enum instance
                'estimated_duration' => $validatedData['estimated_duration'] ?? null,
                'thumbnail_path' => $thumbnailPath,
                // created_by_id / tenant_id handled by traits
            ]);

            DB::commit();
            Log::info("LMS Course created: ID {$course->id}, Title {$course->title} by User ".Auth::id());

            return response()->json(['success' => true, 'message' => 'Course created successfully.', 'course_id' => $course->id], 201);

        } catch (Exception $e) {
            DB::rollBack();
            // Clean up uploaded file if DB fails
            if (isset($thumbnailPath) && isset($diskName) && Storage::disk($diskName)->exists($thumbnailPath)) {
                Storage::disk($diskName)->delete($thumbnailPath);
            }
            Log::error('Error creating LMS course: '.$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to create course.'], 500);
        }
    }

    /**
     * Fetch data for editing the specified course.
     * Route: GET /lms/courses/{course}/edit
     * Name: lms.courses.edit
     */
    public function edit(Course $course): JsonResponse
    {
        // abort_if_cannot('edit_lms_courses');
        // Add tenant check if needed

        // Get thumbnail URL if path exists
        $thumbnailUrl = null;
        if ($course->thumbnail_path && Storage::disk('public')->exists($course->thumbnail_path)) {
            $thumbnailUrl = Storage::disk('public')->url($course->thumbnail_path);
        }

        // Return data formatted for the edit form
        return response()->json([
            'success' => true,
            'course' => [ // Use camelCase if JS expects it, else use snake_case matching form names
                'id' => $course->id,
                'title' => $course->title,
                'description' => $course->description,
                'lms_course_category_id' => $course->lms_course_category_id,
                'status' => $course->status->value, // Send Enum value
                'estimated_duration' => $course->estimated_duration,
                'thumbnail_url' => $thumbnailUrl, // Send URL for preview
                'has_thumbnail' => ! is_null($course->thumbnail_path), // Flag if thumbnail exists
            ],
        ]);
    }

    /**
     * Update the specified course in storage.
     * Route: PUT /lms/courses/{course}
     * Name: lms.courses.update
     */
    public function update(Request $request, Course $course): JsonResponse
    {
        // abort_if_cannot('edit_lms_courses');
        // Add tenant check if needed

        $validator = Validator::make($request->all(), [
            'title' => 'required|string|max:255',
            'description' => 'nullable|string',
            'lms_course_category_id' => 'nullable|exists:lms_course_categories,id',
            'status' => ['required', new EnumRule(LmsCourseStatus::class)],
            'estimated_duration' => 'nullable|string|max:50',
            // Validate thumbnail only if a new file is uploaded
            'thumbnail' => ['nullable', 'image', 'mimes:jpg,jpeg,png,webp', 'max:2048'],
            'remove_thumbnail' => 'nullable|boolean', // Flag to remove existing thumbnail
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        }

        DB::beginTransaction();
        try {
            $validatedData = $validator->validated();
            $thumbnailPath = $course->thumbnail_path; // Keep existing path by default
            $diskName = 'public'; // Disk for thumbnails
            $tenantId = Auth::user()->tenant_id;
            $directory = "lms/course_thumbnails/{$tenantId}";
            $oldThumbnailPath = $course->thumbnail_path; // Store old path for deletion

            // Handle thumbnail removal
            if (filter_var($request->input('remove_thumbnail', false), FILTER_VALIDATE_BOOLEAN)) {
                if ($oldThumbnailPath && Storage::disk($diskName)->exists($oldThumbnailPath)) {
                    Storage::disk($diskName)->delete($oldThumbnailPath);
                }
                $thumbnailPath = null; // Set path to null
                $validatedData['thumbnail_path'] = null; // Ensure it's included in update data
            }
            // Handle new thumbnail upload
            elseif ($request->hasFile('thumbnail')) {
                $file = $request->file('thumbnail');
                // Delete old file before storing new one
                if ($oldThumbnailPath && Storage::disk($diskName)->exists($oldThumbnailPath)) {
                    Storage::disk($diskName)->delete($oldThumbnailPath);
                }
                $thumbnailPath = $file->store($directory, $diskName);
                if (! $thumbnailPath) {
                    throw new Exception('Failed to store new thumbnail.');
                }
                $validatedData['thumbnail_path'] = $thumbnailPath; // Update path for saving
            } else {
                // No new file and remove flag is false, keep existing path
                unset($validatedData['thumbnail_path']); // Don't update path if no action needed
            }

            // Unset helper flags before update
            unset($validatedData['thumbnail']);
            unset($validatedData['remove_thumbnail']);

            // Update the course record
            $course->update($validatedData);
            // updated_by_id handled by trait

            DB::commit();
            Log::info("LMS Course updated: ID {$course->id}, Title {$course->title} by User ".Auth::id());

            return response()->json(['success' => true, 'message' => 'Course updated successfully.']);

        } catch (Exception $e) {
            DB::rollBack();
            // Clean up newly uploaded file if DB fails
            if (isset($thumbnailPath) && $thumbnailPath !== $oldThumbnailPath && isset($diskName) && Storage::disk($diskName)->exists($thumbnailPath)) {
                Storage::disk($diskName)->delete($thumbnailPath);
            }
            Log::error("Error updating LMS course {$course->id}: ".$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to update course.'], 500);
        }
    }

    /**
     * Remove the specified course from storage (Soft Delete).
     * Route: DELETE /lms/courses/{course}
     * Name: lms.courses.destroy
     */
    public function destroy(Course $course): JsonResponse
    {
        // abort_if_cannot('delete_lms_courses');
        // Add tenant check if needed

        try {
            // Check for active enrollments before deleting
            if ($course->enrollments()->where('status', '!=', LmsEnrollmentStatus::COMPLETED->value)->exists()) {
                return response()->json([
                    'success' => false,
                    'message' => 'Cannot delete course: There are active or in-progress enrollments. Please unenroll users or wait for completion.',
                ], 409); // 409 Conflict
            }

            $courseId = $course->id;
            $thumbnailPath = $course->thumbnail_path;
            $diskName = 'public'; // Disk for thumbnails

            DB::beginTransaction();

            // Soft delete the course
            $course->delete();

            // Optionally: Soft delete related lessons? Or let cascade handle?
            // $course->lessons()->delete(); // If lessons should also be soft-deleted

            // NOTE: Enrollments and Completions have cascade constraints in migration,
            // so they will be HARD deleted if the course is hard deleted later.
            // Soft deleting the course keeps related enrollment history.

            // Delete thumbnail file (optional on soft delete, depends on policy)
            // if ($thumbnailPath && Storage::disk($diskName)->exists($thumbnailPath)) {
            //    Storage::disk($diskName)->delete($thumbnailPath);
            // }

            DB::commit();
            Log::info("LMS Course soft deleted: ID {$courseId} by User ".Auth::id());

            return response()->json(['success' => true, 'message' => 'Course deleted successfully.']);

        } catch (Exception $e) {
            DB::rollBack();
            Log::error("Error deleting LMS course {$course->id}: ".$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to delete course.'], 500);
        }
    }
}
