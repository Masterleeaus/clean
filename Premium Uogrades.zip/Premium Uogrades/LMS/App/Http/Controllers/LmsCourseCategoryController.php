<?php

namespace Modules\LMS\App\Http\Controllers;

use App\Http\Controllers\Controller;
use Exception;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Modules\LMS\App\Models\CourseCategory;
use Yajra\DataTables\Facades\DataTables;

class LmsCourseCategoryController extends Controller
{
    /**
     * Display the course categories management view.
     * Route: GET /lms/categories
     * Name: tenant.lms.categories.index
     */
    public function index()
    {
        // abort_if_cannot('view_lms_categories'); // Example permission check
        return view('lms::categories.index'); // Point to view within the module
    }

    /**
     * Handle DataTables AJAX request for course categories.
     * Route: GET /lms/categories/list
     * Name: tenant.lms.categories.listAjax
     */
    public function listAjax(Request $request): JsonResponse
    {
        // abort_if_cannot('view_lms_categories');

        $query = CourseCategory::query()
            ->withCount('courses') // Count associated courses
            ->select('lms_course_categories.*'); // Select columns

        // Apply search from DataTables
        if ($request->filled('search.value')) {
            $searchValue = $request->input('search.value');
            $query->where(function ($q) use ($searchValue) {
                $q->where('name', 'LIKE', "%{$searchValue}%")
                    ->orWhere('description', 'LIKE', "%{$searchValue}%");
            });
        }

        return DataTables::eloquent($query)
            ->editColumn('description', function ($category) {
                return Str::limit($category->description, 60); // Snippet
            })
            ->addColumn('courses_count_display', function ($category) {

                return $category->courses_count ?? 0;
            })
            ->addColumn('status', function ($category) {
                if ($category->is_active) {
                    return '<span class="badge bg-label-success">Active</span>';
                } else {
                    return '<span class="badge bg-label-secondary">Inactive</span>';
                }
            })
            ->addColumn('actions', function ($category) {
                $editUrl = route('lms.categories.edit', $category->id);
                $deleteUrl = route('lms.categories.destroy', $category->id);

                $editButton = '<button class="btn btn-sm btn-icon me-1 edit-category" data-id="'.$category->id.'" data-url="'.$editUrl.'" title="Edit"><i class="bx bx-pencil"></i></button>';
                // Pass courses_count to JS for delete check
                $deleteButton = '<button class="btn btn-sm btn-icon text-danger delete-category" data-id="'.$category->id.'" data-url="'.$deleteUrl.'" title="Delete" data-count="'.$category->courses_count.'"><i class="bx bx-trash"></i></button>';

                return '<div class="d-flex justify-content-center">'.$editButton.$deleteButton.'</div>';
            })
            ->rawColumns(['actions', 'status']) // Only actions column contains raw HTML
            ->make(true);
    }

    /**
     * Store a newly created course category in storage.
     * Route: POST /lms/categories
     * Name: tenant.lms.categories.store
     */
    public function store(Request $request): JsonResponse
    {
        // abort_if_cannot('create_lms_categories');

        $validator = Validator::make($request->all(), [
            'name' => [
                'required', 'string', 'max:255',
                Rule::unique('lms_course_categories', 'name'),
            ],
            'description' => 'nullable|string|max:1000',
            'is_active' => 'sometimes|boolean',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        }

        try {
            $category = CourseCategory::create($validator->validated());

            return response()->json(['success' => true, 'message' => 'Course Category created successfully.', 'category_id' => $category->id], 201);
        } catch (Exception $e) {
            Log::error('Error creating LMS category: '.$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to create category.'], 500);
        }
    }

    /**
     * Fetch data for editing the specified category.
     * Route: GET /lms/categories/{category}/edit
     * Name: tenant.lms.categories.edit
     */
    public function edit(CourseCategory $category): JsonResponse
    {
        // abort_if_cannot('edit_lms_categories');

        return response()->json([
            'success' => true,
            'category' => [ // Use camelCase keys if JS expects it, else match form names
                'id' => $category->id,
                'name' => $category->name,
                'description' => $category->description,
            ],
        ]);
    }

    /**
     * Update the specified course category in storage.
     * Route: PUT /lms/categories/{category}
     * Name: tenant.lms.categories.update
     */
    public function update(Request $request, CourseCategory $category): JsonResponse
    {
        // abort_if_cannot('edit_lms_categories');
        // Add tenant check if needed

        $validator = Validator::make($request->all(), [
            'name' => [
                'required', 'string', 'max:255',
                Rule::unique('lms_course_categories', 'name')
                    ->ignore($category->id), // Ignore current ID
            ],
            'description' => 'nullable|string|max:1000',
            'is_active' => 'sometimes|boolean',
        ]);

        if ($validator->fails()) {
            return response()->json(['success' => false, 'message' => 'Validation failed.', 'errors' => $validator->errors()], 422);
        }

        try {
            $category->update($validator->validated());

            return response()->json(['success' => true, 'message' => 'Course Category updated successfully.']);
        } catch (Exception $e) {
            Log::error("Error updating LMS category {$category->id}: ".$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to update category.'], 500);
        }
    }

    /**
     * Remove the specified course category from storage.
     * Route: DELETE /lms/categories/{category}
     * Name: tenant.lms.categories.destroy
     */
    public function destroy(CourseCategory $category): JsonResponse
    {
        // abort_if_cannot('delete_lms_categories');
        // Add tenant check if needed

        try {
            // Check if category is in use by any courses
            if ($category->courses()->exists()) { // Use relationship check
                return response()->json([
                    'success' => false,
                    'message' => 'Cannot delete category: It is currently assigned to one or more courses. Please reassign courses first.',
                ], 409); // 409 Conflict
            }

            $category->delete(); // Soft delete if trait is used, otherwise permanent

            return response()->json(['success' => true, 'message' => 'Course Category deleted successfully.']);
        } catch (Exception $e) {
            Log::error("Error deleting LMS category {$category->id}: ".$e->getMessage());

            return response()->json(['success' => false, 'message' => 'Failed to delete category.'], 500);
        }
    }
}
