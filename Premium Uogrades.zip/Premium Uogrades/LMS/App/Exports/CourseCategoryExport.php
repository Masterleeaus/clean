<?php

namespace Modules\LMS\App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Modules\LMS\App\Models\CourseCategory;

class CourseCategoryExport implements FromCollection, WithHeadings, WithMapping
{
    /**
     * Export data as a collection.
     */
    public function collection(): Collection
    {
        return CourseCategory::withCount('courses')->get();
    }

    /**
     * Define column headings.
     */
    public function headings(): array
    {
        return [
            'ID',
            'Name',
            'Description',
            'Courses Count',
            'Is Active',
            'Created At',
            'Updated At',
        ];
    }

    /**
     * Map data for export.
     */
    public function map($category): array
    {
        return [
            $category->id,
            $category->name,
            $category->description,
            $category->courses_count,
            $category->is_active ? 'Yes' : 'No',
            $category->created_at?->format('Y-m-d H:i:s'),
            $category->updated_at?->format('Y-m-d H:i:s'),
        ];
    }
}
