<?php

namespace Modules\LMS\App\Exports;

use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Modules\LMS\App\Models\Course;

class CourseExport implements FromCollection, WithHeadings, WithMapping
{
    /**
     * Export data as a collection.
     */
    public function collection(): Collection
    {
        return Course::with(['category', 'creator'])
            ->withCount(['lessons', 'enrollments'])
            ->get();
    }

    /**
     * Define column headings.
     */
    public function headings(): array
    {
        return [
            'ID',
            'UUID',
            'Title',
            'Description',
            'Category',
            'Status',
            'Estimated Duration',
            'Lessons Count',
            'Enrollments Count',
            'Created By',
            'Created At',
            'Updated At',
        ];
    }

    /**
     * Map data for export.
     */
    public function map($course): array
    {
        return [
            $course->id,
            $course->uuid,
            $course->title,
            $course->description,
            $course->category?->name,
            $course->status?->value ?? '',
            $course->estimated_duration,
            $course->lessons_count,
            $course->enrollments_count,
            $course->creator?->getFullName(),
            $course->created_at?->format('Y-m-d H:i:s'),
            $course->updated_at?->format('Y-m-d H:i:s'),
        ];
    }
}
