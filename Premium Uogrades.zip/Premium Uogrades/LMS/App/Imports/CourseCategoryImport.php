<?php

namespace Modules\LMS\App\Imports;

use Maatwebsite\Excel\Concerns\ToModel;
use Maatwebsite\Excel\Concerns\WithHeadingRow;
use Maatwebsite\Excel\Concerns\WithValidation;
use Modules\LMS\App\Models\CourseCategory;

class CourseCategoryImport implements ToModel, WithHeadingRow, WithValidation
{
    /**
     * Create a new CourseCategory instance for each row.
     */
    public function model(array $row): ?CourseCategory
    {
        // Skip if required fields are missing
        if (empty($row['name'])) {
            return null;
        }

        return new CourseCategory([
            'name' => $row['name'],
            'description' => $row['description'] ?? null,
            'is_active' => $this->parseBoolean($row['is_active'] ?? true),
        ]);
    }

    /**
     * Define validation rules.
     */
    public function rules(): array
    {
        return [
            'name' => 'required|string|max:255|unique:lms_course_categories,name',
        ];
    }

    /**
     * Parse boolean value from various formats.
     */
    private function parseBoolean(mixed $value): bool
    {
        if (\is_bool($value)) {
            return $value;
        }

        if (\is_string($value)) {
            return \in_array(strtolower($value), ['yes', 'true', '1', 'active']);
        }

        return (bool) $value;
    }
}
