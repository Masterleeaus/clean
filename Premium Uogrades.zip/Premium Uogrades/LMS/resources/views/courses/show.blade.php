@php
  use Modules\LMS\App\Enums\LmsCourseStatus;
  use \Illuminate\Support\Facades\Storage;
@endphp
@extends('layouts.layoutMaster')

@section('title', 'Course Details: ' . $course->title)

@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss', // For Enrollments Table
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/select2/select2.scss', // For Enroll Modal
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
  ])
@endsection

@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
  ])
@endsection

@section('page-style')
  <style>
    /* Add custom styles if needed */
    .detail-label { font-weight: 600; color: #566a7f; }
    .select2-container--open { z-index: 1090; }
  </style>
@endsection

@section('page-script')
  <script>
    // URLs and Data for JavaScript
    const currentCourseId = {{ $course->id }};
    const enrollmentsListAjaxUrl = "{{ route('lms.courses.enrollments.listAjax', ['course' => $course->id]) }}"; // Define this route later
    const enrollmentsStoreUrl = "{{ route('lms.courses.enrollments.store', ['course' => $course->id]) }}"; // Define this route later
    const enrollmentsBaseUrl = "{{ url('lms/courses/enrollments') }}"; // Base URL for delete etc.
    const unEnrollUrlTemplate = "{{ route('lms.courses.enrollments.destroy', ['course' => $course->id, 'enrollment' => '__enrollmentId__']) }}"; // Define this route later
    const csrfToken = "{{ csrf_token() }}";
    // Pass users for modal dropdown
    const assignableUsers = @json($users->map(fn($user) => ['id' => $user->id, 'text' => $user->getFullName() . ($user->code ? ' ('.$user->code.')' : '') ])->toArray());
    </script>
  @vite(['resources/assets/js/app/lms-course-enrollments.js']) {{-- Dedicated JS for this page's interactions --}}
@endsection


@section('content')
  <div class="container-fluid flex-grow-1 container-p-y">

    {{-- Breadcrumbs & Action Buttons --}}
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1 mb-0">
          <li class="breadcrumb-item"><a >LMS Courses</a></li>
          <li class="breadcrumb-item active">Details: {{ $course->title }}</li>
        </ol>
      </nav>
      <div class="d-flex gap-2">
        {{-- Button to Manage Lessons (Points to future page) --}}
        <a href="{{ route('lms.courses.lessons.index', ['course' => $course->id]) }}" class="btn btn-secondary">
          <i class="bx bx-list-ul me-1"></i> Manage Lessons ({{ $course->lessons_count }})
        </a>
        {{-- Button to trigger Enroll Users Modal --}}
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#enrollUsersModal">
          <i class="bx bx-user-plus me-1"></i> Enroll Users
        </button>
      </div>
    </div>

    <div class="row">
      {{-- Left Column: Course Info --}}
      <div class="col-md-5 col-lg-4">
        <div class="card mb-4">
          <div class="card-body text-center">
            {{-- Thumbnail --}}
            @if($course->thumbnail_path && Storage::disk('public')->exists($course->thumbnail_path))
              <img src="{{ Storage::disk('public')->url($course->thumbnail_path) }}" alt="{{ $course->title }}" class="img-fluid rounded mb-3" style="max-height: 150px;">
            @else
              <div class="avatar avatar-xl mb-3 bg-label-secondary rounded">
                <i class="bx bx-book-open bx-lg"></i>
              </div>
            @endif
            {{-- Title --}}
            <h5 class="card-title mb-1">{{ $course->title }}</h5>
            {{-- Category --}}
            <p class="text-muted small mb-2">{{ $course->category?->name ?? 'Uncategorized' }}</p>
            {{-- Status Badge --}}
            @php $statusBadgeClass = $course->status->colorClass(); @endphp
            <span class="badge {{ $statusBadgeClass }} mb-3">{{ $course->status->label() }}</span>
            {{-- Description Snippet --}}
            <p class="small text-muted">
              {{ \Illuminate\Support\Str::limit($course->description, 100) }}
              @if(strlen($course->description ?? '') > 100)
                <a href="#courseDescriptionModal" data-bs-toggle="modal">(Read More)</a>
              @endif
            </p>
            {{-- Stats --}}
            <div class="d-flex justify-content-around mt-3 border-top pt-3">
              <div><i class="bx bx-time-five bx-xs me-1"></i><small>{{ $course->estimated_duration ?: 'N/A' }}</small></div>
              <div><i class="bx bx-list-ul bx-xs me-1"></i><small>{{ $course->lessons_count }} Lessons</small></div>
              <div><i class="bx bx-user bx-xs me-1"></i><small>{{ $course->enrollments_count }} Enrolled</small></div>
            </div>
          </div>
        </div>
      </div>

      {{-- Right Column: Enrollments & Activity (Add Later) --}}
      <div class="col-md-7 col-lg-8">
        {{-- Current Enrollments Card --}}
        <div class="card mb-4">
          <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="mb-0">Current Enrollments</h5>
            {{-- Add filter/search later --}}
          </div>
          <div class="card-datatable table-responsive pt-0">
            <table class="datatables-enrollments table table-sm">
              <thead>
              <tr>
                <th>Employee</th>
                <th>Status</th>
                <th>Enrolled On</th>
                <th>Completed On</th>
                <th>Actions</th>
              </tr>
              </thead>
              <tbody>
              {{-- DataTable Server Side --}}
              </tbody>
            </table>
          </div>
        </div>

        {{-- TODO: Add Course Activity Timeline Card (if needed) --}}

      </div>
    </div>


    {{-- Enroll Users Modal --}}
    <div class="modal fade" id="enrollUsersModal" tabindex="-1" aria-labelledby="enrollUsersModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg modal-dialog-centered">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="enrollUsersModalLabel">Enroll Users in: {{ $course->title }}</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
          </div>
          <form id="enrollUsersForm" onsubmit="return false;">
            @csrf {{-- Method is POST --}}
            <div class="modal-body">
              {{-- User Selection --}}
              <div class="mb-3">
                <label for="enrollUserIds" class="form-label">Select Employees <span class="text-danger">*</span></label>
                <select id="enrollUserIds" name="user_ids[]" class="select2 form-select" multiple required>
                  {{-- Options populated by $users variable --}}
                  @foreach ($users as $user)
                    <option value="{{ $user->id }}">{{ $user->first_name }} {{ $user->last_name }} ({{ $user->code }})</option>
                  @endforeach
                </select>
                <small class="text-muted">Select one or more employees to enroll.</small>
                <div class="invalid-feedback"></div>
              </div>

              {{-- TODO: Add Role/Group selection later? --}}

              <div class="mt-3 general-error-message text-danger small"></div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
              <button type="submit" class="btn btn-primary" id="submitEnrollmentBtn">Enroll Selected Users</button>
            </div>
          </form>
        </div>
      </div>
    </div>
    {{-- End Enroll Users Modal --}}

    {{-- Modal for Full Description (Optional) --}}
    @if(strlen($course->description ?? '') > 100)
      <div class="modal fade" id="courseDescriptionModal" tabindex="-1" aria-labelledby="courseDescriptionModalLabel" aria-hidden="true">
        <div class="modal-dialog">
          <div class="modal-content">
            <div class="modal-header"><h5 class="modal-title" id="courseDescriptionModalLabel">Course Description</h5><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div>
            <div class="modal-body" style="white-space: pre-wrap;">{{ $course->description }}</div>
          </div>
        </div>
      </div>
    @endif


  </div>


  {{-- NEW: Enrollment Progress Modal --}}
  <div class="modal fade" id="enrollmentProgressModal" tabindex="-1" aria-labelledby="enrollmentProgressModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-dialog-scrollable"> {{-- Allow scroll --}}
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="enrollmentProgressModalLabel">Enrollment Progress</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div id="progress-modal-loading" class="text-center py-5" style="display: none;">
            <div class="spinner-border text-primary" role="status"><span class="visually-hidden">Loading...</span></div>
          </div>
          <div id="progress-modal-content">
            {{-- Basic Info --}}
            <div class="row mb-3">
              <div class="col-md-6">
                <p class="mb-1"><strong class="detail-label">Employee:</strong> <span id="progress-user-name"></span></p>
                <p class="mb-1"><strong class="detail-label">Course:</strong> <span id="progress-course-title"></span></p>
                <p class="mb-1"><strong class="detail-label">Status:</strong> <span id="progress-enrollment-status"></span></p>
              </div>
              <div class="col-md-6">
                <p class="mb-1"><strong class="detail-label">Enrolled:</strong> <span id="progress-enrolled-at"></span></p>
                <p class="mb-1"><strong class="detail-label">Started:</strong> <span id="progress-started-at"></span></p>
                <p class="mb-1"><strong class="detail-label">Completed:</strong> <span id="progress-completed-at"></span></p>
              </div>
            </div>
            {{-- Progress Bar --}}
            <div class="mb-3">
              <label class="form-label" id="progress-summary-text">Progress</label>
              <div class="progress" style="height: 10px;">
                <div class="progress-bar" id="progress-bar-indicator" role="progressbar" style="width: 0%;" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
              </div>
            </div>
            <hr>
            {{-- Lesson List --}}
            <h6>Lesson Completion Status</h6>
            <ul class="list-group list-group-flush" id="modal-lesson-completion-list">
              {{-- JS will populate this list --}}
              {{-- Example:
              <li class="list-group-item d-flex justify-content-between align-items-center">
                  <span>Lesson Title 1</span>
                  <span><i class="bx bx-check text-success"></i> <small>Apr 10, 2025</small></span>
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-center">
                   <span>Lesson Title 2</span>
                   <span><i class="bx bx-x text-muted"></i></span>
              </li>
              --}}
            </ul>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        </div>
      </div>
    </div>
  </div>
  {{-- End Enrollment Progress Modal --}}


@endsection
