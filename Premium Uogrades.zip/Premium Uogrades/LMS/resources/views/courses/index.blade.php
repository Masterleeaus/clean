@php
  // Use Enums passed from controller or import here if needed
  // use Modules\LMS\Enums\LmsCourseStatus;
@endphp
@extends('layouts.layoutMaster')

@section('title', 'LMS Courses')

@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/animate-css/animate.scss',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
    // Flatpickr not directly needed on index page, but maybe for modal consistency
    // 'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss',
  ])
@endsection

@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
    // 'resources/assets/vendor/libs/flatpickr/flatpickr.js',
    'resources/assets/vendor/libs/@form-validation/popular.js',
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js',
    'resources/assets/vendor/libs/@form-validation/auto-focus.js',
  ])
@endsection

@section('page-style')
  <style>
    .dt-buttons .btn-group > .btn { margin-left: 0.5rem; } /* Adjust button spacing */
    .select2-container--open { z-index: 1090; } /* Select2 above offcanvas */
  </style>
@endsection

@section('page-script')
  <script>
    // Pass URLs and CSRF token to JavaScript
    const lmsCoursesListAjaxUrl = "{{ route('lms.courses.listAjax') }}";
    const lmsCoursesStoreUrl = "{{ route('lms.courses.store') }}";
    const lmsCoursesBaseUrl = "{{ url('lms/courses') }}"; // Base for update/delete/edit
    const csrfToken = "{{ csrf_token() }}";
  </script>
  @vite(['resources/assets/js/app/lms-courses-admin.js']) {{-- Link to specific JS file --}}
@endsection

@section('content')
  <div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="py-3 mb-4">
      <span class="text-muted fw-light">LMS /</span> Courses
    </h4>

    <div class="card mb-4">
      <div class="card-widget-separator-wrapper">
        <div class="card-body card-widget-separator">
          <div class="row gy-4 gy-sm-1">
            {{-- Filter by Category --}}
            <div class="col-md-4 col-sm-6 col-12">
              <label for="filter_category_id" class="form-label">Filter by Category</label>
              <select id="filter_category_id" class="form-select select2" data-allow-clear="true">
                <option value="">All Categories</option>
                {{-- $categories passed from LmsCourseController@index --}}
                @foreach ($categories as $category)
                  <option value="{{ $category->id }}">{{ $category->name }}</option>
                @endforeach
              </select>
            </div>
            {{-- Filter by Status --}}
            <div class="col-md-4 col-sm-6 col-12">
              <label for="filter_status" class="form-label">Filter by Status</label>
              <select id="filter_status" class="form-select select2" data-allow-clear="true">
                <option value="">All Statuses</option>
                {{-- $statuses passed from LmsCourseController@index --}}
                @foreach ($statuses as $status)
                  <option value="{{ $status->value }}">{{ $status->label() }}</option>
                @endforeach
              </select>
            </div>
            {{-- Add Button --}}
            <div class="col-md-4 col-sm-12 col-12 d-flex align-items-end justify-content-end">
              <button type="button" class="btn btn-primary w-100 w-md-auto" id="addCourseBtn">
                <i class="bx bx-plus me-sm-1"></i> <span class="d-none d-sm-inline-block">Add New Course</span>
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>


    <div class="card">
      <div class="card-header">
        <h5 class="card-title mb-0">Course List</h5>
      </div>
      <div class="card-datatable table-responsive pt-0">
        <table class="datatables-lms-courses table table-bordered">
          <thead>
          <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Category</th>
            <th>Status</th>
            <th>Duration</th>
            <th>Lessons</th>
            <th>Enrolled</th>
            <th>Actions</th>
          </tr>
          </thead>
          <tbody>
          {{-- DataTables will populate this --}}
          </tbody>
        </table>
      </div>
    </div>

    {{-- Offcanvas for Add/Edit Course --}}
    <div class="offcanvas offcanvas-end" tabindex="-1" id="courseOffcanvas" aria-labelledby="courseOffcanvasLabel" style="width: 600px;"> {{-- Wider offcanvas --}}
      <div class="offcanvas-header">
        <h5 id="courseOffcanvasLabel" class="offcanvas-title">Add Course</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body mx-0 flex-grow-0">
        {{-- IMPORTANT: enctype for file uploads --}}
        <form class="add-edit-course-form pt-0" id="courseForm" onsubmit="return false;" enctype="multipart/form-data">
          @csrf
          <input type="hidden" name="_method" id="courseMethod" value="POST">
          <input type="hidden" name="course_id" id="course_id" value="">

          {{-- Title --}}
          <div class="mb-3">
            <label class="form-label" for="courseTitle">Course Title <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="courseTitle" placeholder="e.g., Introduction to Project Management" name="title" required />
            <div class="invalid-feedback"></div>
          </div>

          {{-- Category --}}
          <div class="mb-3">
            <label class="form-label" for="lms_course_category_id">Category</label>
            <select id="lms_course_category_id" name="lms_course_category_id" class="select2 form-select">
              <option value="">Select Category (Optional)</option>
              @foreach ($categories as $category)
                <option value="{{ $category->id }}">{{ $category->name }}</option>
              @endforeach
            </select>
            <div class="invalid-feedback"></div>
          </div>

          {{-- Status --}}
          <div class="mb-3">
            <label class="form-label" for="courseStatus">Status <span class="text-danger">*</span></label>
            <select id="courseStatus" name="status" class="select2 form-select" required>
              <option value="">Select Status</option>
              @foreach ($statuses as $status)
                <option value="{{ $status->value }}">{{ $status->label() }}</option>
              @endforeach
            </select>
            <div class="invalid-feedback"></div>
          </div>

          {{-- Estimated Duration --}}
          <div class="mb-3">
            <label class="form-label" for="estimated_duration">Estimated Duration</label>
            <input type="text" class="form-control" id="estimated_duration" name="estimated_duration" placeholder="e.g., 2 hours, 45 mins" />
            <div class="invalid-feedback"></div>
          </div>

          {{-- Description --}}
          <div class="mb-3">
            <label class="form-label" for="courseDescription">Description</label>
            <textarea class="form-control" id="courseDescription" name="description" rows="5" placeholder="Detailed course description..."></textarea>
            <div class="invalid-feedback"></div>
          </div>

          {{-- Thumbnail Upload --}}
          <div class="mb-3">
            <label for="thumbnail" class="form-label">Course Thumbnail</label>
            <input class="form-control" type="file" id="thumbnail" name="thumbnail" accept="image/png, image/jpeg, image/webp">
            <div class="invalid-feedback"></div>
            <div id="thumbnailPreviewArea" class="mt-2" style="display: none;">
              <img id="thumbnailPreview" src="#" alt="Thumbnail Preview" style="max-height: 100px; max-width: 100%;" class="img-thumbnail">
              <div class="form-check mt-1">
                <input class="form-check-input" type="checkbox" value="1" id="remove_thumbnail" name="remove_thumbnail">
                <label class="form-check-label small" for="remove_thumbnail"> Remove current thumbnail</label>
              </div>
            </div>
          </div>

          {{-- General Error Message Area --}}
          <div class="mb-3"><small class="text-danger" id="general-error"></small></div>

          <div class="mt-4">
            <button type="submit" class="btn btn-primary me-sm-3 me-1 data-submit" id="submitCourseBtn">Submit</button>
            <button type="reset" class="btn btn-label-secondary" data-bs-dismiss="offcanvas">Cancel</button>
          </div>
        </form>
      </div>
    </div> {{-- End Offcanvas --}}

  </div>
@endsection
