@php
  // Define variables or use Enums if needed for default states etc.
@endphp
@extends('layouts.layoutMaster')

@section('title', 'LMS Course Categories')

@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss', // Optional Buttons
    'resources/assets/vendor/libs/animate-css/animate.scss',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
    // No Select2 needed for this specific view yet, but maybe for consistency?
    // 'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/@form-validation/form-validation.scss', // If using client-side validation JS
  ])
@endsection

@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
    // 'resources/assets/vendor/libs/select2/select2.js', // If needed later
    'resources/assets/vendor/libs/@form-validation/popular.js', // Optional
    'resources/assets/vendor/libs/@form-validation/bootstrap5.js', // Optional
    'resources/assets/vendor/libs/@form-validation/auto-focus.js', // Optional
  ])
@endsection

@section('page-style')
  <style>
    /* Ensure toggle switches align nicely in table cells if needed */
    .dataTables_wrapper .form-check.form-switch {
      display: flex;
      justify-content: center; /* Center switch in cell */
    }
  </style>
@endsection

@section('page-script')
  <script>
    // Pass URLs and CSRF token to JavaScript using corrected route names
    const lmsCategoriesListAjaxUrl = "{{ route('lms.categories.listAjax') }}";
    const lmsCategoriesStoreUrl = "{{ route('lms.categories.store') }}";
    // Base URL for actions requiring ID - JS will append ID and action
    // Assuming prefix is /lms/categories as per route definition
    const lmsCategoriesBaseUrl = "{{ url('lms/categories') }}";
    const csrfToken = "{{ csrf_token() }}";
  </script>
  @vite(['resources/assets/js/app/lms-categories-admin.js']) {{-- Link to specific JS file --}}
@endsection

@section('content')
  <div class="container-fluid flex-grow-1 container-p-y">

    <h4 class="py-3 mb-4">
      <span class="text-muted fw-light">LMS /</span> Course Categories
    </h4>

    <div class="d-flex justify-content-end align-items-center mb-4">
      <button type="button" class="btn btn-primary" id="addLmsCategoryBtn">
        <i class="bx bx-plus me-sm-1"></i> <span class="d-none d-sm-inline-block">Add New Category</span>
      </button>
    </div>

    <div class="card">
      <div class="card-header">
        <h5 class="card-title mb-0">Category List</h5>
        {{-- Add Filters Here later if needed --}}
      </div>
      <div class="card-datatable table-responsive pt-0">
        <table class="datatables-lms-categories table table-bordered">
          <thead>
          <tr>
            <th>ID</th>
            <th>Name</th>
            <th>Description</th>
            <th>Courses</th> {{-- Course Count --}}
            <th>Status</th> {{-- Active/Inactive --}}
            <th>Actions</th>
          </tr>
          </thead>
          <tbody>
          {{-- DataTables will populate this --}}
          </tbody>
        </table>
      </div>
    </div>

    {{-- Offcanvas for Add/Edit Category --}}
    <div class="offcanvas offcanvas-end" tabindex="-1" id="lmsCategoryOffcanvas" aria-labelledby="lmsCategoryOffcanvasLabel">
      <div class="offcanvas-header">
        <h5 id="lmsCategoryOffcanvasLabel" class="offcanvas-title">Add Category</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body mx-0 flex-grow-0">
        <form class="add-edit-lms-category-form pt-0" id="lmsCategoryForm" onsubmit="return false;">
          @csrf
          <input type="hidden" name="_method" id="categoryMethod" value="POST">
          <input type="hidden" name="category_id" id="category_id" value="">

          {{-- Name --}}
          <div class="mb-3">
            <label class="form-label" for="categoryName">Category Name <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="categoryName" placeholder="e.g., Compliance, Leadership Skills" name="name" required />
            <div class="invalid-feedback"></div>
          </div>

          {{-- Description --}}
          <div class="mb-3">
            <label class="form-label" for="categoryDescription">Description</label>
            <textarea class="form-control" id="categoryDescription" name="description" rows="4" placeholder="Brief description of the category..."></textarea>
            <div class="invalid-feedback"></div>
          </div>

          {{-- Is Active Switch --}}
          <div class="mb-4">
            <label class="switch switch-primary">
              {{-- Use the preferred switch style --}}
              <input type="checkbox" class="switch-input" id="is_active" name="is_active" value="1" checked> {{-- Default checked for new --}}
              <span class="switch-toggle-slider">
                             <span class="switch-on"><i class="bx bx-check"></i></span>
                             <span class="switch-off"><i class="bx bx-x"></i></span>
                         </span>
              <span class="switch-label">Set as Active?</span>
            </label>
            <input type="hidden" name="is_active" value="0"> {{-- Value when unchecked --}}
            <div class="invalid-feedback"></div>
          </div>

          {{-- General Error Message Area --}}
          <div class="mb-3">
            <small class="text-danger" id="general-error"></small>
          </div>


          <div class="mt-4">
            <button type="submit" class="btn btn-primary me-sm-3 me-1 data-submit" id="submitLmsCategoryBtn">Submit</button>
            <button type="reset" class="btn btn-label-secondary" data-bs-dismiss="offcanvas">Cancel</button>
          </div>
        </form>
      </div>
    </div> {{-- End Offcanvas --}}

  </div>
@endsection
