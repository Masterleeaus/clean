@php
  use Modules\LMS\App\Enums\LmsContentType; // Import Enum if needed
@endphp
@extends('layouts.layoutMaster')

@section('title', 'Manage Lessons: ' . $course->title)

@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/animate-css/animate.scss',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss',
    'resources/assets/vendor/libs/flatpickr/flatpickr.scss',
  ])
@endsection

@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.js',
    'resources/assets/vendor/libs/flatpickr/flatpickr.js', // If needed
    // SortableJS via CDN or local asset
  ])
  <script src="https://cdn.jsdelivr.net/npm/sortablejs@1.15.6/Sortable.min.js"></script>
  {{-- Add JS for Rich Text Editor if used --}}
@endsection

@section('page-style')
  <style>
    #lessonsListContainer .list-group-item {
      display: flex;
      align-items: center;
      padding: 0.75rem 1rem;
      border-bottom: 1px solid #eee;
      background-color: #fff; /* Ensure background for dragging */
    }
    #lessonsListContainer .list-group-item:last-child {
      border-bottom: none;
    }
    .lesson-handle {
      cursor: move;
      color: #a1acb8;
      font-size: 1.3rem;
      margin-right: 1rem;
    }
    .lesson-content-indicator {
      font-size: 0.8rem;
      color: #6c757d;
    }
    .lesson-actions {
      margin-left: auto; /* Push actions to the right */
      white-space: nowrap;
    }
    .lesson-actions .btn-icon { padding: 0.2rem 0.4rem; font-size: 0.9rem; }
    /* Ensure select2 dropdowns appear above offcanvas */
    .select2-container--open { z-index: 1090; }
    /* Style for sortable ghost element */
    .sortable-ghost { opacity: 0.4; background-color: #e9ecef; border: 1px dashed #ccc; }
    .sortable-chosen { box-shadow: 0 .125rem .25rem rgba(161, 172, 184, .4); }
  </style>
@endsection

@section('page-script')
  <script>
    // URLs and Data for JavaScript
    const currentCourseId = {{ $course->id }};
    const lessonsStoreUrl = "{{ route('lms.courses.lessons.store', ['course' => $course->id]) }}";
    const lessonsReorderUrl = "{{ route('lms.courses.lessons.reorder', ['course' => $course->id]) }}";
    // Base URL for individual lesson actions (update/delete/edit) - JS appends lesson ID
    const lessonsBaseActionUrl = "{{ url('lms/lessons') }}";
    const csrfToken = "{{ csrf_token() }}";
    // Pass content types for the form dropdown
    const lessonContentTypes = @json(collect($contentTypes)->map(fn($type) => ['id' => $type->value, 'text' => $type->label()]));
  </script>
  @vite(['resources/assets/js/app/lms-lessons-admin.js'])
@endsection

@section('content')
  <div class="container-fluid flex-grow-1 container-p-y">

    {{-- Breadcrumbs and Add Button --}}
    <div class="d-flex flex-wrap justify-content-between align-items-center mb-4 gap-3">
      <nav aria-label="breadcrumb">
        <ol class="breadcrumb breadcrumb-style1 mb-0">
          <li class="breadcrumb-item"><a href="{{ route('lms.courses.index') }}">LMS Courses</a></li>
          <li class="breadcrumb-item active">Manage Lessons: {{ $course->title }}</li>
        </ol>
      </nav>
      <button type="button" class="btn btn-primary" id="addLessonBtn">
        <i class="bx bx-plus me-sm-1"></i> <span class="d-none d-sm-inline-block">Add New Lesson</span>
      </button>
    </div>

    {{-- Lesson List Card --}}
    <div class="card">
      <div class="card-header">
        <h5 class="card-title mb-0">Lessons</h5>
        <small class="text-muted">Drag and drop lesson handles <i class="bx bx-grid-vertical"></i> to reorder.</small>
      </div>
      <div class="card-body mb-3">
        <div id="lessonsListContainer" class="list-group">
          @forelse($lessons as $lesson)
            <div class="list-group-item lesson-item" data-lesson-id="{{ $lesson->id }}">
              <i class="bx bx-grid-vertical lesson-handle" title="Drag to reorder"></i>
              <div class="flex-grow-1">
                <h6 class="mb-1">{{ $lesson->title }}</h6>
                <small class="lesson-content-indicator">
                  <i class="bx {{ $lesson->content_type->iconClass() }} bx-xs me-1"></i>
                  {{ $lesson->content_type->label() }}
                  @if($lesson->content_type == LmsContentType::FILE_UPLOAD || $lesson->content_type == LmsContentType::VIDEO_UPLOAD)
                    : {{ $lesson->original_filename ?? basename($lesson->content_file_path) }}
                  @endif
                </small>
              </div>
              <div class="lesson-actions">
                <button class="btn btn-sm btn-icon edit-lesson" data-id="{{ $lesson->id }}" title="Edit Lesson"><i class="bx bx-pencil"></i></button>
                <button class="btn btn-sm btn-icon text-danger delete-lesson" data-id="{{ $lesson->id }}" title="Delete Lesson"><i class="bx bx-trash"></i></button>
              </div>
            </div>
          @empty
            <div id="noLessonsMessage" class="text-center text-muted p-4">
              No lessons added to this course yet. Click "Add New Lesson" to start.
            </div>
          @endforelse
        </div>
      </div>
    </div>

    {{-- Offcanvas for Add/Edit Lesson --}}
    <div class="offcanvas offcanvas-end" tabindex="-1" id="lessonOffcanvas" aria-labelledby="lessonOffcanvasLabel" style="width: 600px;">
      <div class="offcanvas-header">
        <h5 id="lessonOffcanvasLabel" class="offcanvas-title">Add Lesson</h5>
        <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
      </div>
      <div class="offcanvas-body mx-0 flex-grow-0">
        {{-- IMPORTANT: enctype for file uploads --}}
        <form class="add-edit-lesson-form pt-0" id="lessonForm" onsubmit="return false;" enctype="multipart/form-data">
          @csrf
          <input type="hidden" name="_method" id="lessonMethod" value="POST"> {{-- Will be changed to PUT for updates --}}
          <input type="hidden" name="lesson_id" id="lesson_id" value="">
          {{-- Course ID is part of the URL, no hidden input needed --}}

          {{-- Title --}}
          <div class="mb-3">
            <label class="form-label" for="lessonTitle">Lesson Title <span class="text-danger">*</span></label>
            <input type="text" class="form-control" id="lessonTitle" placeholder="e.g., Introduction to Topic" name="title" required />
            <div class="invalid-feedback"></div>
          </div>

          {{-- Content Type --}}
          <div class="mb-3">
            <label class="form-label" for="content_type">Content Type <span class="text-danger">*</span></label>
            <select id="content_type" name="content_type" class="select2 form-select" required>
              <option value="" disabled selected>Select Content Type...</option>
              {{-- $contentTypes passed from controller --}}
              @foreach ($contentTypes as $type)
                <option value="{{ $type->value }}">{{ $type->label() }}</option>
              @endforeach
            </select>
            <div class="invalid-feedback"></div>
          </div>

          {{-- Text/Link/Embed Input (Conditional) --}}
          <div class="mb-3 content-input-group" id="contentTextGroup" style="display: none;">
            <label class="form-label" for="content_text">Content / URL / Embed Code <span class="text-danger">*</span></label>
            {{-- Consider Rich Text Editor Here (e.g., TinyMCE, QuillJS) --}}
            <textarea class="form-control" id="content_text" name="content_text" rows="10" placeholder="Enter text content, https://... link, or video embed code..."></textarea>
            <div class="invalid-feedback"></div>
          </div>

          {{-- File Upload Input (Conditional) --}}
          <div class="mb-3 content-input-group" id="contentFileGroup" style="display: none;">
            <label for="lesson_file" class="form-label">Lesson File <span class="text-danger">*</span></label>
            <input class="form-control" type="file" id="lesson_file" name="lesson_file"> {{-- Accept various types based on validation --}}
            <div id="currentLessonFileDisplay" class="mt-2 small text-muted"></div> {{-- Show current file on edit --}}
            <div class="form-check mt-1" id="removeFileCheckArea" style="display: none;">
              <input class="form-check-input" type="checkbox" value="1" id="remove_file" name="remove_file">
              <label class="form-check-label small" for="remove_file"> Remove current file</label>
            </div>
            <div class="invalid-feedback"></div>
          </div>

          {{-- General Error Message Area --}}
          <div class="mb-3"><small class="text-danger" id="general-error"></small></div>

          <div class="mt-4">
            <button type="submit" class="btn btn-primary me-sm-3 me-1 data-submit" id="submitLessonBtn">Submit</button>
            <button type="reset" class="btn btn-label-secondary" data-bs-dismiss="offcanvas">Cancel</button>
          </div>
        </form>
      </div>
    </div> {{-- End Offcanvas --}}

  </div>
@endsection
