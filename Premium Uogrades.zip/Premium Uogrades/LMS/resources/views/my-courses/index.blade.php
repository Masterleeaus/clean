@php
  $configData = Helper::appClasses();
  use Modules\LMS\App\Enums\LmsEnrollmentStatus;
  use \Illuminate\Support\Facades\Storage;
@endphp

@extends('layouts.layoutMaster')

@section('title', 'My Learning')

@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/select2/select2.scss' // For category filter
  ])
@endsection

@section('page-style')
  @vite('resources/assets/vendor/scss/pages/app-academy.scss') {{-- Use the sample's page style --}}
@endsection

@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/select2/select2.js'
  ])
@endsection

@section('page-script')
  @vite(['resources/assets/js/app/lms-my-courses.js']) {{-- Dedicated JS for this page --}}
@endsection

@section('content')
  <div class="app-academy">
    {{-- 1. Header Banner Section --}}
    <div class="card p-0 mb-6">
      <div class="card-body d-flex flex-column flex-md-row justify-content-between p-0 pt-6">
        <div class="app-academy-md-25 card-body py-0 pt-6 ps-12">
          {{-- Use theme-aware image helper if available --}}
          <img src="{{asset('assets/img/illustrations/bulb-'.$configData['style'].'.png')}}" class="img-fluid app-academy-img-height scaleX-n1-rtl" alt="Bulb in hand" data-app-light-img="illustrations/bulb-light.png" data-app-dark-img="illustrations/bulb-dark.png" height="90" />
        </div>
        <div class="app-academy-md-50 card-body d-flex align-items-md-center flex-column text-md-center mb-6 py-6">
        <span class="card-title mb-4 px-md-12 h4">
          Welcome back, <span class="text-primary">{{ auth()->user()->first_name ?? 'Learner' }}</span>!
          <br>Ready to continue your learning journey?
        </span>
          {{-- Search can be added later with JS functionality --}}
          {{-- <div class="d-flex align-items-center justify-content-between app-academy-md-80">
            <input type="search" placeholder="Find your course" class="form-control me-4" id="myCourseSearch" />
            <button type="button" class="btn btn-primary btn-icon" id="myCourseSearchBtn"><i class="bx bx-search bx-md"></i></button>
          </div> --}}
        </div>
        <div class="app-academy-md-25 d-flex align-items-end justify-content-end">
          <img src="{{asset('assets/img/illustrations/pencil-rocket.png')}}" alt="pencil rocket" height="180" class="scaleX-n1-rtl" />
        </div>
      </div>
    </div>

    {{-- 2. My Courses Section --}}
    <div class="card mb-6">
      {{-- Header with Filters --}}
      <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-4">
        <div class="card-title mb-0 me-1">
          <h5 class="mb-1">My Courses</h5>
          <p class="text-muted mb-0"> {{-- Calculate count from passed $enrollments --}}
            You are enrolled in {{ $enrollments->count() }} course(s).
          </p>
        </div>
        <div class="d-flex justify-content-md-end align-items-center gap-4 flex-wrap">
          {{-- Category Filter --}}
          <div style="width: 150px;"> {{-- Width constraint for select --}}
            <select id="filter-category" class="form-select select2">
              <option value="">All Categories</option>
              {{-- $categories passed from controller --}}
              @foreach($categories as $category)
                <option value="{{ $category->id }}">{{ $category->name }}</option>
              @endforeach
            </select>
          </div>
          {{-- Hide Completed Toggle --}}
          <div class="form-check form-switch my-0 ms-2">
            <input type="checkbox" class="form-check-input" id="filter-hide-completed" />
            <label class="form-check-label text-nowrap mb-0" for="filter-hide-completed">Hide completed</label>
          </div>
        </div>
      </div>

      {{-- Course Grid --}}
      <div class="card-body">
        <div class="row gy-6 mb-6" id="my-courses-grid"> {{-- Add ID for JS filtering --}}
          @forelse($enrollments as $enrollment)
            @php
              // Get course details safely
              $course = $enrollment->course;
              // Skip rendering if course data is missing (e.g., course deleted after enrollment)
              if (!$course) continue;

              // Determine progress and status label/button text
              $progress = $enrollment->progressPercent ?? 0;
              $isCompleted = $enrollment->derived_status == LmsEnrollmentStatus::COMPLETED;
              $isInProgress = $enrollment->derived_status == LmsEnrollmentStatus::IN_PROGRESS;
              $buttonText = $isCompleted ? 'Review Course' : ($isInProgress ? 'Continue' : 'Start Course');
              $buttonIcon = $isCompleted ? 'bx-book-open' : ($isInProgress ? 'bx-play-circle' : 'bx-play-circle');
            @endphp
            <div class="col-sm-6 col-lg-4 course-card-wrapper" data-category-id="{{ $course->lms_course_category_id ?? '' }}" data-completed="{{ $isCompleted ? 'true' : 'false' }}">
              <div class="card p-2 h-100 shadow-none border">
                {{-- Thumbnail --}}
                <div class="rounded-2 text-center mb-4 card-image-container bg-label-secondary">
                  <a href="{{ route('lms.my.course.show', $enrollment->id) }}">
                    @if($course->thumbnail_path && Storage::disk('public')->exists($course->thumbnail_path))
                      <img class="img-fluid" src="{{ Storage::disk('public')->url($course->thumbnail_path) }}" alt="{{ $course->title }}" style="height:150px; object-fit: cover;" />
                    @else
                      {{-- Placeholder Icon --}}
                      <div class="d-flex align-items-center justify-content-center" style="height: 150px;">
                        <i class="bx bx-book-open text-secondary" style="font-size: 4rem;"></i>
                      </div>
                    @endif
                  </a>
                </div>
                <div class="card-body p-4 pt-2">
                  {{-- Category Badge --}}
                  <div class="d-flex justify-content-between align-items-center mb-4">
                    @if($course->category)
                      <span class="badge bg-label-primary">{{ $course->category->name }}</span>
                    @else
                      <span></span> {{-- Placeholder to maintain alignment --}}
                    @endif
                    {{-- Rating - Omitted as not in model --}}
                  </div>
                  {{-- Title --}}
                  <a href="{{ route('lms.my.course.show', $enrollment->id) }}" class="h5">{{ $course->title }}</a>
                  {{-- Description - Omitted from card for brevity --}}
                  {{-- Duration --}}
                  <p class="d-flex align-items-center my-1 text-muted small"><i class="bx bx-time-five me-1"></i>{{ $course->estimated_duration ?: 'N/A' }}</p>
                  {{-- Progress --}}
                  <div class="progress mb-4" style="height: 8px" title="{{ $progress }}% Complete">
                    <div class="progress-bar" role="progressbar" style="width: {{ $progress }}%;" aria-valuenow="{{ $progress }}" aria-valuemin="0" aria-valuemax="100"></div>
                  </div>
                  {{-- Action Buttons --}}
                  <div class="text-center"> {{-- Simplified to one button --}}
                    <a class="w-100 btn btn-primary d-flex align-items-center justify-content-center" href="{{ route('lms.my.course.show', $enrollment->id) }}">
                      <i class="bx {{ $buttonIcon }} bx-sm me-1_5"></i><span>{{ $buttonText }}</span>
                    </a>
                  </div>
                </div>
              </div>
            </div>
          @empty
            <div class="col-12 text-center py-5">
              <p class="text-muted">You are not currently enrolled in any courses.</p>
              {{-- Optional: Link to course catalog if self-enrollment exists --}}
              {{-- <a href="#" class="btn btn-primary">Browse Course Catalog</a> --}}
            </div>
          @endforelse
        </div>
        {{-- Message moved outside the loop, initially hidden --}}
        <div id="noCoursesMessage" class="col-12 text-center py-5 text-muted" style="display: {{ $enrollments->isEmpty() ? 'block' : 'none' }};">
          No courses match your criteria.
        </div>

        {{-- Pagination (Add if controller uses pagination) --}}
        {{-- <nav aria-label="Page navigation" class="d-flex align-items-center justify-content-center">
              {{ $enrollments->links() }}
        </nav> --}}
      </div>
    </div>

  </div>
@endsection
