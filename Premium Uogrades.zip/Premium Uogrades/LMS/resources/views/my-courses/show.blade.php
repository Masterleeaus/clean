@php
  $configData = Helper::appClasses();
  use \Modules\LMS\App\Enums\LmsContentType;
  use \Illuminate\Support\Facades\Storage;
@endphp

@extends('layouts.layoutMaster')

@section('title', $course->title ?? 'Course Details')

@section('vendor-style')
  @vite('resources/assets/vendor/libs/plyr/plyr.scss')
@endsection

@section('page-style')
  <style>
    .scrollable-lessons {
      max-height: 60vh; /* Adjust as needed */
      overflow-y: auto;
    }
    .lesson-item {
      transition: background-color 0.2s ease-in-out;
    }
    .lesson-item.active {
      background-color: rgba(var(--bs-primary-rgb), 0.1); /* Light primary background */
    }
    .lesson-item .lesson-link h6 {
      /* Optional: style for completed lessons */
      text-decoration: none;
    }
    .lesson-item input:checked + .lesson-link h6 {
      /* text-decoration: line-through; */
      /* color: var(--bs-secondary-color); */
    }
  </style>
  @vite('resources/assets/vendor/scss/pages/app-academy-details.scss')
@endsection

@section('vendor-script')
  @vite('resources/assets/vendor/libs/plyr/plyr.js')
@endsection

@section('page-script')
  <script>
    // Pass CSRF token and necessary URLs to JS
    const csrfToken = '{{ csrf_token() }}';
    const markCompleteUrlTemplate = '{{ route('lms.my.api.lesson.complete', ['lesson' => ':lessonId']) }}';
    // const getLessonContentUrlTemplate = '{{ route('lms.my.api.lesson.content', ['lesson' => ':lessonId']) }}'; // If using AJAX load

  </script>
  @vite(['resources/assets/js/app/lms-my-course-player.js']) {{-- Dedicated JS for this page --}}
@endsection

@section('content')
  <h4 class="py-3 mb-4">
    <span class="text-muted fw-light">My Learning /</span> {{ $course->title }}
  </h4>

  <div class="row g-6">
    {{-- Left Column: Course Content Display --}}
    <div class="col-lg-8">
      <div class="card mb-4">
        <div class="card-body">
          {{-- Course Header --}}
          <div class="d-flex justify-content-between align-items-center flex-wrap mb-4 gap-2">
            <div class="me-1">
              <h5 class="mb-0">{{ $course->title }}</h5>
              {{-- Instructor: Add dynamically if available, otherwise static --}}
              <p class="mb-0 text-muted">Instructor: <span class="fw-medium text-heading"> {{ $course->instructor_name ?? 'Internal Training' }} </span></p>
            </div>
            <div class="d-flex align-items-center">
              @if($course->category)
                <span class="badge bg-label-primary me-3">{{ $course->category->name }}</span>
              @endif
              {{-- Static Icons for now --}}
              {{-- <i class='bx bx-share-alt bx-sm mx-2'></i>
              <i class='bx bx-bookmarks bx-sm'></i> --}}
            </div>
          </div>

          {{-- Main Content Area (Populated by JS) --}}
          <div class="card academy-content shadow-none border mb-4" id="lesson-content-area">
            {{-- Placeholder for initial state or non-video content --}}
            <div id="lesson-text-content" class="p-4" style="display: none;">
              {{-- Text content will be injected here by JS --}}
            </div>

            {{-- Video Player Structure (hidden initially) --}}
            <div id="lesson-video-player-container" class="p-2" style="display: none;">
              <video class="w-100" poster="" id="lesson-video-player" playsinline controls>
                {{-- Source will be added by JS --}}
              </video>
            </div>

            {{-- PDF Viewer / Link Area (hidden initially) --}}
            <div id="lesson-pdf-content" class="p-4" style="display: none;">
              <p><a href="#" id="lesson-pdf-link" target="_blank" class="btn btn-primary">View PDF</a></p>
              {{-- OR embed using an iframe/object tag, managed by JS --}}
              {{-- <iframe id="lesson-pdf-iframe" src="" style="width:100%; height:600px;" frameborder="0"></iframe> --}}
            </div>

            {{-- External Link Area (hidden initially) --}}
            <div id="lesson-external-link-content" class="p-4" style="display: none;">
              <p>This lesson links to an external resource:</p>
              <p><a href="#" id="lesson-external-link" target="_blank" class="btn btn-primary">Open Link <i class="bx bx-link-external ms-1"></i></a></p>
            </div>

            {{-- Quiz Area (hidden initially) --}}
            <div id="lesson-quiz-content" class="p-4" style="display: none;">
              <h5>Quiz</h5>
              <p>Quiz functionality is not yet implemented.</p>
              {{-- Quiz form/content would go here --}}
            </div>

            {{-- Initial Message --}}
            <div id="lesson-initial-message" class="p-4 text-center text-muted">
              <i class="bx bx-info-circle bx-lg mb-2"></i>
              <p>Select a lesson from the list to begin.</p>
            </div>
          </div>

          {{-- Course Details Section --}}
          <div class="course-details">
            <h5>About this course</h5>
            <p class="mb-0">{{ $course->description ?? 'No description provided.' }}</p>
            <hr class="my-4">

            {{-- By the numbers (Static placeholders for now) --}}
            <h5>By the numbers</h5>
            <div class="d-flex flex-wrap row-gap-2">
              <div class="me-5">
                <p class="text-nowrap mb-2"><i class='bx bx-check-shield me-2 align-bottom'></i>Skill level: {{ $course->skill_level ?? 'All Levels' }}</p>
                <p class="text-nowrap mb-2"><i class='bx bx-user me-2 align-top'></i>Students Enrolled: {{ $enrollment->course->enrollments_count ?? $enrollment->course->enrollments()->count() }}</p> {{-- Add enrollments_count to Course model or calc here --}}
                <p class="text-nowrap mb-2"><i class='bx bx-globe me-2 align-bottom'></i>Language: {{ $course->language ?? 'English' }}</p>
                {{-- <p class="text-nowrap mb-0"><i class='bx bx-captions me-2 align-bottom'></i>Captions: Yes</p> --}}
              </div>
              <div>
                @php $lessonCount = $lessons->count(); @endphp
                <p class="text-nowrap mb-2"><i class='bx bx-book-content me-2 align-top ms-50'></i>Lessons: {{ $lessonCount }}</p>
                <p class="text-nowrap mb-0"><i class='bx bx-time-five me-2 align-top'></i>Duration: {{ $course->estimated_duration ?: 'N/A' }}</p>
              </div>
            </div>
            <hr class="my-4">

            {{-- Instructor Details (Static placeholders for now) --}}
            {{-- <h5>Instructor</h5>
            <div class="d-flex justify-content-start align-items-center user-name">
              <div class="avatar-wrapper">
                <div class="avatar me-4"><img src="{{asset('assets/img/avatars/11.png')}}" alt="Avatar" class="rounded-circle"></div>
              </div>
              <div class="d-flex flex-column">
                <h6 class="mb-1">Devonne Wallbridge</h6>
                <small>Web Developer, Designer, and Teacher</small>
              </div>
            </div> --}}
          </div>

        </div>
      </div>
    </div>

    {{-- Right Column: Lesson List --}}
    <div class="col-lg-4">
      <div class="accordion stick-top accordion-custom-button" id="courseContent">
        {{-- Only one accordion item for the whole lesson list --}}
        <div class="accordion-item shadow-none border border-bottom-0 active mb-0">
          <div class="accordion-header border-bottom" id="headingLessons">
            <button type="button" class="accordion-button" data-bs-toggle="collapse" data-bs-target="#chapterLessons" aria-expanded="true" aria-controls="chapterLessons">
               <span class="d-flex flex-column">
                 <span class="h5 mb-0">Course Content</span>
                  {{-- Progress calculation --}}
                 @php
                   $totalLessons = $lessons->count();
                   $completedCount = $completedLessonIds->count();
                 @endphp
                 <span class="text-muted fw-normal fs-tiny" id="lesson-progress-indicator">{{ $completedCount }} / {{ $totalLessons }} lessons completed</span>
               </span>
            </button>
          </div>
          <div id="chapterLessons" class="accordion-collapse collapse show" data-bs-parent="#courseContent">
            <div class="accordion-body py-3 scrollable-lessons" id="lesson-list-container">
              @forelse ($lessons as $index => $lessonData)
                @php
                  $lessonId = $lessonData['id'];
                  $isCompleted = isset($completedLessonIds[$lessonId]);
                  // Data needed by JS
                  $contentType = $lessonData['contentType'];
                  $contentData = $lessonData['contentData'];
                  $lessonTitle = $lessonData['title'];
                @endphp
                <div class="lesson-item mb-3 p-2 rounded {{-- active --}}" {{-- JS will add 'active' --}}
                data-lesson-id="{{ $lessonId }}"
                     data-content-type="{{ $contentType }}"
                     data-content-data="{{ htmlspecialchars($contentData ?? '', ENT_QUOTES) }}" {{-- Pass text/URL/embed --}}
                     data-lesson-title="{{ htmlspecialchars($lessonTitle, ENT_QUOTES) }}">
                  <div class="form-check d-flex align-items-center gap-1">
                    {{-- Checkbox for completion --}}
                    <input class="form-check-input lesson-complete-toggle flex-shrink-0 mt-0"
                           type="checkbox"
                           id="lesson-check-{{ $lessonId }}"
                           data-lesson-id="{{ $lessonId }}" {{ $isCompleted ? 'checked' : '' }}>

                    {{-- Lesson Title (clickable) --}}
                    <label for="lesson-check-{{ $lessonId }}" class="form-check-label ms-3 lesson-link" style="cursor:pointer;">
                      <span class="mb-0 h6 fw-medium d-block text-truncate">{{ $index + 1 }}. {{ $lessonTitle }}</span>
                      {{-- Duration - Add if available --}}
                      {{-- <small class="text-muted d-block"> {{ $lesson->duration_minutes ? $lesson->duration_minutes.' min' : '' }} </small> --}}
                    </label>
                  </div>
                </div>
              @empty
                <p class="text-muted text-center">No lessons found for this course.</p>
              @endforelse
            </div>
          </div>
        </div>
        {{-- Add more accordion items here if you implement course modules/chapters --}}
      </div>
    </div>
  </div>
@endsection
