<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Modules\LMS\App\Enums\LmsEnrollmentStatus;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('lms_course_enrollments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('lms_course_id')->constrained('lms_courses')->cascadeOnDelete();
            $table->foreignId('user_id')->constrained('users')->cascadeOnDelete();

            $table->string('status')->default(LmsEnrollmentStatus::NOT_STARTED->value)->index(); // If Enum exists

            $table->foreignId('enrolled_by_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('enrolled_at')->useCurrent(); // When enrollment record created
            $table->timestamp('started_at')->nullable(); // When user first accessed content
            $table->timestamp('completed_at')->nullable()->index(); // When status became 'completed'
            $table->decimal('score', 5, 2)->nullable(); // Optional score if course has assessment

            $table->string('tenant_id', 191)->nullable()->index();
            $table->timestamps(); // created_at (same as enrolled_at?), updated_at

            $table->unique(['lms_course_id', 'user_id']); // Prevent duplicate enrollment
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('lms_course_enrollments');
    }
};
