<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Modules\LMS\App\Enums\LmsContentType;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('lms_lessons', function (Blueprint $table) {
            $table->id();
            $table->foreignId('lms_course_id')
                ->constrained('lms_courses') // Link to courses table
                ->cascadeOnDelete();

            $table->string('title');

            $table->string('content_type')->default(LmsContentType::TEXT->value); // If Enum exists

            $table->text('content_text')->nullable()->comment('Stores text, embed code, or external URL');
            $table->string('content_file_path')->nullable()->comment('Path to uploaded file (PDF, video, etc.)');
            $table->string('original_filename')->nullable();

            $table->integer('order_column')->default(0)->index(); // Order within the course

            $table->string('tenant_id', 191)->nullable()->index();
            $table->foreignId('created_by_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            // No soft deletes for lessons usually, they are deleted if course is deleted
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('lms_lessons');
    }
};
