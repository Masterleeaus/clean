<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('lms_lesson_completions', function (Blueprint $table) {
            $table->id();

            // Link to the specific enrollment record
            $table->foreignId('lms_enrollment_id')
                ->constrained('lms_course_enrollments')
                ->cascadeOnDelete();

            $table->foreignId('lms_lesson_id')
                ->constrained('lms_lessons')
                ->cascadeOnDelete();

            // Add user_id directly for easier querying of user progress across courses
            $table->foreignId('user_id')
                ->constrained('users')
                ->cascadeOnDelete();

            $table->timestamp('completed_at')->useCurrent(); // When lesson was marked complete

            $table->string('tenant_id', 191)->nullable()->index();
            // created_at/updated_at timestamps are optional here, completed_at is key

            // Ensure a user only completes a lesson once per enrollment
            $table->unique(['lms_enrollment_id', 'lms_lesson_id']);
            // Optionally add index on user_id for faster lookups
            $table->index('user_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('lms_lesson_completions');
    }
};
