<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;
use Modules\LMS\App\Enums\LmsCourseStatus;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('lms_courses', function (Blueprint $table) {
            $table->id();
            $table->uuid('uuid')->unique()->nullable();

            $table->string('title')->index();
            $table->text('description')->nullable();

            $table->foreignId('lms_course_category_id')
                ->nullable()
                ->constrained('lms_course_categories')
                ->nullOnDelete();

            // Use string until Enum created and cast in model
            $table->string('status')->default(LmsCourseStatus::DRAFT->value)->index();

            $table->string('estimated_duration')->nullable()->comment('e.g., 2 hours, 30 mins');
            $table->string('thumbnail_path')->nullable()->comment('Path to course image');

            $table->string('tenant_id', 191)->nullable()->index();
            $table->foreignId('created_by_id')->nullable()->constrained('users')->nullOnDelete();
            $table->foreignId('updated_by_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamps();
            $table->softDeletes();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('lms_courses');
    }
};
