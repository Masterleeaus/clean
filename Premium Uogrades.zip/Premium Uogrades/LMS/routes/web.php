<?php

use Illuminate\Support\Facades\Route;
use Modules\LMS\App\Http\Controllers\LmsCourseCategoryController;
use Modules\LMS\App\Http\Controllers\LmsCourseController;
use Modules\LMS\App\Http\Controllers\LmsEnrollmentController;
use Modules\LMS\App\Http\Controllers\LmsLessonController;
use Modules\LMS\App\Http\Controllers\MyLmsApiController;
use Modules\LMS\App\Http\Controllers\MyLmsWebController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['web', 'auth']) // Apply standard web & auth middleware
    ->prefix('lms')               // Prefix for all LMS routes
    ->name('lms.')        // Route Name Prefix (adjust if needed)
    ->group(function () {

        // Root LMS route - redirect to employee learning portal
        Route::get('/', function () {
            return redirect()->route('lms.my.courses');
        })->name('index');

        // --- Course Category Routes ---
        Route::prefix('categories')->name('categories.')->group(function () {
            Route::get('/', [LmsCourseCategoryController::class, 'index'])->name('index');
            Route::get('/list', [LmsCourseCategoryController::class, 'listAjax'])->name('listAjax'); // DataTables
            Route::post('/', [LmsCourseCategoryController::class, 'store'])->name('store');
            Route::get('/{category}/edit', [LmsCourseCategoryController::class, 'edit'])->name('edit'); // Fetch data
            Route::put('/{category}', [LmsCourseCategoryController::class, 'update'])->name('update'); // Standard PUT
            Route::delete('/{category}', [LmsCourseCategoryController::class, 'destroy'])->name('destroy'); // Standard DELETE
        });

        Route::prefix('courses')->name('courses.')->group(function () {
            Route::get('/', [LmsCourseController::class, 'index'])->name('index');
            Route::get('/list', [LmsCourseController::class, 'listAjax'])->name('listAjax'); // DataTables
            Route::post('/', [LmsCourseController::class, 'store'])->name('store');
            Route::get('/{course}/edit', [LmsCourseController::class, 'edit'])->name('edit'); // Fetch data for edit modal
            Route::put('/{course}', [LmsCourseController::class, 'update'])->name('update'); // Use PUT for update
            Route::delete('/{course}', [LmsCourseController::class, 'destroy'])->name('destroy'); // Use DELETE

            Route::get('/{course}', [LmsCourseController::class, 'show'])->name('show');

            Route::prefix('/{course}/lessons')->name('lessons.')->group(function () {
                // Display the lesson management page for a course
                Route::get('/', [LmsLessonController::class, 'index'])->name('index');
                // Store a new lesson for this course
                Route::post('/', [LmsLessonController::class, 'store'])->name('store');
                // Reorder lessons within this course
                Route::post('/reorder', [LmsLessonController::class, 'reorder'])->name('reorder');
            });

            // --- Enrollment Routes (Nested for context) ---
            Route::prefix('/{course}/enrollments')->name('enrollments.')->group(function () {
                // Get list of enrollments for the course (for DataTable)
                Route::get('/list', [LmsEnrollmentController::class, 'listAjax'])->name('listAjax');
                // Enroll users/designations into the course
                Route::post('/', [LmsEnrollmentController::class, 'store'])->name('store');

                Route::delete('/{enrollment}', [LmsEnrollmentController::class, 'destroy'])->name('destroy');

            });

            Route::prefix('/enrollments')->name('enrollments.')->group(function () {

                Route::get('/{enrollmentId}/progress', [LmsEnrollmentController::class, 'getProgressDetails'])->name('progress');
            });
            // --- End Nested Enrollment Routes ---

        });

        Route::prefix('lessons')->name('lessons.')->group(function () {
            // Get data for editing a specific lesson
            Route::get('/{lesson}/edit', [LmsLessonController::class, 'edit'])->name('edit');
            // Update a specific lesson
            Route::put('/{lesson}', [LmsLessonController::class, 'update'])->name('update');
            // Delete a specific lesson
            Route::delete('/{lesson}', [LmsLessonController::class, 'destroy'])->name('destroy');

            Route::get('/{lesson}/content/download', [LmsLessonController::class, 'downloadFile'])->name('downloadFile');
        });

    });

Route::middleware(['web', 'auth']) // Ensure user is logged in via web
    ->prefix('my-learning')
    ->name('lms.my.') // Route name prefix for employee routes
    ->group(function () {

        // Display the list of enrolled courses (My Courses page)
        Route::get('/', [MyLmsWebController::class, 'index'])->name('courses'); // lms.my.courses

        // Display the course details/player page for a specific enrollment
        // Using {enrollment} binding ensures user is enrolled
        Route::get('/course/{enrollment}', [MyLmsWebController::class, 'showCourse'])->name('course.show'); // lms.my.course.show

        // --- AJAX Actions from Employee UI ---
        // Mark a specific lesson as complete (Use POST for action)
        Route::post('/lessons/{lesson}/complete', [MyLmsApiController::class, 'markLessonComplete'])->name('api.lesson.complete');

        // (Optional) Get specific lesson content if needed dynamically
        Route::get('/lessons/{lesson}/content', [MyLmsApiController::class, 'getLessonContent'])->name('api.lesson.content');

    });
