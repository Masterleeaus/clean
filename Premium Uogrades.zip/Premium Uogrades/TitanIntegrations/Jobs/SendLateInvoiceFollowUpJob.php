<?php
namespace Modules\TitanIntegrations\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;
use Modules\TitanIntegrations\Services\MailTemplateRenderer;

class SendLateInvoiceFollowUpJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;
    public function __construct(public array $payload) {}
    public function handle(MailTemplateRenderer $renderer): void
    {
        $template = $this->payload['template'] ?? 'late_invoice_first_notice';
        $message = $renderer->render($template, $this->payload);
        Log::info('Prepared late invoice follow-up', ['template' => $template, 'subject' => $message['subject'], 'requires_approval' => $message['requires_approval'] ?? true]);
    }
}
