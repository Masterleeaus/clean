<?php

use Illuminate\Support\Facades\Route;
use Modules\TitanIntegrations\Http\Controllers\Api\IntegrationAgentController;
use Modules\TitanIntegrations\Http\Controllers\Api\ProviderCatalogController;
use Modules\TitanIntegrations\Http\Controllers\Api\AutomationApiController;
use Modules\TitanIntegrations\Http\Controllers\Api\V1\BookingApiController;
use Modules\TitanIntegrations\Http\Controllers\Api\V1\ClientApiController;
use Modules\TitanIntegrations\Http\Controllers\Api\V1\InvoiceApiController;
use Modules\TitanIntegrations\Http\Controllers\Api\V1\ServiceApiController;
use Modules\TitanIntegrations\Http\Controllers\Api\V1\ZoneApiController;

/*
|--------------------------------------------------------------------------
| TitanIntegrations REST API
|--------------------------------------------------------------------------
| Auth: Bearer token (ApiToken model)
| Prefix after provider boot: /api
*/

Route::get('integrations/providers', [ProviderCatalogController::class, 'index'])
    ->middleware(['auth:sanctum'])
    ->name('titan-integrations.providers.index');
Route::get('integrations/providers/{provider}', [ProviderCatalogController::class, 'show'])
    ->middleware(['auth:sanctum'])
    ->name('titan-integrations.providers.show');

Route::post('ai/integration-agent/ask', [IntegrationAgentController::class, 'ask'])
    ->middleware(['auth:sanctum'])
    ->name('titan-integrations.ai.integration-agent.ask');
Route::get('ai/integration-agent/providers/{provider}/setup-guide', [IntegrationAgentController::class, 'providerGuide'])
    ->middleware(['auth:sanctum'])
    ->name('titan-integrations.ai.integration-agent.provider-guide');

Route::middleware(['auth:sanctum'])->prefix('integrations/automation')->group(function () {
    Route::post('late-invoice', [AutomationApiController::class, 'lateInvoice'])->name('titan-integrations.automation.late-invoice');
    Route::post('payment-assist', [AutomationApiController::class, 'paymentAssist'])->name('titan-integrations.automation.payment-assist');
    Route::post('job-event', [AutomationApiController::class, 'jobEvent'])->name('titan-integrations.automation.job-event');
    Route::post('mail-template/render', [AutomationApiController::class, 'renderTemplate'])->name('titan-integrations.automation.mail-template.render');
});

Route::prefix('v1')
    ->middleware(['throttle:60,1', \Modules\TitanIntegrations\Http\Middleware\ApiTokenMiddleware::class])
    ->group(function () {
        Route::get('ping', fn() => response()->json(['ok' => true, 'service' => 'Titan Integrations API v1']))
            ->withoutMiddleware(\Modules\TitanIntegrations\Http\Middleware\ApiTokenMiddleware::class);

        Route::apiResource('bookings', BookingApiController::class);
        Route::apiResource('clients', ClientApiController::class)->only(['index', 'show', 'store']);
        Route::apiResource('invoices', InvoiceApiController::class)->only(['index', 'show']);
        Route::apiResource('services', ServiceApiController::class)->only(['index']);
        Route::apiResource('zones', ZoneApiController::class)->only(['index']);
    });
