<?php
namespace Modules\TitanIntegrations\Http\Controllers;

use Illuminate\Http\Request;
use Modules\TitanIntegrations\Services\Automation\AutomationRuleEngine;
use Modules\TitanIntegrations\Services\Automation\LateInvoiceFollowUpService;
use Modules\TitanIntegrations\Services\Automation\JobEventAssistService;
use Modules\TitanIntegrations\Services\MailTemplateRenderer;

class AutomationController extends AccountBaseController
{
    public function index()
    {
        return response()->json(['enabled' => config('titanintegrations-automation.enabled', true), 'rules' => ['late_invoice_follow_up', 'payment_assist', 'job_event_watch', 'webhook_retry']]);
    }
    public function evaluate(Request $request, AutomationRuleEngine $engine) { return response()->json($engine->evaluate($request->input('rule', []), $request->input('payload', []))); }
    public function lateInvoices(Request $request, LateInvoiceFollowUpService $service) { return response()->json($service->assess($request->input('invoice', []))); }
    public function jobsEvents(Request $request, JobEventAssistService $service) { return response()->json($service->inspectJob($request->input('job', []))); }
    public function mailTemplates(MailTemplateRenderer $renderer) { return response()->json(['templates' => $renderer->templates()]); }
}
