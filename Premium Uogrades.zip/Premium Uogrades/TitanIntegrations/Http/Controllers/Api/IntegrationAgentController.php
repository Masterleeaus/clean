<?php
namespace Modules\TitanIntegrations\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\TitanIntegrations\AI\Actions\AskIntegrationAgentAction;
use Modules\TitanIntegrations\Services\ProviderSetupGuideGenerator;

class IntegrationAgentController extends Controller
{
    public function ask(Request $request, AskIntegrationAgentAction $agent)
    {
        $data = $request->validate([
            'message' => 'required|string|max:8000',
            'context' => 'array',
        ]);

        return response()->json($agent->execute($data['message'], $data['context'] ?? [])->toArray());
    }

    public function providerGuide(Request $request, string $provider, ProviderSetupGuideGenerator $generator)
    {
        if ($request->query('format') === 'markdown') {
            return response($generator->renderMarkdown($provider), 200, ['Content-Type' => 'text/markdown; charset=UTF-8']);
        }

        return response()->json($generator->generate($provider));
    }
}
