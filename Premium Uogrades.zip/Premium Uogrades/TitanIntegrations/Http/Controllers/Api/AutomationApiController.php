<?php
namespace Modules\TitanIntegrations\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\TitanIntegrations\Actions\AssessLateInvoiceAction;
use Modules\TitanIntegrations\Actions\InspectJobEventAction;
use Modules\TitanIntegrations\Actions\PreparePaymentAssistAction;
use Modules\TitanIntegrations\Services\MailTemplateRenderer;

class AutomationApiController extends Controller
{
    public function lateInvoice(Request $request, AssessLateInvoiceAction $action) { return response()->json($action->execute($request->input('invoice', []))); }
    public function paymentAssist(Request $request, PreparePaymentAssistAction $action) { return response()->json($action->execute($request->input('invoice', []), $request->input('connected_providers', []))); }
    public function jobEvent(Request $request, InspectJobEventAction $action) { return response()->json($action->execute($request->input('job', []))); }
    public function renderTemplate(Request $request, MailTemplateRenderer $renderer) { return response()->json($renderer->render($request->input('template', 'late_invoice_first_notice'), $request->input('data', []))); }
}
