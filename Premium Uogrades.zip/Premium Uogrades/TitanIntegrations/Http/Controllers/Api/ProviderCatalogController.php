<?php
namespace Modules\TitanIntegrations\Http\Controllers\Api;

use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Modules\TitanIntegrations\Services\ProviderRegistryService;
use Modules\TitanIntegrations\Services\ProviderSetupGuideGenerator;

class ProviderCatalogController extends Controller
{
    public function index(Request $request, ProviderRegistryService $registry)
    {
        return response()->json([
            'ok' => true,
            'categories' => $registry->categories(),
            'providers' => $registry->search(
                $request->query('q'),
                $request->query('category'),
                $request->query('auth'),
                (int) $request->query('limit', 50)
            ),
        ]);
    }

    public function show(string $provider, ProviderRegistryService $registry, ProviderSetupGuideGenerator $guides)
    {
        $cfg = $registry->get($provider);
        if (!$cfg) {
            return response()->json(['ok' => false, 'error' => 'Unknown provider.', 'provider' => $provider], 404);
        }
        return response()->json(['ok' => true, 'provider' => $provider, 'config' => $cfg, 'setup_guide' => $guides->generate($provider, $cfg)]);
    }
}
