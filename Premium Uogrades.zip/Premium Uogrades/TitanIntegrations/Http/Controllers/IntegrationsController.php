<?php

namespace Modules\TitanIntegrations\Http\Controllers;

use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\TitanIntegrations\Entities\Integration;
use Modules\TitanIntegrations\Entities\IntegrationLog;
use Modules\TitanIntegrations\Services\ProviderSetupGuideGenerator;

class IntegrationsController extends AccountBaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->pageTitle = 'Integrations';
    }

    /**
     * Integration dashboard — shows all available BYO integrations and status.
     */
    public function index()
    {
        $viewPermission = user()->permission('view_integrations');
        abort_403(!in_array($viewPermission, ['all', 'added', 'owned', 'both']));

        $companyId = company()->id;
        $registry  = config('titanintegrations.integrations', []);

        $connected = Integration::forCompany($companyId)->get()->keyBy('provider');

        $integrations = collect($registry)->map(function ($cfg, $provider) use ($connected) {
            $integration = $connected->get($provider);
            return [
                'provider'     => $provider,
                'label'        => $cfg['label'],
                'icon'         => $cfg['icon'] ?? 'link',
                'category'     => $cfg['category'],
                'auth'         => $cfg['auth'],
                'note'         => $cfg['note'] ?? null,
                'fields'       => $cfg['fields'] ?? [],
                'instructions' => $cfg['instructions'] ?? [],
                'status'       => $integration?->status ?? 'disconnected',
                'is_byo'       => $integration?->is_byo ?? false,
                'last_synced'  => $integration?->last_synced_at?->diffForHumans(),
                'account_name' => $integration?->settings['account_name'] ?? null,
                'error'        => $integration?->error_message,
            ];
        })->groupBy('category');

        $this->data['integrations'] = $integrations;
        $this->data['categories'] = config('titanintegrations.categories', []);
        $this->data['privacy_notice'] = config('titanintegrations.privacy_notice');

        return view('titanintegrations::index', $this->data);
    }

    /**
     * Show connect form for BYO API key, OAuth app or webhook credentials.
     */
    public function showConnect(string $provider)
    {
        abort_403(user()->permission('manage_integrations') !== 'all');

        $cfg = config("titanintegrations.integrations.{$provider}");
        abort_404(!$cfg);

        $this->data['provider']    = $provider;
        $cfg['setup_guide'] = app(ProviderSetupGuideGenerator::class)->generate($provider, $cfg);
        $this->data['config']      = $cfg;
        $this->data['integration'] = Integration::forCompany(company()->id)
            ->where('provider', $provider)
            ->first();

        return view('titanintegrations::connect', $this->data);
    }

    /**
     * Save BYO credentials. Secrets are encrypted through the Integration model accessors.
     */
    public function connect(Request $request, string $provider)
    {
        abort_403(user()->permission('manage_integrations') !== 'all');

        $cfg = config("titanintegrations.integrations.{$provider}");
        abort_404(!$cfg);

        $companyId = company()->id;
        $authType  = $cfg['auth'];

        $integration = Integration::firstOrNew([
            'company_id' => $companyId,
            'provider'   => $provider,
        ]);

        $integration->credential_type = $authType;
        $integration->is_byo = true;

        $settings = $integration->settings ?? [];
        foreach (($cfg['fields'] ?? []) as $field) {
            $name = $field['name'] ?? null;
            if (!$name || !$request->filled($name)) {
                continue;
            }

            if ($name === 'api_key') {
                $integration->api_key = $request->input($name);
                continue;
            }

            if ($name === 'webhook_url') {
                $integration->webhook_url = $request->input($name);
                continue;
            }

            $settings[$name] = $request->input($name);
        }

        if ($authType === 'api_key' && !$request->filled('api_key') && !$integration->api_key) {
            return response()->json(['ok' => false, 'error' => 'API key is required'], 422);
        }

        if ($authType === 'webhook' && !$request->filled('webhook_url') && !$integration->webhook_url) {
            return response()->json(['ok' => false, 'error' => 'Webhook URL is required'], 422);
        }

        $integration->settings = $settings;
        $integration->save();

        $service = $this->resolveService($provider);
        if ($service) {
            $result = $service->testConnection($integration);
            if ($result['ok']) {
                $integration->markConnected($result['account'] ?? null);
                return response()->json(['ok' => true, 'message' => "Connected to {$cfg['label']} successfully"]);
            }

            $integration->markError($result['error'] ?? 'Connection test failed');
            return response()->json(['ok' => false, 'error' => $result['error'] ?? 'Connection test failed'], 422);
        }

        $integration->update(['status' => 'connected']);
        return response()->json(['ok' => true]);
    }

    /**
     * Disconnect an integration — removes credentials.
     */
    public function disconnect(string $provider)
    {
        abort_403(user()->permission('manage_integrations') !== 'all');

        Integration::forCompany(company()->id)
            ->where('provider', $provider)
            ->update([
                'status'        => 'disconnected',
                'access_token'  => null,
                'refresh_token' => null,
                'api_key'       => null,
                'webhook_url'   => null,
                'error_message' => null,
            ]);

        return response()->json(['ok' => true, 'message' => 'Integration disconnected']);
    }

    /**
     * Integration activity log.
     */
    public function logs(Request $request)
    {
        abort_403(user()->permission('view_integration_logs') !== 'all');

        $logs = IntegrationLog::where('company_id', company()->id)
            ->when($request->provider, fn($q) => $q->where('provider', $request->provider))
            ->when($request->status, fn($q) => $q->where('status', $request->status))
            ->latest()
            ->paginate(50);

        return response()->json($logs);
    }

    private function resolveService(string $provider): ?object
    {
        return match ($provider) {
            'google_calendar' => app(\Modules\TitanIntegrations\Services\Integrations\GoogleCalendarIntegration::class),
            'xero'            => app(\Modules\TitanIntegrations\Services\Integrations\XeroIntegration::class),
            'hubspot'         => app(\Modules\TitanIntegrations\Services\Integrations\HubSpotIntegration::class),
            'mailchimp'       => app(\Modules\TitanIntegrations\Services\Integrations\MailchimpIntegration::class),
            'slack'           => app(\Modules\TitanIntegrations\Services\Integrations\SlackIntegration::class),
            default           => app(\Modules\TitanIntegrations\Services\GenericByoIntegrationService::class),
        };
    }
}
