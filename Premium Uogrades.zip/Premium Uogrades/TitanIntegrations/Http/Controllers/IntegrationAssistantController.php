<?php

namespace Modules\TitanIntegrations\Http\Controllers;

use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\TitanIntegrations\Services\IntegrationSetupAssistant;

class IntegrationAssistantController extends AccountBaseController
{
    public function index()
    {
        return view('titanintegrations::agent');
    }

    public function __construct(private IntegrationSetupAssistant $assistant)
    {
        parent::__construct();
    }

    public function explain(Request $request, string $provider)
    {
        abort_403(user()->permission('manage_integrations') !== 'all');
        $request->validate(['question' => 'nullable|string|max:1000']);

        return response()->json($this->assistant->explain($provider, $request->input('question')));
    }

    public function guide(string $provider)
    {
        abort_403(user()->permission('manage_integrations') !== 'all');

        return response()->json($this->assistant->guide($provider));
    }
}
