<?php
use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void {
        Schema::create('titan_integration_agent_runs', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->nullable()->index();
            $table->string('agent_id')->index();
            $table->string('status')->default('completed');
            $table->json('tool_calls')->nullable();
            $table->json('citations')->nullable();
            $table->timestamps();
        });
    }
    public function down(): void { Schema::dropIfExists('titan_integration_agent_runs'); }
};
