# Dynamic Provider Setup Guide Engine

This pass adds a registry-driven guide generator so the Integration Agent can support hundreds of BYO providers without hand-writing every instruction page.

## Added

- `Services/ProviderSetupGuideGenerator.php`
- `Data/ProviderSetupGuideData.php`
- Agent tool: `provider.setup_guide`
- Web route: `GET /account/titan-integrations/{provider}/setup-guide`
- API route: `GET /api/ai/integration-agent/providers/{provider}/setup-guide`
- Markdown output: append `?format=markdown`

## Behaviour

The generator uses provider metadata first. If provider-specific instructions are sparse, it creates safe defaults based on auth type:

- `api_key`: developer settings, token creation, least privilege, encrypted paste
- `oauth`: app creation, callback URL, client ID/secret, scopes
- `webhook`: event selection, signing secret, delivery test

## Privacy model

Users bring and control their own credentials. Titan does not resell provider keys, proxy shared platform credentials, or add provider usage markup.
