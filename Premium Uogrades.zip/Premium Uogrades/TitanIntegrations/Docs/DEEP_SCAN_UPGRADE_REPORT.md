# Deep Scan Upgrade Report

## Repairs

- Fixed recursive knowledge-pack indexing; previous glob pattern did not reliably scan nested folders.
- Added optional persistence for indexed knowledge chunks.
- Fixed retrieval fallback to search nested knowledge files and database-backed chunks.
- Registered the knowledge index console command in the service provider.
- Added provider catalog API endpoints for agent/UI use.
- Hardened IntegrationSetupAssistant tenant resolution so it does not require a global `company()` helper.
- Aligned tool class names with manifest/config tool names.
- Added functional provider search, schema validation, knowledge search and safe connection/webhook planning tool handlers.
- Added missing Action, Repository and Workflow scaffolding for connection testing.

## Preserved

- Existing provider registry with 135 providers.
- Existing web routes, API token system, webhook system, OAuth service, setup guide generator and UI views.
- Existing domain API controllers for clients/bookings/invoices/services/zones for backward compatibility.

## Recommended next pass

- Add per-provider live connection adapters for the highest-value cleaning SaaS systems.
- Add tenant-scoped audit logs for every Integration Agent tool call.
- Add queued webhook replay dashboard and provider rate-limit profiles.
