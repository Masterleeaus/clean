# BYO Cleaning SaaS Provider Expansion

This pass expands Titan Integrations around a privacy-first BYO credential marketplace.

## Added provider families

- Residential cleaning SaaS: ZenMaid, MaidCentral, Launch27, Maidily, BookingKoala, The Cleaning Software, ConvertLabs, The Customer Factor, Cleaning Service Software, MaidEasy, PodiumIO.
- Commercial janitorial: Swept, SweptWorks, Janitorial Manager, CleanTelligent, Clean Smarts.
- Field-service platforms commonly used by cleaning teams: Jobber, Housecall Pro, ServiceM8, Workiz, FieldPulse, Service Fusion, mHelpDesk, GorillaDesk, Service Autopilot, FieldVibe, Simpro, ServiceTitan, Tradify, ServiceWorks, Skedulo, Zuper.
- Workforce/team operations: Connecteam, Hubstaff, Deputy, When I Work, Homebase.
- Marketing/reputation for service businesses: Service Direct, NiceJob.

## BYO setup guide contract

Every provider registry entry now supports:

- `setup_guide.summary`
- `setup_guide.where_to_start`
- `setup_guide.steps`
- `setup_guide.recommended_scopes`
- `setup_guide.privacy_notes`
- `setup_guide.test_checklist`
- `byo_privacy_badges`
- `sync_objects`

The connect screen renders this as a guided panel before credential entry.

## Security posture

Secrets remain user-owned, encrypted at rest, revocable from the original provider, and billed directly by the provider account. The AI assistant is instructed not to ask users to paste secrets into chat.
