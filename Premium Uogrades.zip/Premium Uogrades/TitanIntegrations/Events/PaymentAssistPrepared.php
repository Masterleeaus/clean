<?php
namespace Modules\TitanIntegrations\Events;

class PaymentAssistPrepared
{
    public function __construct(public array $payload = []) {}
}
