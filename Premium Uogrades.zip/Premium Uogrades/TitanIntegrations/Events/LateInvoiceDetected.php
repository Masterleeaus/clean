<?php
namespace Modules\TitanIntegrations\Events;

class LateInvoiceDetected
{
    public function __construct(public array $payload = []) {}
}
