<?php
namespace Modules\TitanIntegrations\Events;

class JobEventFlagged
{
    public function __construct(public array $payload = []) {}
}
