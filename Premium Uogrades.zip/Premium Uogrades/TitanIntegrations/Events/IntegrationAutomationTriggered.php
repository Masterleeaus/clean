<?php
namespace Modules\TitanIntegrations\Events;

class IntegrationAutomationTriggered
{
    public function __construct(public array $payload = []) {}
}
