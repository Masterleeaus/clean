@extends('layouts.app')
@section('content')
<h1>Titan Integration Agent</h1>
<p>Use this assistant for BYO provider setup, diagnostics, late-invoice follow-up, payment assistance, jobs, events, and mail-template preparation.</p>
@endsection
