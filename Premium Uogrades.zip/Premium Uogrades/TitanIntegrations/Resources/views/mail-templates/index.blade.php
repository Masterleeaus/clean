@extends('layouts.app')
@section('content')
<h1>Mail Templates</h1>
<p>Review and customize integration mail templates before enabling external sends.</p>
@endsection
