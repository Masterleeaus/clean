@php
    $canView = user()->permission('view_integrations') === 'all';
@endphp

@if ($canView)
    <x-menu-item icon="plug" :text="__('titanintegrations::app.integrations')" :link="route('titan-integrations.index')" />
    <x-menu-item icon="key" :text="__('titanintegrations::app.api_tokens')" :link="route('titan-integrations.api-tokens.index')" />
    <x-menu-item icon="link" :text="__('titanintegrations::app.webhooks')" :link="route('titan-integrations.webhooks.index')" />
    <x-menu-item icon="activity" :text="__('titanintegrations::app.logs')" :link="route('titan-integrations.logs')" />
@endif
