@php
    $guide = $config['setup_guide'] ?? [];
    $badges = $config['byo_privacy_badges'] ?? ['User-owned key', 'Encrypted storage', 'Revocable anytime'];
@endphp

<div class="card border-primary mb-4">
    <div class="card-header bg-light d-flex justify-content-between align-items-center">
        <h6 class="mb-0"><i class="fa fa-compass"></i> Guided BYO credential setup</h6>
        <span class="badge badge-primary">No shared platform keys</span>
    </div>
    <div class="card-body">
        @if(!empty($guide['summary']))
            <p class="mb-3">{{ $guide['summary'] }}</p>
        @endif

        <div class="mb-3">
            @foreach($badges as $badge)
                <span class="badge badge-info mr-1 mb-1">{{ $badge }}</span>
            @endforeach
        </div>

        @if(!empty($guide['where_to_start']))
            <p class="small mb-3">
                <strong>Start here:</strong>
                <a href="{{ $guide['where_to_start'] }}" target="_blank" rel="noopener noreferrer">{{ $guide['where_to_start'] }}</a>
            </p>
        @endif

        @if(!empty($guide['steps']))
            <h6>Step-by-step</h6>
            <ol class="pl-3">
                @foreach($guide['steps'] as $step)
                    <li>{{ $step }}</li>
                @endforeach
            </ol>
        @endif

        @if(!empty($guide['recommended_scopes']))
            <h6>Recommended least-privilege scopes</h6>
            <div class="mb-3">
                @foreach($guide['recommended_scopes'] as $scope)
                    <span class="badge badge-light border mr-1 mb-1">{{ $scope }}</span>
                @endforeach
            </div>
        @endif

        @if(!empty($guide['test_checklist']))
            <h6>Connection test checklist</h6>
            <ul class="pl-3 mb-3">
                @foreach($guide['test_checklist'] as $item)
                    <li>{{ $item }}</li>
                @endforeach
            </ul>
        @endif

        @if(!empty($guide['privacy_notes']))
            <div class="alert alert-warning small mb-0">
                <strong>Privacy guardrails:</strong>
                <ul class="pl-3 mb-0">
                    @foreach($guide['privacy_notes'] as $note)
                        <li>{{ $note }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
    </div>
</div>
