<p>{{ $data['body'] ?? 'This is a reminder about an overdue invoice.' }}</p>
@if(!empty($data['payment_link']))
<p><a href="{{ $data['payment_link'] }}">Pay invoice</a></p>
@endif
<p><small>This message was prepared by Titan Integrations and may require operator approval before sending.</small></p>
