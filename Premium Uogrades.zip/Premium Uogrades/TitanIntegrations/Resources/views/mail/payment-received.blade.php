<p>{{ $data['body'] ?? 'Payment received. Thank you.' }}</p>
