<p>{{ $data['body'] ?? 'This is a reminder for an upcoming job.' }}</p>
