@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-lg-8 offset-lg-2">
            <div class="card mb-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h5 class="card-title mb-0">Connect {{ $config['label'] }}</h5>
                    <span class="badge badge-info">BYO Credentials</span>
                </div>
                <div class="card-body">
                    <div class="alert alert-light border">
                        <strong>You stay in control.</strong>
                        Bring your own API key, OAuth app, token or webhook. Usage and billing remain with your provider account, and stored secrets are encrypted at rest.
                    </div>

                    @if($integration?->status === 'connected')
                        <div class="alert alert-success">
                            <i class="fa fa-check-circle"></i>
                            Connected
                            @if($integration->settings['account_name'] ?? null)
                                as <strong>{{ $integration->settings['account_name'] }}</strong>
                            @endif
                        </div>
                    @endif

                    @if(config('titanintegrations.guide_ui.enabled', true))
                        @include('titanintegrations::partials.setup-guide', ['config' => $config])
                    @elseif(!empty($config['instructions']))
                        <div class="mb-4">
                            <h6>How to get your {{ $config['label'] }} credentials</h6>
                            <ol class="pl-3 mb-0">
                                @foreach($config['instructions'] as $step)
                                    <li>{{ $step }}</li>
                                @endforeach
                            </ol>
                        </div>
                    @endif
                    <div class="card border-info mb-4">
                        <div class="card-body">
                            <h6 class="mb-2"><i class="fa fa-robot"></i> AI setup assistant</h6>
                            <p class="text-muted small mb-2">Ask for setup guidance without sharing your secret key in chat.</p>
                            <div class="input-group input-group-sm">
                                <input type="text" id="assistant-question" class="form-control" placeholder="e.g. What scopes should I choose?">
                                <div class="input-group-append">
                                    <button class="btn btn-outline-info" type="button" id="assistant-btn">Ask</button>
                                </div>
                            </div>
                            <pre id="assistant-answer" class="small bg-light p-2 mt-2 mb-0" style="white-space: pre-wrap; display:none;"></pre>
                        </div>
                    </div>

                    @if(($config['auth'] ?? null) === 'oauth')
                        <div class="alert alert-warning">
                            <strong>OAuth BYO app:</strong> save your Client ID, Client Secret and Redirect URI here first, then use the OAuth connect button from the integrations dashboard.
                        </div>
                    @endif

                    <form id="connect-form">
                        @csrf

                        @foreach(($config['fields'] ?? []) as $field)
                            @php
                                $name = $field['name'];
                                $type = $field['type'] ?? 'text';
                                $saved = $name === 'webhook_url'
                                    ? ($integration?->webhook_url ? '(saved)' : '')
                                    : ($integration?->settings[$name] ?? '');
                                $isSecret = ($field['secret'] ?? false) || $type === 'password';
                            @endphp
                            <div class="form-group">
                                <label>{{ $field['label'] ?? Str::headline($name) }} @if($field['required'] ?? false)<span class="text-danger">*</span>@endif</label>
                                <input type="{{ $type }}" name="{{ $name }}" class="form-control"
                                       value="{{ $isSecret ? '' : $saved }}"
                                       placeholder="{{ $field['placeholder'] ?? '' }}"
                                       autocomplete="off" @if($field['required'] ?? false) required @endif>
                                @if($isSecret && ($name === 'api_key' ? $integration?->api_key : !empty($saved)))
                                    <small class="form-text text-muted">A secret is already saved. Leave blank to keep it unchanged.</small>
                                @endif
                            </div>
                        @endforeach

                        @if(empty($config['fields']))
                            <div class="alert alert-secondary">No credentials are required for this integration.</div>
                        @endif

                        <div class="d-flex justify-content-between mt-3">
                            <a href="{{ route('titan-integrations.index') }}" class="btn btn-secondary">Cancel</a>
                            <button type="submit" class="btn btn-primary" id="save-btn">
                                <i class="fa fa-plug"></i> Save & Test
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
document.getElementById('connect-form').addEventListener('submit', function(e) {
    e.preventDefault();
    const btn = document.getElementById('save-btn');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa fa-spinner fa-spin"></i> Testing connection...';

    const data = Object.fromEntries(new FormData(this));

    fetch('{{ route('titan-integrations.connect', $provider) }}', {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}'},
        body: JSON.stringify(data),
    })
    .then(r => r.json())
    .then(result => {
        if (result.ok) {
            window.location = '{{ route('titan-integrations.index') }}';
        } else {
            alert('Connection failed: ' + (result.error || 'Unknown error'));
            btn.disabled = false;
            btn.innerHTML = '<i class="fa fa-plug"></i> Save & Test';
        }
    });
});

document.getElementById('assistant-btn').addEventListener('click', function() {
    const answer = document.getElementById('assistant-answer');
    answer.style.display = 'block';
    answer.innerText = 'Thinking...';

    fetch('{{ route('titan-integrations.assistant.explain', $provider) }}', {
        method: 'POST',
        headers: {'Content-Type': 'application/json', 'X-CSRF-TOKEN': '{{ csrf_token() }}'},
        body: JSON.stringify({question: document.getElementById('assistant-question').value}),
    })
    .then(r => r.json())
    .then(result => {
        answer.innerText = result.answer || 'No guidance available.';
    })
    .catch(() => answer.innerText = 'Assistant unavailable. Use the setup steps above.');
});
</script>
@endsection
