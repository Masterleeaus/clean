@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="row">
        <div class="col-sm-12">
            <div class="page-title-box">
                <h4 class="page-title">Integrations</h4>
                <div class="page-title-right">
                    <a href="{{ route('titan-integrations.api-tokens.index') }}" class="btn btn-outline-secondary btn-sm mr-2">
                        <i class="fa fa-key"></i> API Tokens
                    </a>
                    <a href="{{ route('titan-integrations.webhooks.index') }}" class="btn btn-outline-secondary btn-sm">
                        <i class="fa fa-plug"></i> Webhooks
                    </a>
                </div>
            </div>
        </div>
    </div>

    @if(!empty($privacy_notice))
        <div class="alert alert-info"><i class="fa fa-lock"></i> {{ $privacy_notice }}</div>
    @endif

    @if(session('success'))
        <div class="alert alert-success">{{ session('success') }}</div>
    @endif
    @if(session('error'))
        <div class="alert alert-danger">{{ session('error') }}</div>
    @endif

    @foreach($integrations as $category => $items)
        <div class="row mb-4">
            <div class="col-12">
                <h5 class="text-muted mb-3">{{ $categories[$category] ?? ucfirst($category) }}</h5>
            </div>

            @foreach($items as $item)
            <div class="col-md-4 col-lg-3 mb-3">
                <div class="card h-100 integration-card @if($item['status'] === 'connected') border-success @elseif($item['status'] === 'error') border-danger @endif">
                    <div class="card-body d-flex flex-column">
                        <div class="d-flex align-items-center mb-3">
                            <div class="integration-icon mr-3">
                                <i class="fa fa-{{ $item['icon'] }} fa-2x text-muted"></i>
                            </div>
                            <div>
                                <h6 class="mb-0">{{ $item['label'] }}</h6>
                                <span class="badge badge-light badge-sm">{{ strtoupper($item['auth']) }}</span>
                                @if($item['status'] === 'connected')
                                    <span class="badge badge-success badge-sm">Connected</span>
                                    @if($item['is_byo'])
                                        <span class="badge badge-info badge-sm ml-1">Your Credentials</span>
                                    @endif
                                @elseif($item['status'] === 'error')
                                    <span class="badge badge-danger badge-sm">Error</span>
                                @else
                                    <span class="badge badge-secondary badge-sm">Disconnected</span>
                                @endif
                            </div>
                        </div>

                        @if($item['account_name'])
                            <p class="text-muted small mb-1"><i class="fa fa-user-circle"></i> {{ $item['account_name'] }}</p>
                        @endif
                        @if($item['last_synced'])
                            <p class="text-muted small mb-1"><i class="fa fa-sync"></i> Synced {{ $item['last_synced'] }}</p>
                        @endif
                        @if($item['error'])
                            <p class="text-danger small mb-1"><i class="fa fa-exclamation-circle"></i> {{ Str::limit($item['error'], 60) }}</p>
                        @endif
                        @if($item['note'])
                            <p class="text-muted small mb-2">{{ $item['note'] }}</p>
                        @endif
                        @if(!empty($item['instructions']))
                            <p class="text-muted small mb-2"><i class="fa fa-list"></i> Setup guide included</p>
                        @endif

                        <div class="mt-auto pt-2">
                            @if($item['status'] === 'connected')
                                <form method="POST" action="{{ route('titan-integrations.disconnect', $item['provider']) }}" class="d-inline">
                                    @csrf
                                    <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Disconnect {{ $item['label'] }}?')">Disconnect</button>
                                </form>
                            @else
                                <a href="{{ route('titan-integrations.connect.show', $item['provider']) }}" class="btn btn-sm btn-primary">Setup</a>
                                @if($item['auth'] === 'oauth')
                                    <a href="{{ route('titan-integrations.oauth.redirect', $item['provider']) }}" class="btn btn-sm btn-outline-primary mt-1">Start OAuth</a>
                                @endif
                            @endif
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    @endforeach
</div>
@endsection
