@extends('layouts.app')
@section('content')
<h1>Integration Automations</h1>
<p>Manage safe-mode automation rules for invoices, payments, jobs, events, webhooks, and sync diagnostics.</p>
@endsection
