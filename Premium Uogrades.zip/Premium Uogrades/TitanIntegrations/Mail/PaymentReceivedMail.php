<?php
namespace Modules\TitanIntegrations\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class PaymentReceivedMail extends Mailable
{
    use Queueable, SerializesModels;
    public function __construct(public array $messageData) {}
    public function build(): self
    {
        return $this->subject($this->messageData['subject'] ?? 'Payment received')->view('titanintegrations::mail.payment-received', ['data' => $this->messageData]);
    }
}
