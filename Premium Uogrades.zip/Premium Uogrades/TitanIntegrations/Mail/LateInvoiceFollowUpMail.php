<?php
namespace Modules\TitanIntegrations\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class LateInvoiceFollowUpMail extends Mailable
{
    use Queueable, SerializesModels;
    public function __construct(public array $messageData) {}
    public function build(): self
    {
        return $this->subject($this->messageData['subject'] ?? 'Invoice reminder')->view('titanintegrations::mail.late-invoice-follow-up', ['data' => $this->messageData]);
    }
}
