<?php
namespace Modules\TitanIntegrations\Tests\Unit;

use Modules\TitanIntegrations\Services\MailTemplateRenderer;
use Tests\TestCase;

class MailTemplateRendererTest extends TestCase
{
    public function test_renders_invoice_template(): void
    {
        $message = (new MailTemplateRenderer())->render('late_invoice_first_notice', ['customer_name' => 'Alex', 'invoice_number' => 'INV-1', 'amount_due' => '$100', 'payment_link' => 'https://example.test/pay']);
        $this->assertStringContainsString('INV-1', $message['body']);
    }
}
