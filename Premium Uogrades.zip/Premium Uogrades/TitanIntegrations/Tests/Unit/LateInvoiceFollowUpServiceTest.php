<?php
namespace Modules\TitanIntegrations\Tests\Unit;

use Modules\TitanIntegrations\Services\Automation\LateInvoiceFollowUpService;
use Tests\TestCase;

class LateInvoiceFollowUpServiceTest extends TestCase
{
    public function test_detects_late_invoice(): void
    {
        $result = (new LateInvoiceFollowUpService())->assess(['due_at' => now()->subDays(10)->toDateString(), 'balance_due' => 120, 'paid' => false]);
        $this->assertTrue($result['late']);
    }
}
