<?php

it('uses integration agent naming', function () {
    expect(class_exists(\Modules\TitanIntegrations\AI\Actions\AskIntegrationAgentAction::class))->toBeTrue();
});
