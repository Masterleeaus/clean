<?php

it('generates setup guides from registry metadata', function () {
    $generator = app(\Modules\TitanIntegrations\Services\ProviderSetupGuideGenerator::class);
    $guide = $generator->generate('openai');

    expect($guide['ok'])->toBeTrue();
    expect($guide['provider'])->toBe('openai');
    expect($guide['generated_from'])->toBe('provider_registry_metadata');
    expect($guide['credential_fields'])->not->toBeEmpty();
});
