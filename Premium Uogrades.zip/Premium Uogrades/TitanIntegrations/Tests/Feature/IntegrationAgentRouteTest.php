<?php

it('registers integration agent endpoint path', function () {
    expect('api/ai/integration-agent/ask')->toContain('integration-agent');
});
