<?php
namespace Modules\TitanIntegrations\Contracts;

interface AgentToolContract
{
    public function name(): string;
    public function description(): string;
    public function schema(): array;
    public function handle(array $input, array $context = []): array;
}
