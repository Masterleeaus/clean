<?php
namespace Modules\\TitanIntegrations\\Workflows;

class LateInvoiceFollowUpWorkflow
{
    public function definition(): array
    {
        return ['name' => 'late_invoice_follow_up', 'steps' => ['detect_late_invoice', 'prepare_payment_options', 'render_mail_template', 'request_operator_approval', 'send_or_create_task', 'log_outcome']];
    }
}
