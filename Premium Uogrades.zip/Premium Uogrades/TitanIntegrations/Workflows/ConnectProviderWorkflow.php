<?php
namespace Modules\TitanIntegrations\Workflows;

use Modules\TitanIntegrations\Actions\TestProviderConnectionAction;
use Modules\TitanIntegrations\Entities\Integration;

class ConnectProviderWorkflow
{
    public function __construct(protected TestProviderConnectionAction $testConnection) {}

    public function execute(Integration $integration): array
    {
        $integration->is_byo = true;
        $integration->is_active = true;
        $integration->save();
        return $this->testConnection->execute($integration);
    }
}
