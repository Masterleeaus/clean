<?php
namespace Modules\TitanIntegrations\Models;
use Illuminate\Database\Eloquent\Model;
class IntegrationAutomationRun extends Model
{
    protected $table = 'titan_integration_automation_runs';
    protected $guarded = [];
    protected $casts = ['payload'=>'array','result'=>'array','approved_at'=>'datetime'];
}
