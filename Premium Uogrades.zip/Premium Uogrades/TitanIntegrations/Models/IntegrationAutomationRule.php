<?php
namespace Modules\TitanIntegrations\Models;
use Illuminate\Database\Eloquent\Model;
class IntegrationAutomationRule extends Model
{
    protected $table = 'titan_integration_automation_rules';
    protected $guarded = [];
    protected $casts = ['conditions'=>'array','actions'=>'array','enabled'=>'boolean','requires_approval'=>'boolean'];
}
