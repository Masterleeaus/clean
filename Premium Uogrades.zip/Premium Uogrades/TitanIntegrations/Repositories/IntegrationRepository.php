<?php
namespace Modules\TitanIntegrations\Repositories;

use Modules\TitanIntegrations\Entities\Integration;

class IntegrationRepository
{
    public function forCompany(int $companyId)
    {
        return Integration::forCompany($companyId)->orderBy('provider');
    }

    public function findForCompany(int $companyId, string $provider): ?Integration
    {
        return Integration::forCompany($companyId)->where('provider', $provider)->first();
    }
}
