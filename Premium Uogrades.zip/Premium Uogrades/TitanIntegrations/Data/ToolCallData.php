<?php
namespace Modules\TitanIntegrations\Data;

class ToolCallData
{
    public function __construct(public string $tool, public array $input = [], public array $context = []) {}
}
