<?php
namespace Modules\TitanIntegrations\Data;

class AutomationRuleData
{
    public function __construct(public string $name, public array $conditions = [], public array $actions = [], public bool $requiresApproval = true) {}
}
