<?php

namespace Modules\TitanIntegrations\Data;

class ProviderSetupGuideData
{
    public function __construct(public array $guide) {}

    public function toArray(): array
    {
        return $this->guide;
    }
}
