<?php
namespace Modules\TitanIntegrations\Data;

class AgentResponseData
{
    public function __construct(public string $message, public array $citations = [], public array $actions = [], public array $meta = []) {}
    public function toArray(): array { return ['message' => $this->message, 'citations' => $this->citations, 'actions' => $this->actions, 'meta' => $this->meta]; }
}
