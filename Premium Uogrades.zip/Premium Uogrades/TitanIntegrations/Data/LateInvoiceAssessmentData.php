<?php
namespace Modules\TitanIntegrations\Data;

class LateInvoiceAssessmentData
{
    public function __construct(public bool $late, public int $daysLate, public float $balanceDue, public string $recommendedAction, public ?string $paymentLink = null) {}
}
