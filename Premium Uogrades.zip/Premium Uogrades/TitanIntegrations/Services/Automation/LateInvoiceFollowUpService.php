<?php
namespace Modules\TitanIntegrations\Services\Automation;

use Carbon\CarbonInterface;
use Illuminate\Support\Carbon;

class LateInvoiceFollowUpService
{
    public function assess(array $invoice, ?CarbonInterface $now = null): array
    {
        $now ??= Carbon::now();
        $dueAt = isset($invoice['due_at']) ? Carbon::parse($invoice['due_at']) : null;
        $paid = (bool) ($invoice['paid'] ?? false);
        $balance = (float) ($invoice['balance_due'] ?? $invoice['amount_due'] ?? 0);
        $daysLate = $dueAt ? max(0, $dueAt->diffInDays($now, false)) : 0;
        $graceDays = (int) config('titanintegrations-automation.late_invoice.default_grace_days', 2);
        $late = !$paid && $balance > 0 && $dueAt && $daysLate >= $graceDays;
        return [
            'late' => $late,
            'days_late' => $daysLate,
            'balance_due' => $balance,
            'recommended_action' => $late ? $this->recommendedAction($daysLate) : 'none',
            'payment_link' => $this->paymentLink($invoice),
            'template' => $daysLate >= 14 ? 'late_invoice_final_notice' : 'late_invoice_first_notice',
            'requires_approval' => config('titanintegrations-automation.approval_required_for_external_send', true),
        ];
    }

    public function recommendedAction(int $daysLate): string
    {
        return match (true) {
            $daysLate >= 14 => 'send_final_notice_and_create_payment_task',
            $daysLate >= 7 => 'send_second_follow_up',
            $daysLate >= 3 => 'send_friendly_reminder',
            default => 'prepare_first_notice',
        };
    }

    protected function paymentLink(array $invoice): ?string
    {
        foreach (config('titanintegrations-automation.late_invoice.payment_link_fields', []) as $field) {
            if (!empty($invoice[$field])) return $invoice[$field];
        }
        return null;
    }
}
