<?php
namespace Modules\TitanIntegrations\Services\Automation;

use Illuminate\Support\Arr;

class AutomationRuleEngine
{
    public function evaluate(array $rule, array $payload): array
    {
        $matched = true;
        $reasons = [];
        foreach (($rule['conditions'] ?? []) as $field => $expected) {
            $actual = Arr::get($payload, $field);
            $ok = is_array($expected) ? in_array($actual, $expected, true) : $actual == $expected;
            if (!$ok) {
                $matched = false;
                $reasons[] = "Condition {$field} did not match.";
            }
        }
        return ['matched' => $matched, 'actions' => $matched ? ($rule['actions'] ?? []) : [], 'reasons' => $reasons];
    }
}
