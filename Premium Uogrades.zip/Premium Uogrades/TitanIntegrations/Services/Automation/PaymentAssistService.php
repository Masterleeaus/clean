<?php
namespace Modules\TitanIntegrations\Services\Automation;

class PaymentAssistService
{
    public function buildPaymentOptions(array $invoice, array $connectedProviders = []): array
    {
        $options = [];
        foreach (['stripe', 'square', 'paypal', 'xero', 'quickbooks', 'myob'] as $provider) {
            if (in_array($provider, $connectedProviders, true)) {
                $options[] = ['provider' => $provider, 'action' => 'create_or_fetch_payment_link', 'safe_mode' => true, 'requires_approval' => true];
            }
        }
        return [
            'invoice_id' => $invoice['id'] ?? null,
            'amount_due' => $invoice['amount_due'] ?? $invoice['balance_due'] ?? null,
            'currency' => $invoice['currency'] ?? 'AUD',
            'options' => $options,
            'note' => 'The agent prepares payment actions and templates; external sends/payments require approval by default.',
        ];
    }
}
