<?php
namespace Modules\TitanIntegrations\Services\Automation;

use Illuminate\Support\Carbon;

class JobEventAssistService
{
    public function inspectJob(array $job): array
    {
        $scheduledAt = isset($job['scheduled_at']) ? Carbon::parse($job['scheduled_at']) : null;
        $status = $job['status'] ?? 'unknown';
        $flags = [];
        if ($status === 'unassigned') $flags[] = 'job_unassigned';
        if ($scheduledAt && $scheduledAt->isPast() && !in_array($status, ['completed', 'cancelled'], true)) $flags[] = 'job_past_due_not_closed';
        if (!empty($job['customer_needs_confirmation'])) $flags[] = 'customer_confirmation_needed';
        return ['job_id' => $job['id'] ?? null, 'flags' => $flags, 'recommended_actions' => $this->recommendedActions($flags)];
    }

    protected function recommendedActions(array $flags): array
    {
        $map = ['job_unassigned' => 'notify_dispatch_or_assign_team', 'job_past_due_not_closed' => 'request_status_update', 'customer_confirmation_needed' => 'send_confirmation_template'];
        return array_values(array_intersect_key($map, array_flip($flags)));
    }
}
