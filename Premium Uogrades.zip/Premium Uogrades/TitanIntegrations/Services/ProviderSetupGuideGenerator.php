<?php

namespace Modules\TitanIntegrations\Services;

class ProviderSetupGuideGenerator
{
    public function generate(string $provider, ?array $cfg = null): array
    {
        $cfg ??= config("titanintegrations.integrations.{$provider}");
        if (!$cfg) {
            return [
                'ok' => false,
                'provider' => $provider,
                'error' => 'Unknown integration provider.',
            ];
        }

        $auth = $cfg['auth'] ?? 'api_key';
        $fields = array_values($cfg['fields'] ?? []);
        $label = $cfg['label'] ?? str($provider)->headline()->toString();

        $steps = $this->normaliseSteps($cfg, $auth, $fields, $label);

        return [
            'ok' => true,
            'provider' => $provider,
            'label' => $label,
            'category' => $cfg['category'] ?? 'other',
            'auth' => $auth,
            'summary' => $this->summary($label, $auth),
            'where_to_start' => $cfg['docs_url'] ?? $cfg['developer_url'] ?? $cfg['homepage'] ?? null,
            'credential_fields' => $fields,
            'steps' => $steps,
            'recommended_scopes' => $this->recommendedScopes($cfg, $auth),
            'test_checklist' => $this->testChecklist($label, $auth, $fields),
            'troubleshooting' => $this->troubleshooting($auth),
            'privacy_notes' => $this->privacyNotes($auth),
            'agent_prompts' => $this->agentPrompts($label, $auth),
            'generated_from' => 'provider_registry_metadata',
        ];
    }

    public function renderMarkdown(string $provider, ?array $cfg = null): string
    {
        $guide = $this->generate($provider, $cfg);
        if (!($guide['ok'] ?? false)) {
            return 'Unknown integration provider.';
        }

        $lines = [];
        $lines[] = '# ' . $guide['label'] . ' BYO setup guide';
        $lines[] = '';
        $lines[] = $guide['summary'];
        $lines[] = '';
        $lines[] = '## Steps';
        foreach ($guide['steps'] as $index => $step) {
            $lines[] = ($index + 1) . '. ' . $step;
        }
        $lines[] = '';
        $lines[] = '## Required fields';
        foreach ($guide['credential_fields'] as $field) {
            $required = ($field['required'] ?? false) ? 'required' : 'optional';
            $secret = ($field['secret'] ?? false) ? ', secret' : '';
            $lines[] = '- ' . ($field['label'] ?? $field['name'] ?? 'Credential') . ' (' . $required . $secret . ')';
        }
        $lines[] = '';
        $lines[] = '## Test checklist';
        foreach ($guide['test_checklist'] as $item) {
            $lines[] = '- ' . $item;
        }
        $lines[] = '';
        $lines[] = '## Privacy guardrails';
        foreach ($guide['privacy_notes'] as $note) {
            $lines[] = '- ' . $note;
        }

        return implode("\n", $lines);
    }

    private function normaliseSteps(array $cfg, string $auth, array $fields, string $label): array
    {
        $existing = array_values(array_filter($cfg['instructions'] ?? []));
        if (count($existing) >= 3) {
            return $existing;
        }

        $steps = [];
        $steps[] = "Sign in to your {$label} account using an owner or admin profile.";

        if ($auth === 'oauth') {
            $steps[] = 'Open the developer, apps, integrations, or OAuth application area.';
            $steps[] = 'Create a new OAuth app owned by your organisation, then add the callback URL shown in Titan.';
            $steps[] = 'Copy the client ID and client secret into the encrypted credential fields.';
            $steps[] = 'Choose the minimum scopes required for the workflows you want to enable.';
        } elseif ($auth === 'webhook') {
            $steps[] = 'Open webhook, automation, or notification settings in the provider.';
            $steps[] = 'Create a new outbound webhook endpoint for the events Titan should receive.';
            $steps[] = 'Paste the generated webhook URL or signing secret into Titan as requested.';
        } else {
            $steps[] = 'Open developer settings, API settings, personal access tokens, or app passwords.';
            $steps[] = 'Create a new token/key specifically for Titan so it can be revoked independently.';
            $steps[] = 'Copy the key once and paste it only into Titan’s encrypted credential form.';
        }

        foreach ($fields as $field) {
            if (!empty($field['name']) && !in_array($field['name'], ['api_key', 'client_id', 'client_secret', 'webhook_url'], true)) {
                $steps[] = 'Fill the ' . ($field['label'] ?? $field['name']) . ' field from the matching value in your provider account.';
            }
        }

        $steps[] = 'Save, run Test connection, then rotate the key in the provider if you suspect it was exposed.';

        return $steps;
    }

    private function summary(string $label, string $auth): string
    {
        return match ($auth) {
            'oauth' => "Connect {$label} with a user-owned OAuth app. Titan stores only encrypted app credentials and tokens; provider billing and permissions remain under the user’s account.",
            'webhook' => "Connect {$label} with user-owned webhook settings. Titan receives only the events the user explicitly enables.",
            default => "Connect {$label} with a user-owned API key/token. Titan does not resell keys, proxy shared credentials, or add provider usage markup.",
        };
    }

    private function recommendedScopes(array $cfg, string $auth): array
    {
        if (!empty($cfg['recommended_scopes'])) {
            return array_values($cfg['recommended_scopes']);
        }

        return match ($auth) {
            'oauth' => ['read:account', 'read:data', 'write:data only when sync-back is enabled', 'offline_access only when refresh is required'],
            'webhook' => ['event delivery only', 'signature verification if supported'],
            default => ['least privilege', 'read-only first', 'write only for enabled actions'],
        };
    }

    private function testChecklist(string $label, string $auth, array $fields): array
    {
        $items = [
            "Confirm the {$label} credential belongs to the correct workspace/account.",
            'Run Titan’s saved connection test after entering credentials.',
            'Check that no API key or token is pasted into chat, tickets, or notes.',
        ];

        if ($auth === 'oauth') {
            $items[] = 'Verify redirect URI, scopes, client ID, client secret, and refresh-token behaviour.';
        }

        if ($auth === 'webhook') {
            $items[] = 'Send a provider test event and confirm Titan records the delivery.';
        }

        if (collect($fields)->contains(fn ($field) => ($field['name'] ?? null) === 'base_url')) {
            $items[] = 'Confirm the API base URL includes the correct region or tenant hostname.';
        }

        return $items;
    }

    private function troubleshooting(string $auth): array
    {
        return match ($auth) {
            'oauth' => [
                'invalid_client: re-check client ID and client secret.',
                'redirect_uri_mismatch: copy Titan’s callback URL exactly into the provider app.',
                'insufficient_scope: add the missing least-privilege scope and reconnect.',
            ],
            'webhook' => [
                '401/403 delivery: verify signing secret or auth header.',
                '404 delivery: confirm the endpoint URL has not changed.',
                'Duplicate events: enable idempotency keys in downstream processing.',
            ],
            default => [
                '401: key is invalid, expired, revoked, or copied with hidden whitespace.',
                '403: key exists but lacks required permissions.',
                '429: provider rate limit reached; reduce sync frequency or upgrade provider plan.',
            ],
        };
    }

    private function privacyNotes(string $auth): array
    {
        $notes = [
            'Users own the credential and can revoke it in the source provider at any time.',
            'Credentials should be pasted only into encrypted fields, never into AI chat.',
            'Use separate keys per workspace/customer where possible for clean audit trails.',
        ];

        if ($auth === 'oauth') {
            $notes[] = 'Refresh tokens should be encrypted and rotated when provider policy requires it.';
        }

        return $notes;
    }

    private function agentPrompts(string $label, string $auth): array
    {
        return [
            "Show me how to create a {$label} {$auth} credential.",
            "Which {$label} scopes should I choose for read-only sync?",
            "Why did my {$label} connection test fail?",
        ];
    }
}
