<?php

namespace Modules\TitanIntegrations\Services;

use Illuminate\Support\Facades\Http;
use Modules\TitanIntegrations\Entities\Integration;

class OAuthService
{
    /**
     * Build the OAuth authorization URL for a provider using tenant-owned OAuth app credentials.
     */
    public function buildAuthUrl(string $provider, int $companyId): string
    {
        $cfg = config("titanintegrations.integrations.{$provider}", []);
        $integration = Integration::forCompany($companyId)->where('provider', $provider)->first();
        $settings = $integration?->settings ?? [];

        $clientId = $settings['client_id'] ?? ($cfg['client_id'] ?? null);
        $redirectUri = $settings['redirect_uri'] ?? ($cfg['redirect_uri'] ?? route('titan-integrations.oauth.callback', $provider));

        $state = base64_encode(json_encode(['provider' => $provider, 'company_id' => $companyId]));
        session(["oauth_state_{$provider}" => $state]);

        $params = http_build_query([
            'client_id'     => $clientId,
            'redirect_uri'  => $redirectUri,
            'scope'         => implode(' ', $cfg['scopes'] ?? []),
            'response_type' => 'code',
            'access_type'   => 'offline',
            'state'         => $state,
        ]);

        return $this->getAuthEndpoint($provider) . '?' . $params;
    }

    /**
     * Exchange auth code for access + refresh tokens and persist on the Integration record.
     */
    public function exchangeCode(string $provider, string $code, Integration $integration): void
    {
        $cfg = config("titanintegrations.integrations.{$provider}", []);
        $settings = $integration->settings ?? [];
        $clientId = $settings['client_id'] ?? ($cfg['client_id'] ?? null);
        $clientSecret = $settings['client_secret'] ?? ($cfg['client_secret'] ?? null);
        $redirectUri = $settings['redirect_uri'] ?? ($cfg['redirect_uri'] ?? route('titan-integrations.oauth.callback', $provider));

        $response = Http::post($this->getTokenEndpoint($provider), [
            'grant_type'    => 'authorization_code',
            'code'          => $code,
            'client_id'     => $clientId,
            'client_secret' => $clientSecret,
            'redirect_uri'  => $redirectUri,
        ]);

        $data = $response->json();

        $integration->access_token     = $data['access_token'] ?? null;
        $integration->refresh_token    = $data['refresh_token'] ?? $integration->getDecryptedRefreshToken();
        $integration->token_expires_at = isset($data['expires_in'])
            ? now()->addSeconds((int) $data['expires_in'])
            : null;
        $integration->credential_type = 'oauth';
        $integration->save();
    }

    /**
     * Refresh an expiring access token using the stored refresh token and tenant-owned app credentials.
     */
    public function refreshToken(Integration $integration): bool
    {
        $provider = $integration->provider;
        $cfg = config("titanintegrations.integrations.{$provider}", []);
        $settings = $integration->settings ?? [];
        $refreshToken = $integration->getDecryptedRefreshToken();
        $clientId = $settings['client_id'] ?? ($cfg['client_id'] ?? null);
        $clientSecret = $settings['client_secret'] ?? ($cfg['client_secret'] ?? null);

        if (!$refreshToken) return false;

        $response = Http::post($this->getTokenEndpoint($provider), [
            'grant_type'    => 'refresh_token',
            'refresh_token' => $refreshToken,
            'client_id'     => $clientId,
            'client_secret' => $clientSecret,
        ]);

        if (!$response->successful()) {
            $integration->markError('Token refresh failed: ' . $response->body());
            return false;
        }

        $data = $response->json();
        $integration->access_token     = $data['access_token'];
        $integration->token_expires_at = isset($data['expires_in'])
            ? now()->addSeconds((int) $data['expires_in'])
            : null;
        $integration->status = 'connected';
        $integration->save();

        return true;
    }

    private function getAuthEndpoint(string $provider): string
    {
        return match ($provider) {
            'google_calendar', 'google_sheets', 'google_business', 'google_drive', 'google_forms', 'bigquery'
                                => 'https://accounts.google.com/o/oauth2/v2/auth',
            'xero'              => 'https://login.xero.com/identity/connect/authorize',
            'quickbooks'        => 'https://appcenter.intuit.com/connect/oauth2',
            'myob'              => 'https://secure.myob.com/oauth2/account/authorize',
            'outlook_calendar', 'onedrive', 'powerbi'
                                => 'https://login.microsoftonline.com/common/oauth2/v2.0/authorize',
            'salesforce'        => 'https://login.salesforce.com/services/oauth2/authorize',
            'servicem8'         => 'https://go.servicem8.com/oauth/authorize',
            'freshbooks'        => 'https://auth.freshbooks.com/oauth/authorize',
            'zoho_books', 'zoho_crm'
                                => 'https://accounts.zoho.com/oauth/v2/auth',
            'dropbox'           => 'https://www.dropbox.com/oauth2/authorize',
            'box'               => 'https://account.box.com/api/oauth2/authorize',
            'jobber'            => 'https://api.getjobber.com/api/oauth/authorize',
            default             => throw new \InvalidArgumentException("No OAuth endpoint for {$provider}"),
        };
    }

    private function getTokenEndpoint(string $provider): string
    {
        return match ($provider) {
            'google_calendar', 'google_sheets', 'google_business', 'google_drive', 'google_forms', 'bigquery'
                                => 'https://oauth2.googleapis.com/token',
            'xero'              => 'https://identity.xero.com/connect/token',
            'quickbooks'        => 'https://oauth.platform.intuit.com/oauth2/v1/tokens/bearer',
            'myob'              => 'https://secure.myob.com/oauth2/v1/authorize',
            'outlook_calendar', 'onedrive', 'powerbi'
                                => 'https://login.microsoftonline.com/common/oauth2/v2.0/token',
            'salesforce'        => 'https://login.salesforce.com/services/oauth2/token',
            'servicem8'         => 'https://go.servicem8.com/oauth/access_token',
            'freshbooks'        => 'https://api.freshbooks.com/auth/oauth/token',
            'zoho_books', 'zoho_crm'
                                => 'https://accounts.zoho.com/oauth/v2/token',
            'dropbox'           => 'https://api.dropboxapi.com/oauth2/token',
            'box'               => 'https://api.box.com/oauth2/token',
            'jobber'            => 'https://api.getjobber.com/api/oauth/token',
            default             => throw new \InvalidArgumentException("No token endpoint for {$provider}"),
        };
    }
}
