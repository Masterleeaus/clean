<?php

namespace Modules\TitanIntegrations\Services;

use Illuminate\Support\Facades\Http;
use Modules\TitanIntegrations\Entities\Integration;

class IntegrationSetupAssistant
{
    public function __construct(private ProviderSetupGuideGenerator $guideGenerator) {}

    public function explain(string $provider, ?string $question = null): array
    {
        $cfg = config("titanintegrations.integrations.{$provider}");
        if (!$cfg) {
            return ['ok' => false, 'answer' => 'Unknown integration provider.'];
        }

        $guide = $this->guideGenerator->generate($provider, $cfg);
        $fallback = $this->fallbackAnswer($cfg, $question, $guide);
        if (!config('titanintegrations.ai_assist.enabled', true)) {
            return ['ok' => true, 'answer' => $fallback, 'source' => 'registry', 'guide' => $guide];
        }

        $aiProvider = config('titanintegrations.ai_assist.default_provider', 'openai');
        $companyId = $this->currentCompanyId();
        $integration = $companyId ? Integration::forCompany($companyId)
            ->where('provider', $aiProvider)
            ->where('status', 'connected')
            ->first() : null;

        if (!$integration || !$integration->getDecryptedApiKey()) {
            return ['ok' => true, 'answer' => $fallback . "\n\nTip: connect an AI provider, such as OpenAI, Anthropic, Gemini or OpenRouter, to enable live AI setup help.", 'source' => 'registry', 'guide' => $guide];
        }

        if ($aiProvider !== 'openai') {
            return ['ok' => true, 'answer' => $fallback . "\n\nAI provider '{$aiProvider}' is connected, but this build ships with the OpenAI-compatible assistant adapter first. Add an adapter for this provider to enable live responses.", 'source' => 'registry', 'guide' => $guide];
        }

        try {
            $response = Http::withToken($integration->getDecryptedApiKey())
                ->timeout(20)
                ->post('https://api.openai.com/v1/chat/completions', [
                    'model' => $integration->settings['model'] ?? 'gpt-4o-mini',
                    'messages' => [
                        ['role' => 'system', 'content' => config('titanintegrations.ai_assist.system_prompt')],
                        ['role' => 'user', 'content' => "Provider: {$cfg['label']}\nAuth: {$cfg['auth']}\nGenerated guide: " . json_encode($guide) . "\nQuestion: " . ($question ?: 'Give concise setup steps.')],
                    ],
                    'temperature' => 0.2,
                ]);

            if ($response->successful()) {
                return ['ok' => true, 'answer' => $response->json('choices.0.message.content', $fallback), 'source' => 'ai', 'guide' => $guide];
            }
        } catch (\Throwable) {
            // Fallback to registry instructions.
        }

        return ['ok' => true, 'answer' => $fallback, 'source' => 'registry', 'guide' => $guide];
    }

    public function guide(string $provider): array
    {
        return $this->guideGenerator->generate($provider);
    }

    private function currentCompanyId(): ?int
    {
        if (function_exists('company')) {
            try {
                $company = company();
                if ($company && isset($company->id)) {
                    return (int) $company->id;
                }
            } catch (\Throwable) {
                // Fall through to authenticated user lookup.
            }
        }

        $user = auth()->user();
        return $user && isset($user->company_id) ? (int) $user->company_id : null;
    }

    private function fallbackAnswer(array $cfg, ?string $question = null, array $guide = []): string
    {
        $lines = [];
        $lines[] = "How to connect {$cfg['label']} with your own credentials:";
        foreach (($guide['steps'] ?? $cfg['instructions'] ?? []) as $i => $step) {
            $lines[] = ($i + 1) . '. ' . $step;
        }
        if (!empty($guide['credential_fields'] ?? $cfg['fields'] ?? [])) {
            $lines[] = '';
            $lines[] = 'Fields needed: ' . collect($guide['credential_fields'] ?? $cfg['fields'])->pluck('label')->implode(', ') . '.';
        }
        if (!empty($guide['recommended_scopes'])) {
            $lines[] = '';
            $lines[] = 'Recommended scopes: ' . implode(', ', $guide['recommended_scopes']) . '.';
        }
        if (!empty($guide['test_checklist'])) {
            $lines[] = '';
            $lines[] = 'Test checklist:';
            foreach ($guide['test_checklist'] as $item) {
                $lines[] = '- ' . $item;
            }
        }
        $lines[] = '';
        $lines[] = 'Security: paste keys only into the encrypted credential form, not into support chat. Revoke or rotate the key anytime in the original provider account.';
        if ($question) {
            $lines[] = '';
            $lines[] = 'Your question: ' . $question;
        }
        return implode("\n", $lines);
    }
}
