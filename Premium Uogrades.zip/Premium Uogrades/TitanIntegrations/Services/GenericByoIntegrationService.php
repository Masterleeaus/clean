<?php

namespace Modules\TitanIntegrations\Services;

use Illuminate\Support\Facades\Http;
use Modules\TitanIntegrations\Entities\Integration;

/**
 * Generic BYO credential tester for registry-defined API key/webhook integrations.
 * Provider-specific services can still override this when deeper sync methods exist.
 */
class GenericByoIntegrationService
{
    public function testConnection(Integration $integration): array
    {
        $cfg = config("titanintegrations.integrations.{$integration->provider}", []);
        $auth = $cfg['auth'] ?? 'api_key';

        if ($auth === 'none') {
            return ['ok' => true, 'account' => $cfg['label'] ?? $integration->provider];
        }

        if ($auth === 'webhook') {
            if (!$integration->webhook_url) {
                return ['ok' => false, 'error' => 'Webhook URL is required'];
            }
            return ['ok' => true, 'account' => ($cfg['label'] ?? $integration->provider) . ' webhook'];
        }

        if ($auth === 'oauth') {
            $settings = $integration->settings ?? [];
            foreach (['client_id', 'client_secret', 'redirect_uri'] as $required) {
                if (empty($settings[$required])) {
                    return ['ok' => false, 'error' => "{$required} is required before OAuth can start"];
                }
            }
            return ['ok' => true, 'account' => ($cfg['label'] ?? $integration->provider) . ' OAuth app'];
        }

        $key = $integration->getDecryptedApiKey();
        if (!$key) {
            return ['ok' => false, 'error' => 'API key is required'];
        }

        $test = $cfg['test'] ?? null;
        if (!$test || empty($test['url'])) {
            return ['ok' => true, 'account' => ($cfg['label'] ?? $integration->provider) . ' API key saved'];
        }

        try {
            $request = Http::timeout(10)->acceptJson();
            foreach (($test['headers'] ?? []) as $name => $value) {
                $request = $request->withHeaders([$name => $value]);
            }

            $authMode = $test['auth'] ?? 'bearer';
            if ($authMode === 'bearer') {
                $request = $request->withToken($key);
            } elseif ($authMode === 'x-api-key') {
                $request = $request->withHeaders(['x-api-key' => $key]);
            } elseif ($authMode === 'query') {
                $separator = str_contains($test['url'], '?') ? '&' : '?';
                $test['url'] .= $separator . ($test['query_name'] ?? 'api_key') . '=' . urlencode($key);
            }

            $method = strtolower($test['method'] ?? 'get');
            $response = $request->{$method}($test['url']);

            return $response->successful()
                ? ['ok' => true, 'account' => ($cfg['label'] ?? $integration->provider) . ' API']
                : ['ok' => false, 'error' => $response->json('error.message', $response->json('message', 'Connection test failed'))];
        } catch (\Throwable $e) {
            return ['ok' => false, 'error' => $e->getMessage()];
        }
    }
}
