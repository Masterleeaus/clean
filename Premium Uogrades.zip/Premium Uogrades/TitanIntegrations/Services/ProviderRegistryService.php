<?php
namespace Modules\TitanIntegrations\Services;

class ProviderRegistryService
{
    public function all(): array
    {
        return config('titanintegrations.integrations', []);
    }

    public function get(string $provider): ?array
    {
        $cfg = config("titanintegrations.integrations.{$provider}");
        return is_array($cfg) ? $cfg : null;
    }

    public function categories(): array
    {
        $categories = [];
        foreach ($this->all() as $cfg) {
            $category = $cfg['category'] ?? 'other';
            $categories[$category] = ($categories[$category] ?? 0) + 1;
        }
        ksort($categories);
        return $categories;
    }

    public function search(?string $query = null, ?string $category = null, ?string $auth = null, int $limit = 50): array
    {
        $query = mb_strtolower(trim((string) $query));
        $limit = max(1, min($limit, 100));
        $matches = [];

        foreach ($this->all() as $slug => $cfg) {
            if ($category && ($cfg['category'] ?? null) !== $category) continue;
            if ($auth && ($cfg['auth'] ?? null) !== $auth) continue;
            $haystack = mb_strtolower($slug.' '.($cfg['label'] ?? '').' '.($cfg['category'] ?? '').' '.implode(' ', $cfg['tags'] ?? []));
            if ($query === '' || str_contains($haystack, $query)) {
                $matches[] = [
                    'provider' => $slug,
                    'label' => $cfg['label'] ?? $slug,
                    'category' => $cfg['category'] ?? 'other',
                    'auth' => $cfg['auth'] ?? 'api_key',
                    'fields' => array_values($cfg['fields'] ?? []),
                    'docs_url' => $cfg['docs_url'] ?? $cfg['developer_url'] ?? null,
                ];
            }
            if (count($matches) >= $limit) break;
        }

        return $matches;
    }
}
