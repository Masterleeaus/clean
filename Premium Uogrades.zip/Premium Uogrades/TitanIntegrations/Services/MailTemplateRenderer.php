<?php
namespace Modules\TitanIntegrations\Services;

class MailTemplateRenderer
{
    public function render(string $template, array $data = []): array
    {
        $subject = match ($template) {
            'late_invoice_first_notice' => 'Friendly reminder: invoice payment due',
            'late_invoice_final_notice' => 'Final reminder: overdue invoice action needed',
            'payment_received' => 'Payment received — thank you',
            'job_reminder' => 'Upcoming job reminder',
            default => 'Titan Integrations notification',
        };
        $body = match ($template) {
            'late_invoice_first_notice' => 'Hi {{customer_name}}, this is a friendly reminder that invoice {{invoice_number}} has an outstanding balance of {{amount_due}}. You can pay here: {{payment_link}}',
            'late_invoice_final_notice' => 'Hi {{customer_name}}, invoice {{invoice_number}} is now overdue. Please arrange payment of {{amount_due}} using {{payment_link}} or contact us to discuss.',
            'payment_received' => 'Hi {{customer_name}}, thanks — we have received payment for invoice {{invoice_number}}.',
            'job_reminder' => 'Hi {{customer_name}}, this is a reminder for your scheduled job on {{scheduled_at}}.',
            default => '{{message}}',
        };
        foreach ($data as $key => $value) {
            $body = str_replace('{{'.$key.'}}', (string) $value, $body);
            $subject = str_replace('{{'.$key.'}}', (string) $value, $subject);
        }
        return ['subject' => $subject, 'body' => $body, 'requires_approval' => config('titanintegrations-automation.approval_required_for_external_send', true)];
    }
    public function templates(): array { return ['late_invoice_first_notice', 'late_invoice_final_notice', 'payment_received', 'job_reminder']; }
}
