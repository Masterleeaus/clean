<?php
return [
    'items' => [
        ['label' => 'Integrations', 'route' => 'titan-integrations.index', 'icon' => 'puzzle-piece', 'permission' => 'view_integrations'],
        ['label' => 'Integration Agent', 'route' => 'titan-integrations.agent', 'icon' => 'sparkles', 'permission' => 'run_integration_agent'],
        ['label' => 'API Tokens', 'route' => 'titan-integrations.api-tokens.index', 'icon' => 'key', 'permission' => 'manage_api_tokens'],
        ['label' => 'Webhooks', 'route' => 'titan-integrations.webhooks.index', 'icon' => 'signal', 'permission' => 'manage_webhooks'],
        ['label' => 'Logs', 'route' => 'titan-integrations.logs', 'icon' => 'document-text', 'permission' => 'view_integration_logs'],
        ['label' => 'Automation Rules', 'route' => 'titan-integrations.automations.index', 'icon' => 'bolt', 'permission' => 'manage_integration_automations'],
        ['label' => 'Late Invoices', 'route' => 'titan-integrations.invoices.late', 'icon' => 'banknotes', 'permission' => 'manage_integration_payments'],
        ['label' => 'Jobs & Events', 'route' => 'titan-integrations.jobs.events', 'icon' => 'calendar-days', 'permission' => 'manage_integrations'],
        ['label' => 'Mail Templates', 'route' => 'titan-integrations.mail-templates.index', 'icon' => 'envelope', 'permission' => 'manage_integration_mail_templates'],
    ],
];
