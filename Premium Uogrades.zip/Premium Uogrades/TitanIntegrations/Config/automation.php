<?php
return [
    'enabled' => true,
    'approval_required_for_external_send' => true,
    'late_invoice' => [
        'default_grace_days' => 2,
        'follow_up_offsets_days' => [0, 3, 7, 14],
        'payment_link_fields' => ['stripe_payment_url', 'square_payment_url', 'xero_invoice_url', 'quickbooks_invoice_url', 'payment_url'],
    ],
    'jobs' => ['stale_job_hours' => 24, 'missed_arrival_minutes' => 30],
    'events' => ['sync_back_window_days' => 30, 'sync_forward_window_days' => 90],
    'mail_templates' => [
        'late_invoice_first_notice' => 'titanintegrations::mail.late-invoice-follow-up',
        'late_invoice_final_notice' => 'titanintegrations::mail.late-invoice-follow-up',
        'payment_received' => 'titanintegrations::mail.payment-received',
        'job_reminder' => 'titanintegrations::mail.job-reminder',
    ],
];
