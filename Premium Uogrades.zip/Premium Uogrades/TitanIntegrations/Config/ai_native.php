<?php
return [
    'enabled' => env('TITAN_INTEGRATIONS_AI_NATIVE', true),
    'agent' => [
        'id' => 'integration_agent',
        'name' => 'Titan Integration Agent',
        'purpose' => 'Connect BYO API systems and assist cleaning/field-service integration workflows.',
        'default_model_provider' => env('TITAN_INTEGRATIONS_AI_PROVIDER', 'openai'),
        'byo_only' => true,
    ],
    'retrieval' => [
        'enabled' => true,
        'knowledge_path' => module_path('TitanIntegrations', 'Knowledge'),
        'embedding_store' => env('TITAN_INTEGRATIONS_VECTOR_STORE', 'database'),
        'top_k' => 8,
    ],
    'guardrails' => [
        'never_request_plaintext_secret_in_chat' => true,
        'redact_credentials' => true,
        'require_user_confirmation_before_external_write' => true,
    ],
];
