<?php

return array (
  'byo_only' => true,
  'privacy_notice' => 'Users bring their own API keys, OAuth apps, tokens and webhooks. Credentials are encrypted at rest, never resold, and usage/billing remains with the user-owned provider account.',
  'ai_assist' => 
  array (
    'enabled' => true,
    'default_provider' => 'openai',
    'system_prompt' => 'Guide users through BYO API key setup without asking them to reveal secrets in chat. Explain where to click, what scopes to choose, and how to keep keys secure.',
  ),
  'categories' => 
  array (
    'ai' => 'AI Assistants & Model Providers',
    'calendar' => 'Calendar & Scheduling',
    'accounting' => 'Accounting',
    'payments' => 'Payments',
    'crm' => 'CRM & Pipelines',
    'marketing' => 'Marketing & Email',
    'communication' => 'Communication',
    'automation' => 'Automation',
    'data' => 'Data & Reporting',
    'storage' => 'Storage & Files',
    'forms' => 'Forms',
    'publishing' => 'Publishing & Commerce',
    'support' => 'Support',
    'maps' => 'Maps & Location',
    'field_service' => 'Field Service & Dispatch',
    'cleaning_saas' => 'Cleaning SaaS & Maid Platforms',
    'janitorial' => 'Janitorial & Commercial Cleaning',
    'workforce' => 'Workforce, Time & Team Ops',
  ),
  'integrations' => 
  array (
    'openai' => 
    array (
      'label' => 'OpenAI',
      'icon' => 'robot',
      'category' => 'ai',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your OpenAI account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your OpenAI account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in OpenAI.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'anthropic' => 
    array (
      'label' => 'Anthropic Claude',
      'icon' => 'brain',
      'category' => 'ai',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Anthropic Claude account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Anthropic Claude account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Anthropic Claude.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'google_gemini' => 
    array (
      'label' => 'Google Gemini',
      'icon' => 'google',
      'category' => 'ai',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Google Gemini account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Google Gemini account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Google Gemini.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'mistral' => 
    array (
      'label' => 'Mistral AI',
      'icon' => 'robot',
      'category' => 'ai',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Mistral AI account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Mistral AI account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Mistral AI.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'groq' => 
    array (
      'label' => 'Groq',
      'icon' => 'bolt',
      'category' => 'ai',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Groq account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Groq account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Groq.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'perplexity' => 
    array (
      'label' => 'Perplexity',
      'icon' => 'search',
      'category' => 'ai',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Perplexity account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Perplexity account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Perplexity.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'deepseek' => 
    array (
      'label' => 'DeepSeek',
      'icon' => 'robot',
      'category' => 'ai',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your DeepSeek account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your DeepSeek account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in DeepSeek.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'openrouter' => 
    array (
      'label' => 'OpenRouter',
      'icon' => 'route',
      'category' => 'ai',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your OpenRouter account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your OpenRouter account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in OpenRouter.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'huggingface' => 
    array (
      'label' => 'Hugging Face',
      'icon' => 'smile',
      'category' => 'ai',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Hugging Face account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Hugging Face account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Hugging Face.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'replicate' => 
    array (
      'label' => 'Replicate',
      'icon' => 'copy',
      'category' => 'ai',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Replicate account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Replicate account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Replicate.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'elevenlabs' => 
    array (
      'label' => 'ElevenLabs',
      'icon' => 'microphone',
      'category' => 'ai',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your ElevenLabs account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your ElevenLabs account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in ElevenLabs.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'google_calendar' => 
    array (
      'label' => 'Google Calendar',
      'icon' => 'calendar',
      'category' => 'calendar',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Google Calendar developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Google Calendar admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Google Calendar, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Google Calendar account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'outlook_calendar' => 
    array (
      'label' => 'Outlook / Microsoft 365 Calendar',
      'icon' => 'calendar',
      'category' => 'calendar',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Outlook / Microsoft 365 Calendar developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Outlook / Microsoft 365 Calendar admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Outlook / Microsoft 365 Calendar, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Outlook / Microsoft 365 Calendar account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'ical_feed' => 
    array (
      'label' => 'Apple Calendar / iCal Feed',
      'icon' => 'calendar',
      'category' => 'calendar',
      'auth' => 'none',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
      ),
      'instructions' => 
      array (
        0 => 'No API key is required.',
        1 => 'Use the generated signed URL or built-in connection instructions.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Apple Calendar / iCal Feed account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Apple Calendar / iCal Feed.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'calendly' => 
    array (
      'label' => 'Calendly',
      'icon' => 'calendar',
      'category' => 'calendar',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Calendly account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Calendly account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Calendly.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'acuity' => 
    array (
      'label' => 'Acuity Scheduling',
      'icon' => 'calendar',
      'category' => 'calendar',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Acuity Scheduling account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Acuity Scheduling account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Acuity Scheduling.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'xero' => 
    array (
      'label' => 'Xero',
      'icon' => 'file-invoice',
      'category' => 'accounting',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Xero developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Xero admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Xero, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Xero account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'quickbooks' => 
    array (
      'label' => 'QuickBooks Online',
      'icon' => 'file-invoice',
      'category' => 'accounting',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the QuickBooks Online developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your QuickBooks Online admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into QuickBooks Online, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own QuickBooks Online account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'myob' => 
    array (
      'label' => 'MYOB AccountRight',
      'icon' => 'file-invoice',
      'category' => 'accounting',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the MYOB AccountRight developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your MYOB AccountRight admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into MYOB AccountRight, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own MYOB AccountRight account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'freshbooks' => 
    array (
      'label' => 'FreshBooks',
      'icon' => 'file-invoice',
      'category' => 'accounting',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the FreshBooks developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your FreshBooks admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into FreshBooks, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own FreshBooks account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'zoho_books' => 
    array (
      'label' => 'Zoho Books',
      'icon' => 'file-invoice',
      'category' => 'accounting',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Zoho Books developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Zoho Books admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Zoho Books, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Zoho Books account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'stripe' => 
    array (
      'label' => 'Stripe',
      'icon' => 'credit-card',
      'category' => 'payments',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Stripe account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Stripe account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Stripe.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'paypal' => 
    array (
      'label' => 'PayPal',
      'icon' => 'credit-card',
      'category' => 'payments',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your PayPal account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your PayPal account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in PayPal.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'square' => 
    array (
      'label' => 'Square',
      'icon' => 'credit-card',
      'category' => 'payments',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Square account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Square account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Square.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'braintree' => 
    array (
      'label' => 'Braintree',
      'icon' => 'credit-card',
      'category' => 'payments',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Braintree account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Braintree account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Braintree.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'wise' => 
    array (
      'label' => 'Wise',
      'icon' => 'credit-card',
      'category' => 'payments',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Wise account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Wise account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Wise.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'hubspot' => 
    array (
      'label' => 'HubSpot',
      'icon' => 'address-book',
      'category' => 'crm',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your HubSpot account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your HubSpot account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in HubSpot.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'salesforce' => 
    array (
      'label' => 'Salesforce',
      'icon' => 'address-book',
      'category' => 'crm',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Salesforce developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Salesforce admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Salesforce, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Salesforce account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'pipedrive' => 
    array (
      'label' => 'Pipedrive',
      'icon' => 'address-book',
      'category' => 'crm',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Pipedrive account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Pipedrive account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Pipedrive.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'zoho_crm' => 
    array (
      'label' => 'Zoho CRM',
      'icon' => 'address-book',
      'category' => 'crm',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Zoho CRM developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Zoho CRM admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Zoho CRM, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Zoho CRM account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'freshsales' => 
    array (
      'label' => 'Freshsales',
      'icon' => 'address-book',
      'category' => 'crm',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Freshsales account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Freshsales account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Freshsales.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'zendesk_sell' => 
    array (
      'label' => 'Zendesk Sell',
      'icon' => 'address-book',
      'category' => 'crm',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Zendesk Sell account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Zendesk Sell account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Zendesk Sell.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'monday' => 
    array (
      'label' => 'Monday.com',
      'icon' => 'address-book',
      'category' => 'crm',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Monday.com account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Monday.com account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Monday.com.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'notion' => 
    array (
      'label' => 'Notion',
      'icon' => 'address-book',
      'category' => 'crm',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Notion account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Notion account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Notion.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'airtable' => 
    array (
      'label' => 'Airtable',
      'icon' => 'address-book',
      'category' => 'crm',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Airtable account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Airtable account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Airtable.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'mailchimp' => 
    array (
      'label' => 'Mailchimp',
      'icon' => 'bullhorn',
      'category' => 'marketing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Mailchimp account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Mailchimp account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Mailchimp.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'activecampaign' => 
    array (
      'label' => 'ActiveCampaign',
      'icon' => 'bullhorn',
      'category' => 'marketing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your ActiveCampaign account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your ActiveCampaign account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in ActiveCampaign.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'klaviyo' => 
    array (
      'label' => 'Klaviyo',
      'icon' => 'bullhorn',
      'category' => 'marketing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Klaviyo account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Klaviyo account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Klaviyo.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'constant_contact' => 
    array (
      'label' => 'Constant Contact',
      'icon' => 'bullhorn',
      'category' => 'marketing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Constant Contact account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Constant Contact account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Constant Contact.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'sendgrid' => 
    array (
      'label' => 'SendGrid',
      'icon' => 'bullhorn',
      'category' => 'marketing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your SendGrid account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your SendGrid account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in SendGrid.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'mailerlite' => 
    array (
      'label' => 'MailerLite',
      'icon' => 'bullhorn',
      'category' => 'marketing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your MailerLite account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your MailerLite account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in MailerLite.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'brevo' => 
    array (
      'label' => 'Brevo',
      'icon' => 'bullhorn',
      'category' => 'marketing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Brevo account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Brevo account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Brevo.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'campaign_monitor' => 
    array (
      'label' => 'Campaign Monitor',
      'icon' => 'bullhorn',
      'category' => 'marketing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Campaign Monitor account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Campaign Monitor account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Campaign Monitor.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'postmark' => 
    array (
      'label' => 'Postmark',
      'icon' => 'bullhorn',
      'category' => 'marketing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Postmark account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Postmark account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Postmark.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'slack' => 
    array (
      'label' => 'Slack',
      'icon' => 'comments',
      'category' => 'communication',
      'auth' => 'webhook',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'webhook_url',
          'label' => 'Webhook URL',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'https://hooks.example.com/...',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open Slack and create a webhook/catch-hook/incoming webhook.',
        1 => 'Choose the destination channel or workflow.',
        2 => 'Copy the generated URL.',
        3 => 'Paste the webhook URL into this encrypted form and send a test event.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Slack account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Slack.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'teams' => 
    array (
      'label' => 'Microsoft Teams',
      'icon' => 'comments',
      'category' => 'communication',
      'auth' => 'webhook',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'webhook_url',
          'label' => 'Webhook URL',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'https://hooks.example.com/...',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open Microsoft Teams and create a webhook/catch-hook/incoming webhook.',
        1 => 'Choose the destination channel or workflow.',
        2 => 'Copy the generated URL.',
        3 => 'Paste the webhook URL into this encrypted form and send a test event.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Microsoft Teams account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Microsoft Teams.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'discord' => 
    array (
      'label' => 'Discord',
      'icon' => 'comments',
      'category' => 'communication',
      'auth' => 'webhook',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'webhook_url',
          'label' => 'Webhook URL',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'https://hooks.example.com/...',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open Discord and create a webhook/catch-hook/incoming webhook.',
        1 => 'Choose the destination channel or workflow.',
        2 => 'Copy the generated URL.',
        3 => 'Paste the webhook URL into this encrypted form and send a test event.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Discord account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Discord.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'google_chat' => 
    array (
      'label' => 'Google Chat',
      'icon' => 'comments',
      'category' => 'communication',
      'auth' => 'webhook',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'webhook_url',
          'label' => 'Webhook URL',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'https://hooks.example.com/...',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open Google Chat and create a webhook/catch-hook/incoming webhook.',
        1 => 'Choose the destination channel or workflow.',
        2 => 'Copy the generated URL.',
        3 => 'Paste the webhook URL into this encrypted form and send a test event.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Google Chat account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Google Chat.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'twilio' => 
    array (
      'label' => 'Twilio',
      'icon' => 'message',
      'category' => 'communication',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Twilio account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Twilio account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Twilio.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'telnyx' => 
    array (
      'label' => 'Telnyx',
      'icon' => 'message',
      'category' => 'communication',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Telnyx account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Telnyx account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Telnyx.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'vonage' => 
    array (
      'label' => 'Vonage',
      'icon' => 'message',
      'category' => 'communication',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Vonage account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Vonage account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Vonage.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'messagebird' => 
    array (
      'label' => 'MessageBird',
      'icon' => 'message',
      'category' => 'communication',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your MessageBird account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your MessageBird account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in MessageBird.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'zapier' => 
    array (
      'label' => 'Zapier',
      'icon' => 'shuffle',
      'category' => 'automation',
      'auth' => 'webhook',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'webhook_url',
          'label' => 'Webhook URL',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'https://hooks.example.com/...',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open Zapier and create a webhook/catch-hook/incoming webhook.',
        1 => 'Choose the destination channel or workflow.',
        2 => 'Copy the generated URL.',
        3 => 'Paste the webhook URL into this encrypted form and send a test event.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Zapier account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Zapier.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'make' => 
    array (
      'label' => 'Make',
      'icon' => 'shuffle',
      'category' => 'automation',
      'auth' => 'webhook',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'webhook_url',
          'label' => 'Webhook URL',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'https://hooks.example.com/...',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open Make and create a webhook/catch-hook/incoming webhook.',
        1 => 'Choose the destination channel or workflow.',
        2 => 'Copy the generated URL.',
        3 => 'Paste the webhook URL into this encrypted form and send a test event.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Make account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Make.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'n8n' => 
    array (
      'label' => 'n8n',
      'icon' => 'shuffle',
      'category' => 'automation',
      'auth' => 'webhook',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'webhook_url',
          'label' => 'Webhook URL',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'https://hooks.example.com/...',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open n8n and create a webhook/catch-hook/incoming webhook.',
        1 => 'Choose the destination channel or workflow.',
        2 => 'Copy the generated URL.',
        3 => 'Paste the webhook URL into this encrypted form and send a test event.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your n8n account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in n8n.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'pabbly' => 
    array (
      'label' => 'Pabbly Connect',
      'icon' => 'shuffle',
      'category' => 'automation',
      'auth' => 'webhook',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'webhook_url',
          'label' => 'Webhook URL',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'https://hooks.example.com/...',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open Pabbly Connect and create a webhook/catch-hook/incoming webhook.',
        1 => 'Choose the destination channel or workflow.',
        2 => 'Copy the generated URL.',
        3 => 'Paste the webhook URL into this encrypted form and send a test event.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Pabbly Connect account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Pabbly Connect.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'ifttt' => 
    array (
      'label' => 'IFTTT',
      'icon' => 'shuffle',
      'category' => 'automation',
      'auth' => 'webhook',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'webhook_url',
          'label' => 'Webhook URL',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'https://hooks.example.com/...',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open IFTTT and create a webhook/catch-hook/incoming webhook.',
        1 => 'Choose the destination channel or workflow.',
        2 => 'Copy the generated URL.',
        3 => 'Paste the webhook URL into this encrypted form and send a test event.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your IFTTT account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in IFTTT.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'workato' => 
    array (
      'label' => 'Workato',
      'icon' => 'shuffle',
      'category' => 'automation',
      'auth' => 'webhook',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'webhook_url',
          'label' => 'Webhook URL',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'https://hooks.example.com/...',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open Workato and create a webhook/catch-hook/incoming webhook.',
        1 => 'Choose the destination channel or workflow.',
        2 => 'Copy the generated URL.',
        3 => 'Paste the webhook URL into this encrypted form and send a test event.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Workato account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Workato.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'google_sheets' => 
    array (
      'label' => 'Google Sheets',
      'icon' => 'table',
      'category' => 'data',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Google Sheets developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Google Sheets admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Google Sheets, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Google Sheets account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'bigquery' => 
    array (
      'label' => 'Google BigQuery',
      'icon' => 'database',
      'category' => 'data',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Google BigQuery developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Google BigQuery admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Google BigQuery, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Google BigQuery account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'snowflake' => 
    array (
      'label' => 'Snowflake',
      'icon' => 'database',
      'category' => 'data',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Snowflake account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Snowflake account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Snowflake.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'postgres' => 
    array (
      'label' => 'External PostgreSQL',
      'icon' => 'database',
      'category' => 'data',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your External PostgreSQL account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your External PostgreSQL account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in External PostgreSQL.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'mysql' => 
    array (
      'label' => 'External MySQL',
      'icon' => 'database',
      'category' => 'data',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your External MySQL account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your External MySQL account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in External MySQL.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'supabase' => 
    array (
      'label' => 'Supabase',
      'icon' => 'database',
      'category' => 'data',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Supabase account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Supabase account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Supabase.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'firebase' => 
    array (
      'label' => 'Firebase',
      'icon' => 'database',
      'category' => 'data',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Firebase account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Firebase account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Firebase.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'mongodb_atlas' => 
    array (
      'label' => 'MongoDB Atlas',
      'icon' => 'database',
      'category' => 'data',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your MongoDB Atlas account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your MongoDB Atlas account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in MongoDB Atlas.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'powerbi' => 
    array (
      'label' => 'Power BI',
      'icon' => 'chart-bar',
      'category' => 'data',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Power BI developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Power BI admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Power BI, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Power BI account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'google_drive' => 
    array (
      'label' => 'Google Drive',
      'icon' => 'folder',
      'category' => 'storage',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Google Drive developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Google Drive admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Google Drive, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Google Drive account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'dropbox' => 
    array (
      'label' => 'Dropbox',
      'icon' => 'folder',
      'category' => 'storage',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Dropbox developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Dropbox admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Dropbox, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Dropbox account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'box' => 
    array (
      'label' => 'Box',
      'icon' => 'folder',
      'category' => 'storage',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Box developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Box admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Box, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Box account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'onedrive' => 
    array (
      'label' => 'OneDrive',
      'icon' => 'folder',
      'category' => 'storage',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the OneDrive developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your OneDrive admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into OneDrive, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own OneDrive account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    's3' => 
    array (
      'label' => 'Amazon S3',
      'icon' => 'folder',
      'category' => 'storage',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Amazon S3 account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Amazon S3 account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Amazon S3.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'cloudinary' => 
    array (
      'label' => 'Cloudinary',
      'icon' => 'folder',
      'category' => 'storage',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Cloudinary account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Cloudinary account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Cloudinary.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'typeform' => 
    array (
      'label' => 'Typeform',
      'icon' => 'clipboard-list',
      'category' => 'forms',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Typeform account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Typeform account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Typeform.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'jotform' => 
    array (
      'label' => 'Jotform',
      'icon' => 'clipboard-list',
      'category' => 'forms',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Jotform account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Jotform account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Jotform.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'google_forms' => 
    array (
      'label' => 'Google Forms',
      'icon' => 'clipboard-list',
      'category' => 'forms',
      'auth' => 'oauth',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'OAuth client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'OAuth client secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Copy this app callback URL into the provider',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open the Google Forms developer console.',
        1 => 'Create an OAuth app owned by your account.',
        2 => 'Add this app redirect URI to the provider app.',
        3 => 'Paste your Client ID and Client Secret here, then start OAuth.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Google Forms admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Google Forms, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Google Forms account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'formstack' => 
    array (
      'label' => 'Formstack',
      'icon' => 'clipboard-list',
      'category' => 'forms',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Formstack account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Formstack account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Formstack.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'tally' => 
    array (
      'label' => 'Tally',
      'icon' => 'clipboard-list',
      'category' => 'forms',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Tally account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Tally account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Tally.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'wordpress' => 
    array (
      'label' => 'WordPress',
      'icon' => 'globe',
      'category' => 'publishing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your WordPress account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your WordPress account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in WordPress.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'webflow' => 
    array (
      'label' => 'Webflow',
      'icon' => 'globe',
      'category' => 'publishing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Webflow account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Webflow account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Webflow.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'shopify' => 
    array (
      'label' => 'Shopify',
      'icon' => 'shopping-cart',
      'category' => 'publishing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Shopify account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Shopify account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Shopify.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'woocommerce' => 
    array (
      'label' => 'WooCommerce',
      'icon' => 'shopping-cart',
      'category' => 'publishing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your WooCommerce account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your WooCommerce account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in WooCommerce.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'squarespace' => 
    array (
      'label' => 'Squarespace',
      'icon' => 'globe',
      'category' => 'publishing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Squarespace account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Squarespace account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Squarespace.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'wix' => 
    array (
      'label' => 'Wix',
      'icon' => 'globe',
      'category' => 'publishing',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Wix account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Wix account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Wix.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'zendesk' => 
    array (
      'label' => 'Zendesk',
      'icon' => 'life-ring',
      'category' => 'support',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Zendesk account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Zendesk account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Zendesk.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'freshdesk' => 
    array (
      'label' => 'Freshdesk',
      'icon' => 'life-ring',
      'category' => 'support',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Freshdesk account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Freshdesk account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Freshdesk.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'intercom' => 
    array (
      'label' => 'Intercom',
      'icon' => 'life-ring',
      'category' => 'support',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Intercom account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Intercom account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Intercom.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'helpscout' => 
    array (
      'label' => 'Help Scout',
      'icon' => 'life-ring',
      'category' => 'support',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Help Scout account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Help Scout account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Help Scout.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'gorgias' => 
    array (
      'label' => 'Gorgias',
      'icon' => 'life-ring',
      'category' => 'support',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Gorgias account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Gorgias account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Gorgias.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'google_maps' => 
    array (
      'label' => 'Google Maps',
      'icon' => 'map',
      'category' => 'maps',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Google Maps account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Google Maps account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Google Maps.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'mapbox' => 
    array (
      'label' => 'Mapbox',
      'icon' => 'map',
      'category' => 'maps',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Mapbox account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Mapbox account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Mapbox.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'here_maps' => 
    array (
      'label' => 'HERE Maps',
      'icon' => 'map',
      'category' => 'maps',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your HERE Maps account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your HERE Maps account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in HERE Maps.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'tomtom' => 
    array (
      'label' => 'TomTom',
      'icon' => 'map',
      'category' => 'maps',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your TomTom account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your TomTom account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in TomTom.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'servicem8' => 
    array (
      'label' => 'ServiceM8',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'oauth',
      'note' => 'BYO ServiceM8 credentials: user controls privacy, revocation, scopes and provider billing. Job scheduling, dispatch, quotes, invoices, forms and mobile field-team operations.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Paste your app Client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your app Client Secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => false,
          'secret' => false,
          'placeholder' => 'Copy from this app into the provider OAuth app',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your ServiceM8 admin/developer settings in a new tab.',
        1 => 'Create a private OAuth app owned by your business account.',
        2 => 'Copy this app\'s redirect URI into ServiceM8, then copy the Client ID and Client Secret back here.',
        3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
        4 => 'Save the credentials here, then start OAuth and approve access from your own ServiceM8 account.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Job scheduling, dispatch, quotes, invoices, forms and mobile field-team operations.',
        'where_to_start' => 'https://developer.servicem8.com/',
        'steps' => 
        array (
          0 => 'Open your ServiceM8 admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into ServiceM8, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own ServiceM8 account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'jobber' => 
    array (
      'label' => 'Jobber',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'oauth',
      'note' => 'BYO Jobber credentials: user controls privacy, revocation, scopes and provider billing. Field service CRM, quotes, jobs, invoices and client comms for cleaning teams.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Paste your app Client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your app Client Secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => false,
          'secret' => false,
          'placeholder' => 'Copy from this app into the provider OAuth app',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Jobber admin/developer settings in a new tab.',
        1 => 'Create a private OAuth app owned by your business account.',
        2 => 'Copy this app\'s redirect URI into Jobber, then copy the Client ID and Client Secret back here.',
        3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
        4 => 'Save the credentials here, then start OAuth and approve access from your own Jobber account.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Field service CRM, quotes, jobs, invoices and client comms for cleaning teams.',
        'where_to_start' => 'https://developer.getjobber.com/',
        'steps' => 
        array (
          0 => 'Open your Jobber admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Jobber, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Jobber account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'simpro' => 
    array (
      'label' => 'Simpro',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'oauth',
      'note' => 'BYO Simpro credentials: user controls privacy, revocation, scopes and provider billing. Job management, scheduling, quotes, inventory and field-service operations.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Paste your app Client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your app Client Secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => false,
          'secret' => false,
          'placeholder' => 'Copy from this app into the provider OAuth app',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Simpro admin/developer settings in a new tab.',
        1 => 'Create a private OAuth app owned by your business account.',
        2 => 'Copy this app\'s redirect URI into Simpro, then copy the Client ID and Client Secret back here.',
        3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
        4 => 'Save the credentials here, then start OAuth and approve access from your own Simpro account.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Job management, scheduling, quotes, inventory and field-service operations.',
        'where_to_start' => 'https://developer.simprogroup.com/',
        'steps' => 
        array (
          0 => 'Open your Simpro admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Simpro, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Simpro account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'tradify' => 
    array (
      'label' => 'Tradify',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO Tradify credentials: user controls privacy, revocation, scopes and provider billing. Quotes, jobs, scheduling, timesheets and invoicing for service teams.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Tradify account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Tradify.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Quotes, jobs, scheduling, timesheets and invoicing for service teams.',
        'where_to_start' => 'https://www.tradifyhq.com/',
        'steps' => 
        array (
          0 => 'Open your Tradify account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Tradify.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'fieldpulse' => 
    array (
      'label' => 'FieldPulse',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO FieldPulse credentials: user controls privacy, revocation, scopes and provider billing. Field service CRM, scheduling, estimates, invoices and job tracking.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your FieldPulse account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in FieldPulse.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Field service CRM, scheduling, estimates, invoices and job tracking.',
        'where_to_start' => 'https://help.fieldpulse.com/',
        'steps' => 
        array (
          0 => 'Open your FieldPulse account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in FieldPulse.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'airtasker' => 
    array (
      'label' => 'Airtasker',
      'icon' => 'toolbox',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Airtasker account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Airtasker account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Airtasker.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'hipages' => 
    array (
      'label' => 'Hipages',
      'icon' => 'toolbox',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Hipages account dashboard.',
        1 => 'Go to developer settings, API keys, tokens, or private apps.',
        2 => 'Create a least-privilege key owned by your account.',
        3 => 'Copy the key once and paste it into this encrypted form.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'BYO credentials: user controls privacy, usage limits, revocation and provider billing.',
        'where_to_start' => NULL,
        'steps' => 
        array (
          0 => 'Open your Hipages account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Hipages.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'housecall_pro' => 
    array (
      'label' => 'Housecall Pro',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO Housecall Pro credentials: user controls privacy, revocation, scopes and provider billing. Home-service scheduling, dispatch, invoicing, payments and customer communication.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Housecall Pro account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Housecall Pro.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Home-service scheduling, dispatch, invoicing, payments and customer communication.',
        'where_to_start' => 'https://docs.housecallpro.com/',
        'steps' => 
        array (
          0 => 'Open your Housecall Pro account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Housecall Pro.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'workiz' => 
    array (
      'label' => 'Workiz',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO Workiz credentials: user controls privacy, revocation, scopes and provider billing. Dispatch, job management, calls, texts, invoicing and payment workflows.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Workiz account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Workiz.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Dispatch, job management, calls, texts, invoicing and payment workflows.',
        'where_to_start' => 'https://developer.workiz.com/',
        'steps' => 
        array (
          0 => 'Open your Workiz account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Workiz.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'servicefusion' => 
    array (
      'label' => 'Service Fusion',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO Service Fusion credentials: user controls privacy, revocation, scopes and provider billing. Service dispatch, customer management, estimates, invoices and reporting.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Service Fusion account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Service Fusion.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Service dispatch, customer management, estimates, invoices and reporting.',
        'where_to_start' => 'https://www.servicefusion.com/',
        'steps' => 
        array (
          0 => 'Open your Service Fusion account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Service Fusion.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'mhelpdesk' => 
    array (
      'label' => 'mHelpDesk',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO mHelpDesk credentials: user controls privacy, revocation, scopes and provider billing. Field service work orders, scheduling, dispatch and billing workflows.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your mHelpDesk account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in mHelpDesk.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Field service work orders, scheduling, dispatch and billing workflows.',
        'where_to_start' => 'https://www.mhelpdesk.com/',
        'steps' => 
        array (
          0 => 'Open your mHelpDesk account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in mHelpDesk.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'gorilladesk' => 
    array (
      'label' => 'GorillaDesk',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO GorillaDesk credentials: user controls privacy, revocation, scopes and provider billing. Route scheduling, dispatch, invoicing and customer follow-up for service businesses.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your GorillaDesk account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in GorillaDesk.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Route scheduling, dispatch, invoicing and customer follow-up for service businesses.',
        'where_to_start' => 'https://gorilladesk.com/',
        'steps' => 
        array (
          0 => 'Open your GorillaDesk account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in GorillaDesk.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'service_autopilot' => 
    array (
      'label' => 'Service Autopilot',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO Service Autopilot credentials: user controls privacy, revocation, scopes and provider billing. CRM, scheduling, routing, dispatch and automations for recurring service businesses.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Service Autopilot account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Service Autopilot.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'CRM, scheduling, routing, dispatch and automations for recurring service businesses.',
        'where_to_start' => 'https://www.serviceautopilot.com/',
        'steps' => 
        array (
          0 => 'Open your Service Autopilot account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Service Autopilot.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'fieldvibe' => 
    array (
      'label' => 'FieldVibe',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO FieldVibe credentials: user controls privacy, revocation, scopes and provider billing. Scheduling, job reminders and lightweight field-service management for small teams.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your FieldVibe account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in FieldVibe.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Scheduling, job reminders and lightweight field-service management for small teams.',
        'where_to_start' => 'https://www.fieldvibe.com/',
        'steps' => 
        array (
          0 => 'Open your FieldVibe account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in FieldVibe.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'zenmaid' => 
    array (
      'label' => 'ZenMaid',
      'icon' => 'broom',
      'category' => 'cleaning_saas',
      'auth' => 'api_key',
      'note' => 'BYO ZenMaid credentials: user controls privacy, revocation, scopes and provider billing. Residential maid-service scheduling, recurring jobs, reminders and team dispatch.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your ZenMaid account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in ZenMaid.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Residential maid-service scheduling, recurring jobs, reminders and team dispatch.',
        'where_to_start' => 'https://www.zenmaid.com/',
        'steps' => 
        array (
          0 => 'Open your ZenMaid account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in ZenMaid.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'maidcentral' => 
    array (
      'label' => 'MaidCentral',
      'icon' => 'broom',
      'category' => 'cleaning_saas',
      'auth' => 'api_key',
      'note' => 'BYO MaidCentral credentials: user controls privacy, revocation, scopes and provider billing. Residential cleaning operating system for scheduling, payroll, dispatch and reporting.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your MaidCentral account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in MaidCentral.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Residential cleaning operating system for scheduling, payroll, dispatch and reporting.',
        'where_to_start' => 'https://maidcentral.com/',
        'steps' => 
        array (
          0 => 'Open your MaidCentral account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in MaidCentral.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'launch27' => 
    array (
      'label' => 'Launch27',
      'icon' => 'broom',
      'category' => 'cleaning_saas',
      'auth' => 'api_key',
      'note' => 'BYO Launch27 credentials: user controls privacy, revocation, scopes and provider billing. Online booking forms, pricing, scheduling and maid-service booking automation.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Launch27 account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Launch27.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Online booking forms, pricing, scheduling and maid-service booking automation.',
        'where_to_start' => 'https://www.launch27.com/',
        'steps' => 
        array (
          0 => 'Open your Launch27 account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Launch27.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'maidily' => 
    array (
      'label' => 'Maidily',
      'icon' => 'broom',
      'category' => 'cleaning_saas',
      'auth' => 'api_key',
      'note' => 'BYO Maidily credentials: user controls privacy, revocation, scopes and provider billing. Cleaning-business scheduling, booking, payments, invoicing and team management.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Maidily account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Maidily.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Cleaning-business scheduling, booking, payments, invoicing and team management.',
        'where_to_start' => 'https://maidily.com/',
        'steps' => 
        array (
          0 => 'Open your Maidily account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Maidily.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'bookingkoala' => 
    array (
      'label' => 'BookingKoala',
      'icon' => 'broom',
      'category' => 'cleaning_saas',
      'auth' => 'api_key',
      'note' => 'BYO BookingKoala credentials: user controls privacy, revocation, scopes and provider billing. Booking engine, scheduling, teams, customers, payments and provider marketplace workflows.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your BookingKoala account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in BookingKoala.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Booking engine, scheduling, teams, customers, payments and provider marketplace workflows.',
        'where_to_start' => 'https://www.bookingkoala.com/',
        'steps' => 
        array (
          0 => 'Open your BookingKoala account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in BookingKoala.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'the_cleaning_software' => 
    array (
      'label' => 'The Cleaning Software',
      'icon' => 'broom',
      'category' => 'cleaning_saas',
      'auth' => 'api_key',
      'note' => 'BYO The Cleaning Software credentials: user controls privacy, revocation, scopes and provider billing. Cleaning-company CRM, scheduling, quotes, invoices and customer workflows.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your The Cleaning Software account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in The Cleaning Software.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Cleaning-company CRM, scheduling, quotes, invoices and customer workflows.',
        'where_to_start' => 'https://thecleaningsoftware.com/',
        'steps' => 
        array (
          0 => 'Open your The Cleaning Software account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in The Cleaning Software.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'convertlabs' => 
    array (
      'label' => 'ConvertLabs',
      'icon' => 'broom',
      'category' => 'cleaning_saas',
      'auth' => 'api_key',
      'note' => 'BYO ConvertLabs credentials: user controls privacy, revocation, scopes and provider billing. Sales, booking and follow-up workflows for residential cleaning companies.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your ConvertLabs account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in ConvertLabs.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Sales, booking and follow-up workflows for residential cleaning companies.',
        'where_to_start' => 'https://convertlabs.io/',
        'steps' => 
        array (
          0 => 'Open your ConvertLabs account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in ConvertLabs.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'customer_factor' => 
    array (
      'label' => 'The Customer Factor',
      'icon' => 'broom',
      'category' => 'cleaning_saas',
      'auth' => 'api_key',
      'note' => 'BYO The Customer Factor credentials: user controls privacy, revocation, scopes and provider billing. Scheduling, CRM, estimates, invoices and marketing for cleaning/service businesses.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your The Customer Factor account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in The Customer Factor.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Scheduling, CRM, estimates, invoices and marketing for cleaning/service businesses.',
        'where_to_start' => 'https://www.thecustomerfactor.com/',
        'steps' => 
        array (
          0 => 'Open your The Customer Factor account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in The Customer Factor.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'cleaning_service_software' => 
    array (
      'label' => 'Cleaning Service Software',
      'icon' => 'broom',
      'category' => 'cleaning_saas',
      'auth' => 'api_key',
      'note' => 'BYO Cleaning Service Software credentials: user controls privacy, revocation, scopes and provider billing. Cleaning scheduling, dispatch, quoting, invoicing and recurring customer management.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Cleaning Service Software account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Cleaning Service Software.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Cleaning scheduling, dispatch, quoting, invoicing and recurring customer management.',
        'where_to_start' => 'https://cleaningservicesoftware.com/',
        'steps' => 
        array (
          0 => 'Open your Cleaning Service Software account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Cleaning Service Software.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'maid_easy' => 
    array (
      'label' => 'MaidEasy',
      'icon' => 'broom',
      'category' => 'cleaning_saas',
      'auth' => 'api_key',
      'note' => 'BYO MaidEasy credentials: user controls privacy, revocation, scopes and provider billing. Maid-service CRM, booking and cleaning job management workflows.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your MaidEasy account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in MaidEasy.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Maid-service CRM, booking and cleaning job management workflows.',
        'where_to_start' => 'https://maideasysoftware.com/',
        'steps' => 
        array (
          0 => 'Open your MaidEasy account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in MaidEasy.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'swept' => 
    array (
      'label' => 'Swept',
      'icon' => 'broom',
      'category' => 'janitorial',
      'auth' => 'api_key',
      'note' => 'BYO Swept credentials: user controls privacy, revocation, scopes and provider billing. Commercial cleaning operations, site checklists, issue reporting and cleaner communication.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Swept account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Swept.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Commercial cleaning operations, site checklists, issue reporting and cleaner communication.',
        'where_to_start' => 'https://www.sweptworks.com/',
        'steps' => 
        array (
          0 => 'Open your Swept account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Swept.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'janitorial_manager' => 
    array (
      'label' => 'Janitorial Manager',
      'icon' => 'broom',
      'category' => 'janitorial',
      'auth' => 'api_key',
      'note' => 'BYO Janitorial Manager credentials: user controls privacy, revocation, scopes and provider billing. Commercial janitorial inspections, work orders, QR codes, inventory and team operations.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Janitorial Manager account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Janitorial Manager.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Commercial janitorial inspections, work orders, QR codes, inventory and team operations.',
        'where_to_start' => 'https://www.janitorialmanager.com/',
        'steps' => 
        array (
          0 => 'Open your Janitorial Manager account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Janitorial Manager.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'cleantelligent' => 
    array (
      'label' => 'CleanTelligent',
      'icon' => 'broom',
      'category' => 'janitorial',
      'auth' => 'api_key',
      'note' => 'BYO CleanTelligent credentials: user controls privacy, revocation, scopes and provider billing. Janitorial quality management, inspections, work orders and reporting.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your CleanTelligent account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in CleanTelligent.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Janitorial quality management, inspections, work orders and reporting.',
        'where_to_start' => 'https://cleantelligent.com/',
        'steps' => 
        array (
          0 => 'Open your CleanTelligent account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in CleanTelligent.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'clean_smartr' => 
    array (
      'label' => 'Clean Smarts',
      'icon' => 'broom',
      'category' => 'janitorial',
      'auth' => 'api_key',
      'note' => 'BYO Clean Smarts credentials: user controls privacy, revocation, scopes and provider billing. Janitorial inspections, work orders, messaging and accountability workflows.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Clean Smarts account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Clean Smarts.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Janitorial inspections, work orders, messaging and accountability workflows.',
        'where_to_start' => 'https://cleansmarts.com/',
        'steps' => 
        array (
          0 => 'Open your Clean Smarts account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Clean Smarts.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'sweptworks' => 
    array (
      'label' => 'SweptWorks',
      'icon' => 'broom',
      'category' => 'janitorial',
      'auth' => 'api_key',
      'note' => 'BYO SweptWorks credentials: user controls privacy, revocation, scopes and provider billing. Commercial cleaning communication, instructions, inspections and issue tracking.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your SweptWorks account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in SweptWorks.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Commercial cleaning communication, instructions, inspections and issue tracking.',
        'where_to_start' => 'https://learn.sweptworks.com/',
        'steps' => 
        array (
          0 => 'Open your SweptWorks account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in SweptWorks.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'connecteam' => 
    array (
      'label' => 'Connecteam',
      'icon' => 'truck',
      'category' => 'workforce',
      'auth' => 'api_key',
      'note' => 'BYO Connecteam credentials: user controls privacy, revocation, scopes and provider billing. Employee scheduling, time clock, forms, checklists, chats and field team operations.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Connecteam account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Connecteam.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Employee scheduling, time clock, forms, checklists, chats and field team operations.',
        'where_to_start' => 'https://connecteam.com/',
        'steps' => 
        array (
          0 => 'Open your Connecteam account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Connecteam.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'hubstaff' => 
    array (
      'label' => 'Hubstaff',
      'icon' => 'truck',
      'category' => 'workforce',
      'auth' => 'api_key',
      'note' => 'BYO Hubstaff credentials: user controls privacy, revocation, scopes and provider billing. Time tracking, GPS, workforce productivity and payroll integrations.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Hubstaff account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Hubstaff.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Time tracking, GPS, workforce productivity and payroll integrations.',
        'where_to_start' => 'https://developer.hubstaff.com/',
        'steps' => 
        array (
          0 => 'Open your Hubstaff account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Hubstaff.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'deputy' => 
    array (
      'label' => 'Deputy',
      'icon' => 'truck',
      'category' => 'workforce',
      'auth' => 'oauth',
      'note' => 'BYO Deputy credentials: user controls privacy, revocation, scopes and provider billing. Rostering, timesheets, labour compliance and team communication.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Paste your app Client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your app Client Secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => false,
          'secret' => false,
          'placeholder' => 'Copy from this app into the provider OAuth app',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Deputy admin/developer settings in a new tab.',
        1 => 'Create a private OAuth app owned by your business account.',
        2 => 'Copy this app\'s redirect URI into Deputy, then copy the Client ID and Client Secret back here.',
        3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
        4 => 'Save the credentials here, then start OAuth and approve access from your own Deputy account.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Rostering, timesheets, labour compliance and team communication.',
        'where_to_start' => 'https://www.deputy.com/api-docs/',
        'steps' => 
        array (
          0 => 'Open your Deputy admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Deputy, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Deputy account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'when_i_work' => 
    array (
      'label' => 'When I Work',
      'icon' => 'truck',
      'category' => 'workforce',
      'auth' => 'api_key',
      'note' => 'BYO When I Work credentials: user controls privacy, revocation, scopes and provider billing. Employee scheduling, shift swaps, time clock and team messaging.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your When I Work account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in When I Work.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Employee scheduling, shift swaps, time clock and team messaging.',
        'where_to_start' => 'https://dev.wheniwork.com/',
        'steps' => 
        array (
          0 => 'Open your When I Work account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in When I Work.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'homebase' => 
    array (
      'label' => 'Homebase',
      'icon' => 'truck',
      'category' => 'workforce',
      'auth' => 'api_key',
      'note' => 'BYO Homebase credentials: user controls privacy, revocation, scopes and provider billing. Team scheduling, time clock, payroll prep and employee communication.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Homebase account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Homebase.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Team scheduling, time clock, payroll prep and employee communication.',
        'where_to_start' => 'https://joinhomebase.com/',
        'steps' => 
        array (
          0 => 'Open your Homebase account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Homebase.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'servicetitan' => 
    array (
      'label' => 'ServiceTitan',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'oauth',
      'note' => 'BYO ServiceTitan credentials: user controls privacy, revocation, scopes and provider billing. Enterprise field-service CRM, dispatch, call booking, invoices and payments.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Paste your app Client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your app Client Secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => false,
          'secret' => false,
          'placeholder' => 'Copy from this app into the provider OAuth app',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your ServiceTitan admin/developer settings in a new tab.',
        1 => 'Create a private OAuth app owned by your business account.',
        2 => 'Copy this app\'s redirect URI into ServiceTitan, then copy the Client ID and Client Secret back here.',
        3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
        4 => 'Save the credentials here, then start OAuth and approve access from your own ServiceTitan account.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Enterprise field-service CRM, dispatch, call booking, invoices and payments.',
        'where_to_start' => 'https://developer.servicetitan.io/',
        'steps' => 
        array (
          0 => 'Open your ServiceTitan admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into ServiceTitan, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own ServiceTitan account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'method_crm' => 
    array (
      'label' => 'Method CRM',
      'icon' => 'truck',
      'category' => 'crm',
      'auth' => 'oauth',
      'note' => 'BYO Method CRM credentials: user controls privacy, revocation, scopes and provider billing. QuickBooks-connected CRM, estimates, invoices and cleaning-business customer management.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Paste your app Client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your app Client Secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => false,
          'secret' => false,
          'placeholder' => 'Copy from this app into the provider OAuth app',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Method CRM admin/developer settings in a new tab.',
        1 => 'Create a private OAuth app owned by your business account.',
        2 => 'Copy this app\'s redirect URI into Method CRM, then copy the Client ID and Client Secret back here.',
        3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
        4 => 'Save the credentials here, then start OAuth and approve access from your own Method CRM account.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'QuickBooks-connected CRM, estimates, invoices and cleaning-business customer management.',
        'where_to_start' => 'https://www.method.me/',
        'steps' => 
        array (
          0 => 'Open your Method CRM admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Method CRM, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Method CRM account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'podiumio' => 
    array (
      'label' => 'PodiumIO',
      'icon' => 'broom',
      'category' => 'cleaning_saas',
      'auth' => 'api_key',
      'note' => 'BYO PodiumIO credentials: user controls privacy, revocation, scopes and provider billing. Booking, sales, payments and customer workflows for home and commercial services.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your PodiumIO account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in PodiumIO.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Booking, sales, payments and customer workflows for home and commercial services.',
        'where_to_start' => 'https://www.podiumio.com/',
        'steps' => 
        array (
          0 => 'Open your PodiumIO account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in PodiumIO.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'serviceworks' => 
    array (
      'label' => 'ServiceWorks',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO ServiceWorks credentials: user controls privacy, revocation, scopes and provider billing. Field service scheduling, dispatch, jobs, invoices and customer management.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your ServiceWorks account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in ServiceWorks.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Field service scheduling, dispatch, jobs, invoices and customer management.',
        'where_to_start' => 'https://www.service.works/',
        'steps' => 
        array (
          0 => 'Open your ServiceWorks account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in ServiceWorks.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'skedulo' => 
    array (
      'label' => 'Skedulo',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'oauth',
      'note' => 'BYO Skedulo credentials: user controls privacy, revocation, scopes and provider billing. Mobile workforce scheduling, dispatch and field productivity platform.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'client_id',
          'label' => 'Client ID',
          'type' => 'text',
          'required' => true,
          'secret' => false,
          'placeholder' => 'Paste your app Client ID',
        ),
        1 => 
        array (
          'name' => 'client_secret',
          'label' => 'Client Secret',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your app Client Secret',
        ),
        2 => 
        array (
          'name' => 'redirect_uri',
          'label' => 'Redirect URI',
          'type' => 'url',
          'required' => false,
          'secret' => false,
          'placeholder' => 'Copy from this app into the provider OAuth app',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Skedulo admin/developer settings in a new tab.',
        1 => 'Create a private OAuth app owned by your business account.',
        2 => 'Copy this app\'s redirect URI into Skedulo, then copy the Client ID and Client Secret back here.',
        3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
        4 => 'Save the credentials here, then start OAuth and approve access from your own Skedulo account.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Mobile workforce scheduling, dispatch and field productivity platform.',
        'where_to_start' => 'https://developer.skedulo.com/',
        'steps' => 
        array (
          0 => 'Open your Skedulo admin/developer settings in a new tab.',
          1 => 'Create a private OAuth app owned by your business account.',
          2 => 'Copy this app\'s redirect URI into Skedulo, then copy the Client ID and Client Secret back here.',
          3 => 'Choose the smallest scopes needed for the workflows you want: customers, jobs/bookings, invoices/payments, staff/schedules, webhooks, or reporting.',
          4 => 'Save the credentials here, then start OAuth and approve access from your own Skedulo account.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'zuper' => 
    array (
      'label' => 'Zuper',
      'icon' => 'truck',
      'category' => 'field_service',
      'auth' => 'api_key',
      'note' => 'BYO Zuper credentials: user controls privacy, revocation, scopes and provider billing. Field service scheduling, work orders, dispatch, timesheets and mobile workflows.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Zuper account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Zuper.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Field service scheduling, work orders, dispatch, timesheets and mobile workflows.',
        'where_to_start' => 'https://www.zuper.co/',
        'steps' => 
        array (
          0 => 'Open your Zuper account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Zuper.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'service_direct' => 
    array (
      'label' => 'Service Direct',
      'icon' => 'truck',
      'category' => 'marketing',
      'auth' => 'api_key',
      'note' => 'BYO Service Direct credentials: user controls privacy, revocation, scopes and provider billing. Lead tracking, call attribution and marketing source analytics for service businesses.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your Service Direct account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Service Direct.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Lead tracking, call attribution and marketing source analytics for service businesses.',
        'where_to_start' => 'https://www.servicedirect.com/',
        'steps' => 
        array (
          0 => 'Open your Service Direct account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in Service Direct.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
    'nicejob' => 
    array (
      'label' => 'NiceJob',
      'icon' => 'truck',
      'category' => 'marketing',
      'auth' => 'api_key',
      'note' => 'BYO NiceJob credentials: user controls privacy, revocation, scopes and provider billing. Review requests, reputation management and referral workflows for local service businesses.',
      'fields' => 
      array (
        0 => 
        array (
          'name' => 'api_key',
          'label' => 'API Key / Personal Access Token',
          'type' => 'password',
          'required' => true,
          'secret' => true,
          'placeholder' => 'Paste your user-owned API key/token',
        ),
      ),
      'instructions' => 
      array (
        0 => 'Open your NiceJob account as an administrator.',
        1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
        2 => 'Create a new key/token for this Titan integration only.',
        3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
        4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in NiceJob.',
      ),
      'setup_guide' => 
      array (
        'summary' => 'Review requests, reputation management and referral workflows for local service businesses.',
        'where_to_start' => 'https://nicejob.com/',
        'steps' => 
        array (
          0 => 'Open your NiceJob account as an administrator.',
          1 => 'Go to Settings, Developer, API, Integrations, Private App, or Personal Access Tokens.',
          2 => 'Create a new key/token for this Titan integration only.',
          3 => 'Grant least-privilege access for the data you want to sync: customers, bookings/jobs, invoices, payments, staff, timesheets, checklists, notes, or webhooks.',
          4 => 'Copy the key once, paste it into this encrypted form, test the connection, then store/revoke it only in NiceJob.',
        ),
        'recommended_scopes' => 
        array (
          0 => 'customers/clients',
          1 => 'jobs/bookings/work orders',
          2 => 'quotes/estimates',
          3 => 'invoices/payments',
          4 => 'staff/schedules',
          5 => 'webhooks/events',
          6 => 'reports/analytics',
        ),
        'privacy_notes' => 
        array (
          0 => 'Keys remain user-owned and provider-billed.',
          1 => 'Secrets are encrypted at rest.',
          2 => 'Users can revoke access in the original provider account at any time.',
          3 => 'AI help must never request or display secret values.',
        ),
        'test_checklist' => 
        array (
          0 => 'Credential saved',
          1 => 'Connection endpoint responds',
          2 => 'Account or workspace identified',
          3 => 'Sample read permission succeeds',
          4 => 'Write/sync permissions only enabled when requested',
        ),
      ),
      'tags' => 
      array (
        0 => 'cleaning',
        1 => 'service business',
        2 => 'byo credentials',
        3 => 'privacy-first',
      ),
      'sync_objects' => 
      array (
        0 => 'clients',
        1 => 'bookings/jobs',
        2 => 'quotes',
        3 => 'invoices',
        4 => 'payments',
        5 => 'staff',
        6 => 'schedules',
        7 => 'webhooks',
        8 => 'notes',
        9 => 'reports',
      ),
      'byo_privacy_badges' => 
      array (
        0 => 'User-owned key',
        1 => 'Encrypted storage',
        2 => 'No platform markup',
        3 => 'Revocable anytime',
      ),
    ),
  ),
  'api' => 
  array (
    'version' => 'v1',
    'rate_limit' => 60,
    'token_expiry' => 365,
  ),
  'webhooks' => 
  array (
    'retry_attempts' => 3,
    'retry_delays' => 
    array (
      0 => 5,
      1 => 30,
      2 => 300,
    ),
    'timeout' => 10,
    'events' => 
    array (
      0 => 'booking.created',
      1 => 'booking.updated',
      2 => 'booking.completed',
      3 => 'booking.cancelled',
      4 => 'invoice.created',
      5 => 'invoice.paid',
      6 => 'invoice.overdue',
      7 => 'client.created',
      8 => 'review.submitted',
      9 => 'complaint.opened',
      10 => 'provider.assigned',
      11 => 'ai.assist.requested',
    ),
  ),
  'guide_ui' => 
  array (
    'enabled' => true,
    'show_before_credentials' => true,
    'secret_warning' => 'Never paste API keys into chat. Paste secrets only into the encrypted credential fields, rotate keys from the provider dashboard, and use least-privilege scopes wherever the provider allows it.',
  ),
);
