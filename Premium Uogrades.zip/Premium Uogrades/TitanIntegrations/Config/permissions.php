<?php
return [
    'view_integrations', 'manage_integrations', 'manage_api_tokens', 'manage_webhooks', 'view_integration_logs',
    'manage_integration_automations', 'manage_integration_payments', 'manage_integration_mail_templates', 'run_integration_agent',
];
