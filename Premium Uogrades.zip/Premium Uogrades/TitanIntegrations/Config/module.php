<?php
return [
    'name' => 'TitanIntegrations',
    'display_name' => 'Titan Integrations',
    'version' => '1.0.0-pass18',
    'ai_controlled' => true,
    'privacy_model' => 'BYO API keys; tenant-owned credentials; no shared provider keys',
    'agent' => 'integration_agent',
];
