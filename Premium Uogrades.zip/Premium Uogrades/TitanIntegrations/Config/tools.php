<?php
return [
    'enabled' => true,
    'tools' => [
        'providers.search',
        'providers.get_setup_guide',
        'provider.setup_guide',
        'credentials.validate_schema',
        'credentials.rotation_guide',
        'connection.test',
        'oauth.troubleshoot',
        'webhook.dispatch_test',
        'sync.diagnostics',
        'integration.lookup',
        'integration.plan_change',
        'knowledge.search',
        'automation.late_invoice.assess',
        'payments.assist',
        'jobs.events.inspect',
        'mail.template.render',
    ],
];
