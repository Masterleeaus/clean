<?php
namespace Modules\TitanIntegrations\Notifications;

use Illuminate\Bus\Queueable;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class LateInvoiceFollowUpPrepared extends Notification
{
    use Queueable;
    public function __construct(public array $payload) {}
    public function via(object $notifiable): array { return ['mail']; }
    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)->subject('Late invoice follow-up prepared')->line('Titan Integrations prepared a late invoice follow-up for review.')->line('Invoice: '.($this->payload['invoice_number'] ?? $this->payload['invoice_id'] ?? 'unknown'));
    }
}
