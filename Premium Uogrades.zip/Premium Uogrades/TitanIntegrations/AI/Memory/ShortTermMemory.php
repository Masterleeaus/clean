<?php
namespace Modules\ExampleModule\AI\Memory;
use Illuminate\Support\Facades\Cache;
class ShortTermMemory
{
    public const TTL = 3600;
    public function __construct(protected string $conversationId = 'demo', protected string $agentId = 'demo-agent') {}
    public function rememberMessage(string $role, string $content, array $metadata = []): void
    {
        $key = $this->key(); $context = Cache::get($key, []);
        $context[] = ['role'=>$role,'content'=>$content,'metadata'=>$metadata,'tokens'=>(int) ceil(strlen($content)/4),'at'=>now()->toIso8601String()];
        Cache::put($key, array_slice($context, -50), self::TTL);
    }
    public function getContext(int $max = 20): array { return array_slice(Cache::get($this->key(), []), -$max); }
    public function forget(): void { Cache::forget($this->key()); }
    protected function key(): string { return "example-module:memory:{$this->agentId}:{$this->conversationId}"; }
}
