<?php
namespace Modules\ExampleModule\AI\Memory;
use Modules\ExampleModule\Models\AgentLearning;
class LongTermMemory
{
    public function learn(string $agentId, string $domain, array $context, array $decision, ?float $quality = null, ?string $feedback = null): AgentLearning
    { return AgentLearning::query()->create(['agent_id'=>$agentId,'domain'=>$domain,'context'=>$context,'decision'=>$decision,'quality_score'=>$quality,'feedback'=>$feedback,'learned_at'=>now()]); }
    public function recallSimilar(string $agentId, string $domain, int $limit = 5): array
    { return AgentLearning::query()->where('agent_id',$agentId)->where('domain',$domain)->orderByDesc('quality_score')->limit($limit)->get()->toArray(); }
    public function forgetBefore(\DateTimeInterface $date): int { return AgentLearning::query()->where('learned_at','<',$date)->delete(); }
}
