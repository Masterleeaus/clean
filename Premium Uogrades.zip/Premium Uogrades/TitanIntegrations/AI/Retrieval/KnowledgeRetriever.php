<?php
namespace Modules\TitanIntegrations\AI\Retrieval;

use Illuminate\Support\Facades\DB;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use SplFileInfo;

class KnowledgeRetriever
{
    public function search(string $query, int $limit = 8): array
    {
        $query = trim($query);
        $limit = max(1, min($limit, 25));

        $dbMatches = $this->searchDatabase($query, $limit);
        if ($dbMatches !== []) {
            return $dbMatches;
        }

        return $this->searchFilesystem($query, $limit);
    }

    private function searchDatabase(string $query, int $limit): array
    {
        try {
            if (!DB::getSchemaBuilder()->hasTable('titan_integration_knowledge_chunks')) {
                return [];
            }

            $builder = DB::table('titan_integration_knowledge_chunks')
                ->select(['title', 'source', 'content', 'metadata']);

            if ($query !== '') {
                foreach ($this->terms($query) as $term) {
                    $builder->where(function ($q) use ($term) {
                        $q->where('title', 'like', "%{$term}%")
                          ->orWhere('content', 'like', "%{$term}%");
                    });
                }
            }

            return $builder->limit($limit)->get()->map(function ($row) {
                $metadata = json_decode((string) $row->metadata, true) ?: [];
                return [
                    'title' => $row->title,
                    'source' => $row->source,
                    'path' => $metadata['path'] ?? null,
                    'excerpt' => mb_substr(trim((string) $row->content), 0, 700),
                    'metadata' => $metadata,
                ];
            })->all();
        } catch (\Throwable) {
            return [];
        }
    }

    private function searchFilesystem(string $query, int $limit): array
    {
        $base = module_path('TitanIntegrations', 'Knowledge');
        if (!is_dir($base)) {
            return [];
        }

        $matches = [];
        $terms = $this->terms($query);
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base));

        foreach ($iterator as $file) {
            if (!($file instanceof SplFileInfo) || !$file->isFile() || strtolower($file->getExtension()) !== 'md') {
                continue;
            }

            $text = file_get_contents($file->getPathname()) ?: '';
            $haystack = mb_strtolower($file->getBasename() . ' ' . $text);
            $score = $query === '' ? 1 : 0;
            foreach ($terms as $term) {
                if (str_contains($haystack, mb_strtolower($term))) {
                    $score++;
                }
            }

            if ($score > 0) {
                $relative = str_replace($base . DIRECTORY_SEPARATOR, '', $file->getPathname());
                $matches[] = [
                    'title' => $file->getBasename('.md'),
                    'source' => 'knowledge-pack',
                    'path' => str_replace(DIRECTORY_SEPARATOR, '/', $relative),
                    'excerpt' => mb_substr(trim($text), 0, 700),
                    'score' => $score,
                ];
            }
        }

        usort($matches, fn ($a, $b) => ($b['score'] <=> $a['score']) ?: strcmp($a['title'], $b['title']));
        return array_slice($matches, 0, $limit);
    }

    private function terms(string $query): array
    {
        if ($query === '') {
            return [];
        }

        $terms = preg_split('/[^a-zA-Z0-9_\-]+/', $query) ?: [];
        return array_values(array_filter(array_unique($terms), fn ($term) => mb_strlen($term) >= 3));
    }
}
