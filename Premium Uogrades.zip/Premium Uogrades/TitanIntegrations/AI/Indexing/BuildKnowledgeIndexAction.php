<?php
namespace Modules\TitanIntegrations\AI\Indexing;

use Illuminate\Support\Facades\DB;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;
use SplFileInfo;

class BuildKnowledgeIndexAction
{
    public function execute(bool $persist = false): array
    {
        $base = module_path('TitanIntegrations', 'Knowledge');
        $files = $this->markdownFiles($base);
        $chunks = [];

        foreach ($files as $file) {
            $text = trim((string) file_get_contents($file->getPathname()));
            if ($text === '') {
                continue;
            }

            $relative = str_replace($base . DIRECTORY_SEPARATOR, '', $file->getPathname());
            $chunks[] = [
                'source' => 'knowledge-pack',
                'title' => $file->getBasename('.md'),
                'content' => mb_substr($text, 0, 12000),
                'metadata' => [
                    'path' => str_replace(DIRECTORY_SEPARATOR, '/', $relative),
                    'bytes' => $file->getSize(),
                    'sha1' => sha1($text),
                ],
            ];
        }

        if ($persist && class_exists(DB::class) && DB::getSchemaBuilder()->hasTable('titan_integration_knowledge_chunks')) {
            DB::table('titan_integration_knowledge_chunks')->truncate();
            foreach ($chunks as $chunk) {
                DB::table('titan_integration_knowledge_chunks')->insert([
                    'source' => $chunk['source'],
                    'title' => $chunk['title'],
                    'content' => $chunk['content'],
                    'metadata' => json_encode($chunk['metadata']),
                    'created_at' => now(),
                    'updated_at' => now(),
                ]);
            }
        }

        return [
            'indexed_files' => count($files),
            'indexed_chunks' => count($chunks),
            'persisted' => $persist,
            'store' => config('titanintegrations-ai.retrieval.embedding_store', 'database'),
        ];
    }

    /** @return SplFileInfo[] */
    private function markdownFiles(string $base): array
    {
        if (!is_dir($base)) {
            return [];
        }

        $files = [];
        $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($base));
        foreach ($iterator as $file) {
            if ($file instanceof SplFileInfo && $file->isFile() && strtolower($file->getExtension()) === 'md') {
                $files[] = $file;
            }
        }

        usort($files, fn (SplFileInfo $a, SplFileInfo $b) => strcmp($a->getPathname(), $b->getPathname()));
        return $files;
    }
}
