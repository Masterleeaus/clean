<?php
namespace Modules\TitanIntegrations\AI\Citations;

class CitationBuilder
{
    public function fromKnowledge(array $chunks): array
    {
        return array_map(fn($chunk) => ['title' => $chunk['title'] ?? 'Knowledge', 'path' => $chunk['path'] ?? null], $chunks);
    }
}
