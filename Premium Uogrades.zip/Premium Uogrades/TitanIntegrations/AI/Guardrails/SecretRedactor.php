<?php
namespace Modules\TitanIntegrations\AI\Guardrails;

class SecretRedactor
{
    public function redact(string $text): string
    {
        $patterns = ['/(sk-[A-Za-z0-9_\-]{12,})/', '/(xox[baprs]-[A-Za-z0-9\-]+)/', '/(ya29\.[A-Za-z0-9_\-\.]+)/', '/(AKIA[0-9A-Z]{16})/'];
        return preg_replace($patterns, '[REDACTED_SECRET]', $text) ?? $text;
    }
}
