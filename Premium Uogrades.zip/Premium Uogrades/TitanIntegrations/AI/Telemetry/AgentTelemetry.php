<?php
namespace Modules\TitanIntegrations\AI\Telemetry;

class AgentTelemetry
{
    public function record(string $event, array $payload = []): void
    {
        logger()->info('titan_integrations.agent.'.$event, array_merge($payload, ['module' => 'TitanIntegrations']));
    }
}
