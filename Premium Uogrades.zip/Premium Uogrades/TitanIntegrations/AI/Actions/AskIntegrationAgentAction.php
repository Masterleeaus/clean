<?php
namespace Modules\TitanIntegrations\AI\Actions;

use Modules\TitanIntegrations\Data\AgentResponseData;
use Modules\TitanIntegrations\AI\Retrieval\KnowledgeRetriever;

class AskIntegrationAgentAction
{
    public function __construct(protected KnowledgeRetriever $retriever) {}

    public function execute(string $message, array $context = []): AgentResponseData
    {
        $knowledge = $this->retriever->search($message);

        return new AgentResponseData(
            'I can help with BYO API-key setup, OAuth app configuration, provider selection, credential field validation, connection tests, webhook troubleshooting, sync diagnostics, and safe integration rollout. Use secure credential fields for secrets; never paste API keys into chat.',
            $knowledge,
            [
                ['type' => 'suggested_next_step', 'label' => 'Find matching providers'],
                ['type' => 'suggested_next_step', 'label' => 'Open provider setup guide'],
                ['type' => 'suggested_next_step', 'label' => 'Validate credential schema'],
                ['type' => 'suggested_next_step', 'label' => 'Run saved connection test'],
                ['type' => 'suggested_next_step', 'label' => 'Troubleshoot webhook delivery'],
            ],
            ['agent' => 'integration_agent']
        );
    }
}
