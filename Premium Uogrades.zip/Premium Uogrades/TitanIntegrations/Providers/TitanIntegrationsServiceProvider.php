<?php

namespace Modules\TitanIntegrations\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Facades\Route;
use Modules\TitanIntegrations\Services\OAuthService;
use Modules\TitanIntegrations\Services\WebhookDispatcher;
use Modules\TitanIntegrations\Services\GenericByoIntegrationService;
use Modules\TitanIntegrations\Services\IntegrationSetupAssistant;
use Modules\TitanIntegrations\Services\ProviderRegistryService;
use Modules\TitanIntegrations\Console\Commands\BuildIntegrationKnowledgeIndexCommand;
use Modules\TitanIntegrations\AI\Retrieval\KnowledgeRetriever;
use Modules\TitanIntegrations\AI\Actions\AskIntegrationAgentAction;
use Modules\TitanIntegrations\Services\Integrations\GoogleCalendarIntegration;
use Modules\TitanIntegrations\Services\Integrations\XeroIntegration;
use Modules\TitanIntegrations\Services\Integrations\HubSpotIntegration;
use Modules\TitanIntegrations\Services\Integrations\MailchimpIntegration;
use Modules\TitanIntegrations\Services\Integrations\SlackIntegration;
use Modules\TitanIntegrations\Services\MailTemplateRenderer;
use Modules\TitanIntegrations\Services\Automation\JobEventAssistService;
use Modules\TitanIntegrations\Services\Automation\PaymentAssistService;
use Modules\TitanIntegrations\Services\Automation\LateInvoiceFollowUpService;
use Modules\TitanIntegrations\Services\Automation\AutomationRuleEngine;
use Modules\TitanIntegrations\Console\Commands\ValidateIntegrationProvidersCommand;
use Modules\TitanIntegrations\Console\Commands\IntegrationModuleHealthCommand;

class TitanIntegrationsServiceProvider extends ServiceProvider
{
    protected string $moduleName      = 'TitanIntegrations';
    protected string $moduleNameLower = 'titanintegrations';

    public function boot(): void
    {
        $this->registerTranslations();
        $this->registerViews();
        $this->loadMigrationsFrom(module_path($this->moduleName, 'Database/Migrations'));
        $this->registerRoutes();

        if ($this->app->runningInConsole()) {
            $this->commands([
                BuildIntegrationKnowledgeIndexCommand::class,
                IntegrationModuleHealthCommand::class,
                ValidateIntegrationProvidersCommand::class,
            ]);
        }
    }

    public function register(): void
    {
        $this->mergeConfigFrom(module_path($this->moduleName, 'Config/config.php'), 'titanintegrations');
        $this->mergeConfigFrom(module_path($this->moduleName, 'Config/ai_native.php'), 'titanintegrations-ai');
        $this->mergeConfigFrom(module_path($this->moduleName, 'Config/tools.php'), 'titanintegrations-tools');
        $this->mergeConfigFrom(module_path($this->moduleName, 'Config/automation.php'), 'titanintegrations-automation');
        $this->mergeConfigFrom(module_path($this->moduleName, 'Config/navigation.php'), 'titanintegrations-navigation');
        $this->mergeConfigFrom(module_path($this->moduleName, 'Config/permissions.php'), 'titanintegrations-permissions');

        $this->app->singleton(OAuthService::class);
        $this->app->singleton(WebhookDispatcher::class);
        $this->app->singleton(GenericByoIntegrationService::class);
        $this->app->singleton(IntegrationSetupAssistant::class);
        $this->app->singleton(ProviderRegistryService::class);
        $this->app->singleton(KnowledgeRetriever::class);
        $this->app->singleton(AskIntegrationAgentAction::class);
        $this->app->singleton(MailTemplateRenderer::class);
        $this->app->singleton(JobEventAssistService::class);
        $this->app->singleton(PaymentAssistService::class);
        $this->app->singleton(LateInvoiceFollowUpService::class);
        $this->app->singleton(AutomationRuleEngine::class);

        $this->app->singleton(GoogleCalendarIntegration::class, fn($app) =>
            new GoogleCalendarIntegration($app->make(OAuthService::class))
        );
        $this->app->singleton(XeroIntegration::class, fn($app) =>
            new XeroIntegration($app->make(OAuthService::class))
        );
        $this->app->singleton(HubSpotIntegration::class);
        $this->app->singleton(MailchimpIntegration::class);
        $this->app->singleton(SlackIntegration::class);
    }

    protected function registerRoutes(): void
    {
        $web = module_path($this->moduleName, 'Routes/web.php');
        if (file_exists($web)) {
            Route::middleware('web')->group($web);
        }

        $api = module_path($this->moduleName, 'Routes/api.php');
        if (file_exists($api)) {
            Route::middleware('api')->prefix('api')->group($api);
        }
    }

    public function registerViews(): void
    {
        $sourcePath = module_path($this->moduleName, 'Resources/views');
        if (is_dir($sourcePath)) {
            $this->loadViewsFrom($sourcePath, $this->moduleNameLower);
        }
    }

    public function registerTranslations(): void
    {
        $langPath = resource_path("lang/modules/{$this->moduleNameLower}");
        if (is_dir($langPath)) {
            $this->loadTranslationsFrom($langPath, $this->moduleNameLower);
        } else {
            $moduleLang = module_path($this->moduleName, 'Resources/lang');
            if (is_dir($moduleLang)) {
                $this->loadTranslationsFrom($moduleLang, $this->moduleNameLower);
            }
        }
    }
}
