<?php
namespace Modules\TitanIntegrations\Actions;

use Modules\TitanIntegrations\Services\Automation\PaymentAssistService;

class PreparePaymentAssistAction
{
    public function __construct(protected PaymentAssistService $service) {}
    public function execute(array $invoice, array $connectedProviders = []): array { return $this->service->buildPaymentOptions($invoice, $connectedProviders); }
}
