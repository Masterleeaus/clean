<?php
namespace Modules\TitanIntegrations\Actions;

use Modules\TitanIntegrations\Services\Automation\LateInvoiceFollowUpService;

class AssessLateInvoiceAction
{
    public function __construct(protected LateInvoiceFollowUpService $service) {}
    public function execute(array $invoice): array { return $this->service->assess($invoice); }
}
