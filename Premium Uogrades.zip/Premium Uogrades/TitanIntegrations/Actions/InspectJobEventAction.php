<?php
namespace Modules\TitanIntegrations\Actions;

use Modules\TitanIntegrations\Services\Automation\JobEventAssistService;

class InspectJobEventAction
{
    public function __construct(protected JobEventAssistService $service) {}
    public function execute(array $job): array { return $this->service->inspectJob($job); }
}
