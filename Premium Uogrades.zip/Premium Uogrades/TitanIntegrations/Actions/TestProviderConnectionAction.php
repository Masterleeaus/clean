<?php
namespace Modules\TitanIntegrations\Actions;

use Modules\TitanIntegrations\Entities\Integration;
use Modules\TitanIntegrations\Services\GenericByoIntegrationService;

class TestProviderConnectionAction
{
    public function __construct(protected GenericByoIntegrationService $service) {}

    public function execute(Integration $integration): array
    {
        $result = $this->service->test($integration);
        if (($result['ok'] ?? false) === true) {
            $integration->markConnected($result['account_name'] ?? null);
        } else {
            $integration->markError((string)($result['error'] ?? 'Connection test failed.'));
        }
        return $result;
    }
}
