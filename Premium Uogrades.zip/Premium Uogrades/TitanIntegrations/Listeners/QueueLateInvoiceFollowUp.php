<?php
namespace Modules\TitanIntegrations\Listeners;

use Modules\TitanIntegrations\Events\LateInvoiceDetected;
use Modules\TitanIntegrations\Jobs\SendLateInvoiceFollowUpJob;

class QueueLateInvoiceFollowUp
{
    public function handle(LateInvoiceDetected $event): void
    {
        if (($event->payload['late'] ?? false) === true) {
            SendLateInvoiceFollowUpJob::dispatch($event->payload);
        }
    }
}
