<?php
namespace Modules\TitanIntegrations\ValueObjects;

class KnowledgeChunk
{
    public function __construct(public string $id, public string $title, public string $content, public array $metadata = []) {}
    public function toArray(): array { return get_object_vars($this); }
}
