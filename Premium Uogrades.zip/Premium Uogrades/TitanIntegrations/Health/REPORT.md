# TitanIntegrations Health Report

- Healthy: yes
- Panels: `*`
- Namespace: `Modules\TitanIntegrations\`

- [WARNING] missing_psr4: Missing module composer PSR-4 autoload; using fallback namespace.
