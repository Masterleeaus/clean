<?php
namespace Modules\TitanIntegrations\Console\Commands;

use Illuminate\Console\Command;
use Modules\TitanIntegrations\Services\ProviderRegistryService;

class IntegrationModuleHealthCommand extends Command
{
    protected $signature = 'titan-integrations:health';
    protected $description = 'Run a lightweight health check for Titan Integrations.';
    public function handle(ProviderRegistryService $registry): int
    {
        $this->info('Titan Integrations health check');
        $this->line('Providers: '.count($registry->all()));
        $this->line('AI Agent: '.(config('titanintegrations-ai.enabled', true) ? 'enabled' : 'disabled'));
        $this->line('Automation: '.(config('titanintegrations-automation.enabled', true) ? 'enabled' : 'disabled'));
        return self::SUCCESS;
    }
}
