<?php
namespace Modules\TitanIntegrations\Console\Commands;

use Illuminate\Console\Command;
use Modules\TitanIntegrations\Services\ProviderRegistryService;

class ValidateIntegrationProvidersCommand extends Command
{
    protected $signature = 'titan-integrations:validate-providers';
    protected $description = 'Validate provider registry metadata for required BYO fields.';
    public function handle(ProviderRegistryService $registry): int
    {
        $errors = 0;
        foreach ($registry->all() as $slug => $provider) {
            foreach (['label', 'category', 'auth'] as $required) {
                if (empty($provider[$required])) { $this->error("{$slug} missing {$required}"); $errors++; }
            }
        }
        $this->info($errors === 0 ? 'Provider registry OK' : "Provider registry has {$errors} issue(s)");
        return $errors === 0 ? self::SUCCESS : self::FAILURE;
    }
}
