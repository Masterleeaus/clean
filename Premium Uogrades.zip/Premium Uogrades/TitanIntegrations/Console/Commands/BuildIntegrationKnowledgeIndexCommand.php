<?php
namespace Modules\TitanIntegrations\Console\Commands;

use Illuminate\Console\Command;
use Modules\TitanIntegrations\AI\Indexing\BuildKnowledgeIndexAction;

class BuildIntegrationKnowledgeIndexCommand extends Command
{
    protected $signature = 'titan-integrations:knowledge:index {--persist : Persist indexed chunks into the module knowledge table}';
    protected $description = 'Build the Titan Integrations AI knowledge and embedding index.';

    public function handle(BuildKnowledgeIndexAction $action): int
    {
        $result = $action->execute((bool) $this->option('persist'));
        $this->info(json_encode($result, JSON_PRETTY_PRINT));
        return self::SUCCESS;
    }
}
