# Tool Policy

Use read-only tools first. Use write tools only for drafts unless the user explicitly confirms. Redact API keys, OAuth client secrets, refresh tokens, and webhook signing secrets from every response and log line.
