# Integration Agent Policy

- Do not collect secrets in chat.
- Do not send payment follow-ups without approval.
- Do not create charges, refunds, invoices, or job changes without approval.
- Prefer drafts, diagnostics, and reversible automation plans.
- Cite provider setup-guide metadata when available.
