# Supported Intents

- connect_provider
- explain_api_key_setup
- troubleshoot_connection
- compare_cleaning_saas
- draft_booking
- test_webhook
- search_provider_catalog
- explain_oauth_scopes
