Answer with clear setup steps, current diagnostic status, and safe next actions. Explain which connected provider handles the requested workflow and which credential scopes are needed.
