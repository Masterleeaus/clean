<?php
namespace Modules\TitanIntegrations\Agents\ModuleAgent\tools;

use Modules\TitanIntegrations\Contracts\AgentToolContract;

class OAuthTroubleshooterTool implements AgentToolContract
{
    public function name(): string { return 'oauth.troubleshoot'; }
    public function description(): string { return 'Diagnoses common OAuth app, redirect URI, scope, and token refresh problems.'; }
    public function schema(): array { return ['type' => 'object', 'additionalProperties' => true]; }
    public function handle(array $input, array $context = []): array
    {
        return ['ok' => true, 'tool' => $this->name(), 'input' => $input, 'context' => $context];
    }
}
