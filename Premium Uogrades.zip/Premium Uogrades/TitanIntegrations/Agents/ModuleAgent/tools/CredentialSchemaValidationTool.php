<?php
namespace Modules\TitanIntegrations\Agents\ModuleAgent\tools;

use Modules\TitanIntegrations\Contracts\AgentToolContract;

class CredentialSchemaValidationTool implements AgentToolContract
{
    public function name(): string { return 'credentials.validate_schema'; }
    public function description(): string { return 'Validates non-secret credential metadata against a provider schema without echoing secret values.'; }
    public function schema(): array
    {
        return [
            'type' => 'object',
            'required' => ['provider'],
            'properties' => [
                'provider' => ['type' => 'string'],
                'fields' => ['type' => 'object', 'additionalProperties' => true],
            ],
        ];
    }
    public function handle(array $input, array $context = []): array
    {
        $provider = (string)($input['provider'] ?? '');
        $cfg = config("titanintegrations.integrations.{$provider}");
        if (!$cfg) return ['ok' => false, 'error' => 'Unknown provider.', 'provider' => $provider];
        $given = array_keys((array)($input['fields'] ?? []));
        $missing = [];
        $known = [];
        foreach (($cfg['fields'] ?? []) as $field) {
            $name = $field['name'] ?? null;
            if (!$name) continue;
            $known[] = $name;
            if (($field['required'] ?? false) && !in_array($name, $given, true)) $missing[] = $name;
        }
        return [
            'ok' => $missing === [],
            'provider' => $provider,
            'missing_required_fields' => $missing,
            'known_fields' => $known,
            'note' => 'Secret values are intentionally not returned by this tool.',
        ];
    }
}
