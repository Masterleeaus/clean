<?php
namespace Modules\TitanIntegrations\Agents\ModuleAgent\tools;

use Modules\TitanIntegrations\Contracts\AgentToolContract;

class IntegrationLookupTool implements AgentToolContract
{
    public function name(): string { return 'integration.lookup'; }
    public function description(): string { return 'Looks up configured providers, saved integration metadata, and available actions.'; }
    public function schema(): array { return ['type' => 'object', 'additionalProperties' => true]; }
    public function handle(array $input, array $context = []): array
    {
        return ['ok' => true, 'tool' => $this->name(), 'input' => $input, 'context' => $context];
    }
}
