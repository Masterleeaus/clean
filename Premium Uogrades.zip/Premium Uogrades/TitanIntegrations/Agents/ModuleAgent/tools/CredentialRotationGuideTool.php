<?php
namespace Modules\TitanIntegrations\Agents\ModuleAgent\tools;

use Modules\TitanIntegrations\Contracts\AgentToolContract;

class CredentialRotationGuideTool implements AgentToolContract
{
    public function name(): string { return 'credentials.rotation_guide'; }
    public function description(): string { return 'Guides users through safe API-key or OAuth secret rotation without exposing secrets.'; }
    public function schema(): array { return ['type' => 'object', 'additionalProperties' => true]; }
    public function handle(array $input, array $context = []): array
    {
        return ['ok' => true, 'tool' => $this->name(), 'input' => $input, 'context' => $context];
    }
}
