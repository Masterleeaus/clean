<?php
namespace Modules\TitanIntegrations\Agents\ModuleAgent\tools;

use Modules\TitanIntegrations\Contracts\AgentToolContract;

class WebhookDispatchTestTool implements AgentToolContract
{
    public function name(): string { return 'webhook.dispatch_test'; }
    public function description(): string { return 'Prepares a safe webhook dispatch test plan and validates event naming before sending.'; }
    public function schema(): array { return ['type' => 'object', 'properties' => ['event' => ['type' => 'string'], 'endpoint_id' => ['type' => 'integer']]]; }
    public function handle(array $input, array $context = []): array
    {
        $event = trim((string)($input['event'] ?? 'integration.test'));
        return [
            'ok' => true,
            'event' => $event,
            'safe_payload' => ['event' => $event, 'test' => true, 'redacted' => true],
            'requires_confirmation' => true,
        ];
    }
}
