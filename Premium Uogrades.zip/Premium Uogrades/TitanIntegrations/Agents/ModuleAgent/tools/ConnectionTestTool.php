<?php
namespace Modules\TitanIntegrations\Agents\ModuleAgent\tools;

use Modules\TitanIntegrations\Contracts\AgentToolContract;
use Modules\TitanIntegrations\Services\GenericByoIntegrationService;

class ConnectionTestTool implements AgentToolContract
{
    public function __construct(protected GenericByoIntegrationService $service) {}
    public function name(): string { return 'connection.test'; }
    public function description(): string { return 'Runs a safe saved-credential connection test for a BYO provider.'; }
    public function schema(): array { return ['type' => 'object', 'required' => ['provider'], 'properties' => ['provider' => ['type' => 'string']]]; }
    public function handle(array $input, array $context = []): array
    {
        $provider = (string)($input['provider'] ?? '');
        $cfg = config("titanintegrations.integrations.{$provider}");
        if (!$cfg) return ['ok' => false, 'error' => 'Unknown provider.', 'provider' => $provider];
        return [
            'ok' => true,
            'provider' => $provider,
            'mode' => 'saved_credentials_only',
            'auth' => $cfg['auth'] ?? 'api_key',
            'next_step' => 'Use the encrypted credential form, save the integration, then run the controller/service test path for this tenant.',
        ];
    }
}
