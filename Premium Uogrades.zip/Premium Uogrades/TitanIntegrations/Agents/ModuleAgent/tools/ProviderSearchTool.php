<?php
namespace Modules\TitanIntegrations\Agents\ModuleAgent\tools;

use Modules\TitanIntegrations\Contracts\AgentToolContract;

class ProviderSearchTool implements AgentToolContract
{
    public function name(): string { return 'providers.search'; }
    public function description(): string { return 'Searches the BYO provider registry by name, category, auth type, tags, or common use case.'; }
    public function schema(): array
    {
        return [
            'type' => 'object',
            'properties' => [
                'query' => ['type' => 'string'],
                'category' => ['type' => 'string'],
                'auth' => ['type' => 'string'],
                'limit' => ['type' => 'integer', 'minimum' => 1, 'maximum' => 50],
            ],
        ];
    }
    public function handle(array $input, array $context = []): array
    {
        $query = mb_strtolower((string)($input['query'] ?? ''));
        $category = $input['category'] ?? null;
        $auth = $input['auth'] ?? null;
        $limit = max(1, min((int)($input['limit'] ?? 20), 50));
        $providers = config('titanintegrations.integrations', []);
        $matches = [];
        foreach ($providers as $slug => $cfg) {
            if ($category && ($cfg['category'] ?? null) !== $category) continue;
            if ($auth && ($cfg['auth'] ?? null) !== $auth) continue;
            $haystack = mb_strtolower($slug.' '.($cfg['label'] ?? '').' '.($cfg['category'] ?? '').' '.implode(' ', $cfg['tags'] ?? []));
            if ($query === '' || str_contains($haystack, $query)) {
                $matches[] = [
                    'provider' => $slug,
                    'label' => $cfg['label'] ?? $slug,
                    'category' => $cfg['category'] ?? 'other',
                    'auth' => $cfg['auth'] ?? 'api_key',
                    'docs_url' => $cfg['docs_url'] ?? $cfg['developer_url'] ?? null,
                ];
            }
            if (count($matches) >= $limit) break;
        }
        return ['ok' => true, 'count' => count($matches), 'providers' => $matches];
    }
}
