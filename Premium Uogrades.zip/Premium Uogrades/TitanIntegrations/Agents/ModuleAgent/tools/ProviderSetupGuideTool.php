<?php
namespace Modules\TitanIntegrations\Agents\ModuleAgent\tools;

use Modules\TitanIntegrations\Contracts\AgentToolContract;
use Modules\TitanIntegrations\Services\ProviderSetupGuideGenerator;

class ProviderSetupGuideTool implements AgentToolContract
{
    public function __construct(protected ProviderSetupGuideGenerator $generator) {}

    public function name(): string { return 'provider.setup_guide'; }
    public function description(): string { return 'Generate BYO API key, OAuth, webhook, scope, privacy and test instructions from provider registry metadata.'; }
    public function schema(): array
    {
        return [
            'type' => 'object',
            'required' => ['provider'],
            'properties' => [
                'provider' => ['type' => 'string'],
                'format' => ['type' => 'string', 'enum' => ['array', 'markdown']],
            ],
        ];
    }
    public function handle(array $input, array $context = []): array
    {
        $provider = (string)($input['provider'] ?? '');
        if (($input['format'] ?? 'array') === 'markdown') {
            return ['ok' => true, 'provider' => $provider, 'markdown' => $this->generator->renderMarkdown($provider)];
        }
        return $this->generator->generate($provider);
    }
}
