<?php
namespace Modules\TitanIntegrations\Agents\ModuleAgent\tools;

use Modules\TitanIntegrations\Contracts\AgentToolContract;
use Modules\TitanIntegrations\AI\Retrieval\KnowledgeRetriever;

class KnowledgeSearchTool implements AgentToolContract
{
    public function __construct(protected KnowledgeRetriever $retriever) {}
    public function name(): string { return 'knowledge.search'; }
    public function description(): string { return 'Searches the integration-agent knowledge pack and indexed setup guidance.'; }
    public function schema(): array { return ['type' => 'object', 'properties' => ['query' => ['type' => 'string'], 'limit' => ['type' => 'integer']]]; }
    public function handle(array $input, array $context = []): array
    {
        return ['ok' => true, 'results' => $this->retriever->search((string)($input['query'] ?? ''), (int)($input['limit'] ?? 8))];
    }
}
