# Final Production Hardening Checklist

- Run route:list and config:cache in host app.
- Publish migrations and verify tenant scoping.
- Confirm provider credential encryption.
- Run knowledge index build.
- Run provider connection smoke tests.
- Confirm payment/mail automations require approval.
