# Provider Release Checklist

Registry entry, credential schema, setup guide, scopes, connection test, error mapping, webhooks, object mapping, agent tool compatibility.
