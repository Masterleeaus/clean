# Privacy and Cost FAQ

Titan Integrations is BYO-only. Users keep provider ownership, billing, quotas, and audit controls. Credentials are encrypted and API access is not resold.
