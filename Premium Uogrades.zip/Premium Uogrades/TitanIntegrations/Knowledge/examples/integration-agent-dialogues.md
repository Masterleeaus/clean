# Integration Agent Dialogues

## Provider setup
User asks how to connect a provider. Agent explains where to create the API key, which scopes are needed, and directs the user to secure credential fields.

## Webhook troubleshooting
Agent checks endpoint URL, signing secret presence, recent delivery logs, retry status, and common HTTP failure causes.

## OAuth repair
Agent verifies redirect URI, client ID presence, missing scopes, token refresh failures, and provider app status.
