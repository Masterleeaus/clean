# Credential Handling

Secrets must be encrypted at rest, redacted in logs, never returned through API responses, and never requested in AI chat.
