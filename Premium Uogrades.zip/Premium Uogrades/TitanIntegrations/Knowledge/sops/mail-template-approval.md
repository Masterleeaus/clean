# Mail Template Approval SOP

All invoice, payment, job, and event emails are rendered as drafts first. Operators approve before send unless the tenant explicitly enables trusted automation for that template and provider.
