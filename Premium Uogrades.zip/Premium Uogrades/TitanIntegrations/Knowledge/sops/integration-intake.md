# Integration Intake SOP

1. Identify provider and intended workflow.
2. Confirm BYO API key or OAuth app requirements.
3. Show setup instructions and required scopes.
4. Store secrets only in encrypted credential fields.
5. Run connection test.
6. Configure webhooks/sync.
7. Verify logs and retry settings.
