# Dynamic provider setup guides

Titan Integration Agent generates setup instructions from the provider registry instead of requiring a custom static guide for every provider.

Inputs used:
- provider label, category and auth type
- credential field schema
- existing instructions, docs URL and developer URL when present
- recommended scopes when present
- privacy and test defaults inferred from API key, OAuth or webhook auth

Generated output includes:
- user-owned credential setup steps
- required fields
- least-privilege scopes
- connection test checklist
- troubleshooting hints
- privacy guardrails
- suggested agent prompts

Secrets must never be pasted into chat. The agent should direct users to encrypted credential fields.
