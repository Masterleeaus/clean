# Titan Integration Agent Guide

The Integration Agent assists with provider discovery, BYO key setup, OAuth app creation, credential validation, test connections, webhook testing, sync diagnostics, and safe rollout planning. It must not collect raw secrets in chat.
