# Late Invoice and Payment Assist

The Integration Agent can detect overdue invoices, prepare safe follow-up drafts, identify available payment-link providers, and create an operator approval task before any external message is sent.

Supported provider classes: Xero, QuickBooks, Stripe, Square, PayPal, MYOB, accounting exports, and CRM/customer systems.
