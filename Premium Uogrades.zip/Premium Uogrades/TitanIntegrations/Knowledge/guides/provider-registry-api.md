# Provider registry API

The Integration Agent can use the registry API to list, filter and inspect BYO providers.

- `GET /api/integrations/providers?q=slack` returns matching providers.
- `GET /api/integrations/providers/{provider}` returns registry metadata and a generated setup guide.
- Provider guides are generated from auth type, credential schema, docs URL, recommended scopes and safety notes.

Never expose stored credentials in API responses. Secret fields should be represented by field names and labels only.
