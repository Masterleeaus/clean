# BYO API Key Setup Standard

Open the provider developer/API settings, create a key or OAuth app owned by the user, choose minimum scopes, paste the secret only into Titan encrypted credential fields, then run Test Connection.
