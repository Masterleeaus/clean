# Jobs and Events Automation

The agent can inspect job/event payloads for unassigned jobs, missed arrivals, stale status, customer confirmation needs, and calendar sync issues. It prepares recommendations and reviewable actions for dispatch teams.
