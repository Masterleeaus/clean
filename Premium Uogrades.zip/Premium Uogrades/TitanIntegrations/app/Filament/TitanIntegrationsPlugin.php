<?php

namespace Modules\TitanIntegrations\Filament;

use Coolsam\Modules\Concerns\ModuleFilamentPlugin;
use Filament\Contracts\Plugin;
use Filament\Panel;

class TitanIntegrationsPlugin implements Plugin
{
    use ModuleFilamentPlugin;

    public function getModuleName(): string
    {
        return 'TitanIntegrations';
    }

    public function getId(): string
    {
        return 'titanintegrations';
    }

    public function boot(Panel $panel): void
    {
        // TODO: Implement boot() method.
    }
}
