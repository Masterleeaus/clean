<?php
namespace Modules\JobAssist\Entities;

use Illuminate\Database\Eloquent\Model;

class JobAssistAnalyticsSnapshot extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['snapshot_date' => 'date', 'dimensions' => 'array', 'metadata' => 'array'];

    public function scopeForCompany($query, $companyId)
    {
        return $query->where('company_id', $companyId);
    }
}
