<?php

namespace Modules\JobAssist\Entities;

use Illuminate\Database\Eloquent\Model;

class JobAssistAuditLog extends Model
{
    protected $table = 'jobassist_audit_logs';
    protected $guarded = ['id'];
    protected $casts = ['metadata' => 'array'];
}
