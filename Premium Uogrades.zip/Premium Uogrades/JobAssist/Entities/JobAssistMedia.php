<?php
namespace Modules\JobAssist\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Illuminate\Database\Eloquent\Relations\HasMany;

class JobAssistMedia extends Model
{
    use SoftDeletes;

    protected $table = 'jobassist_media';
    protected $guarded = ['id'];
    protected $casts = [
        'metadata' => 'array',
        'detected_objects' => 'array',
        'analysis_summary' => 'array',
        'processed_at' => 'datetime',
    ];

    public function analyses(): HasMany { return $this->hasMany(JobAssistMediaAnalysis::class, 'media_id'); }
    public function reports(): HasMany { return $this->hasMany(JobAssistReport::class, 'media_id'); }
    public function detections(): HasMany { return $this->hasMany(JobAssistDetection::class, 'media_id'); }
    public function ocrResults(): HasMany { return $this->hasMany(JobAssistOcrResult::class, 'media_id'); }
    public function recommendations(): HasMany { return $this->hasMany(JobAssistRecommendation::class, 'media_id'); }
    public function searchIndexes(): HasMany { return $this->hasMany(JobAssistSearchIndex::class, 'media_id'); }

    public function scopeForCompany($query, $companyId) { return $query->where('company_id', $companyId); }
    public function isProcessed(): bool { return $this->status === 'processed'; }
}
