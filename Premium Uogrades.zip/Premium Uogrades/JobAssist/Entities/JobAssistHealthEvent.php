<?php

namespace Modules\JobAssist\Entities;

use Illuminate\Database\Eloquent\Model;

class JobAssistHealthEvent extends Model
{
    protected $table = 'jobassist_health_events';
    protected $guarded = [];

    protected $casts = [
        'context' => 'array',
    ];
}
