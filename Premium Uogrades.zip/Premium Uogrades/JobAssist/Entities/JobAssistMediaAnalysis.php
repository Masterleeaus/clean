<?php
namespace Modules\JobAssist\Entities;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
class JobAssistMediaAnalysis extends Model { protected $table='jobassist_media_analyses'; protected $guarded=['id']; protected $casts=['vision_result'=>'array','ocr_result'=>'array','retrieval_context'=>'array','recommendations'=>'array','confidence_score'=>'float']; public function media(): BelongsTo { return $this->belongsTo(JobAssistMedia::class,'media_id'); }}
