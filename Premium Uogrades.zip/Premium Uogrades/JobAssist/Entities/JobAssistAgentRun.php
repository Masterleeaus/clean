<?php
namespace Modules\JobAssist\Entities;
use Illuminate\Database\Eloquent\Model;
class JobAssistAgentRun extends Model {
    protected $table = 'jobassist_agent_runs';
    protected $guarded = ['id'];
    protected $casts = ['input'=>'array','output'=>'array'];
    public function scopeForCompany($query, $companyId) { return $query->where('company_id', $companyId); }
}
