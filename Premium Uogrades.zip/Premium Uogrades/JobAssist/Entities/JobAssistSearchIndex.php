<?php
namespace Modules\JobAssist\Entities;
use Illuminate\Database\Eloquent\Model;
class JobAssistSearchIndex extends Model {
    protected $table = 'jobassist_search_indexes';
    protected $guarded = ['id'];
    protected $casts = ['embedding'=>'array','metadata'=>'array'];
    public function scopeForCompany($query, $companyId) { return $query->where('company_id', $companyId); }
}
