<?php
namespace Modules\JobAssist\Entities;
use Illuminate\Database\Eloquent\Model;
class JobAssistDetection extends Model {
    protected $table = 'jobassist_detections';
    protected $guarded = ['id'];
    protected $casts = ['bounding_box'=>'array','segmentation'=>'array','metadata'=>'array'];
    public function scopeForCompany($query, $companyId) { return $query->where('company_id', $companyId); }
}
