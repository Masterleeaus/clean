<?php
namespace Modules\JobAssist\Entities;
use Illuminate\Database\Eloquent\Model;
class JobAssistRecommendation extends Model {
    protected $table = 'jobassist_recommendations';
    protected $guarded = ['id'];
    protected $casts = ['actions'=>'array','tools_parts'=>'array'];
    public function scopeForCompany($query, $companyId) { return $query->where('company_id', $companyId); }
}
