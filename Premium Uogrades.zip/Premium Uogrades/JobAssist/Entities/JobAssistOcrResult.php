<?php
namespace Modules\JobAssist\Entities;
use Illuminate\Database\Eloquent\Model;
class JobAssistOcrResult extends Model {
    protected $table = 'jobassist_ocr_results';
    protected $guarded = ['id'];
    protected $casts = ['blocks'=>'array','metadata'=>'array'];
    public function scopeForCompany($query, $companyId) { return $query->where('company_id', $companyId); }
}
