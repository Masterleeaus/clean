<?php
namespace Modules\JobAssist\Entities;

use Illuminate\Database\Eloquent\Model;

class JobAssistChecklistUpdate extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['evidence' => 'array', 'payload' => 'array'];

    public function scopeForCompany($query, $companyId)
    {
        return $query->where('company_id', $companyId);
    }
}
