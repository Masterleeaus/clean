<?php

namespace Modules\JobAssist\Entities;

use Illuminate\Database\Eloquent\Model;

class JobAssistRetentionRun extends Model
{
    protected $table = 'jobassist_retention_runs';
    protected $guarded = [];

    protected $casts = [
        'metadata' => 'array',
    ];
}
