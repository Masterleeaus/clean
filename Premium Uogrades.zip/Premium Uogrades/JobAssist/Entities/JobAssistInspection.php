<?php
namespace Modules\JobAssist\Entities;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
class JobAssistInspection extends Model { use SoftDeletes; protected $table='jobassist_inspections'; protected $guarded=['id']; protected $casts=['checklist'=>'array','scores'=>'array','metadata'=>'array']; public function scopeForCompany($q,$companyId){ return $q->where('company_id',$companyId); }}
