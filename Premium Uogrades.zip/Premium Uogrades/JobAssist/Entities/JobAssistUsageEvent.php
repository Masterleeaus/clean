<?php

namespace Modules\JobAssist\Entities;

use Illuminate\Database\Eloquent\Model;

class JobAssistUsageEvent extends Model
{
    protected $table = 'jobassist_usage_events';
    protected $guarded = [];

    protected $casts = [
        'metadata' => 'array',
        'estimated_cost' => 'decimal:6',
    ];
}
