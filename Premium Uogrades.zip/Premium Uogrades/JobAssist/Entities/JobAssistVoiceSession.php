<?php
namespace Modules\JobAssist\Entities;

use Illuminate\Database\Eloquent\Model;

class JobAssistVoiceSession extends Model
{
    protected $guarded = ['id'];
    protected $casts = ['image_context' => 'array', 'retrieval_context' => 'array'];

    public function scopeForCompany($query, $companyId)
    {
        return $query->where('company_id', $companyId);
    }
}
