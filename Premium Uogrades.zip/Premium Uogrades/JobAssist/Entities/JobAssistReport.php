<?php

namespace Modules\JobAssist\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class JobAssistReport extends Model
{
    protected $table = 'jobassist_reports';
    protected $guarded = ['id'];
    protected $casts = ['data' => 'array', 'published_at' => 'datetime'];

    public function media(): BelongsTo { return $this->belongsTo(JobAssistMedia::class, 'media_id'); }
    public function scopeForCompany($query, $companyId) { return $query->where('company_id', $companyId); }
}
