# JobAssist Pass 4 QA Checklist

## Added in this pass

- Operations migration for checklist update records, analytics snapshots, and voice sessions.
- Analytics service and analytics dashboard metrics.
- Settings persistence service and WorkSuite Reply-based settings endpoint.
- Voice/image-context question endpoint using Aitools bridge only.
- Checklist integration now persists suggested updates for Booking, TitanGoField, CleanQuality, and Complaint when available.
- Dashboard repaired to use `JobAssistController@index` and display analytics summary.
- Media detail page now exposes image-context assistant form.
- Aitools bridge now includes generic reasoning wrapper and method candidates.

## Validation

- Run `php artisan module:migrate JobAssist`.
- Run permission seeder.
- Visit `/account/job-assist` and confirm dashboard loads.
- Upload media and confirm processing job still runs.
- Open a media detail page and submit an image-context question.
- Visit `/account/job-assist/analytics`.
- Save settings at `/account/job-assist/settings`.
- Confirm records can be created in:
  - `jobassist_checklist_updates`
  - `jobassist_voice_sessions`
  - `jobassist_analytics_snapshots`

## Known remaining work

- Wire exact Aitools concrete service class/method names once final Aitools module API is locked.
- Add real PDF binary generation if WorkSuite has a preferred DomPDF/Snappy package enabled.
- Add JavaScript/AJAX handling for voice and settings forms to avoid full-page JSON display.
- Add command/scheduler for analytics snapshots and media retention cleanup.
