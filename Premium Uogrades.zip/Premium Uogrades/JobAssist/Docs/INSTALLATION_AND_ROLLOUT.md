# JobAssist Installation and Rollout

## Safe rollout sequence

1. Back up database and media storage.
2. Install/replace the `JobAssist` module directory.
3. Run migrations.
4. Run `JobAssistPermissionSeeder`.
5. Clear config, route, and view caches.
6. Confirm navigation appears for permitted users.
7. Upload one test image per company boundary.
8. Confirm queue worker processes `ProcessJobAssistMedia`.
9. Confirm no media is accessible across companies.
10. Enable optional integrations only after base media processing passes.

## Required queue coverage

- Vision/OCR analysis
- Knowledge retrieval
- Reasoning
- Report generation
- Embedding generation
- Retention command via scheduler

## Scheduler suggestion

Run retention daily:

```php
$schedule->command('jobassist:retention')->dailyAt('02:30');
```

## Rollback

Disable navigation/permissions first, then restore previous module and database backup. Do not delete media storage during rollback unless retention has been validated.
