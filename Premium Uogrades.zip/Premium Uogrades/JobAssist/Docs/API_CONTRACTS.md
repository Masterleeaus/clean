# JobAssist API Contracts

These contracts are intentionally WorkSuite-native and company-isolated. All endpoints require authenticated WorkSuite users and must pass JobAssist permission checks.

## Media Upload

`POST /account/job-assist/media`

Multipart fields:

- `media` file, required
- `vertical` string, optional: cleaning, handyman, electrical, plumbing, hvac, pest, gardening, painting, property_inspection
- `job_id` integer, optional
- `booking_id` integer, optional
- `notes` string, optional

Response uses WorkSuite `Reply` helpers when available.

## Signed Media URL

`GET /account/job-assist/media/{media}/signed-url`

Returns a temporary access URL for company-owned media only.

## Voice/Image Context

`POST /account/job-assist/media/{media}/voice/ask`

JSON:

```json
{
  "question": "What is this part?"
}
```

Response includes the answer, detected objects, OCR context, recommendations, and confidence where available.

## Monitoring Health

`GET /account/job-assist/monitoring/health`

Returns current pipeline component health for admin/analytics users.
