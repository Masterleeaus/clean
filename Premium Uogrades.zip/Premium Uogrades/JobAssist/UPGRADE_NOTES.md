# JobAssist Upgrade Notes

## Pass 1
- Converted ProShots concept into JobAssist module foundation.
- Removed Pebblely/product-photo assumptions from the active module scaffold.
- Added WorkSuite-native routing, controllers, views, media upload, config and core tables.

## Pass 2
- Added Aitools bridge layer with dynamic method discovery so JobAssist uses Aitools without creating a separate AI runtime.
- Expanded media processing into vision → OCR → knowledge retrieval → domain reasoning → checklist sync → draft report → visual search indexing.
- Added intelligence tables: detections, OCR results, recommendations, search indexes and agent runs.
- Added domain recommendation scaffolding for cleaning, electrical, plumbing, HVAC, pest control, painting, gardening and general inspections.
- Added report and visual search controllers/views.
- Added optional-module-safe checklist integration boundary for Booking, TitanGoField/FieldOps, CleanQuality and Complaint.

## Remaining
- Wire exact Aitools service method names after inspecting the installed Aitools module implementation.
- Add signed media preview/download controller.
- Add manager approval and customer sign-off flows.
- Add PDF rendering for customer reports.
- Add voice endpoint integration with TitanEchoVoice.
- Add full permission seeder and sidebar registration according to final WorkSuite install target.


## Pass 3 Additions

- Added signed/private media URL service with local-disk fallback.
- Added authorization service wrapping WorkSuite permission checks.
- Added permission seeder for JobAssist permissions.
- Added navigation service and shared nav partial for WorkSuite Blade pages.
- Added report generation action and PDF/HTML report endpoint.
- Added secure media delete flow.
- Added JobAssist settings and audit log migrations/entities/services.
- Hardened routes and controllers to use explicit company isolation checks.

## Remaining Work

- Wire installer to call `JobAssistPermissionSeeder` automatically if this WorkSuite build expects module install hooks.
- Replace Aitools bridge stubs with exact Aitools module service names after final source inspection.
- Add true malware scanner integration where infrastructure supports it.
- Add voice assistant UI and TitanEchoVoice adapter.
- Add image annotation canvas for issue marking.
