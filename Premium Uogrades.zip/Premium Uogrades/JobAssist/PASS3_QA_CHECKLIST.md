# JobAssist Pass 3 QA Checklist

- Confirm `php artisan module:enable JobAssist` still loads.
- Run migrations including `jobassist_settings` and `jobassist_audit_logs`.
- Run `JobAssistPermissionSeeder` manually or from module installer.
- Verify routes resolve for dashboard, media, search, reports, PDF.
- Upload image/PDF as company A and confirm company B cannot access it.
- Confirm signed media route returns JSON URL or protected download with valid signature.
- Generate a report from processed or partially processed media.
- Test PDF endpoint with DomPDF installed and without DomPDF installed.
- Confirm permission denial returns 403 for non-authorized users where WorkSuite permission APIs exist.
- Confirm delete removes private media file and soft deletes record.
