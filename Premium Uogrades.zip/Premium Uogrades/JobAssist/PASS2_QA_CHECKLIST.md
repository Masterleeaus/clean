# Pass 2 QA Checklist

- Run `php artisan migrate` and confirm all JobAssist tables are created.
- Upload an image/PDF/video as a company user.
- Confirm media record stores `company_id` and `created_by`.
- Run queue worker and confirm `ProcessJobAssistMedia` completes or safely marks skipped when Aitools method names are not yet bound.
- Confirm analysis, report and search index rows are created.
- Confirm `/account/job-assist/search` loads and filters by text/object.
- Confirm `/account/job-assist/reports` loads and report show page renders JSON sections.
- Confirm electrical output includes non-certification disclaimer.
- Confirm no direct OpenAI/Anthropic provider keys exist inside JobAssist.
- Confirm optional integrations do not fatal when Booking/CleanQuality/Complaint are disabled.
