<?php

namespace Modules\JobAssist\Support;

final class JobAssistPermissions
{
    public const VIEW = 'view_jobassist';
    public const MANAGE_MEDIA = 'manage_jobassist_media';
    public const RUN_ANALYSIS = 'run_jobassist_analysis';
    public const VIEW_REPORTS = 'view_jobassist_reports';
    public const MANAGE_SETTINGS = 'manage_jobassist_settings';

    public static function all(): array
    {
        return [self::VIEW, self::MANAGE_MEDIA, self::RUN_ANALYSIS, self::VIEW_REPORTS, self::MANAGE_SETTINGS];
    }

    public static function labels(): array
    {
        return [
            self::VIEW => 'View JobAssist',
            self::MANAGE_MEDIA => 'Upload and manage JobAssist media',
            self::RUN_ANALYSIS => 'Run JobAssist AI analysis',
            self::VIEW_REPORTS => 'View JobAssist reports',
            self::MANAGE_SETTINGS => 'Manage JobAssist settings',
        ];
    }
}
