<?php

namespace Modules\JobAssist\Services;

use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Entities\JobAssistReport;

class JobAssistReportService
{
    public function generate(JobAssistMedia $media): JobAssistReport
    {
        $media->load(['detections', 'ocrResults', 'recommendations', 'analyses']);

        $summary = [
            'media_id' => $media->id,
            'vertical' => $media->vertical,
            'status' => $media->status,
            'completion_score' => $this->score($media),
            'confidence_score' => $this->confidence($media),
            'detections' => $media->detections->pluck('label')->values()->all(),
            'recommendations' => $media->recommendations->map(fn ($r) => [
                'title' => $r->title,
                'severity' => $r->severity,
                'confidence' => $r->confidence,
            ])->values()->all(),
            'ocr_excerpt' => optional($media->ocrResults->first())->text,
        ];

        return JobAssistReport::create([
            'company_id' => $media->company_id,
            'media_id' => $media->id,
            'created_by' => function_exists('user') && user() ? user()->id : auth()->id(),
            'report_type' => $media->vertical ?: 'general',
            'title' => 'JobAssist ' . ucfirst($media->vertical ?: 'Visual') . ' Report',
            'summary' => 'AI-assisted field report generated from uploaded work evidence.',
            'status' => 'draft',
            'data' => $summary,
        ]);
    }

    protected function score(JobAssistMedia $media): int
    {
        $penalty = $media->recommendations->whereIn('severity', ['high', 'critical'])->count() * 15;
        $minor = $media->recommendations->where('severity', 'medium')->count() * 7;
        return max(0, min(100, 100 - $penalty - $minor));
    }

    protected function confidence(JobAssistMedia $media): float
    {
        $values = collect()
            ->merge($media->detections->pluck('confidence'))
            ->merge($media->recommendations->pluck('confidence'))
            ->filter(fn ($value) => $value !== null);

        return $values->count() ? round((float) $values->avg(), 3) : 0.5;
    }
}
