<?php
namespace Modules\JobAssist\Services;

use Illuminate\Support\Facades\DB;
use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Entities\JobAssistRecommendation;
use Modules\JobAssist\Entities\JobAssistReport;

class JobAssistAnalyticsService
{
    public function dashboard(int $companyId): array
    {
        $media = JobAssistMedia::forCompany($companyId);
        $recommendations = JobAssistRecommendation::forCompany($companyId);

        return [
            'photos_analyzed' => (clone $media)->whereIn('media_type', ['image','photo'])->count(),
            'videos_analyzed' => (clone $media)->where('media_type', 'video')->count(),
            'documents_analyzed' => (clone $media)->whereIn('media_type', ['pdf','document'])->count(),
            'processed_media' => (clone $media)->where('status', 'processed')->count(),
            'failed_media' => (clone $media)->where('status', 'failed')->count(),
            'average_confidence' => round((float) (clone $media)->whereNotNull('confidence_score')->avg('confidence_score'), 2),
            'open_recommendations' => (clone $recommendations)->whereIn('status', ['suggested','accepted'])->count(),
            'high_severity_items' => (clone $recommendations)->whereIn('severity', ['high','critical'])->count(),
            'reports_generated' => JobAssistReport::forCompany($companyId)->count(),
            'top_defects' => $this->topDefects($companyId),
            'vertical_mix' => $this->verticalMix($companyId),
        ];
    }

    protected function topDefects(int $companyId): array
    {
        return DB::table('jobassist_recommendations')
            ->select('type', DB::raw('count(*) as total'))
            ->where('company_id', $companyId)
            ->groupBy('type')
            ->orderByDesc('total')
            ->limit(8)
            ->get()
            ->map(fn ($row) => ['label' => $row->type, 'total' => (int) $row->total])
            ->all();
    }

    protected function verticalMix(int $companyId): array
    {
        return DB::table('jobassist_media')
            ->select(DB::raw('coalesce(vertical, "unknown") as vertical'), DB::raw('count(*) as total'))
            ->where('company_id', $companyId)
            ->whereNull('deleted_at')
            ->groupBy('vertical')
            ->orderByDesc('total')
            ->limit(10)
            ->get()
            ->map(fn ($row) => ['label' => $row->vertical, 'total' => (int) $row->total])
            ->all();
    }
}
