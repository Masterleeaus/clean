<?php

namespace Modules\JobAssist\Services;

use Modules\JobAssist\Support\JobAssistPermissions;

class JobAssistNavigationService
{
    public function items(): array
    {
        return [
            ['name' => 'Dashboard', 'route' => 'jobassist.dashboard', 'permission' => JobAssistPermissions::VIEW],
            ['name' => 'Live Camera', 'route' => 'jobassist.media.create', 'permission' => JobAssistPermissions::MANAGE_MEDIA],
            ['name' => 'Photos & Videos', 'route' => 'jobassist.media.index', 'permission' => JobAssistPermissions::VIEW],
            ['name' => 'Reports', 'route' => 'jobassist.reports.index', 'permission' => JobAssistPermissions::VIEW_REPORTS],
            ['name' => 'AI Assistant', 'route' => 'jobassist.assistant', 'permission' => JobAssistPermissions::VIEW],
            ['name' => 'Search', 'route' => 'jobassist.search.index', 'permission' => JobAssistPermissions::VIEW],
            ['name' => 'Analytics', 'route' => 'jobassist.analytics', 'permission' => JobAssistPermissions::VIEW],
            ['name' => 'Monitoring', 'route' => 'jobassist.monitoring.index', 'permission' => JobAssistPermissions::VIEW_ANALYTICS],
            ['name' => 'Settings', 'route' => 'jobassist.settings', 'permission' => JobAssistPermissions::MANAGE_SETTINGS],
        ];
    }
}
