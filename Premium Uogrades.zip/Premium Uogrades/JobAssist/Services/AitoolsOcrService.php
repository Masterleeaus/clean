<?php
namespace Modules\JobAssist\Services;
use Modules\JobAssist\Entities\JobAssistMedia;

class AitoolsOcrService
{
    public function __construct(protected AitoolsBridge $bridge) {}
    public function extract(JobAssistMedia $media): array
    {
        return $this->bridge->call(config('jobassist.aitools.ocr_method_candidates', []), [
            'task' => 'jobassist_ocr',
            'company_id' => $media->company_id,
            'media_id' => $media->id,
            'disk' => $media->disk,
            'path' => $media->path,
            'mime_type' => $media->mime_type,
        ], ['text' => null, 'blocks' => [], 'confidence' => null]);
    }
}
