<?php

namespace Modules\JobAssist\Services;

use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\URL;
use Modules\JobAssist\Entities\JobAssistMedia;

class SignedMediaUrlService
{
    public function temporaryUrl(JobAssistMedia $media, int $minutes = null): string
    {
        $minutes = $minutes ?: (int) config('jobassist.storage.signed_url_minutes', 30);
        $disk = Storage::disk($media->disk ?: config('jobassist.storage.disk', 'local'));

        if (method_exists($disk, 'temporaryUrl')) {
            try {
                return $disk->temporaryUrl($media->path, now()->addMinutes($minutes));
            } catch (\Throwable $e) {
                report($e);
            }
        }

        return URL::temporarySignedRoute('jobassist.media.signed-url', now()->addMinutes($minutes), ['media' => $media->id]);
    }
}
