<?php
namespace Modules\JobAssist\Services;

use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Entities\JobAssistSearchIndex;

class JobAssistSearchService
{
    public function indexMedia(JobAssistMedia $media, array $vision, array $ocr, array $recommendations): void
    {
        $labels = collect($vision['objects'] ?? [])->map(fn($o) => is_array($o) ? ($o['label'] ?? null) : (string)$o)->filter()->values()->all();
        $text = implode(' ', array_filter([
            $media->original_name,
            $media->vertical,
            implode(' ', $labels),
            $ocr['text'] ?? null,
            $recommendations['summary'] ?? null,
        ]));

        JobAssistSearchIndex::create([
            'company_id' => $media->company_id,
            'media_id' => $media->id,
            'index_type' => 'media_analysis',
            'object_label' => $labels[0] ?? null,
            'search_text' => $text,
            'metadata' => ['labels' => $labels, 'status' => $media->status],
        ]);
    }

    public function search(int $companyId, ?string $query = null, ?string $object = null)
    {
        return JobAssistSearchIndex::forCompany($companyId)
            ->when($object, fn($q) => $q->where('object_label', 'like', '%'.$object.'%'))
            ->when($query, fn($q) => $q->where('search_text', 'like', '%'.$query.'%'))
            ->latest()
            ->paginate(20);
    }
}
