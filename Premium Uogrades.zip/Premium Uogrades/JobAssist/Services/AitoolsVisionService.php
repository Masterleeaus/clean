<?php
namespace Modules\JobAssist\Services;

use Illuminate\Support\Facades\Storage;
use Modules\JobAssist\Entities\JobAssistMedia;

class AitoolsVisionService
{
    public function __construct(protected AitoolsBridge $bridge) {}

    public function analyze(JobAssistMedia $media): array
    {
        $payload = $this->basePayload($media) + [
            'task' => 'jobassist_vision_analysis',
            'prompt_version' => config('jobassist.aitools.prompt_version', 'jobassist-v1'),
            'instructions' => $this->visionInstructions($media->vertical),
        ];

        return $this->bridge->call(config('jobassist.aitools.vision_method_candidates', []), $payload, [
            'objects' => [],
            'confidence' => config('jobassist.analysis.fallback_confidence', 0.35),
            'summary' => 'Vision analysis queued/skipped until Aitools vision method is wired.',
        ]);
    }

    protected function basePayload(JobAssistMedia $media): array
    {
        return [
            'company_id' => $media->company_id,
            'user_id' => $media->created_by,
            'media_id' => $media->id,
            'media_type' => $media->media_type,
            'mime_type' => $media->mime_type,
            'disk' => $media->disk,
            'path' => $media->path,
            'exists' => Storage::disk($media->disk)->exists($media->path),
            'metadata' => $media->metadata ?: [],
        ];
    }

    protected function visionInstructions(?string $vertical): string
    {
        return match ($vertical) {
            'cleaning' => 'Inspect completion quality: floor, bins, mirrors, toilets, kitchen, dust, cobwebs, windows, stocked supplies, missing rooms, before/after evidence.',
            'electrical' => 'Identify switchboards, breakers, sockets, lighting, cable damage, missing covers, corrosion and labels. Never certify electrical safety.',
            'plumbing' => 'Identify leaks, pipes, fittings, drainage, valves, hot water systems, corrosion and water damage. Suggest likely causes and urgency.',
            'hvac' => 'Inspect filters, coils, condensers, rust, leaks, blockages and maintenance condition.',
            'pest_control' => 'Look for rodents, termites, droppings, nests, damage, mould and insects. Estimate visible severity.',
            'gardening' => 'Identify plants, weeds, disease, dead growth, irrigation issues and pruning opportunities.',
            'painting' => 'Detect missed areas, uneven coats, runs, peeling, preparation issues and coverage quality.',
            'property_inspection' => 'Generate inspection observations, issue severity, repair priority and evidence notes.',
            default => 'Analyze worksite media for objects, hazards, defects, OCR text, recommendations and confidence scoring.',
        };
    }
}
