<?php

namespace Modules\JobAssist\Services;

use Modules\JobAssist\Entities\JobAssistHealthEvent;

class JobAssistHealthService
{
    public function record(string $component, string $status, ?string $message = null, array $context = []): void
    {
        JobAssistHealthEvent::create([
            'company_id' => $context['company_id'] ?? optional(company())->id,
            'component' => $component,
            'status' => $status,
            'message' => $message,
            'context' => $context,
        ]);
    }

    public function snapshot(): array
    {
        $components = ['media', 'vision', 'ocr', 'retrieval', 'reasoning', 'reports', 'voice', 'search'];
        $items = [];

        foreach ($components as $component) {
            $latest = JobAssistHealthEvent::where('component', $component)->latest()->first();
            $items[$component] = [
                'status' => $latest->status ?? 'unknown',
                'message' => $latest->message ?? 'No recent health event recorded.',
                'checked_at' => optional($latest)->created_at,
            ];
        }

        return $items;
    }
}
