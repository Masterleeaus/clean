<?php

namespace Modules\JobAssist\Services;

use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Jobs\ProcessJobAssistMedia;
use Modules\JobAssist\Support\JobAssistPermissions;

class JobAssistMediaService
{
    public function __construct(
        protected WorkSuiteContext $context,
        protected JobAssistAuthorizationService $auth
    ) {}

    public function store(UploadedFile $file, array $data): JobAssistMedia
    {
        $this->auth->ensure(JobAssistPermissions::MANAGE_MEDIA);

        $companyId = $this->context->companyId();
        $disk = config('jobassist.storage.disk', 'local');
        $directory = 'jobassist/company-' . $companyId . '/' . now()->format('Y/m');
        $path = $file->store($directory, $disk);

        $media = JobAssistMedia::create([
            'company_id' => $companyId,
            'created_by' => $this->context->userId(),
            'source_type' => $data['source_type'] ?? 'upload',
            'vertical' => $data['vertical'] ?? 'general',
            'related_type' => $data['related_type'] ?? null,
            'related_id' => $data['related_id'] ?? null,
            'disk' => $disk,
            'path' => $path,
            'original_filename' => $file->getClientOriginalName(),
            'mime_type' => $file->getMimeType(),
            'size_bytes' => $file->getSize(),
            'status' => 'queued',
            'metadata' => [
                'ip' => request()?->ip(),
                'user_agent' => request()?->userAgent(),
            ],
        ]);

        ProcessJobAssistMedia::dispatch($media->id)->onQueue(config('jobassist.queues.vision', 'default'));

        return $media;
    }

    public function assertCompanyAccess(JobAssistMedia $media): void
    {
        $this->auth->ensureMediaAccess($media, $this->context->companyId());
    }

    public function delete(JobAssistMedia $media): void
    {
        $this->auth->ensure(JobAssistPermissions::MANAGE_MEDIA);
        $this->assertCompanyAccess($media);
        Storage::disk($media->disk ?: config('jobassist.storage.disk', 'local'))->delete($media->path);
        $media->delete();
    }
}
