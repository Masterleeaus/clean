<?php
namespace Modules\JobAssist\Services;
class WorkSuiteContext { public function companyId(): int { if (function_exists('company') && company()) return (int) company()->id; if (function_exists('user') && user()) return (int) (user()->company_id ?? 0); return (int) (auth()->user()->company_id ?? 0); } public function userId(): ?int { if (function_exists('user') && user()) return (int) user()->id; return auth()->id(); } }
