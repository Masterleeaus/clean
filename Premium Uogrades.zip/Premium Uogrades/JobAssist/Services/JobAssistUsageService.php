<?php

namespace Modules\JobAssist\Services;

use Illuminate\Support\Facades\Cache;
use Modules\JobAssist\Entities\JobAssistUsageEvent;

class JobAssistUsageService
{
    public function record(string $eventType, array $meta = [], int $units = 1, ?float $estimatedCost = null): JobAssistUsageEvent
    {
        $context = app(WorkSuiteContext::class);

        return JobAssistUsageEvent::create([
            'company_id' => $context->companyId(),
            'user_id' => $context->userId(),
            'event_type' => $eventType,
            'provider' => $meta['provider'] ?? 'aitools',
            'model' => $meta['model'] ?? null,
            'units' => $units,
            'estimated_cost' => $estimatedCost ?? (float)($meta['estimated_cost'] ?? 0),
            'metadata' => $meta,
        ]);
    }

    public function checkLimit(string $bucket, int $max, int $decaySeconds = 60): bool
    {
        $context = app(WorkSuiteContext::class);
        $key = 'jobassist:limit:' . $context->companyId() . ':' . $bucket . ':' . now()->format('YmdHi');
        $count = Cache::increment($key);
        Cache::put($key, $count, $decaySeconds);

        return $count <= $max;
    }

    public function monthlySummary(?int $companyId = null): array
    {
        $companyId = $companyId ?: app(WorkSuiteContext::class)->companyId();
        $start = now()->startOfMonth();

        $query = JobAssistUsageEvent::where('company_id', $companyId)->where('created_at', '>=', $start);

        return [
            'events' => (clone $query)->count(),
            'units' => (clone $query)->sum('units'),
            'estimated_cost' => round((float)(clone $query)->sum('estimated_cost'), 4),
            'by_type' => (clone $query)->selectRaw('event_type, count(*) as total, sum(units) as units')
                ->groupBy('event_type')->orderByDesc('total')->get(),
        ];
    }
}
