<?php
namespace Modules\JobAssist\Services;

use Illuminate\Support\Facades\App;
use Illuminate\Support\Facades\Log;

class AitoolsBridge
{
    public function available(): bool
    {
        return class_exists('Modules\Aitools\Providers\AitoolsServiceProvider')
            || App::bound('aitools')
            || App::bound('ai-tools')
            || App::bound('Modules\Aitools\Services\AitoolsService');
    }

    public function call(array $methodCandidates, array $payload, array $fallback = []): array
    {
        $services = $this->candidateServices();
        foreach ($services as $service) {
            if (!$service) continue;
            foreach ($methodCandidates as $method) {
                if (is_object($service) && method_exists($service, $method)) {
                    try {
                        $result = $service->{$method}($payload);
                        return is_array($result) ? $result : ['raw' => $result, 'status' => 'completed'];
                    } catch (\Throwable $e) {
                        Log::warning('JobAssist Aitools bridge call failed', ['method' => $method, 'error' => $e->getMessage()]);
                    }
                }
            }
        }

        return $fallback + ['status' => 'skipped', 'reason' => 'Aitools runtime not available or compatible method not found'];
    }

    public function reason(array $payload): array
    {
        return $this->call(config('jobassist.aitools.reasoning_method_candidates', []), $payload, [
            'answer' => 'Aitools reasoning runtime is not available yet. Image context and retrieval context were captured for later processing.',
            'confidence_score' => null,
            'status' => 'skipped',
        ]);
    }

    protected function candidateServices(): array
    {
        $keys = ['aitools', 'ai-tools', 'Modules\Aitools\Services\AitoolsService', 'Modules\Aitools\Services\AiService'];
        $services = [];
        foreach ($keys as $key) {
            try { if (App::bound($key)) $services[] = App::make($key); } catch (\Throwable $e) {}
        }
        return $services;
    }
}
