<?php

namespace Modules\JobAssist\Services;

use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Entities\JobAssistRetentionRun;

class JobAssistRetentionService
{
    public function run(?int $companyId = null, ?int $days = null): JobAssistRetentionRun
    {
        $days = $days ?: (int) config('jobassist.retention.media_days', 365);
        $cutoff = now()->subDays($days);

        $query = JobAssistMedia::where('created_at', '<', $cutoff);
        if ($companyId) {
            $query->where('company_id', $companyId);
        }

        $count = (clone $query)->count();

        // Soft delete if model supports it; otherwise this is still constrained by age and company.
        (clone $query)->delete();

        return JobAssistRetentionRun::create([
            'company_id' => $companyId,
            'media_deleted' => $count,
            'metadata' => [
                'days' => $days,
                'cutoff' => $cutoff->toDateTimeString(),
            ],
        ]);
    }
}
