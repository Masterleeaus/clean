<?php
namespace Modules\JobAssist\Services;

class DomainRecommendationService
{
    public function build(?string $vertical, array $vision, array $ocr, array $knowledge): array
    {
        $objects = $vision['objects'] ?? [];
        $summary = $vision['summary'] ?? ($vision['description'] ?? 'Visual analysis completed.');
        $confidence = $vision['confidence'] ?? config('jobassist.analysis.fallback_confidence', 0.35);

        $base = [
            'summary' => $summary,
            'confidence' => $confidence,
            'knowledge_used' => !empty($knowledge['documents']),
            'ocr_text_present' => !empty($ocr['text']),
            'recommendations' => [],
            'checklist_updates' => [],
            'disclaimers' => [],
        ];

        return match ($vertical) {
            'cleaning' => $this->cleaning($base, $objects),
            'electrical' => $this->electrical($base),
            'plumbing' => $this->genericTrade($base, 'Check visible leak source, isolate water if active, document damage, and confirm required replacement parts.'),
            'hvac' => $this->genericTrade($base, 'Inspect filters/coils/condensers and schedule maintenance for blockage, rust, leaks or reduced airflow.'),
            'pest_control' => $this->genericTrade($base, 'Confirm pest evidence, estimate visible severity, document entry points and recommend treatment path.'),
            'painting' => $this->genericTrade($base, 'Review coverage, preparation quality, missed areas, runs, peeling and required touch-ups.'),
            'gardening' => $this->genericTrade($base, 'Assess plant health, weeds, disease, irrigation and pruning opportunities.'),
            default => $this->genericTrade($base, 'Review visual evidence, confirm issue severity, document work completed and request manager review if confidence is low.'),
        };
    }

    protected function cleaning(array $base, array $objects): array
    {
        $base['recommendations'][] = ['type' => 'quality', 'title' => 'Cleaning QA review', 'action' => 'Compare visible areas against checklist and request reclean for low-confidence or incomplete items.'];
        $base['checklist_updates'] = ['floor_cleaned' => null, 'bins_emptied' => null, 'mirrors_streak_free' => null, 'toilets_cleaned' => null, 'supplies_stocked' => null];
        return $base;
    }

    protected function electrical(array $base): array
    {
        $base = $this->genericTrade($base, 'Document visible hazards and recommend licensed electrician inspection where covers, corrosion, damaged cables or switchboard issues are visible.');
        $base['disclaimers'][] = config('jobassist.analysis.electrical_disclaimer');
        return $base;
    }

    protected function genericTrade(array $base, string $action): array
    {
        $base['recommendations'][] = ['type' => 'field_assistance', 'title' => 'Recommended next action', 'action' => $action];
        return $base;
    }
}
