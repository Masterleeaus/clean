<?php

namespace Modules\JobAssist\Services;

use Illuminate\Database\Eloquent\Model;
use Modules\JobAssist\Entities\JobAssistAuditLog;

class JobAssistAuditService
{
    public function log(string $event, ?int $companyId, ?Model $auditable = null, array $metadata = []): void
    {
        try {
            JobAssistAuditLog::create([
                'company_id' => $companyId,
                'user_id' => auth()->id(),
                'event' => $event,
                'auditable_type' => $auditable ? get_class($auditable) : null,
                'auditable_id' => $auditable?->getKey(),
                'metadata' => $metadata,
                'ip_address' => request()?->ip(),
            ]);
        } catch (\Throwable $e) {
            report($e);
        }
    }
}
