<?php
namespace Modules\JobAssist\Services;

use Illuminate\Support\Facades\DB;

class JobAssistSettingsService
{
    public function all(int $companyId): array
    {
        $rows = DB::table('jobassist_settings')->where('company_id', $companyId)->pluck('value', 'key')->all();
        return [
            'auto_process_uploads' => $this->bool($rows['auto_process_uploads'] ?? true),
            'customer_reports_enabled' => $this->bool($rows['customer_reports_enabled'] ?? true),
            'minimum_confidence' => (float) ($rows['minimum_confidence'] ?? config('jobassist.ai.minimum_confidence', 0.55)),
            'media_retention_days' => (int) ($rows['media_retention_days'] ?? 365),
            'voice_enabled' => $this->bool($rows['voice_enabled'] ?? true),
        ];
    }

    public function save(int $companyId, array $values): void
    {
        foreach ($values as $key => $value) {
            DB::table('jobassist_settings')->updateOrInsert(
                ['company_id' => $companyId, 'key' => $key],
                ['value' => is_bool($value) ? ($value ? '1' : '0') : (string) $value, 'updated_at' => now(), 'created_at' => now()]
            );
        }
    }

    protected function bool(mixed $value): bool
    {
        return filter_var($value, FILTER_VALIDATE_BOOLEAN);
    }
}
