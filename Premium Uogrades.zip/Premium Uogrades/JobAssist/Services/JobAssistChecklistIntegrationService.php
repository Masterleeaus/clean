<?php
namespace Modules\JobAssist\Services;

use Modules\JobAssist\Entities\JobAssistChecklistUpdate;
use Modules\JobAssist\Entities\JobAssistMedia;

class JobAssistChecklistIntegrationService
{
    public function sync(JobAssistMedia $media, array $recommendations): array
    {
        $targets = $this->availableTargets();
        $updates = $recommendations['checklist_updates'] ?? $this->inferChecklistUpdates($media, $recommendations);
        $created = [];

        foreach ($targets as $target) {
            foreach ($updates as $update) {
                $created[] = JobAssistChecklistUpdate::create([
                    'company_id' => $media->company_id,
                    'media_id' => $media->id,
                    'inspection_id' => null,
                    'target_module' => $target,
                    'target_type' => $media->related_type,
                    'target_id' => $media->related_id,
                    'task_key' => $update['task_key'] ?? $update['label'] ?? null,
                    'status' => $update['status'] ?? 'suggested',
                    'completion_score' => $update['completion_score'] ?? null,
                    'confidence_score' => $update['confidence_score'] ?? ($recommendations['confidence'] ?? null),
                    'evidence' => ['media_id' => $media->id, 'path' => $media->path],
                    'payload' => $update,
                    'notes' => $update['notes'] ?? null,
                ])->id;
            }
        }

        return [
            'synced' => !empty($created),
            'targets' => $targets,
            'checklist_updates' => $updates,
            'created_update_ids' => $created,
        ];
    }

    protected function availableTargets(): array
    {
        $targets = [];
        foreach (['Booking', 'TitanGoField', 'CleanQuality', 'Complaint'] as $module) {
            if (!function_exists('module_enabled') || module_enabled($module)) {
                $targets[] = $module;
            }
        }
        return $targets;
    }

    protected function inferChecklistUpdates(JobAssistMedia $media, array $recommendations): array
    {
        return collect($recommendations['recommendations'] ?? [])->map(function ($item) {
            return [
                'task_key' => $item['type'] ?? 'visual_review',
                'label' => $item['title'] ?? 'Visual review',
                'status' => in_array(($item['severity'] ?? ''), ['high', 'critical']) ? 'manager_review_required' : 'suggested',
                'completion_score' => $item['completion_score'] ?? null,
                'confidence_score' => $item['confidence_score'] ?? null,
                'notes' => $item['description'] ?? ($item['action'] ?? null),
            ];
        })->values()->all();
    }
}
