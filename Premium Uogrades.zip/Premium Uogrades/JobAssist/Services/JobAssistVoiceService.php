<?php
namespace Modules\JobAssist\Services;

use Illuminate\Support\Str;
use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Entities\JobAssistVoiceSession;

class JobAssistVoiceService
{
    public function __construct(
        protected AitoolsBridge $aitools,
        protected AitoolsKnowledgeService $knowledgeService,
        protected JobAssistAgentRouter $router
    ) {}

    public function ask(int $companyId, ?int $userId, JobAssistMedia $media, string $question): JobAssistVoiceSession
    {
        $imageContext = [
            'media_id' => $media->id,
            'vertical' => $media->vertical,
            'detected_objects' => $media->detected_objects ?: [],
            'analysis_summary' => $media->analysis_summary ?: [],
            'confidence_score' => $media->confidence_score,
        ];

        $retrieval = $this->knowledgeService->retrieveForMedia($media, $question);
        $agentKey = $this->router->resolve($media->vertical ?: 'general');

        $answer = $this->aitools->reason([
            'agent' => $agentKey,
            'task' => 'voice_field_assistant_answer',
            'question' => $question,
            'image_context' => $imageContext,
            'retrieval_context' => $retrieval,
            'guardrails' => [
                'do_not_certify_electrical_safety' => true,
                'state_uncertainty_when_confidence_low' => true,
                'recommend_professional_inspection_when_needed' => true,
            ],
        ]);

        return JobAssistVoiceSession::create([
            'company_id' => $companyId,
            'user_id' => $userId,
            'media_id' => $media->id,
            'session_key' => (string) Str::uuid(),
            'question' => $question,
            'answer' => is_array($answer) ? ($answer['answer'] ?? json_encode($answer)) : (string) $answer,
            'image_context' => $imageContext,
            'retrieval_context' => $retrieval,
            'confidence_score' => is_array($answer) ? ($answer['confidence_score'] ?? null) : null,
            'status' => 'completed',
        ]);
    }
}
