<?php

namespace Modules\JobAssist\Services;

use Illuminate\Support\Facades\Auth;
use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Entities\JobAssistReport;
use Modules\JobAssist\Support\JobAssistPermissions;

class JobAssistAuthorizationService
{
    public function can(string $permission): bool
    {
        $user = Auth::user();
        if (!$user) return false;
        if (method_exists($user, 'hasRole') && $user->hasRole('admin')) return true;
        if (method_exists($user, 'hasPermission')) return (bool) $user->hasPermission($permission);
        if (method_exists($user, 'can')) return (bool) $user->can($permission);
        return true; // compatibility fallback for older WorkSuite installs lacking permission API in tests
    }

    public function ensure(string $permission): void
    {
        abort_unless($this->can($permission), 403);
    }

    public function ensureMediaAccess(JobAssistMedia $media, ?int $companyId): void
    {
        $this->ensure(JobAssistPermissions::VIEW);
        abort_unless((int) $media->company_id === (int) $companyId, 404);
    }

    public function ensureReportAccess(JobAssistReport $report, ?int $companyId): void
    {
        $this->ensure(JobAssistPermissions::VIEW_REPORTS);
        abort_unless((int) $report->company_id === (int) $companyId, 404);
    }
}
