<?php
namespace Modules\JobAssist\Services;
use Modules\JobAssist\Entities\JobAssistMedia;

class AitoolsKnowledgeService
{
    public function __construct(protected AitoolsBridge $bridge) {}
    public function retrieve(JobAssistMedia $media, array $vision = [], array $ocr = []): array
    {
        return $this->bridge->call(config('jobassist.aitools.retrieval_method_candidates', []), [
            'task' => 'jobassist_knowledge_retrieval',
            'company_id' => $media->company_id,
            'vertical' => $media->vertical,
            'job_ref' => $media->job_ref,
            'query' => $this->buildQuery($media, $vision, $ocr),
            'sources' => ['company_sop','training_manual','equipment_manual','safety_procedure','manufacturer_guide','industry_standard','customer_history','previous_jobs'],
        ], ['documents' => [], 'summary' => null]);
    }
    public function retrieveForMedia(JobAssistMedia $media, ?string $question = null): array
    {
        return $this->bridge->call(config('jobassist.aitools.retrieval_method_candidates', []), [
            'task' => 'jobassist_contextual_question_retrieval',
            'company_id' => $media->company_id,
            'vertical' => $media->vertical,
            'job_ref' => $media->job_ref,
            'query' => trim(($question ?: '').' '.json_encode($media->analysis_summary ?: []).' '.json_encode($media->detected_objects ?: [])),
            'sources' => ['company_sop','training_manual','equipment_manual','safety_procedure','manufacturer_guide','industry_standard','customer_history','previous_jobs'],
        ], ['documents' => [], 'summary' => null]);
    }

    protected function buildQuery(JobAssistMedia $media, array $vision, array $ocr): string
    {
        $objects = implode(', ', array_filter(array_map(fn($o) => is_array($o) ? ($o['label'] ?? '') : (string)$o, $vision['objects'] ?? [])));
        return trim(($media->vertical ?: 'general').' '.$objects.' '.($ocr['text'] ?? ''));
    }
}
