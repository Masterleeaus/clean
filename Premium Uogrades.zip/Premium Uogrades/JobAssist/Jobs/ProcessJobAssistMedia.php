<?php
namespace Modules\JobAssist\Jobs;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Entities\JobAssistMediaAnalysis;
use Modules\JobAssist\Entities\JobAssistDetection;
use Modules\JobAssist\Entities\JobAssistOcrResult;
use Modules\JobAssist\Entities\JobAssistRecommendation;
use Modules\JobAssist\Services\AitoolsKnowledgeService;
use Modules\JobAssist\Services\AitoolsOcrService;
use Modules\JobAssist\Services\AitoolsVisionService;
use Modules\JobAssist\Services\DomainRecommendationService;
use Modules\JobAssist\Services\JobAssistAgentRouter;
use Modules\JobAssist\Services\JobAssistChecklistIntegrationService;
use Modules\JobAssist\Services\JobAssistReportService;
use Modules\JobAssist\Services\JobAssistSearchService;
use Modules\JobAssist\Services\JobAssistUsageService;
use Modules\JobAssist\Services\JobAssistHealthService;

class ProcessJobAssistMedia implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public function __construct(public int $mediaId) {}

    public function handle(
        AitoolsVisionService $vision,
        AitoolsOcrService $ocr,
        AitoolsKnowledgeService $knowledge,
        DomainRecommendationService $domain,
        JobAssistAgentRouter $router,
        JobAssistReportService $reports,
        JobAssistSearchService $search,
        JobAssistChecklistIntegrationService $checklists,
        JobAssistUsageService $usage,
        JobAssistHealthService $health
    ): void {
        $media = JobAssistMedia::find($this->mediaId);
        if (!$media) return;

        $media->update(['status' => 'processing']);
        $usage->record('media_processing_started', ['media_id' => $media->id, 'vertical' => $media->vertical]);

        try {
            $visionResult = $vision->analyze($media);
            $usage->record('vision_analysis', ['media_id' => $media->id, 'model' => $visionResult['model'] ?? null]);
            $health->record('vision', 'ok', 'Vision analysis completed.', ['media_id' => $media->id, 'company_id' => $media->company_id]);
            $ocrResult = $ocr->extract($media);
            $usage->record('ocr_analysis', ['media_id' => $media->id, 'model' => $ocrResult['model'] ?? null]);
            $health->record('ocr', 'ok', 'OCR analysis completed.', ['media_id' => $media->id, 'company_id' => $media->company_id]);
            $retrievalContext = $knowledge->retrieve($media, $visionResult, $ocrResult);
            $usage->record('knowledge_retrieval', ['media_id' => $media->id]);
            $recommendations = $domain->build($media->vertical, $visionResult, $ocrResult, $retrievalContext);
            $agent = $router->route($media->vertical, $visionResult + $recommendations);
            $checklistResult = $checklists->sync($media, $recommendations);

            $analysis = JobAssistMediaAnalysis::create([
                'company_id' => $media->company_id,
                'media_id' => $media->id,
                'analysis_type' => 'vision_ocr_retrieval_reasoning',
                'agent_key' => $agent,
                'model_key' => $visionResult['model'] ?? null,
                'prompt_version' => config('jobassist.ai.prompt_version', 'jobassist-v1'),
                'vision_result' => $visionResult,
                'ocr_result' => $ocrResult,
                'retrieval_context' => $retrievalContext,
                'recommendations' => $recommendations + ['checklist_sync' => $checklistResult],
                'confidence_score' => $recommendations['confidence'] ?? ($visionResult['confidence'] ?? null),
                'status' => (($visionResult['status'] ?? null) === 'skipped') ? 'skipped' : 'completed',
            ]);

            foreach (($visionResult['objects'] ?? []) as $object) {
                $label = is_array($object) ? ($object['label'] ?? null) : (string) $object;
                if (!$label) continue;
                JobAssistDetection::create([
                    'company_id' => $media->company_id,
                    'media_id' => $media->id,
                    'label' => $label,
                    'category' => is_array($object) ? ($object['category'] ?? null) : null,
                    'confidence_score' => is_array($object) ? ($object['confidence'] ?? null) : null,
                    'bounding_box' => is_array($object) ? ($object['box'] ?? null) : null,
                    'metadata' => is_array($object) ? $object : [],
                ]);
            }

            if (!empty($ocrResult['text']) || !empty($ocrResult['blocks'])) {
                JobAssistOcrResult::create([
                    'company_id' => $media->company_id,
                    'media_id' => $media->id,
                    'text' => $ocrResult['text'] ?? null,
                    'language' => $ocrResult['language'] ?? null,
                    'confidence_score' => $ocrResult['confidence'] ?? null,
                    'blocks' => $ocrResult['blocks'] ?? [],
                    'metadata' => $ocrResult,
                ]);
            }

            foreach (($recommendations['recommendations'] ?? []) as $item) {
                JobAssistRecommendation::create([
                    'company_id' => $media->company_id,
                    'media_id' => $media->id,
                    'vertical' => $media->vertical,
                    'type' => $item['type'] ?? 'general',
                    'severity' => $item['severity'] ?? null,
                    'title' => $item['title'] ?? 'Recommendation',
                    'description' => $item['action'] ?? ($item['description'] ?? null),
                    'actions' => $item,
                    'confidence_score' => $recommendations['confidence'] ?? null,
                ]);
            }

            $reports->createDraftForMedia($media, $recommendations);
            $search->indexMedia($media, $visionResult, $ocrResult, $recommendations);

            $usage->record('media_processing_completed', ['media_id' => $media->id, 'vertical' => $media->vertical]);
            $health->record('media', 'ok', 'Media processing completed.', ['media_id' => $media->id, 'company_id' => $media->company_id]);

            $media->update([
                'status' => 'processed',
                'analysis_summary' => $recommendations + ['analysis_id' => $analysis->id],
                'detected_objects' => $visionResult['objects'] ?? [],
                'confidence_score' => $recommendations['confidence'] ?? ($visionResult['confidence'] ?? null),
                'processed_at' => now(),
            ]);
        } catch (\Throwable $e) {
            $health->record('media', 'failed', $e->getMessage(), ['media_id' => $media->id, 'company_id' => $media->company_id]);
            $media->update(['status' => 'failed', 'analysis_summary' => ['error' => $e->getMessage()]]);
            throw $e;
        }
    }
}
