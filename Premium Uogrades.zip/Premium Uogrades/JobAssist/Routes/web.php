<?php

use Illuminate\Support\Facades\Route;
use Modules\JobAssist\Http\Controllers\JobAssistController;
use Modules\JobAssist\Http\Controllers\JobAssistMediaController;
use Modules\JobAssist\Http\Controllers\JobAssistReportController;
use Modules\JobAssist\Http\Controllers\JobAssistSearchController;
use Modules\JobAssist\Http\Controllers\JobAssistSettingsController;
use Modules\JobAssist\Http\Controllers\JobAssistVoiceController;
use Modules\JobAssist\Http\Controllers\JobAssistMonitoringController;

Route::group(['middleware' => ['web', 'auth'], 'prefix' => 'account/job-assist', 'as' => 'jobassist.'], function () {
    Route::get('/', [JobAssistController::class, 'index'])->name('dashboard');
    Route::get('/assistant', [JobAssistController::class, 'assistant'])->name('assistant');
    Route::get('/analytics', [JobAssistController::class, 'analytics'])->name('analytics');
    Route::get('/settings', [JobAssistController::class, 'settings'])->name('settings');
    Route::post('/settings', [JobAssistSettingsController::class, 'update'])->name('settings.update');

    Route::get('/monitoring', [JobAssistMonitoringController::class, 'index'])->name('monitoring.index');
    Route::get('/monitoring/health', [JobAssistMonitoringController::class, 'health'])->name('monitoring.health');

    Route::get('/search', [JobAssistSearchController::class, 'index'])->name('search.index');

    Route::get('/reports', [JobAssistReportController::class, 'index'])->name('reports.index');
    Route::post('/reports/generate/{media}', [JobAssistReportController::class, 'generate'])->name('reports.generate');
    Route::get('/reports/{report}', [JobAssistReportController::class, 'show'])->name('reports.show');
    Route::get('/reports/{report}/pdf', [JobAssistReportController::class, 'pdf'])->name('reports.pdf');

    Route::post('/media/{media}/voice/ask', [JobAssistVoiceController::class, 'ask'])->name('media.voice.ask');
    Route::get('/media/{media}/signed-url', [JobAssistMediaController::class, 'signedUrl'])->name('media.signed-url');
    Route::resource('media', JobAssistMediaController::class)->only(['index','create','store','show','destroy']);
});
