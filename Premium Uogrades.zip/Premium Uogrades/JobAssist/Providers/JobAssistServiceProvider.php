<?php

namespace Modules\JobAssist\Providers;

use Illuminate\Support\ServiceProvider;
use Modules\JobAssist\Services\AitoolsBridge;
use Modules\JobAssist\Services\JobAssistNavigationService;
use Modules\JobAssist\Console\Commands\RunJobAssistRetention;

class JobAssistServiceProvider extends ServiceProvider
{
    protected string $moduleName = 'JobAssist';
    protected string $moduleNameLower = 'jobassist';

    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__ . '/../Config/config.php', $this->moduleNameLower);
        $this->app->singleton(AitoolsBridge::class);
        $this->app->singleton(JobAssistNavigationService::class);
    }

    public function boot(): void
    {
        $this->registerTranslations();
        $this->registerViews();
        $this->loadMigrationsFrom(module_path($this->moduleName, 'Database/Migrations'));
        $this->registerViewComposers();

        if ($this->app->runningInConsole()) {
            $this->commands([RunJobAssistRetention::class]);
        }
    }

    protected function registerTranslations(): void
    {
        $langPath = resource_path('lang/modules/' . $this->moduleNameLower);
        $this->loadTranslationsFrom(is_dir($langPath) ? $langPath : __DIR__ . '/../Resources/lang', $this->moduleNameLower);
    }

    protected function registerViews(): void
    {
        $this->loadViewsFrom(__DIR__ . '/../Resources/views', $this->moduleNameLower);
    }

    protected function registerViewComposers(): void
    {
        view()->composer('jobassist::*', function ($view) {
            $view->with('jobAssistNavItems', app(JobAssistNavigationService::class)->items());
        });
    }
}
