<?php

return [
    'name' => 'JobAssist',
    'description' => 'AI-powered field assistant and visual intelligence engine for WorkSuite.',

    'storage' => [
        'disk' => env('JOBASSIST_STORAGE_DISK', 'local'),
        'signed_url_minutes' => env('JOBASSIST_SIGNED_URL_MINUTES', 30),
        'max_upload_mb' => env('JOBASSIST_MAX_UPLOAD_MB', 50),
        'allowed_mimes' => [
            'image/jpeg','image/png','image/webp','image/heic','image/heif',
            'video/mp4','video/quicktime','application/pdf',
            'image/tiff','text/plain',
        ],
    ],

    'queues' => [
        'vision' => env('JOBASSIST_VISION_QUEUE', 'default'),
        'ocr' => env('JOBASSIST_OCR_QUEUE', 'default'),
        'reports' => env('JOBASSIST_REPORT_QUEUE', 'default'),
        'embeddings' => env('JOBASSIST_EMBEDDING_QUEUE', 'default'),
    ],

    'security' => [
        'rate_limit_uploads_per_minute' => env('JOBASSIST_UPLOAD_RATE_LIMIT', 20),
        'malware_scan_enabled' => env('JOBASSIST_MALWARE_SCAN', false),
        'log_ai_payloads' => env('JOBASSIST_LOG_AI_PAYLOADS', false),
        'uploads_per_hour' => env('JOBASSIST_UPLOADS_PER_HOUR', 200),
        'ai_requests_per_hour' => env('JOBASSIST_AI_REQUESTS_PER_HOUR', 500),
    ],

    'integrations' => [
        'aitools_module' => 'Aitools',
        'booking_module' => 'Booking',
        'fieldops_module' => 'TitanGoField',
        'cleanquality_module' => 'CleanQuality',
        'complaint_module' => 'Complaint',
        'voice_module' => 'TitanEchoVoice',
    ],

    'ai' => [
        'prompt_version' => 'jobassist-v1',
        'minimum_confidence' => 0.55,
        'fallback_to_text_reasoning' => true,
        'monthly_cost_limit' => env('JOBASSIST_MONTHLY_COST_LIMIT', 0),
    ],

    'aitools' => [
        'vision_method_candidates' => ['analyzeVision', 'vision', 'analyzeImage', 'processVision'],
        'ocr_method_candidates' => ['ocr', 'extractText', 'analyzeDocument', 'processOcr'],
        'retrieval_method_candidates' => ['retrieveKnowledge', 'knowledgeSearch', 'searchKnowledge', 'retrieve'],
        'reasoning_method_candidates' => ['reason', 'askAgent', 'runAgent', 'chat'],
        'embedding_method_candidates' => ['embed', 'createEmbedding', 'generateEmbedding'],
    ],

    'retention' => [
        'media_days' => env('JOBASSIST_RETENTION_MEDIA_DAYS', 365),
        'analysis_days' => env('JOBASSIST_RETENTION_ANALYSIS_DAYS', 365),
        'report_days' => env('JOBASSIST_RETENTION_REPORT_DAYS', 730),
    ],
];
