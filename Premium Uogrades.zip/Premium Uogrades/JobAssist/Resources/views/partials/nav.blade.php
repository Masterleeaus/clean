<div class="card mb-3">
    <div class="card-body py-2">
        <strong>Job Assist</strong>
        <div class="mt-2 d-flex flex-wrap gap-2">
            @foreach($jobAssistNavItems ?? [] as $item)
                <a class="btn btn-sm btn-outline-secondary" href="{{ route($item['route']) }}">{{ $item['name'] }}</a>
            @endforeach
        </div>
    </div>
</div>
