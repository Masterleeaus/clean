@extends('layouts.app')
@section('content')
<div class="container-fluid">
    @include('jobassist::partials.nav')
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>{{ $media->original_name }}</h3>
        <form method="POST" action="{{ route('jobassist.reports.generate', $media->id) }}">
            @csrf
            <button class="btn btn-primary">Generate customer report</button>
        </form>
    </div>

    <div class="row">
        <div class="col-md-5">
            <div class="card"><div class="card-body">
                <h5>Secure media preview</h5>
                @if(str_starts_with($media->mime_type ?? '', 'image/'))
                    <img src="{{ $signedUrl }}" class="img-fluid rounded border" alt="JobAssist media">
                @else
                    <a class="btn btn-outline-primary" href="{{ $signedUrl }}" target="_blank">Open secured media</a>
                @endif
                <hr>
                <p><strong>Status:</strong> {{ $media->status }}</p>
                <p><strong>Vertical:</strong> {{ $media->vertical }}</p>
                <p><strong>MIME:</strong> {{ $media->mime_type }}</p>
            </div></div>

            <div class="card mt-3"><div class="card-body">
                <h5>Ask with image context</h5>
                <form method="POST" action="{{ route('jobassist.media.voice.ask', $media->id) }}">
                    @csrf
                    <div class="form-group">
                        <input name="question" class="form-control" placeholder="What is this part? Did I miss anything? What tool do I need?">
                    </div>
                    <button class="btn btn-secondary">Ask JobAssist</button>
                </form>
                <p class="text-muted small mt-2 mb-0">Responses must use captured media context and cannot certify regulated trade safety.</p>
            </div></div>
        </div>
        <div class="col-md-7">
            <div class="card mb-3"><div class="card-body">
                <h5>Detections</h5>
                @forelse($media->detections as $d)
                    <span class="badge bg-secondary me-1">{{ $d->label }} {{ $d->confidence_score ? '(' . round($d->confidence_score * 100) . '%)' : '' }}</span>
                @empty <p class="text-muted">No detections yet.</p> @endforelse
            </div></div>
            <div class="card mb-3"><div class="card-body">
                <h5>OCR</h5>
                @forelse($media->ocrResults as $o)<pre class="small bg-light p-2">{{ $o->text }}</pre>@empty <p class="text-muted">No OCR yet.</p> @endforelse
            </div></div>
            <div class="card"><div class="card-body">
                <h5>Recommendations</h5>
                @forelse($media->recommendations as $r)
                    <div class="border-bottom py-2"><strong>{{ $r->title }}</strong><br><span class="text-muted">{{ $r->description }}</span></div>
                @empty <p class="text-muted">No recommendations yet.</p> @endforelse
            </div></div>
        </div>
    </div>
</div>
@endsection
