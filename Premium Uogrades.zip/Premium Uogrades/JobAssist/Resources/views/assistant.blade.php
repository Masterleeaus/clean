@extends('layouts.app')
@section('content')
@include('jobassist::partials.nav')
<div class="content-wrapper">
    <div class="card"><div class="card-body">
        <h4>JobAssist AI Assistant</h4>
        <p class="text-muted">Single assistant interface. Specialist routing remains internal across cleaning, repair, electrical, plumbing, HVAC, pest, painting, property, documentation, and insurance workflows.</p>
        <div class="alert alert-info mb-0">Voice/image-context questions are available from each media detail page once media has been uploaded.</div>
    </div></div>
</div>
@endsection
