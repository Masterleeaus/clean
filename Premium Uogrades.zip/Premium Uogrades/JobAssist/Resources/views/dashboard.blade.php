@extends('layouts.app')
@section('content')
@include('jobassist::partials.nav')
<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">@lang('jobassist::jobassist.dashboard')</h4>
        <a href="{{ route('jobassist.media.create') }}" class="btn btn-primary btn-sm">@lang('jobassist::jobassist.upload_media')</a>
    </div>
    <div class="row">
        <div class="col-md-3"><div class="card"><div class="card-body"><h6>Photos / Documents</h6><h3>{{ $mediaCount }}</h3></div></div></div>
        <div class="col-md-3"><div class="card"><div class="card-body"><h6>Processed</h6><h3>{{ $processedCount }}</h3></div></div></div>
        <div class="col-md-3"><div class="card"><div class="card-body"><h6>@lang('jobassist::jobassist.reports')</h6><h3>{{ $reportCount }}</h3></div></div></div>
        <div class="col-md-3"><div class="card"><div class="card-body"><h6>Avg Confidence</h6><h3>{{ $stats['average_confidence'] ?? 0 }}</h3></div></div></div>
    </div>
    <div class="row mt-3">
        <div class="col-md-6"><div class="card"><div class="card-header">Open recommendations</div><div class="card-body"><h3>{{ $stats['open_recommendations'] ?? 0 }}</h3><span class="text-muted">Suggested / accepted items needing action.</span></div></div></div>
        <div class="col-md-6"><div class="card"><div class="card-header">High severity</div><div class="card-body"><h3>{{ $stats['high_severity_items'] ?? 0 }}</h3><span class="text-muted">Issues that should be reviewed first.</span></div></div></div>
    </div>
    <div class="card mt-3"><div class="card-header"><h5 class="mb-0">Recent Media</h5></div><div class="card-body table-responsive"><table class="table table-hover"><thead><tr><th>Name</th><th>Type</th><th>Vertical</th><th>Status</th><th>Confidence</th></tr></thead><tbody>@forelse($recentMedia as $item)<tr><td><a href="{{ route('jobassist.media.show',$item->id) }}">{{ $item->original_name }}</a></td><td>{{ $item->media_type }}</td><td>{{ $item->vertical }}</td><td><span class="badge badge-info">{{ $item->status }}</span></td><td>{{ $item->confidence_score ?? '-' }}</td></tr>@empty<tr><td colspan="5" class="text-muted">No media yet.</td></tr>@endforelse</tbody></table></div></div>
</div>
@endsection
