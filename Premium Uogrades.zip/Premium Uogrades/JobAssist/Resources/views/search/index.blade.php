@extends('layouts.app')
@section('content')
<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h4 class="mb-0">JobAssist Visual Search</h4>
    </div>
    <form method="GET" class="card card-body mb-3">
        <div class="row g-2">
            <div class="col-md-6"><input name="q" value="{{ request('q') }}" class="form-control" placeholder="Search OCR, recommendations, job notes"></div>
            <div class="col-md-4"><input name="object" value="{{ request('object') }}" class="form-control" placeholder="Object e.g. mould, leaking pipe"></div>
            <div class="col-md-2"><button class="btn btn-primary w-100">Search</button></div>
        </div>
    </form>
    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-hover">
                <thead><tr><th>Type</th><th>Object</th><th>Text</th><th>Media</th><th>Date</th></tr></thead>
                <tbody>
                @forelse($results as $row)
                    <tr>
                        <td>{{ $row->index_type }}</td>
                        <td>{{ $row->object_label }}</td>
                        <td>{{ \Illuminate\Support\Str::limit($row->search_text, 160) }}</td>
                        <td>@if($row->media_id)<a href="{{ route('jobassist.media.show', $row->media_id) }}">#{{ $row->media_id }}</a>@endif</td>
                        <td>{{ $row->created_at }}</td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="text-muted">No visual intelligence results yet.</td></tr>
                @endforelse
                </tbody>
            </table>
            @if(method_exists($results, 'links')) {{ $results->links() }} @endif
        </div>
    </div>
</div>
@endsection
