@extends('layouts.app')

@section('content')
    @include('jobassist::partials.nav')

    <div class="row">
        <div class="col-md-4">
            <div class="card mb-3">
                <div class="card-header">Monthly Usage</div>
                <div class="card-body">
                    <p><strong>Events:</strong> {{ $usage['events'] ?? 0 }}</p>
                    <p><strong>Units:</strong> {{ $usage['units'] ?? 0 }}</p>
                    <p><strong>Estimated Cost:</strong> {{ $usage['estimated_cost'] ?? 0 }}</p>
                </div>
            </div>
        </div>
        <div class="col-md-8">
            <div class="card mb-3">
                <div class="card-header">Pipeline Health</div>
                <div class="table-responsive">
                    <table class="table table-sm mb-0">
                        <thead><tr><th>Component</th><th>Status</th><th>Message</th><th>Checked</th></tr></thead>
                        <tbody>
                        @foreach($health as $component => $item)
                            <tr>
                                <td>{{ ucfirst($component) }}</td>
                                <td><span class="badge badge-{{ ($item['status'] ?? '') === 'ok' ? 'success' : 'secondary' }}">{{ $item['status'] ?? 'unknown' }}</span></td>
                                <td>{{ $item['message'] ?? '' }}</td>
                                <td>{{ $item['checked_at'] ?? '-' }}</td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection
