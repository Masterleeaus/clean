@extends('layouts.app')
@section('content')
@include('jobassist::partials.nav')
<div class="content-wrapper">
    <h4 class="mb-4">JobAssist Settings</h4>
    <div class="card"><div class="card-body">
        <form id="jobassist-settings-form" method="POST" action="{{ route('jobassist.settings.update') }}">
            @csrf
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" name="auto_process_uploads" value="1" {{ ($settings['auto_process_uploads'] ?? true) ? 'checked' : '' }}>
                <label class="form-check-label">Automatically process uploads</label>
            </div>
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" name="customer_reports_enabled" value="1" {{ ($settings['customer_reports_enabled'] ?? true) ? 'checked' : '' }}>
                <label class="form-check-label">Enable customer-ready reports</label>
            </div>
            <div class="form-group form-check">
                <input type="checkbox" class="form-check-input" name="voice_enabled" value="1" {{ ($settings['voice_enabled'] ?? true) ? 'checked' : '' }}>
                <label class="form-check-label">Enable voice-context assistant</label>
            </div>
            <div class="form-group">
                <label>Minimum AI confidence</label>
                <input type="number" step="0.01" min="0" max="1" name="minimum_confidence" class="form-control" value="{{ $settings['minimum_confidence'] ?? 0.55 }}">
            </div>
            <div class="form-group">
                <label>Media retention days</label>
                <input type="number" min="1" max="3650" name="media_retention_days" class="form-control" value="{{ $settings['media_retention_days'] ?? 365 }}">
            </div>
            <button class="btn btn-primary">Save settings</button>
        </form>
    </div></div>
</div>
@endsection
