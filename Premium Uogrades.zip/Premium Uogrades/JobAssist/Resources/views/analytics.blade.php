@extends('layouts.app')
@section('content')
@include('jobassist::partials.nav')
<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h4 class="mb-0">JobAssist Analytics</h4>
        <span class="text-muted small">Visual intelligence metrics</span>
    </div>
    <div class="row">
        @foreach(['photos_analyzed'=>'Photos','videos_analyzed'=>'Videos','documents_analyzed'=>'Documents','processed_media'=>'Processed','failed_media'=>'Failed','average_confidence'=>'Avg Confidence','open_recommendations'=>'Open Recommendations','high_severity_items'=>'High Severity','reports_generated'=>'Reports'] as $key => $label)
            <div class="col-md-3 mb-3">
                <div class="card h-100"><div class="card-body">
                    <div class="text-muted small">{{ $label }}</div>
                    <h3 class="mb-0">{{ $stats[$key] ?? 0 }}</h3>
                </div></div>
            </div>
        @endforeach
    </div>
    <div class="row">
        <div class="col-md-6"><div class="card"><div class="card-header">Common defects</div><div class="card-body">
            @forelse(($stats['top_defects'] ?? []) as $row)
                <div class="d-flex justify-content-between border-bottom py-2"><span>{{ $row['label'] }}</span><strong>{{ $row['total'] }}</strong></div>
            @empty <p class="text-muted mb-0">No defect patterns yet.</p> @endforelse
        </div></div></div>
        <div class="col-md-6"><div class="card"><div class="card-header">Vertical mix</div><div class="card-body">
            @forelse(($stats['vertical_mix'] ?? []) as $row)
                <div class="d-flex justify-content-between border-bottom py-2"><span>{{ ucfirst($row['label']) }}</span><strong>{{ $row['total'] }}</strong></div>
            @empty <p class="text-muted mb-0">No vertical data yet.</p> @endforelse
        </div></div></div>
    </div>
</div>
@endsection
