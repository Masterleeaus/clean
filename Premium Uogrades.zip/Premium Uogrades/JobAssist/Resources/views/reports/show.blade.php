@extends('layouts.app')
@section('content')
<div class="container-fluid">
    @include('jobassist::partials.nav')
    <div class="d-flex justify-content-between align-items-center mb-3">
        <h3>{{ $report->title }}</h3>
        <a class="btn btn-outline-primary" href="{{ route('jobassist.reports.pdf', $report->id) }}">Download PDF</a>
    </div>
    <div class="card"><div class="card-body">
        <p>{{ $report->summary }}</p>
        @if($signedUrl && $report->media && str_starts_with($report->media->mime_type ?? '', 'image/'))
            <img src="{{ $signedUrl }}" class="img-fluid rounded border mb-3" style="max-height:420px" alt="Report media">
        @endif
        <h5>Report data</h5>
        <pre class="bg-light p-3 small">{{ json_encode($report->data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) }}</pre>
    </div></div>
</div>
@endsection
