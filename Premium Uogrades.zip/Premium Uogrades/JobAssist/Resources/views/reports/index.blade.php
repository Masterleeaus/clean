@extends('layouts.app')
@section('content')
<div class="content-wrapper">
    <h4>JobAssist Reports</h4>
    <div class="card"><div class="card-body table-responsive">
        <table class="table table-hover">
            <thead><tr><th>Title</th><th>Type</th><th>Status</th><th>Media</th><th>Created</th></tr></thead>
            <tbody>
            @forelse($reports as $report)
                <tr>
                    <td><a href="{{ route('jobassist.reports.show', $report->id) }}">{{ $report->title }}</a></td>
                    <td>{{ $report->report_type }}</td>
                    <td><span class="badge bg-secondary">{{ $report->status }}</span></td>
                    <td>@if($report->media_id)<a href="{{ route('jobassist.media.show', $report->media_id) }}">#{{ $report->media_id }}</a>@endif</td>
                    <td>{{ $report->created_at }}</td>
                </tr>
            @empty
                <tr><td colspan="5" class="text-muted">No reports generated yet.</td></tr>
            @endforelse
            </tbody>
        </table>
        {{ $reports->links() }}
    </div></div>
</div>
@endsection
