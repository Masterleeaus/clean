<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <title>{{ $report->title }}</title>
    <style>
        body { font-family: DejaVu Sans, Arial, sans-serif; font-size: 13px; color: #222; }
        h1 { font-size: 22px; margin-bottom: 4px; }
        .muted { color: #666; }
        .section { margin-top: 18px; padding-top: 10px; border-top: 1px solid #ddd; }
        table { width:100%; border-collapse: collapse; }
        td, th { border: 1px solid #ddd; padding: 6px; vertical-align: top; }
    </style>
</head>
<body>
    <h1>{{ $report->title }}</h1>
    <div class="muted">Generated {{ optional($report->created_at)->format('Y-m-d H:i') }}</div>
    <p>{{ $report->summary }}</p>

    <div class="section">
        <h2>Scores</h2>
        <table>
            <tr><th>Completion score</th><td>{{ data_get($report->data, 'completion_score', 'n/a') }}</td></tr>
            <tr><th>Confidence score</th><td>{{ data_get($report->data, 'confidence_score', 'n/a') }}</td></tr>
            <tr><th>Vertical</th><td>{{ data_get($report->data, 'vertical', 'general') }}</td></tr>
        </table>
    </div>

    <div class="section">
        <h2>Recommendations</h2>
        @forelse(data_get($report->data, 'recommendations', []) as $rec)
            <p><strong>{{ data_get($rec, 'title') }}</strong> — {{ data_get($rec, 'severity', 'normal') }} / {{ data_get($rec, 'confidence', 'n/a') }}</p>
        @empty
            <p>No recommendations recorded.</p>
        @endforelse
    </div>

    <div class="section">
        <h2>OCR excerpt</h2>
        <p>{{ data_get($report->data, 'ocr_excerpt', 'No OCR text recorded.') }}</p>
    </div>
</body>
</html>
