<?php

return [
    'name' => 'JobAssist',
    'media_uploaded' => 'Media uploaded. JobAssist analysis has been queued.',
    'media_deleted' => 'Media deleted.',
    'report_generated' => 'JobAssist report generated.',
    'settings_saved' => 'JobAssist settings saved.',
    'voice_answer_ready' => 'JobAssist answer ready.',
    'monitoring' => 'JobAssist Monitoring',
];
