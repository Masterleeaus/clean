<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('jobassist_detections')) {
            Schema::create('jobassist_detections', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('media_id')->index();
                $table->string('label')->index();
                $table->string('category', 80)->nullable()->index();
                $table->decimal('confidence_score', 5, 2)->nullable();
                $table->json('bounding_box')->nullable();
                $table->json('segmentation')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->index(['company_id', 'label']);
            });
        }

        if (!Schema::hasTable('jobassist_ocr_results')) {
            Schema::create('jobassist_ocr_results', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('media_id')->index();
                $table->longText('text')->nullable();
                $table->string('language', 20)->nullable();
                $table->decimal('confidence_score', 5, 2)->nullable();
                $table->json('blocks')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->fullText('text');
            });
        }

        if (!Schema::hasTable('jobassist_recommendations')) {
            Schema::create('jobassist_recommendations', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('media_id')->nullable()->index();
                $table->unsignedBigInteger('inspection_id')->nullable()->index();
                $table->string('vertical', 50)->nullable()->index();
                $table->string('type', 80)->index();
                $table->string('severity', 40)->nullable()->index();
                $table->string('title');
                $table->text('description')->nullable();
                $table->json('actions')->nullable();
                $table->json('tools_parts')->nullable();
                $table->decimal('confidence_score', 5, 2)->nullable();
                $table->string('status', 40)->default('suggested')->index();
                $table->timestamps();
                $table->index(['company_id', 'status']);
            });
        }

        if (!Schema::hasTable('jobassist_search_indexes')) {
            Schema::create('jobassist_search_indexes', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('media_id')->nullable()->index();
                $table->unsignedBigInteger('analysis_id')->nullable()->index();
                $table->string('index_type', 50)->index();
                $table->string('object_label')->nullable()->index();
                $table->longText('search_text')->nullable();
                $table->json('embedding')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->fullText('search_text');
                $table->index(['company_id','index_type']);
            });
        }

        if (!Schema::hasTable('jobassist_agent_runs')) {
            Schema::create('jobassist_agent_runs', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->unsignedBigInteger('media_id')->nullable()->index();
                $table->string('agent_key', 80)->index();
                $table->string('prompt_version', 80)->nullable();
                $table->json('input')->nullable();
                $table->json('output')->nullable();
                $table->decimal('confidence_score', 5, 2)->nullable();
                $table->string('status', 40)->default('completed')->index();
                $table->text('error_message')->nullable();
                $table->timestamps();
                $table->index(['company_id','agent_key']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('jobassist_agent_runs');
        Schema::dropIfExists('jobassist_search_indexes');
        Schema::dropIfExists('jobassist_recommendations');
        Schema::dropIfExists('jobassist_ocr_results');
        Schema::dropIfExists('jobassist_detections');
    }
};
