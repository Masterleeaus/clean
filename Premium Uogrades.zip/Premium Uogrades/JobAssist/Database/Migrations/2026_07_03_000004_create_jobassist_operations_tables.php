<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('jobassist_checklist_updates')) {
            Schema::create('jobassist_checklist_updates', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('media_id')->nullable()->index();
                $table->unsignedBigInteger('inspection_id')->nullable()->index();
                $table->string('target_module', 80)->index();
                $table->string('target_type')->nullable()->index();
                $table->unsignedBigInteger('target_id')->nullable()->index();
                $table->string('task_key')->nullable()->index();
                $table->string('status', 40)->default('pending')->index();
                $table->decimal('completion_score', 5, 2)->nullable();
                $table->decimal('confidence_score', 5, 2)->nullable();
                $table->json('evidence')->nullable();
                $table->json('payload')->nullable();
                $table->text('notes')->nullable();
                $table->timestamps();
                $table->index(['company_id','target_module','status']);
            });
        }

        if (!Schema::hasTable('jobassist_analytics_snapshots')) {
            Schema::create('jobassist_analytics_snapshots', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->date('snapshot_date')->index();
                $table->string('metric_key', 120)->index();
                $table->decimal('metric_value', 12, 2)->default(0);
                $table->json('dimensions')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->unique(['company_id','snapshot_date','metric_key'], 'jobassist_metric_unique');
            });
        }

        if (!Schema::hasTable('jobassist_voice_sessions')) {
            Schema::create('jobassist_voice_sessions', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->unsignedBigInteger('media_id')->nullable()->index();
                $table->string('session_key')->index();
                $table->text('question')->nullable();
                $table->longText('answer')->nullable();
                $table->json('image_context')->nullable();
                $table->json('retrieval_context')->nullable();
                $table->decimal('confidence_score', 5, 2)->nullable();
                $table->string('status', 40)->default('completed')->index();
                $table->timestamps();
                $table->index(['company_id','session_key']);
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('jobassist_voice_sessions');
        Schema::dropIfExists('jobassist_analytics_snapshots');
        Schema::dropIfExists('jobassist_checklist_updates');
    }
};
