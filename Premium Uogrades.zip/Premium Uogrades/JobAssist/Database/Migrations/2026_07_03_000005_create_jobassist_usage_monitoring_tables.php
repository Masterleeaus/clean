<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('jobassist_usage_events', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->string('event_type')->index();
            $table->string('provider')->nullable()->index();
            $table->string('model')->nullable();
            $table->unsignedInteger('units')->default(1);
            $table->decimal('estimated_cost', 12, 6)->default(0);
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->index(['company_id', 'event_type', 'created_at'], 'jobassist_usage_company_event_created_idx');
        });

        Schema::create('jobassist_health_events', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->string('component')->index();
            $table->string('status')->default('ok')->index();
            $table->string('message')->nullable();
            $table->json('context')->nullable();
            $table->timestamps();

            $table->index(['component', 'status', 'created_at'], 'jobassist_health_component_status_idx');
        });

        Schema::create('jobassist_retention_runs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->nullable()->index();
            $table->unsignedInteger('media_deleted')->default(0);
            $table->unsignedInteger('analyses_deleted')->default(0);
            $table->unsignedInteger('reports_deleted')->default(0);
            $table->json('metadata')->nullable();
            $table->timestamps();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('jobassist_retention_runs');
        Schema::dropIfExists('jobassist_health_events');
        Schema::dropIfExists('jobassist_usage_events');
    }
};
