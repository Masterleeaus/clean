<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('jobassist_media')) {
            Schema::create('jobassist_media', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('created_by')->nullable()->index();
                $table->string('source_type', 50)->default('upload')->index();
                $table->string('related_type')->nullable()->index();
                $table->unsignedBigInteger('related_id')->nullable()->index();
                $table->string('job_ref')->nullable()->index();
                $table->string('vertical', 50)->nullable()->index();
                $table->string('media_type', 30)->index();
                $table->string('mime_type', 120)->nullable();
                $table->string('original_name')->nullable();
                $table->string('disk', 80)->default('local');
                $table->string('path');
                $table->string('thumbnail_path')->nullable();
                $table->unsignedBigInteger('size_bytes')->default(0);
                $table->string('status', 30)->default('queued')->index();
                $table->json('metadata')->nullable();
                $table->json('detected_objects')->nullable();
                $table->json('analysis_summary')->nullable();
                $table->decimal('confidence_score', 5, 2)->nullable();
                $table->timestamp('processed_at')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->index(['company_id','status']);
                $table->index(['company_id','vertical']);
            });
        }
        if (!Schema::hasTable('jobassist_media_analyses')) {
            Schema::create('jobassist_media_analyses', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('media_id')->index();
                $table->string('analysis_type', 50)->index();
                $table->string('agent_key', 80)->nullable()->index();
                $table->string('model_key', 120)->nullable();
                $table->string('prompt_version', 80)->nullable();
                $table->json('vision_result')->nullable();
                $table->json('ocr_result')->nullable();
                $table->json('retrieval_context')->nullable();
                $table->json('recommendations')->nullable();
                $table->decimal('confidence_score', 5, 2)->nullable();
                $table->string('status', 30)->default('pending')->index();
                $table->text('error_message')->nullable();
                $table->timestamps();
                $table->index(['company_id','media_id']);
            });
        }
        if (!Schema::hasTable('jobassist_reports')) {
            Schema::create('jobassist_reports', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('media_id')->nullable()->index();
                $table->unsignedBigInteger('inspection_id')->nullable()->index();
                $table->unsignedBigInteger('created_by')->nullable()->index();
                $table->string('title');
                $table->string('report_type', 50)->default('customer')->index();
                $table->string('status', 30)->default('draft')->index();
                $table->json('sections')->nullable();
                $table->json('metadata')->nullable();
                $table->string('pdf_disk', 80)->nullable();
                $table->string('pdf_path')->nullable();
                $table->timestamp('published_at')->nullable();
                $table->timestamps();
                $table->index(['company_id','status']);
            });
        }
        if (!Schema::hasTable('jobassist_inspections')) {
            Schema::create('jobassist_inspections', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('created_by')->nullable()->index();
                $table->string('related_type')->nullable()->index();
                $table->unsignedBigInteger('related_id')->nullable()->index();
                $table->string('job_ref')->nullable()->index();
                $table->string('vertical', 50)->nullable()->index();
                $table->string('title');
                $table->string('status', 30)->default('open')->index();
                $table->json('checklist')->nullable();
                $table->json('scores')->nullable();
                $table->json('metadata')->nullable();
                $table->timestamps();
                $table->softDeletes();
                $table->index(['company_id','status']);
            });
        }
    }
    public function down(): void
    {
        Schema::dropIfExists('jobassist_inspections');
        Schema::dropIfExists('jobassist_reports');
        Schema::dropIfExists('jobassist_media_analyses');
        Schema::dropIfExists('jobassist_media');
    }
};
