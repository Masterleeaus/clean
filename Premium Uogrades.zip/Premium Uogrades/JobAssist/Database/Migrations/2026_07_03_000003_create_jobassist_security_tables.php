<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        if (!Schema::hasTable('jobassist_settings')) {
            Schema::create('jobassist_settings', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->string('key')->index();
                $table->json('value')->nullable();
                $table->timestamps();
                $table->unique(['company_id', 'key']);
            });
        }

        if (!Schema::hasTable('jobassist_audit_logs')) {
            Schema::create('jobassist_audit_logs', function (Blueprint $table) {
                $table->id();
                $table->unsignedBigInteger('company_id')->index();
                $table->unsignedBigInteger('user_id')->nullable()->index();
                $table->string('event')->index();
                $table->nullableMorphs('auditable');
                $table->json('metadata')->nullable();
                $table->ipAddress('ip_address')->nullable();
                $table->timestamps();
            });
        }
    }

    public function down(): void
    {
        Schema::dropIfExists('jobassist_audit_logs');
        Schema::dropIfExists('jobassist_settings');
    }
};
