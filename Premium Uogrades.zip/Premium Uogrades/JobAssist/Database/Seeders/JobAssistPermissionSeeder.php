<?php

namespace Modules\JobAssist\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Modules\JobAssist\Support\JobAssistPermissions;

class JobAssistPermissionSeeder extends Seeder
{
    public function run(): void
    {
        foreach (JobAssistPermissions::labels() as $name => $displayName) {
            if (class_exists('App\\Models\\Permission')) {
                \App\Models\Permission::updateOrCreate(['name' => $name], [
                    'display_name' => $displayName,
                    'module_id' => 'jobassist',
                    'allowed_permissions' => json_encode(['all', 'added', 'owned', 'none']),
                ]);
                continue;
            }

            if (DB::getSchemaBuilder()->hasTable('permissions')) {
                DB::table('permissions')->updateOrInsert(['name' => $name], [
                    'display_name' => $displayName,
                    'module_id' => 'jobassist',
                    'allowed_permissions' => json_encode(['all', 'added', 'owned', 'none']),
                ]);
            }
        }
    }
}
