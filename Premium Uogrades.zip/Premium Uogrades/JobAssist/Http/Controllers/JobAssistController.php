<?php
namespace Modules\JobAssist\Http\Controllers;

use App\Http\Controllers\AccountBaseController;
use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Entities\JobAssistReport;
use Modules\JobAssist\Services\JobAssistAnalyticsService;
use Modules\JobAssist\Services\JobAssistSettingsService;
use Modules\JobAssist\Services\WorkSuiteContext;

class JobAssistController extends AccountBaseController
{
    public function __construct(protected WorkSuiteContext $context)
    {
        parent::__construct();
        $this->pageTitle = 'jobassist::jobassist.dashboard';
    }

    public function index(JobAssistAnalyticsService $analyticsService)
    {
        $companyId = $this->context->companyId();
        $stats = $companyId ? $analyticsService->dashboard($companyId) : [];

        return view('jobassist::dashboard', [
            'mediaCount' => $companyId ? JobAssistMedia::forCompany($companyId)->count() : 0,
            'processedCount' => $companyId ? JobAssistMedia::forCompany($companyId)->where('status', 'processed')->count() : 0,
            'reportCount' => $companyId ? JobAssistReport::forCompany($companyId)->count() : 0,
            'recentMedia' => $companyId ? JobAssistMedia::forCompany($companyId)->latest()->limit(8)->get() : collect(),
            'stats' => $stats,
        ]);
    }

    public function assistant()
    {
        $this->pageTitle = 'jobassist::jobassist.assistant';
        return view('jobassist::assistant');
    }

    public function analytics(JobAssistAnalyticsService $analyticsService)
    {
        $this->pageTitle = 'jobassist::jobassist.analytics';
        $companyId = $this->context->companyId();
        $stats = $companyId ? $analyticsService->dashboard($companyId) : [];
        return view('jobassist::analytics', compact('stats'));
    }

    public function settings(JobAssistSettingsService $settingsService)
    {
        $this->pageTitle = 'jobassist::jobassist.settings';
        $companyId = $this->context->companyId();
        $settings = $companyId ? $settingsService->all($companyId) : [];
        return view('jobassist::settings', compact('settings'));
    }
}
