<?php

namespace Modules\JobAssist\Http\Controllers;

use App\Http\Controllers\Controller;
use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Entities\JobAssistReport;
use Modules\JobAssist\Services\JobAssistAuthorizationService;
use Modules\JobAssist\Services\JobAssistReportService;
use Modules\JobAssist\Services\SignedMediaUrlService;
use Modules\JobAssist\Services\WorkSuiteContext;
use Modules\JobAssist\Support\JobAssistPermissions;

class JobAssistReportController extends Controller
{
    public function index(WorkSuiteContext $context, JobAssistAuthorizationService $auth)
    {
        $auth->ensure(JobAssistPermissions::VIEW_REPORTS);
        return view('jobassist::reports.index', [
            'reports' => JobAssistReport::where('company_id', $context->companyId())->latest()->paginate(20),
        ]);
    }

    public function generate(JobAssistMedia $media, JobAssistReportService $reports, JobAssistAuthorizationService $auth, WorkSuiteContext $context)
    {
        $auth->ensure(JobAssistPermissions::RUN_ANALYSIS);
        $auth->ensureMediaAccess($media, $context->companyId());
        $report = $reports->generate($media);

        if (class_exists('App\\Classes\\Reply')) {
            return \App\Classes\Reply::successWithData(__('jobassist::jobassist.report_generated'), ['redirectUrl' => route('jobassist.reports.show', $report->id)]);
        }

        return redirect()->route('jobassist.reports.show', $report->id);
    }

    public function show(JobAssistReport $report, JobAssistAuthorizationService $auth, WorkSuiteContext $context, SignedMediaUrlService $signed)
    {
        $auth->ensureReportAccess($report, $context->companyId());
        $report->load('media');

        return view('jobassist::reports.show', [
            'report' => $report,
            'signedUrl' => $report->media ? $signed->temporaryUrl($report->media) : null,
        ]);
    }

    public function pdf(JobAssistReport $report, JobAssistAuthorizationService $auth, WorkSuiteContext $context, SignedMediaUrlService $signed)
    {
        $auth->ensureReportAccess($report, $context->companyId());
        $report->load('media');

        $html = view('jobassist::reports.pdf', [
            'report' => $report,
            'signedUrl' => $report->media ? $signed->temporaryUrl($report->media) : null,
        ])->render();

        if (class_exists('Barryvdh\\DomPDF\\Facade\\Pdf')) {
            return \Barryvdh\DomPDF\Facade\Pdf::loadHTML($html)->download('jobassist-report-' . $report->id . '.pdf');
        }

        return response($html)->header('Content-Type', 'text/html');
    }
}
