<?php

namespace Modules\JobAssist\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Http\Requests\StoreJobAssistMediaRequest;
use Modules\JobAssist\Services\JobAssistAuthorizationService;
use Modules\JobAssist\Services\JobAssistMediaService;
use Modules\JobAssist\Services\SignedMediaUrlService;
use Modules\JobAssist\Services\WorkSuiteContext;
use Modules\JobAssist\Support\JobAssistPermissions;

class JobAssistMediaController extends Controller
{
    public function index(WorkSuiteContext $context, JobAssistAuthorizationService $auth)
    {
        $auth->ensure(JobAssistPermissions::VIEW);
        return view('jobassist::media.index', [
            'media' => JobAssistMedia::forCompany($context->companyId())->latest()->paginate(20),
        ]);
    }

    public function create(JobAssistAuthorizationService $auth)
    {
        $auth->ensure(JobAssistPermissions::MANAGE_MEDIA);
        return view('jobassist::media.create');
    }

    public function store(StoreJobAssistMediaRequest $request, JobAssistMediaService $service)
    {
        $service->store($request->file('media'), $request->validated());

        if (class_exists('App\\Classes\\Reply')) {
            return \App\Classes\Reply::success(__('jobassist::jobassist.media_uploaded'));
        }

        return redirect()->route('jobassist.media.index')->with(['type' => 'success', 'message' => __('jobassist::jobassist.media_uploaded')]);
    }

    public function show(JobAssistMedia $media, JobAssistMediaService $service, SignedMediaUrlService $signed)
    {
        $service->assertCompanyAccess($media);

        return view('jobassist::media.show', [
            'media' => $media->load(['analyses', 'detections', 'ocrResults', 'recommendations', 'reports']),
            'signedUrl' => $signed->temporaryUrl($media),
        ]);
    }

    public function signedUrl(Request $request, JobAssistMedia $media, JobAssistMediaService $service, SignedMediaUrlService $signed)
    {
        $service->assertCompanyAccess($media);

        if ($request->hasValidSignature()) {
            return Storage::disk($media->disk ?: config('jobassist.storage.disk', 'local'))->download($media->path, $media->original_filename);
        }

        return response()->json(['url' => $signed->temporaryUrl($media)]);
    }

    public function destroy(JobAssistMedia $media, JobAssistMediaService $service)
    {
        $service->delete($media);

        if (class_exists('App\\Classes\\Reply')) {
            return \App\Classes\Reply::success(__('jobassist::jobassist.media_deleted'));
        }

        return redirect()->route('jobassist.media.index')->with(['type' => 'success', 'message' => __('jobassist::jobassist.media_deleted')]);
    }
}
