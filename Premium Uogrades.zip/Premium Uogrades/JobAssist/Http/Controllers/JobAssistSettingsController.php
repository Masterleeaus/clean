<?php
namespace Modules\JobAssist\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\JobAssist\Services\JobAssistSettingsService;
use Modules\JobAssist\Services\WorkSuiteContext;

class JobAssistSettingsController extends AccountBaseController
{
    public function update(Request $request, WorkSuiteContext $context, JobAssistSettingsService $settingsService)
    {
        $companyId = $context->companyId();
        abort_if(!$companyId, 403);

        $validated = $request->validate([
            'auto_process_uploads' => 'nullable|boolean',
            'customer_reports_enabled' => 'nullable|boolean',
            'minimum_confidence' => 'required|numeric|min:0|max:1',
            'media_retention_days' => 'required|integer|min:1|max:3650',
            'voice_enabled' => 'nullable|boolean',
        ]);

        $settingsService->save($companyId, [
            'auto_process_uploads' => $request->boolean('auto_process_uploads'),
            'customer_reports_enabled' => $request->boolean('customer_reports_enabled'),
            'minimum_confidence' => $validated['minimum_confidence'],
            'media_retention_days' => $validated['media_retention_days'],
            'voice_enabled' => $request->boolean('voice_enabled'),
        ]);

        return Reply::success(__('jobassist::jobassist.settings_saved'));
    }
}
