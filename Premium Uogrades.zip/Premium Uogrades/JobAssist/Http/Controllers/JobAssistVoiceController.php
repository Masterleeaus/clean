<?php
namespace Modules\JobAssist\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\JobAssist\Entities\JobAssistMedia;
use Modules\JobAssist\Services\JobAssistAuthorizationService;
use Modules\JobAssist\Services\JobAssistVoiceService;
use Modules\JobAssist\Services\WorkSuiteContext;

class JobAssistVoiceController extends AccountBaseController
{
    public function ask(Request $request, JobAssistMedia $media, WorkSuiteContext $context, JobAssistAuthorizationService $auth, JobAssistVoiceService $voiceService)
    {
        $companyId = $context->companyId();
        abort_if(!$companyId || !$auth->canViewMedia($media, $companyId), 403);

        $validated = $request->validate([
            'question' => 'required|string|min:3|max:1000',
        ]);

        $session = $voiceService->ask($companyId, optional(user())->id, $media, $validated['question']);

        return Reply::successWithData(__('jobassist::jobassist.voice_answer_ready'), [
            'answer' => $session->answer,
            'confidence_score' => $session->confidence_score,
            'session_key' => $session->session_key,
        ]);
    }
}
