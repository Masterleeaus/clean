<?php
namespace Modules\JobAssist\Http\Controllers;

use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\JobAssist\Services\JobAssistSearchService;

class JobAssistSearchController extends AccountBaseController
{
    public function __construct(protected JobAssistSearchService $searchService)
    {
        parent::__construct();
        $this->pageTitle = 'jobassist::jobassist.search';
    }

    public function index(Request $request)
    {
        $companyId = function_exists('company') && company() ? company()->id : null;
        $results = $companyId ? $this->searchService->search($companyId, $request->get('q'), $request->get('object')) : collect();
        return view('jobassist::search.index', compact('results'));
    }
}
