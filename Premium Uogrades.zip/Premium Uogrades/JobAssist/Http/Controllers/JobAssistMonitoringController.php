<?php

namespace Modules\JobAssist\Http\Controllers;

use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\JobAssist\Services\JobAssistAuthorizationService;
use Modules\JobAssist\Services\JobAssistHealthService;
use Modules\JobAssist\Services\JobAssistUsageService;

class JobAssistMonitoringController extends AccountBaseController
{
    public function index(JobAssistAuthorizationService $auth, JobAssistUsageService $usage, JobAssistHealthService $health)
    {
        $auth->authorize('view_analytics');

        $this->pageTitle = __('jobassist::jobassist.monitoring');

        return view('jobassist::monitoring.index', [
            'usage' => $usage->monthlySummary(),
            'health' => $health->snapshot(),
        ]);
    }

    public function health(Request $request, JobAssistAuthorizationService $auth, JobAssistHealthService $health)
    {
        $auth->authorize('view_analytics');

        return response()->json([
            'ok' => true,
            'module' => 'JobAssist',
            'health' => $health->snapshot(),
        ]);
    }
}
