<?php

namespace Modules\JobAssist\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreJobAssistMediaRequest extends FormRequest
{
    public function authorize(): bool { return auth()->check(); }

    public function rules(): array
    {
        $maxKb = (int) config('jobassist.storage.max_upload_mb', 50) * 1024;
        return [
            'media' => ['required', 'file', 'max:' . $maxKb],
            'vertical' => ['nullable', 'string', 'max:80'],
            'source_type' => ['nullable', 'string', 'max:80'],
            'related_type' => ['nullable', 'string', 'max:180'],
            'related_id' => ['nullable', 'integer'],
        ];
    }
}
