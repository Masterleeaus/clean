<?php

namespace Modules\JobAssist\Console\Commands;

use Illuminate\Console\Command;
use Modules\JobAssist\Services\JobAssistRetentionService;

class RunJobAssistRetention extends Command
{
    protected $signature = 'jobassist:retention {--company_id=} {--days=}';
    protected $description = 'Apply JobAssist media retention rules safely by company and age.';

    public function handle(JobAssistRetentionService $retention): int
    {
        $run = $retention->run(
            $this->option('company_id') ? (int) $this->option('company_id') : null,
            $this->option('days') ? (int) $this->option('days') : null
        );

        $this->info('JobAssist retention complete. Media deleted: ' . $run->media_deleted);

        return self::SUCCESS;
    }
}
