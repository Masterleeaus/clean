# JobAssist Pass 5 QA Checklist

## Added in pass 5

- Usage/cost event tracking
- Pipeline health event tracking
- Monitoring page and JSON health endpoint
- Retention run tracking
- Retention console command
- Configurable upload/AI request limits
- Configurable retention policy
- API contract documentation
- Installation/rollout documentation

## Validate

- Run migrations including `2026_07_03_000005_create_jobassist_usage_monitoring_tables.php`
- Confirm `/account/job-assist/monitoring` loads for permitted users
- Confirm `/account/job-assist/monitoring/health` returns JSON
- Process one media file and confirm usage events are created
- Confirm failed queue jobs create health events
- Run `php artisan jobassist:retention --days=9999` on test data
- Confirm company isolation remains enforced on media, reports, and monitoring
- Confirm route cache and config cache do not fail

## Known remaining work

- Wire exact Aitools provider methods once final Aitools service signatures are confirmed
- Add browser-based live camera capture page
- Add image annotation canvas
- Add formal feature tests against a real WorkSuite install
- Add scheduler registration in host app kernel if WorkSuite allows module-level scheduling
