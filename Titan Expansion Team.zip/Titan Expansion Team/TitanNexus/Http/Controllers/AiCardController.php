<?php

namespace Modules\TitanNexus\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;

class AiCardController extends AccountBaseController
{
    public function execute(string $card)
    {
        return Reply::successWithData('AI card prepared for approval.', [
            'card' => $card,
            'mode' => 'draft_then_approve',
            'company_id' => tenant_company_id(),
        ]);
    }
}
