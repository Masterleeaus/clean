<?php

namespace Modules\TitanNexus\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use InvalidArgumentException;
use Modules\TitanNexus\Http\Requests\StoreLeadRecordRequest;
use Modules\TitanNexus\Models\LeadRecord;
use Modules\TitanNexus\Services\Lifecycle\LifecycleTransitionService;

class LeadController extends AccountBaseController
{
    public function index(Request $request)
    {
        $this->pageTitle = 'Titan Nexus Leads';

        $leads = LeadRecord::query()
            ->latest()
            ->paginate(25);

        return view('titannexus::leads', compact('leads'));
    }

    public function store(StoreLeadRecordRequest $request)
    {
        $lead = LeadRecord::create($request->toModelData());

        return Reply::successWithData('Lead captured.', ['lead' => $lead]);
    }

    public function advance(Request $request, LeadRecord $lead, LifecycleTransitionService $lifecycle)
    {
        $data = $request->validate([
            'to_stage' => ['required', 'string'],
            'payload' => ['nullable', 'array'],
        ]);

        try {
            $transition = $lifecycle->transition($lead, $data['to_stage'], $data['payload'] ?? []);
        } catch (InvalidArgumentException $exception) {
            return Reply::error($exception->getMessage());
        }

        return Reply::successWithData('Lead lifecycle stage updated.', [
            'lead' => $lead->fresh(),
            'transition' => $transition,
        ]);
    }
}
