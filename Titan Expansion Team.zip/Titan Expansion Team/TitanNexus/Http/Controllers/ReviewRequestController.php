<?php

namespace Modules\TitanNexus\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\TitanNexus\Models\LeadRecord;
use Modules\TitanNexus\Models\NexusReviewRequest;
use Modules\TitanNexus\Services\Reviews\ReviewRequestService;

class ReviewRequestController extends AccountBaseController
{
    public function index()
    {
        $this->pageTitle = 'Titan Nexus Review Requests';

        $reviews = NexusReviewRequest::query()
            ->with('lead')
            ->latest()
            ->paginate(25);

        return view('titannexus::reviews', compact('reviews'));
    }

    public function store(Request $request, ReviewRequestService $service)
    {
        $data = $request->validate([
            'lead_id' => ['required', 'integer'],
            'customer_name' => ['nullable', 'string', 'max:255'],
            'email' => ['nullable', 'email', 'max:255'],
            'phone' => ['nullable', 'string', 'max:60'],
            'platform' => ['nullable', 'string', 'max:80'],
            'requested_at' => ['nullable', 'date'],
        ]);

        $lead = LeadRecord::query()->findOrFail($data['lead_id']);
        $review = $service->queueForLead($lead, $data);

        return Reply::successWithData('Review request queued.', ['review' => $review]);
    }
}
