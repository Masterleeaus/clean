<?php

namespace Modules\TitanNexus\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\TitanNexus\Models\LeadRecord;
use Modules\TitanNexus\Models\NexusCommunication;
use Modules\TitanNexus\Services\Communications\CommunicationService;

class CommunicationController extends AccountBaseController
{
    public function index()
    {
        $this->pageTitle = 'Titan Nexus Communications';

        $communications = NexusCommunication::query()
            ->with(['lead', 'campaign'])
            ->latest()
            ->paginate(25);

        return view('titannexus::communications', compact('communications'));
    }

    public function store(Request $request, CommunicationService $service)
    {
        $data = $request->validate([
            'lead_id' => ['required', 'integer'],
            'channel' => ['required', 'string', 'max:40'],
            'subject' => ['nullable', 'string', 'max:255'],
            'body' => ['nullable', 'string'],
            'scheduled_at' => ['nullable', 'date'],
        ]);

        $lead = LeadRecord::query()->findOrFail($data['lead_id']);
        $communication = $service->queueForLead($lead, $data);

        return Reply::successWithData('Communication queued.', ['communication' => $communication]);
    }
}
