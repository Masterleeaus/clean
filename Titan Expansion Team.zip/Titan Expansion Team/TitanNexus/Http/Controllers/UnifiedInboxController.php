<?php

namespace Modules\TitanNexus\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\TitanNexus\Services\UnifiedLeadIngestService;

class UnifiedInboxController extends AccountBaseController
{
    public function store(Request $request, UnifiedLeadIngestService $ingest)
    {
        $payload = $request->validate([
            'name' => ['nullable', 'string', 'max:191'],
            'email' => ['nullable', 'email', 'max:191'],
            'phone' => ['nullable', 'string', 'max:50'],
            'source' => ['nullable', 'string', 'max:100'],
            'message' => ['nullable', 'string'],
            'payload' => ['nullable', 'array'],
        ]);

        $lead = $ingest->ingest($payload, $payload['source'] ?? 'inbox');

        return Reply::successWithData('Inbox message ingested.', ['lead' => $lead]);
    }
}
