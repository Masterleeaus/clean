<?php

namespace Modules\TitanNexus\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Modules\TitanNexus\Http\Requests\LaunchCampaignRequest;
use Modules\TitanNexus\Models\NexusCampaign;

class CampaignController extends AccountBaseController
{
    public function index()
    {
        $this->pageTitle = 'Titan Nexus Campaigns';

        $campaigns = NexusCampaign::query()
            ->latest()
            ->paginate(25);

        return view('titannexus::campaigns', compact('campaigns'));
    }

    public function launch(LaunchCampaignRequest $request)
    {
        $campaign = NexusCampaign::create($request->toModelData());

        return Reply::successWithData('Campaign queued.', ['campaign' => $campaign]);
    }
}
