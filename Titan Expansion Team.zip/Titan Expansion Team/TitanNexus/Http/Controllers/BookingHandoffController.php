<?php

namespace Modules\TitanNexus\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\TitanNexus\Models\LeadRecord;
use Modules\TitanNexus\Models\NexusBookingHandoff;
use Modules\TitanNexus\Services\BookingHandoffService;

class BookingHandoffController extends AccountBaseController
{
    public function index()
    {
        $this->pageTitle = 'Titan Nexus Booking Handoffs';

        $handoffs = NexusBookingHandoff::query()
            ->with('lead')
            ->latest()
            ->paginate(25);

        return view('titannexus::booking-handoffs', compact('handoffs'));
    }

    public function store(Request $request, BookingHandoffService $service)
    {
        $data = $request->validate([
            'lead_id' => ['required', 'integer'],
            'amount' => ['nullable', 'numeric'],
            'currency' => ['nullable', 'string', 'max:8'],
            'scheduled_at' => ['nullable', 'date'],
            'notes' => ['nullable', 'string'],
        ]);

        $lead = LeadRecord::query()->findOrFail($data['lead_id']);
        $handoff = $service->createFromLead($lead, $data);

        return Reply::successWithData('Booking / quote handoff created.', ['handoff' => $handoff]);
    }
}
