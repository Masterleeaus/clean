<?php

namespace Modules\TitanNexus\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;

class ChannelWebhookController extends AccountBaseController
{
    public function receive(Request $request)
    {
        // Provider-specific signature verification belongs in channel adapters before side effects.
        return Reply::successWithData('Webhook received.', [
            'received' => true,
            'channel' => $request->input('channel', 'unknown'),
            'company_id' => tenant_company_id(),
        ]);
    }
}
