<?php

namespace Modules\TitanNexus\Http\Controllers;

use App\Http\Controllers\AccountBaseController;
use Modules\TitanNexus\Models\LeadRecord;
use Modules\TitanNexus\Models\NexusBookingHandoff;
use Modules\TitanNexus\Models\NexusCampaign;
use Modules\TitanNexus\Models\NexusCommunication;
use Modules\TitanNexus\Models\NexusReferral;
use Modules\TitanNexus\Models\NexusReviewRequest;
use Modules\TitanNexus\Models\TitanNexusLifecycleTransition;

class ControlPanelController extends AccountBaseController
{
    public function dashboard()
    {
        $this->pageTitle = 'Titan Nexus';

        $stages = config('titannexus.lifecycle_stages', []);
        $stageCounts = LeadRecord::query()
            ->selectRaw('status, COUNT(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status')
            ->toArray();

        return view('titannexus::dashboard', [
            'stages' => $stages,
            'stageCounts' => $stageCounts,
            'leadCount' => LeadRecord::query()->count(),
            'campaignCount' => NexusCampaign::query()->count(),
            'handoffCount' => NexusBookingHandoff::query()->count(),
            'transitionCount' => TitanNexusLifecycleTransition::query()->count(),
            'communicationCount' => NexusCommunication::query()->count(),
            'reviewCount' => NexusReviewRequest::query()->count(),
            'referralCount' => NexusReferral::query()->count(),
        ]);
    }
}
