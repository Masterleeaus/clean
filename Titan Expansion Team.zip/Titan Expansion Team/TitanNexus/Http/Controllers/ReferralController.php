<?php

namespace Modules\TitanNexus\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;
use Modules\TitanNexus\Models\LeadRecord;
use Modules\TitanNexus\Models\NexusReferral;
use Modules\TitanNexus\Services\Referrals\ReferralService;

class ReferralController extends AccountBaseController
{
    public function index()
    {
        $this->pageTitle = 'Titan Nexus Referrals';

        $referrals = NexusReferral::query()
            ->with('lead')
            ->latest()
            ->paginate(25);

        return view('titannexus::referrals', compact('referrals'));
    }

    public function store(Request $request, ReferralService $service)
    {
        $data = $request->validate([
            'lead_id' => ['required', 'integer'],
            'referrer_name' => ['nullable', 'string', 'max:255'],
            'referrer_email' => ['nullable', 'email', 'max:255'],
            'referrer_phone' => ['nullable', 'string', 'max:60'],
            'referred_name' => ['nullable', 'string', 'max:255'],
            'referred_email' => ['nullable', 'email', 'max:255'],
            'referred_phone' => ['nullable', 'string', 'max:60'],
        ]);

        $lead = LeadRecord::query()->findOrFail($data['lead_id']);
        $referral = $service->captureFromLead($lead, $data);

        return Reply::successWithData('Referral captured.', ['referral' => $referral]);
    }
}
