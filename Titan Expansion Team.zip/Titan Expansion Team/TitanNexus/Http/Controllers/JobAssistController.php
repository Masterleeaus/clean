<?php

namespace Modules\TitanNexus\Http\Controllers;

use App\Helper\Reply;
use App\Http\Controllers\AccountBaseController;
use Illuminate\Http\Request;

class JobAssistController extends AccountBaseController
{
    public function __invoke(Request $request)
    {
        return Reply::successWithData('Titan Nexus request accepted.', [
            'controller' => 'JobAssistController',
            'description' => 'job communication endpoint',
            'company_id' => function_exists('tenant_company_id') ? tenant_company_id() : null,
        ]);
    }
}
