<?php

namespace Modules\TitanNexus\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class LaunchCampaignRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:191'],
            'vertical' => ['nullable', 'string', 'max:100'],
            'channel' => ['nullable', 'string', 'max:50'],
            'payload' => ['nullable', 'array'],
            'metadata' => ['nullable', 'array'],
        ];
    }

    public function toModelData(): array
    {
        $data = $this->validated();
        $data['company_id'] = tenant_company_id();
        $data['user_id'] = function_exists('user') && user() ? user()->id : null;
        $data['status'] = 'queued';

        return $data;
    }
}
