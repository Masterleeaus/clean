<?php

namespace Modules\TitanNexus\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;

class StoreLeadRecordRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    public function rules(): array
    {
        return [
            'name' => ['required', 'string', 'max:191'],
            'email' => ['nullable', 'email', 'max:191'],
            'phone' => ['nullable', 'string', 'max:50'],
            'source' => ['nullable', 'string', 'max:100'],
            'score' => ['nullable', 'integer', 'min:0', 'max:100'],
            'payload' => ['nullable', 'array'],
            'metadata' => ['nullable', 'array'],
        ];
    }

    public function toModelData(): array
    {
        $data = $this->validated();
        $data['company_id'] = tenant_company_id();
        $data['user_id'] = function_exists('user') && user() ? user()->id : null;
        $data['status'] = $data['status'] ?? 'lead_capture';
        $data['score'] = $data['score'] ?? 0;

        return $data;
    }
}
