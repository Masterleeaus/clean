<?php class QualifiedToBookedTransition {}
