<?php class LeadRepliedCondition {}
