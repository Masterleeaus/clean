<?php

use Illuminate\Support\Facades\Schema;

if (! function_exists('titan_nexus_feature')) {
    function titan_nexus_feature(string $name): string
    {
        return 'titan-nexus.'.$name;
    }
}

if (! function_exists('tenant_company_id')) {
    function tenant_company_id(): ?int
    {
        if (function_exists('company') && company()) {
            return (int) company()->id;
        }

        if (function_exists('user') && user() && isset(user()->company_id)) {
            return (int) user()->company_id;
        }

        return null;
    }
}

if (! function_exists('titan_nexus_permissions')) {
    function titan_nexus_permissions(): array
    {
        return config('titannexus.permissions', require __DIR__.'/../Config/permissions.php');
    }
}
