<?php

namespace Modules\TitanNexus\Console;

use Illuminate\Console\Command;
use Modules\TitanNexus\Database\Seeders\TitanNexusPermissionSeeder;

class ActivateTitanNexusCommand extends Command
{
    protected $signature = 'titannexus:activate';
    protected $description = 'Activate TitanNexus permissions and WorkSuite-native defaults.';

    public function handle(): int
    {
        $this->call('db:seed', ['--class' => TitanNexusPermissionSeeder::class, '--force' => true]);
        $this->info('TitanNexus activated.');
        return self::SUCCESS;
    }
}
