<?php

namespace Modules\TitanNexus\Providers;

/** Compatibility alias for WorkSuite/Nwidart module discovery. */
class ModuleServiceProvider extends TitanNexusServiceProvider
{
}
