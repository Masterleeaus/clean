<?php

namespace Modules\TitanNexus\Providers;

use Illuminate\Foundation\Support\Providers\RouteServiceProvider as ServiceProvider;
use Illuminate\Support\Facades\Route;

class RouteServiceProvider extends ServiceProvider
{
    protected string $moduleNamespace = 'Modules\TitanNexus\Http\Controllers';

    public function boot(): void
    {
        parent::boot();
    }

    public function map(): void
    {
        $this->mapWebRoutes();
        $this->mapApiRoutes();
    }

    protected function mapWebRoutes(): void
    {
        Route::middleware(['web', 'auth', 'multi-company-select', 'email_verified'])
            ->prefix('account/titan-nexus')
            ->as('titannexus.')
            ->namespace($this->moduleNamespace)
            ->group(__DIR__.'/../Routes/web.php');
    }

    protected function mapApiRoutes(): void
    {
        Route::middleware(['api', 'auth:sanctum'])
            ->prefix('api/titan-nexus')
            ->as('api.titannexus.')
            ->namespace($this->moduleNamespace)
            ->group(__DIR__.'/../Routes/api.php');
    }
}
