<?php

namespace Modules\TitanNexus\Providers;

use Illuminate\Support\ServiceProvider;

class TitanNexusServiceProvider extends ServiceProvider
{
    protected string $moduleName = 'TitanNexus';
    protected string $moduleNameLower = 'titannexus';

    public function register(): void
    {
        $this->mergeConfigFrom(__DIR__.'/../Config/config.php', $this->moduleNameLower);
        $this->mergeConfigFrom(__DIR__.'/../Config/permissions.php', $this->moduleNameLower.'.permissions');
        $this->app->register(RouteServiceProvider::class);
        $this->app->register(EventServiceProvider::class);
        $this->app->register(AuthServiceProvider::class);
    }

    public function boot(): void
    {
        if ($this->app->runningInConsole()) {
            $this->commands([\Modules\TitanNexus\Console\ActivateTitanNexusCommand::class]);
        }

        $this->loadViewsFrom(__DIR__.'/../Resources/views', $this->moduleNameLower);
        $this->loadTranslationsFrom(__DIR__.'/../Resources/lang', $this->moduleNameLower);
        $this->loadMigrationsFrom(__DIR__.'/../Database/Migrations');

        if (file_exists(__DIR__.'/../Helpers/nexus.php')) {
            require_once __DIR__.'/../Helpers/nexus.php';
        }
    }
}
