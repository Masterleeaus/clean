<?php

namespace Modules\TitanNexus\Providers;

use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    protected $listen = [
        \Modules\TitanNexus\Events\LeadCaptured::class => [
            \Modules\TitanNexus\Listeners\ScoreCapturedLead::class,
        ],
        \Modules\TitanNexus\Events\LeadQualified::class => [
            \Modules\TitanNexus\Listeners\CreateDealFromQualifiedLead::class,
        ],
    ];
}
