<?php

return [
    'label' => 'Business Growth',
    'route' => 'titannexus.dashboard',
    'permission' => 'view_titan_nexus',
    'items' => [
        ['label' => 'Dashboard', 'route' => 'titannexus.dashboard', 'permission' => 'view_titan_nexus'],
        ['label' => 'Leads', 'route' => 'titannexus.leads.index', 'permission' => 'view_titan_nexus'],
        ['label' => 'CRM', 'route' => 'titannexus.crm.index', 'permission' => 'view_titan_nexus'],
        ['label' => 'Campaigns', 'route' => 'titannexus.campaigns.index', 'permission' => 'manage_titan_nexus_campaigns'],
        ['label' => 'Pipelines', 'route' => 'titannexus.pipelines.index', 'permission' => 'manage_titan_nexus_automations'],
        ['label' => 'Booking / Quote', 'route' => 'titannexus.booking-handoffs.index', 'permission' => 'manage_titan_nexus_automations'],
        ['label' => 'Vertical Builder', 'route' => 'titannexus.vertical-builder.index', 'permission' => 'manage_titan_nexus_settings'],
        ['label' => 'Automations', 'route' => 'titannexus.automations.index', 'permission' => 'manage_titan_nexus_automations'],
        ['label' => 'Voice', 'route' => 'titannexus.voice.index', 'permission' => 'manage_titan_nexus_automations'],
        ['label' => 'Communications', 'route' => 'titannexus.communications.index', 'permission' => 'manage_titan_nexus_communications'],
        ['label' => 'Reviews', 'route' => 'titannexus.reviews.index', 'permission' => 'manage_titan_nexus_reviews'],
        ['label' => 'Referrals', 'route' => 'titannexus.referrals.index', 'permission' => 'manage_titan_nexus_referrals'],
        ['label' => 'Analytics', 'route' => 'titannexus.analytics.index', 'permission' => 'view_titan_nexus_analytics'],
        ['label' => 'AI Assistant', 'route' => 'titannexus.ai-assistant.index', 'permission' => 'manage_titan_nexus_automations'],
        ['label' => 'Settings', 'route' => 'titannexus.settings.index', 'permission' => 'manage_titan_nexus_settings'],
    ],
];
