<?php

return [
    'name' => 'TitanNexus',
    'ui' => [
        'blade' => true,
        'bootstrap' => true,
        'filament' => false,
    ],
    'tenant_key' => 'company_id',
];
