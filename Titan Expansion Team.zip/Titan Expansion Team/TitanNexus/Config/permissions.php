<?php

return [
    'view_titan_nexus',
    'add_titan_nexus_leads',
    'edit_titan_nexus_leads',
    'delete_titan_nexus_leads',
    'manage_titan_nexus_campaigns',
    'manage_titan_nexus_automations',
    'manage_titan_nexus_communications',
    'manage_titan_nexus_reviews',
    'manage_titan_nexus_referrals',
    'view_titan_nexus_analytics',
    'manage_titan_nexus_settings',
];
