<?php

namespace Modules\TitanNexus\Events;

use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class LeadCaptured
{
    use Dispatchable, SerializesModels;

    public function __construct(public array $payload) {}
}
