@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <div>
            <h4 class="mb-1">Titan Nexus</h4>
            <p class="text-muted mb-0">Business Growth Engine: lifecycle, leads, campaigns, handoffs, follow-up and retention.</p>
        </div>
    </div>

    <div class="row mb-4">
        <div class="col-md-3 mb-3"><div class="card h-100"><div class="card-body"><h3 class="mb-1">{{ $leadCount ?? 0 }}</h3><small class="text-muted">Company Leads</small></div></div></div>
        <div class="col-md-3 mb-3"><div class="card h-100"><div class="card-body"><h3 class="mb-1">{{ $campaignCount ?? 0 }}</h3><small class="text-muted">Campaigns</small></div></div></div>
        <div class="col-md-3 mb-3"><div class="card h-100"><div class="card-body"><h3 class="mb-1">{{ $handoffCount ?? 0 }}</h3><small class="text-muted">Booking / Quote Handoffs</small></div></div></div>
        <div class="col-md-3 mb-3"><div class="card h-100"><div class="card-body"><h3 class="mb-1">{{ $transitionCount ?? 0 }}</h3><small class="text-muted">Lifecycle Audit Events</small></div></div></div>
    </div>

    <div class="row mb-4">
        <div class="col-md-4 mb-3"><div class="card h-100"><div class="card-body"><h3 class="mb-1">{{ $communicationCount ?? 0 }}</h3><small class="text-muted">Communications Queued</small></div></div></div>
        <div class="col-md-4 mb-3"><div class="card h-100"><div class="card-body"><h3 class="mb-1">{{ $reviewCount ?? 0 }}</h3><small class="text-muted">Review Requests</small></div></div></div>
        <div class="col-md-4 mb-3"><div class="card h-100"><div class="card-body"><h3 class="mb-1">{{ $referralCount ?? 0 }}</h3><small class="text-muted">Referrals Captured</small></div></div></div>
    </div>

    <div class="row">
        @foreach($stages as $stage)
            <div class="col-md-3 mb-3">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h6 class="mb-1">{{ \Illuminate\Support\Str::title(str_replace('_', ' ', $stage)) }}</h6>
                                <small class="text-muted">Auditable lifecycle stage</small>
                            </div>
                            <span class="badge bg-light text-dark">{{ $stageCounts[$stage] ?? 0 }}</span>
                        </div>
                    </div>
                </div>
            </div>
        @endforeach
    </div>
</div>
@endsection
