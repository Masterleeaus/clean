@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Titan Nexus Campaigns</h4>
            <p class="text-muted mb-0">Native campaign queue for Business Growth automation.</p>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="POST" action="{{ route('titannexus.campaigns.launch') }}" class="row g-3">
                @csrf
                <div class="col-md-4"><input name="name" class="form-control" placeholder="Campaign name" required></div>
                <div class="col-md-3"><input name="vertical" class="form-control" placeholder="Vertical"></div>
                <div class="col-md-3"><input name="channel" class="form-control" placeholder="Channel"></div>
                <div class="col-md-2"><button class="btn btn-primary w-100" type="submit">Queue</button></div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-hover mb-0">
                <thead><tr><th>Name</th><th>Vertical</th><th>Channel</th><th>Status</th><th>Created</th></tr></thead>
                <tbody>
                @forelse(($campaigns ?? []) as $campaign)
                    <tr>
                        <td>{{ $campaign->name }}</td>
                        <td>{{ $campaign->vertical }}</td>
                        <td>{{ $campaign->channel }}</td>
                        <td><span class="badge bg-light text-dark">{{ $campaign->status }}</span></td>
                        <td>{{ optional($campaign->created_at)->format('Y-m-d') }}</td>
                    </tr>
                @empty
                    <tr><td colspan="5" class="text-muted">No campaigns queued yet.</td></tr>
                @endforelse
                </tbody>
            </table>

            @if(isset($campaigns) && method_exists($campaigns, 'links'))
                <div class="mt-3">{{ $campaigns->links() }}</div>
            @endif
        </div>
    </div>
</div>
@endsection
