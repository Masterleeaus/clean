@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <h4 class="mb-3">{{ $title ?? 'Titan Nexus' }}</h4>
    <div class="card"><div class="card-body">This area is reserved for the native WorkSuite implementation.</div></div>
</div>
@endsection
