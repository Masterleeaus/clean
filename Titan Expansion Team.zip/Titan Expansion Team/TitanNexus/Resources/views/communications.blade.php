@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Communications</h4>
            <p class="text-muted mb-0">Company-scoped outbound/inbound message queue for lead, campaign and lifecycle follow-up.</p>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="POST" action="{{ route('titannexus.communications.store') }}" class="row g-3">
                @csrf
                <div class="col-md-2"><input name="lead_id" class="form-control" placeholder="Lead ID" required></div>
                <div class="col-md-2"><input name="channel" class="form-control" placeholder="email/sms/whatsapp" value="email" required></div>
                <div class="col-md-4"><input name="subject" class="form-control" placeholder="Subject"></div>
                <div class="col-md-2"><input name="scheduled_at" type="datetime-local" class="form-control"></div>
                <div class="col-md-2"><button class="btn btn-primary w-100" type="submit">Queue</button></div>
                <div class="col-md-12"><textarea name="body" class="form-control" rows="2" placeholder="Message body"></textarea></div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-hover mb-0">
                <thead><tr><th>ID</th><th>Lead</th><th>Channel</th><th>Direction</th><th>Subject</th><th>Status</th><th>Scheduled</th><th>Created</th></tr></thead>
                <tbody>
                @forelse(($communications ?? []) as $communication)
                    <tr>
                        <td>{{ $communication->id }}</td>
                        <td>{{ optional($communication->lead)->name ?: $communication->lead_id }}</td>
                        <td>{{ $communication->channel }}</td>
                        <td>{{ $communication->direction }}</td>
                        <td>{{ $communication->subject ?: '-' }}</td>
                        <td><span class="badge bg-light text-dark">{{ $communication->status }}</span></td>
                        <td>{{ optional($communication->scheduled_at)->format('Y-m-d H:i') ?: '-' }}</td>
                        <td>{{ optional($communication->created_at)->format('Y-m-d') }}</td>
                    </tr>
                @empty
                    <tr><td colspan="8" class="text-muted">No communications queued yet.</td></tr>
                @endforelse
                </tbody>
            </table>

            @if(isset($communications) && method_exists($communications, 'links'))
                <div class="mt-3">{{ $communications->links() }}</div>
            @endif
        </div>
    </div>
</div>
@endsection
