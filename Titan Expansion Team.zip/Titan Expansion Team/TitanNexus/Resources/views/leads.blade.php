@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Titan Nexus Leads</h4>
            <p class="text-muted mb-0">Company-scoped WorkSuite lead lifecycle records.</p>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="POST" action="{{ route('titannexus.leads.store') }}" class="row g-3">
                @csrf
                <div class="col-md-3"><input name="name" class="form-control" placeholder="Lead name" required></div>
                <div class="col-md-3"><input name="email" type="email" class="form-control" placeholder="Email"></div>
                <div class="col-md-2"><input name="phone" class="form-control" placeholder="Phone"></div>
                <div class="col-md-2"><input name="source" class="form-control" placeholder="Source"></div>
                <div class="col-md-2"><button class="btn btn-primary w-100" type="submit">Capture</button></div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-hover mb-0">
                <thead><tr><th>Name</th><th>Contact</th><th>Source</th><th>Status</th><th>Score</th><th>Created</th></tr></thead>
                <tbody>
                @forelse(($leads ?? []) as $lead)
                    <tr>
                        <td>{{ $lead->name }}</td>
                        <td>{{ $lead->email ?: $lead->phone }}</td>
                        <td>{{ $lead->source }}</td>
                        <td><span class="badge bg-light text-dark">{{ str_replace('_', ' ', $lead->status) }}</span></td>
                        <td>{{ $lead->score }}</td>
                        <td>{{ optional($lead->created_at)->format('Y-m-d') }}</td>
                    </tr>
                @empty
                    <tr><td colspan="6" class="text-muted">No Titan Nexus leads captured yet.</td></tr>
                @endforelse
                </tbody>
            </table>

            @if(isset($leads) && method_exists($leads, 'links'))
                <div class="mt-3">{{ $leads->links() }}</div>
            @endif
        </div>
    </div>
</div>
@endsection
