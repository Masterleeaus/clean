@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Booking / Quote Handoffs</h4>
            <p class="text-muted mb-0">TitanNexus prepares booking payloads; BookingModule owns scheduling, WorkSuite Events owns calendar visibility, and ZeroPay owns payment collection.</p>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="POST" action="{{ route('titannexus.booking-handoffs.store') }}" class="row g-3">
                @csrf
                <div class="col-md-3"><input name="lead_id" class="form-control" placeholder="Lead ID" required></div>
                <div class="col-md-2"><input name="amount" type="number" step="0.01" class="form-control" placeholder="Amount"></div>
                <div class="col-md-2"><input name="currency" class="form-control" placeholder="Currency"></div>
                <div class="col-md-3"><input name="scheduled_at" type="datetime-local" class="form-control"></div>
                <div class="col-md-2"><button class="btn btn-primary w-100" type="submit">Create Handoff</button></div>
                <div class="col-md-12"><textarea name="notes" class="form-control" rows="2" placeholder="Booking or quote notes"></textarea></div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-hover mb-0">
                <thead><tr><th>ID</th><th>Lead</th><th>Contact</th><th>Status</th><th>Amount</th><th>Scheduled</th><th>Created</th></tr></thead>
                <tbody>
                @forelse(($handoffs ?? []) as $handoff)
                    <tr>
                        <td>{{ $handoff->id }}</td>
                        <td>{{ optional($handoff->lead)->name ?: $handoff->name }}</td>
                        <td>{{ $handoff->email ?: $handoff->phone }}</td>
                        <td><span class="badge bg-light text-dark">{{ str_replace('_', ' ', $handoff->status) }}</span></td>
                        <td>{{ $handoff->amount ? $handoff->currency.' '.$handoff->amount : '-' }}</td>
                        <td>{{ optional($handoff->scheduled_at)->format('Y-m-d H:i') ?: '-' }}</td>
                        <td>{{ optional($handoff->created_at)->format('Y-m-d') }}</td>
                    </tr>
                @empty
                    <tr><td colspan="7" class="text-muted">No booking handoffs created yet.</td></tr>
                @endforelse
                </tbody>
            </table>

            @if(isset($handoffs) && method_exists($handoffs, 'links'))
                <div class="mt-3">{{ $handoffs->links() }}</div>
            @endif
        </div>
    </div>
</div>
@endsection
