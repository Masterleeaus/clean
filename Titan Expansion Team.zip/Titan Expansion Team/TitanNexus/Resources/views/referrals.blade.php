@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Referrals</h4>
            <p class="text-muted mb-0">Referral capture and reactivation queue for existing customer networks.</p>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="POST" action="{{ route('titannexus.referrals.store') }}" class="row g-3">
                @csrf
                <div class="col-md-2"><input name="lead_id" class="form-control" placeholder="Lead ID" required></div>
                <div class="col-md-3"><input name="referrer_name" class="form-control" placeholder="Referrer name"></div>
                <div class="col-md-3"><input name="referred_name" class="form-control" placeholder="Referred name"></div>
                <div class="col-md-2"><input name="referred_phone" class="form-control" placeholder="Referred phone"></div>
                <div class="col-md-2"><button class="btn btn-primary w-100" type="submit">Capture</button></div>
                <div class="col-md-3"><input name="referrer_email" type="email" class="form-control" placeholder="Referrer email"></div>
                <div class="col-md-3"><input name="referred_email" type="email" class="form-control" placeholder="Referred email"></div>
                <div class="col-md-3"><input name="referrer_phone" class="form-control" placeholder="Referrer phone"></div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-hover mb-0">
                <thead><tr><th>ID</th><th>Referrer</th><th>Referred</th><th>Contact</th><th>Status</th><th>Created</th></tr></thead>
                <tbody>
                @forelse(($referrals ?? []) as $referral)
                    <tr>
                        <td>{{ $referral->id }}</td>
                        <td>{{ $referral->referrer_name ?: optional($referral->lead)->name }}</td>
                        <td>{{ $referral->referred_name ?: '-' }}</td>
                        <td>{{ $referral->referred_email ?: $referral->referred_phone }}</td>
                        <td><span class="badge bg-light text-dark">{{ $referral->status }}</span></td>
                        <td>{{ optional($referral->created_at)->format('Y-m-d') }}</td>
                    </tr>
                @empty
                    <tr><td colspan="6" class="text-muted">No referrals captured yet.</td></tr>
                @endforelse
                </tbody>
            </table>

            @if(isset($referrals) && method_exists($referrals, 'links'))
                <div class="mt-3">{{ $referrals->links() }}</div>
            @endif
        </div>
    </div>
</div>
@endsection
