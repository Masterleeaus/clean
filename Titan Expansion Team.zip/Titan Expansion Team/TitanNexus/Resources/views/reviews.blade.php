@extends('layouts.app')

@section('content')
<div class="content-wrapper">
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div>
            <h4 class="mb-1">Reviews</h4>
            <p class="text-muted mb-0">Review request queue for completed jobs and satisfied customers.</p>
        </div>
    </div>

    <div class="card mb-4">
        <div class="card-body">
            <form method="POST" action="{{ route('titannexus.reviews.store') }}" class="row g-3">
                @csrf
                <div class="col-md-2"><input name="lead_id" class="form-control" placeholder="Lead ID" required></div>
                <div class="col-md-3"><input name="customer_name" class="form-control" placeholder="Customer name"></div>
                <div class="col-md-3"><input name="email" type="email" class="form-control" placeholder="Email"></div>
                <div class="col-md-2"><input name="platform" class="form-control" placeholder="Google/Facebook"></div>
                <div class="col-md-2"><button class="btn btn-primary w-100" type="submit">Queue</button></div>
                <div class="col-md-3"><input name="phone" class="form-control" placeholder="Phone"></div>
                <div class="col-md-3"><input name="requested_at" type="datetime-local" class="form-control"></div>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body table-responsive">
            <table class="table table-hover mb-0">
                <thead><tr><th>ID</th><th>Customer</th><th>Contact</th><th>Platform</th><th>Status</th><th>Requested</th><th>Created</th></tr></thead>
                <tbody>
                @forelse(($reviews ?? []) as $review)
                    <tr>
                        <td>{{ $review->id }}</td>
                        <td>{{ $review->customer_name ?: optional($review->lead)->name }}</td>
                        <td>{{ $review->email ?: $review->phone }}</td>
                        <td>{{ $review->platform ?: '-' }}</td>
                        <td><span class="badge bg-light text-dark">{{ $review->status }}</span></td>
                        <td>{{ optional($review->requested_at)->format('Y-m-d H:i') ?: '-' }}</td>
                        <td>{{ optional($review->created_at)->format('Y-m-d') }}</td>
                    </tr>
                @empty
                    <tr><td colspan="7" class="text-muted">No review requests queued yet.</td></tr>
                @endforelse
                </tbody>
            </table>

            @if(isset($reviews) && method_exists($reviews, 'links'))
                <div class="mt-3">{{ $reviews->links() }}</div>
            @endif
        </div>
    </div>
</div>
@endsection
