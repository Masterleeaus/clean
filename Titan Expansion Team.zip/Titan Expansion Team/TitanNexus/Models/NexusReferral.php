<?php

namespace Modules\TitanNexus\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class NexusReferral extends TenantModel
{
    use SoftDeletes;

    protected $table = 'nexus_referrals';

    protected $fillable = [
        'company_id', 'user_id', 'lead_id', 'referrer_name', 'referrer_email', 'referrer_phone',
        'referred_name', 'referred_email', 'referred_phone', 'status', 'converted_at', 'payload', 'metadata',
    ];

    protected $casts = [
        'converted_at' => 'datetime',
        'payload' => 'array',
        'metadata' => 'array',
    ];

    public function lead(): BelongsTo
    {
        return $this->belongsTo(LeadRecord::class, 'lead_id');
    }
}
