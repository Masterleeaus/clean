<?php

namespace Modules\TitanNexus\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class NexusCampaign extends TenantModel
{
    use SoftDeletes;

    protected $table = 'titan_nexus_campaigns';

    protected $fillable = [
        'company_id',
        'user_id',
        'name',
        'vertical',
        'channel',
        'status',
        'payload',
        'metadata',
    ];

    protected $casts = [
        'payload' => 'array',
        'metadata' => 'array',
    ];
}
