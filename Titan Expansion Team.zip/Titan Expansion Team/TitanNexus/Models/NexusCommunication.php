<?php

namespace Modules\TitanNexus\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class NexusCommunication extends TenantModel
{
    use SoftDeletes;

    protected $table = 'nexus_communications';

    protected $fillable = [
        'company_id', 'user_id', 'lead_id', 'campaign_id', 'channel', 'direction', 'subject', 'body',
        'status', 'scheduled_at', 'sent_at', 'payload', 'metadata',
    ];

    protected $casts = [
        'scheduled_at' => 'datetime',
        'sent_at' => 'datetime',
        'payload' => 'array',
        'metadata' => 'array',
    ];

    public function lead(): BelongsTo
    {
        return $this->belongsTo(LeadRecord::class, 'lead_id');
    }

    public function campaign(): BelongsTo
    {
        return $this->belongsTo(NexusCampaign::class, 'campaign_id');
    }
}
