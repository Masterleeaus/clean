<?php

namespace Modules\TitanNexus\Models;

use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\SoftDeletes;

class NexusReviewRequest extends TenantModel
{
    use SoftDeletes;

    protected $table = 'nexus_review_requests';

    protected $fillable = [
        'company_id', 'user_id', 'lead_id', 'job_id', 'customer_name', 'email', 'phone', 'platform',
        'status', 'requested_at', 'completed_at', 'payload', 'metadata',
    ];

    protected $casts = [
        'requested_at' => 'datetime',
        'completed_at' => 'datetime',
        'payload' => 'array',
        'metadata' => 'array',
    ];

    public function lead(): BelongsTo
    {
        return $this->belongsTo(LeadRecord::class, 'lead_id');
    }
}
