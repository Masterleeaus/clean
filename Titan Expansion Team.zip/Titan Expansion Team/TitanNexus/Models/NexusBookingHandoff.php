<?php

namespace Modules\TitanNexus\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class NexusBookingHandoff extends TenantModel
{
    use SoftDeletes;

    protected $table = 'nexus_booking_handoffs';

    protected $fillable = [
        'company_id',
        'user_id',
        'lead_id',
        'campaign_id',
        'name',
        'email',
        'phone',
        'channel',
        'source',
        'status',
        'stage',
        'amount',
        'currency',
        'payload',
        'metadata',
        'scheduled_at',
        'completed_at',
    ];

    protected $casts = [
        'payload' => 'array',
        'metadata' => 'array',
        'scheduled_at' => 'datetime',
        'completed_at' => 'datetime',
    ];

    public function lead()
    {
        return $this->belongsTo(LeadRecord::class, 'lead_id');
    }

    public function campaign()
    {
        return $this->belongsTo(NexusCampaign::class, 'campaign_id');
    }
}
