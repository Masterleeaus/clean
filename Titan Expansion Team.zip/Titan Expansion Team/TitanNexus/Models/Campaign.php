<?php

namespace Modules\TitanNexus\Models;

/**
 * WorkSuite-native campaign model alias retained for old internal references.
 */
class Campaign extends NexusCampaign
{
}
