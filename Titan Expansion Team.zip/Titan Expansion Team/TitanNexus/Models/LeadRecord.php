<?php

namespace Modules\TitanNexus\Models;

use Illuminate\Database\Eloquent\SoftDeletes;

class LeadRecord extends TenantModel
{
    use SoftDeletes;

    protected $table = 'titan_nexus_leads';

    protected $fillable = [
        'company_id', 'user_id', 'campaign_id', 'name', 'email', 'phone', 'source', 'score', 'status', 'metadata', 'payload',
    ];

    protected $casts = ['metadata' => 'array', 'payload' => 'array'];

    public function scopeForCompany($query, int $companyId)
    {
        return $query->where('company_id', $companyId);
    }
}
