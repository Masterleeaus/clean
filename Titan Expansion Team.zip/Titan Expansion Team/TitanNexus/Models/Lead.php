<?php

namespace Modules\TitanNexus\Models;

/**
 * WorkSuite-native lead model alias retained for old internal references.
 */
class Lead extends LeadRecord
{
}
