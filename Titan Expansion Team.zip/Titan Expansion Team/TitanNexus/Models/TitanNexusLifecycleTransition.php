<?php

namespace Modules\TitanNexus\Models;

class TitanNexusLifecycleTransition extends TenantModel
{
    protected $table = 'titan_nexus_lifecycle_transitions';

    protected $fillable = [
        'company_id',
        'user_id',
        'lead_id',
        'from_stage',
        'to_stage',
        'payload',
        'metadata',
    ];

    protected $casts = [
        'payload' => 'array',
        'metadata' => 'array',
    ];
}
