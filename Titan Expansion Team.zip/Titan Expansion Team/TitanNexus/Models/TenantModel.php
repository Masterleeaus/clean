<?php

namespace Modules\TitanNexus\Models;

use Illuminate\Database\Eloquent\Model;
use Modules\TitanNexus\Models\Scopes\TenantScope;

abstract class TenantModel extends Model
{
    protected static function booted(): void
    {
        static::addGlobalScope(new TenantScope());

        static::creating(function (Model $model): void {
            if (! $model->getAttribute('company_id') && function_exists('tenant_company_id')) {
                $model->setAttribute('company_id', tenant_company_id());
            }
        });
    }
}
