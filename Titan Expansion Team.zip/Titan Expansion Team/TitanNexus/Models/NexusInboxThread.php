<?php

namespace Modules\TitanNexus\Models;

class NexusInboxThread extends TenantModel
{
    protected $table = 'nexus_inbox_threads';

    protected $fillable = [
        'company_id', 'user_id', 'lead_id', 'campaign_id', 'name', 'title', 'email', 'phone',
        'channel', 'source', 'status', 'stage', 'score', 'amount', 'currency',
        'payload', 'metadata', 'due_at', 'paid_at', 'scheduled_at', 'completed_at',
    ];

    protected $casts = ['payload' => 'array', 'metadata' => 'array', 'due_at' => 'datetime', 'paid_at' => 'datetime', 'scheduled_at' => 'datetime', 'completed_at' => 'datetime'];
}
