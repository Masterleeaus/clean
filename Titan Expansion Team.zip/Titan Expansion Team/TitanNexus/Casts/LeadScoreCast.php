<?php class LeadScoreCast {}
