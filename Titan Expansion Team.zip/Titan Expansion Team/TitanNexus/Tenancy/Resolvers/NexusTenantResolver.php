<?php

namespace Modules\TitanNexus\Tenancy\Resolvers;

final class NexusTenantResolver
{
    public function resolve(array $context): ?int
    {
        if (function_exists('tenant_company_id') && tenant_company_id()) {
            return tenant_company_id();
        }

        return isset($context['company_id']) ? (int) $context['company_id'] : null;
    }
}
