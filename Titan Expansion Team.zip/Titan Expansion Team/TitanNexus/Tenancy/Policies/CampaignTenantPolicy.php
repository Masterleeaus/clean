<?php

namespace Modules\TitanNexus\Tenancy\Policies;

final class CampaignTenantPolicy
{
    public function canAccess(?int $companyId, array $campaign): bool
    {
        return (int) ($campaign['company_id'] ?? 0) === (int) $companyId;
    }
}
