<?php
// Voice webhooks must be registered through Routes/api.php with signed/verified provider handlers.
