<?php

use Illuminate\Support\Facades\Route;
use Modules\TitanNexus\Http\Controllers\BookingHandoffController;
use Modules\TitanNexus\Http\Controllers\CampaignController;
use Modules\TitanNexus\Http\Controllers\ControlPanelController;
use Modules\TitanNexus\Http\Controllers\CommunicationController;
use Modules\TitanNexus\Http\Controllers\ReferralController;
use Modules\TitanNexus\Http\Controllers\ReviewRequestController;
use Modules\TitanNexus\Http\Controllers\LeadController;
use Modules\TitanNexus\Http\Controllers\UnifiedInboxController;

Route::get('/', [ControlPanelController::class, 'dashboard'])->name('dashboard');

Route::get('/leads', [LeadController::class, 'index'])->name('leads.index');
Route::post('/leads', [LeadController::class, 'store'])->name('leads.store');
Route::post('/leads/{lead}/advance', [LeadController::class, 'advance'])->name('leads.advance');

Route::get('/booking-handoffs', [BookingHandoffController::class, 'index'])->name('booking-handoffs.index');
Route::post('/booking-handoffs', [BookingHandoffController::class, 'store'])->name('booking-handoffs.store');

Route::get('/campaigns', [CampaignController::class, 'index'])->name('campaigns.index');
Route::post('/campaigns/launch', [CampaignController::class, 'launch'])->name('campaigns.launch');

Route::post('/inbox', [UnifiedInboxController::class, 'store'])->name('inbox.store');

Route::view('/crm', 'titannexus::placeholder', ['title' => 'CRM'])->name('crm.index');
Route::view('/pipelines', 'titannexus::placeholder', ['title' => 'Pipelines'])->name('pipelines.index');
Route::view('/vertical-builder', 'titannexus::placeholder', ['title' => 'Vertical Builder'])->name('vertical-builder.index');
Route::view('/automations', 'titannexus::placeholder', ['title' => 'Automations'])->name('automations.index');
Route::view('/voice', 'titannexus::placeholder', ['title' => 'Voice'])->name('voice.index');
Route::get('/communications', [CommunicationController::class, 'index'])->name('communications.index');
Route::post('/communications', [CommunicationController::class, 'store'])->name('communications.store');
Route::get('/reviews', [ReviewRequestController::class, 'index'])->name('reviews.index');
Route::post('/reviews', [ReviewRequestController::class, 'store'])->name('reviews.store');
Route::get('/referrals', [ReferralController::class, 'index'])->name('referrals.index');
Route::post('/referrals', [ReferralController::class, 'store'])->name('referrals.store');
Route::view('/analytics', 'titannexus::placeholder', ['title' => 'Analytics'])->name('analytics.index');
Route::view('/ai-assistant', 'titannexus::placeholder', ['title' => 'AI Assistant'])->name('ai-assistant.index');
Route::view('/settings', 'titannexus::placeholder', ['title' => 'Settings'])->name('settings.index');
