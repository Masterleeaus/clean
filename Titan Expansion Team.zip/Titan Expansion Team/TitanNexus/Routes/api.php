<?php

use Illuminate\Support\Facades\Route;
use Modules\TitanNexus\Http\Controllers\ChannelWebhookController;
use Modules\TitanNexus\Http\Controllers\InvoiceController;
use Modules\TitanNexus\Http\Controllers\PaymentController;
use Modules\TitanNexus\Http\Controllers\JobAssistController;
use Modules\TitanNexus\Http\Controllers\MarketingAgentController;

Route::post('agent/run', [MarketingAgentController::class, '__invoke'])->name('agent.run');
Route::post('webhooks/channel', [ChannelWebhookController::class, 'receive'])->name('webhooks.channel');
Route::post('invoices/followup', [InvoiceController::class, '__invoke'])->name('invoices.followup');
Route::post('payments/link', [PaymentController::class, '__invoke'])->name('payments.link');
Route::post('jobs/assist', [JobAssistController::class, '__invoke'])->name('jobs.assist');
