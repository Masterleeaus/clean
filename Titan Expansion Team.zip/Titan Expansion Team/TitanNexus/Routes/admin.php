<?php
// Admin routes intentionally disabled; TitanNexus uses native WorkSuite account routes.
