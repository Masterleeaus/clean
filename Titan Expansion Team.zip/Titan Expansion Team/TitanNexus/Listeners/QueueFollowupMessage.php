<?php class QueueFollowupMessage {}
