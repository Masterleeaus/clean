<?php
namespace Modules\TitanNexus\Search\Indexes;
class NexusPaymentIndex { public function fields(): array { return ['id','company_id','status','updated_at']; } }
