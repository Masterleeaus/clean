<?php
namespace Modules\TitanNexus\Search\Indexes;
class NexusInvoiceIndex { public function fields(): array { return ['id','company_id','status','updated_at']; } }
