<?php

namespace Modules\TitanNexus\Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class TitanNexusPermissionSeeder extends Seeder
{
    public function run(): void
    {
        if (! DB::getSchemaBuilder()->hasTable('permissions')) {
            return;
        }

        foreach (config('titannexus.permissions', []) as $permission) {
            DB::table('permissions')->updateOrInsert(
                ['name' => $permission],
                [
                    'display_name' => ucwords(str_replace('_', ' ', $permission)),
                    'guard_name' => 'web',
                    'is_custom' => 1,
                    'created_at' => now(),
                    'updated_at' => now(),
                ]
            );
        }
    }
}
