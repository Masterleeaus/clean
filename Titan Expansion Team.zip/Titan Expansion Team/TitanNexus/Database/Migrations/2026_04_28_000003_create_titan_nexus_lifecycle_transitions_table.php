<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_nexus_lifecycle_transitions')) {
            return;
        }

        Schema::create('titan_nexus_lifecycle_transitions', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->unsignedBigInteger('lead_id')->index();
            $table->string('from_stage')->index();
            $table->string('to_stage')->index();
            $table->json('payload')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->index(['company_id', 'lead_id']);
            $table->index(['company_id', 'to_stage']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_nexus_lifecycle_transitions');
    }
};
