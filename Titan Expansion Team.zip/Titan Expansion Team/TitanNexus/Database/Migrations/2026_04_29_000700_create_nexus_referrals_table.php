<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('nexus_referrals')) {
            return;
        }

        Schema::create('nexus_referrals', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->unsignedBigInteger('lead_id')->nullable()->index();
            $table->string('referrer_name')->nullable();
            $table->string('referrer_email')->nullable()->index();
            $table->string('referrer_phone')->nullable()->index();
            $table->string('referred_name')->nullable();
            $table->string('referred_email')->nullable()->index();
            $table->string('referred_phone')->nullable()->index();
            $table->string('status')->default('captured')->index();
            $table->timestamp('converted_at')->nullable()->index();
            $table->json('payload')->nullable();
            $table->json('metadata')->nullable();
            $table->timestamps();
            $table->softDeletes();

            $table->index(['company_id', 'status']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('nexus_referrals');
    }
};
