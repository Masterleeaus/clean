<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (Schema::hasTable('titan_nexus_lifecycle_logs')) {
            return;
        }

        Schema::create('titan_nexus_lifecycle_logs', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('company_id')->index();
            $table->unsignedBigInteger('user_id')->nullable()->index();
            $table->unsignedBigInteger('entity_id')->index();
            $table->string('entity_type')->default('lead')->index();
            $table->string('from_stage')->nullable()->index();
            $table->string('to_stage')->index();
            $table->json('metadata')->nullable();
            $table->timestamps();

            $table->index(['company_id', 'entity_type', 'entity_id'], 'tn_lifecycle_company_entity_idx');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('titan_nexus_lifecycle_logs');
    }
};
