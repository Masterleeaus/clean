<?php

return [
    'status' => 'report_only',
    'message' => 'Run TitanNexus WorkSuite validation before boot.',
];
