<?php class CampaignObserver {}
