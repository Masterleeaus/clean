<?php
namespace Modules\TitanNexus\Repositories; class MessageRepository { public function create(array $payload): array { return $payload; } public function find(string|int $id): ?array { return null; } }
