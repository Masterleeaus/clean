<?php

namespace Modules\TitanNexus\Services\Referrals;

use Modules\TitanNexus\Models\LeadRecord;
use Modules\TitanNexus\Models\NexusReferral;

class ReferralService
{
    public function captureFromLead(LeadRecord $lead, array $data): NexusReferral
    {
        return NexusReferral::create([
            'lead_id' => $lead->id,
            'referrer_name' => $data['referrer_name'] ?? $lead->name,
            'referrer_email' => $data['referrer_email'] ?? $lead->email,
            'referrer_phone' => $data['referrer_phone'] ?? $lead->phone,
            'referred_name' => $data['referred_name'] ?? null,
            'referred_email' => $data['referred_email'] ?? null,
            'referred_phone' => $data['referred_phone'] ?? null,
            'status' => $data['status'] ?? 'captured',
            'payload' => $data['payload'] ?? [],
            'metadata' => [
                'source' => 'titan_nexus_native',
                'lead_status' => $lead->status,
            ],
        ]);
    }
}
