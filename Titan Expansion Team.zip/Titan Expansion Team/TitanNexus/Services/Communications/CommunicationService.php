<?php

namespace Modules\TitanNexus\Services\Communications;

use Modules\TitanNexus\Models\LeadRecord;
use Modules\TitanNexus\Models\NexusCommunication;

class CommunicationService
{
    public function queueForLead(LeadRecord $lead, array $data): NexusCommunication
    {
        return NexusCommunication::create([
            'lead_id' => $lead->id,
            'campaign_id' => $lead->campaign_id,
            'channel' => $data['channel'] ?? 'email',
            'direction' => $data['direction'] ?? 'outbound',
            'subject' => $data['subject'] ?? null,
            'body' => $data['body'] ?? null,
            'status' => $data['status'] ?? 'queued',
            'scheduled_at' => $data['scheduled_at'] ?? null,
            'payload' => $data['payload'] ?? [],
            'metadata' => [
                'source' => 'titan_nexus_native',
                'lead_status' => $lead->status,
            ],
        ]);
    }
}
