<?php

namespace Modules\TitanNexus\Services\Lifecycle;

use InvalidArgumentException;
use Modules\TitanNexus\Events\LeadCaptured;
use Modules\TitanNexus\Events\LeadQualified;
use Modules\TitanNexus\Models\LeadRecord;
use Modules\TitanNexus\Models\TitanNexusLifecycleTransition;

class LifecycleTransitionService
{
    public function transition(LeadRecord $lead, string $toStage, array $payload = []): TitanNexusLifecycleTransition
    {
        return $this->moveTo($lead, $toStage, $payload, true);
    }

    public function moveTo(LeadRecord $lead, string $toStage, array $payload = [], bool $strictNext = false): TitanNexusLifecycleTransition
    {
        $stages = config('titannexus.lifecycle_stages', []);
        $fromStage = $lead->status ?: 'lead_capture';

        if (! in_array($fromStage, $stages, true) || ! in_array($toStage, $stages, true)) {
            throw new InvalidArgumentException('Invalid Titan Nexus lifecycle stage.');
        }

        $fromIndex = array_search($fromStage, $stages, true);
        $toIndex = array_search($toStage, $stages, true);

        if ($strictNext && $toIndex !== $fromIndex + 1) {
            throw new InvalidArgumentException('Lifecycle transitions must move one deterministic stage at a time.');
        }

        if ($toIndex < $fromIndex) {
            throw new InvalidArgumentException('Lifecycle transitions cannot move backwards.');
        }

        $lead->forceFill(['status' => $toStage])->save();

        $transition = TitanNexusLifecycleTransition::create([
            'company_id' => tenant_company_id(),
            'user_id' => function_exists('user') && user() ? user()->id : null,
            'lead_id' => $lead->id,
            'from_stage' => $fromStage,
            'to_stage' => $toStage,
            'payload' => $payload,
            'metadata' => [
                'source' => $payload['source'] ?? 'worksuite_native_controller',
                'strict_next' => $strictNext,
                'transitioned_at' => now()->toDateTimeString(),
            ],
        ]);

        if ($toStage === 'lead_capture' && class_exists(LeadCaptured::class)) {
            event(new LeadCaptured($transition->toArray()));
        }

        if ($toStage === 'lead_qualification' && class_exists(LeadQualified::class)) {
            event(new LeadQualified($transition->toArray()));
        }

        return $transition;
    }

    public function nextStageFor(string $stage): ?string
    {
        $stages = config('titannexus.lifecycle_stages', []);
        $index = array_search($stage, $stages, true);

        if ($index === false) {
            return null;
        }

        return $stages[$index + 1] ?? null;
    }
}
