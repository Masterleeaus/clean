<?php

namespace Modules\TitanNexus\Services;

use Modules\TitanNexus\Events\LeadQualified;
use Modules\TitanNexus\Models\LeadRecord;

class UnifiedLeadIngestService
{
    public function ingest(array $payload, string $source = 'legacy'): LeadRecord
    {
        $lead = LeadRecord::create([
            'company_id' => tenant_company_id(),
            'user_id' => function_exists('user') && user() ? user()->id : null,
            'name' => $payload['name'] ?? $payload['full_name'] ?? $payload['contact_name'] ?? 'Unknown Lead',
            'email' => $payload['email'] ?? null,
            'phone' => $payload['phone'] ?? $payload['mobile'] ?? null,
            'source' => $source,
            'score' => (int) ($payload['score'] ?? 0),
            'status' => ($payload['qualified'] ?? false) === true ? 'lead_qualification' : 'lead_capture',
            'payload' => $payload,
            'metadata' => [
                'ingested_by' => static::class,
                'company' => $payload['company'] ?? $payload['business_name'] ?? null,
            ],
        ]);

        if (($payload['qualified'] ?? false) === true) {
            event(new LeadQualified($lead->toArray()));
        }

        return $lead;
    }
}
