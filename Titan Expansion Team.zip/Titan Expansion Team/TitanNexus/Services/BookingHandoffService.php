<?php

namespace Modules\TitanNexus\Services;

use Modules\TitanNexus\Events\BookingHandoffCreated;
use Modules\TitanNexus\Models\LeadRecord;
use Modules\TitanNexus\Models\NexusBookingHandoff;
use Modules\TitanNexus\Services\Lifecycle\LifecycleTransitionService;

class BookingHandoffService
{
    public function createFromLead(LeadRecord $lead, array $payload = []): NexusBookingHandoff
    {
        $handoff = NexusBookingHandoff::create([
            'company_id' => tenant_company_id(),
            'user_id' => function_exists('user') && user() ? user()->id : null,
            'lead_id' => $lead->id,
            'campaign_id' => $lead->campaign_id,
            'name' => $payload['name'] ?? $lead->name,
            'email' => $payload['email'] ?? $lead->email,
            'phone' => $payload['phone'] ?? $lead->phone,
            'channel' => $payload['channel'] ?? $lead->source,
            'source' => $payload['source'] ?? 'titan_nexus',
            'status' => $payload['status'] ?? 'ready',
            'stage' => 'booking_quote',
            'amount' => $payload['amount'] ?? null,
            'currency' => $payload['currency'] ?? null,
            'scheduled_at' => $payload['scheduled_at'] ?? null,
            'payload' => $payload,
            'metadata' => [
                'created_from' => 'lead_lifecycle',
                'lead_status_at_handoff' => $lead->status,
                'booking_module_contract' => 'BookingModule owns booking lifecycle; WorkSuite Events owns calendar visibility; ZeroPay owns payments.',
            ],
        ]);

        app(LifecycleTransitionService::class)->moveTo($lead, 'booking_quote', [
            'booking_handoff_id' => $handoff->id,
            'source' => 'booking_handoff_service',
        ]);

        event(new BookingHandoffCreated($handoff->toArray()));

        return $handoff;
    }
}
