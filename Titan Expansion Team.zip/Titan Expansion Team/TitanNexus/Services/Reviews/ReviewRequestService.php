<?php

namespace Modules\TitanNexus\Services\Reviews;

use Modules\TitanNexus\Models\LeadRecord;
use Modules\TitanNexus\Models\NexusReviewRequest;

class ReviewRequestService
{
    public function queueForLead(LeadRecord $lead, array $data): NexusReviewRequest
    {
        return NexusReviewRequest::create([
            'lead_id' => $lead->id,
            'customer_name' => $data['customer_name'] ?? $lead->name,
            'email' => $data['email'] ?? $lead->email,
            'phone' => $data['phone'] ?? $lead->phone,
            'platform' => $data['platform'] ?? null,
            'status' => $data['status'] ?? 'queued',
            'requested_at' => $data['requested_at'] ?? now(),
            'payload' => $data['payload'] ?? [],
            'metadata' => [
                'source' => 'titan_nexus_native',
                'lead_status' => $lead->status,
            ],
        ]);
    }
}
