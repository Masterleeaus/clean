# Blueprint Notes

Actions mutate. Services orchestrate. Queries read. WorkSuite Blade consumes.
