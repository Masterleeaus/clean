<?php

return [
    'name' => 'IpAddressAttendance',
];
