<?php

use Illuminate\Support\Facades\Route;
use Modules\IpAddressAttendance\App\Http\Controllers\IpAddressAttendanceController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['web', 'auth'])->group(function () {
    // AJAX endpoints
    Route::get('ipgroup/indexAjax', [IpAddressAttendanceController::class, 'indexAjax'])->name('ipgroup.indexAjax');
    Route::get('ipgroup/getByIdAjax/{id}', [IpAddressAttendanceController::class, 'getByIdAjax'])->name('ipgroup.getByIdAjax');
    Route::post('ipgroup/addOrUpdateAjax', [IpAddressAttendanceController::class, 'addOrUpdateAjax'])->name('ipgroup.addOrUpdateAjax');
    Route::delete('ipgroup/deleteAjax/{id}', [IpAddressAttendanceController::class, 'deleteAjax'])->name('ipgroup.deleteAjax');
    Route::post('ipgroup/changeStatusAjax/{id}', [IpAddressAttendanceController::class, 'changeStatusAjax'])->name('ipgroup.changeStatusAjax');

    // Resource routes (excluding edit and create - handled via offcanvas)
    Route::resource('ipgroup', IpAddressAttendanceController::class)->names('ipgroup')->except(['edit', 'create']);

    // Additional routes
    Route::post('ipgroup/addIpAddress', [IpAddressAttendanceController::class, 'addIpAddress'])->name('ipgroup.addIpAddress');
    Route::post('ipgroup/changeStatus', [IpAddressAttendanceController::class, 'changeStatus'])->name('ipgroup.changeStatus');
    Route::post('ipgroup/changeStatusItem', [IpAddressAttendanceController::class, 'changeStatusItem'])->name('ipgroup.changeStatusItem');
    Route::post('ipgroup/update', [IpAddressAttendanceController::class, 'update'])->name('ipgroup.update');

    // IP Address management routes
    Route::get('ipgroup/ipaddress/{id}', [IpAddressAttendanceController::class, 'getIpAddress'])->name('ipgroup.getIpAddress');
    Route::put('ipgroup/ipaddress/{id}', [IpAddressAttendanceController::class, 'updateIpAddress'])->name('ipgroup.updateIpAddress');
    Route::delete('ipgroup/ipaddress/{id}', [IpAddressAttendanceController::class, 'destroyIpAddress'])->name('ipgroup.deleteIpAddress');
});
