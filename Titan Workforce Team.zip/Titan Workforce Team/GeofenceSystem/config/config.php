<?php

return [
    'name' => 'GeofenceSystem',
];
