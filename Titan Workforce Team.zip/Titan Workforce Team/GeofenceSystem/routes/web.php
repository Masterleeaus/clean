<?php

use Illuminate\Support\Facades\Route;
use Modules\GeofenceSystem\App\Http\Controllers\GeofenceSystemController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['web', 'auth'])->group(function () {
    // AJAX endpoints
    Route::get('geofencegroup/indexAjax', [GeofenceSystemController::class, 'indexAjax'])->name('geofencegroup.indexAjax');
    Route::get('geofencegroup/getByIdAjax/{id}', [GeofenceSystemController::class, 'getByIdAjax'])->name('geofencegroup.getByIdAjax');
    Route::post('geofencegroup/addOrUpdateAjax', [GeofenceSystemController::class, 'addOrUpdateAjax'])->name('geofencegroup.addOrUpdateAjax');
    Route::delete('geofencegroup/deleteAjax/{id}', [GeofenceSystemController::class, 'deleteAjax'])->name('geofencegroup.deleteAjax');
    Route::post('geofencegroup/changeStatusAjax/{id}', [GeofenceSystemController::class, 'changeStatusAjax'])->name('geofencegroup.changeStatusAjax');

    // Resource routes (only index, create, store, show, destroy)
    Route::resource('geofencegroup', GeofenceSystemController::class)->except(['edit', 'update'])->names('geofencegroup');

    // Additional routes
    Route::post('geofencegroup/addLocation', [GeofenceSystemController::class, 'addGeofenceLocation'])->name('geofencegroup.addGeofenceLocation');
    Route::post('geofencegroup/changeStatus', [GeofenceSystemController::class, 'changeStatus'])->name('geofencegroup.changeStatus');
    Route::post('geofencegroup/changeStatusItem', [GeofenceSystemController::class, 'changeStatusItem'])->name('geofencegroup.changeStatusItem');

    // Geofence Location management routes
    Route::get('geofencegroup/location/{id}', [GeofenceSystemController::class, 'getGeofenceLocation'])->name('geofencegroup.getGeofenceLocation');
    Route::put('geofencegroup/location/{id}', [GeofenceSystemController::class, 'updateGeofenceLocation'])->name('geofencegroup.updateGeofenceLocation');
    Route::delete('geofencegroup/location/{id}', [GeofenceSystemController::class, 'destroyGeofenceLocation'])->name('geofencegroup.deleteGeofenceLocation');
});
