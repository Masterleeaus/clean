<?php

return [
    'name' => 'Shifts'
];
