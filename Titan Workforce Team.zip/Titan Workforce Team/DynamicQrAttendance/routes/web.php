<?php

use App\Http\Middleware\AddonCheckMiddleware;
use Illuminate\Support\Facades\Route;
use Modules\DynamicQrAttendance\App\Http\Controllers\DynamicQrDeviceController;
use Stancl\Tenancy\Middleware\InitializeTenancyByDomain;
use Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['middleware' => function ($request, $next) {
  $request->headers->set('addon', ModuleConstants::DYNAMIC_QR_ATTENDANCE);
  return $next($request);
}], function () {
  Route::middleware([
    'api',
    'auth',
    InitializeTenancyByDomain::class,
    PreventAccessFromCentralDomains::class,
    AddonCheckMiddleware::class
  ])->group(function () {
    Route::resource('dynamicqrattendance', DynamicQrDeviceController::class)->names('dynamicqrattendance');
    Route::post('dynamicqrattendance/addOrUpdateAjax', [DynamicQrDeviceController::class, 'addOrUpdateAjax'])->name('dynamicqrattendance.addOrUpdateAjax');

    Route::get('dynamicqrattendance/getByIdAjax/{id}', [DynamicQrDeviceController::class, 'getByIdAjax']);
  });
});
