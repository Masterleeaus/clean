<?php

use Illuminate\Support\Facades\Route;
use Modules\DynamicQrAttendance\App\Http\Api\DynamicQrDeviceApiController;
use Stancl\Tenancy\Middleware\InitializeTenancyByDomain;
use Stancl\Tenancy\Middleware\PreventAccessFromCentralDomains;

/*
 *--------------------------------------------------------------------------
 * API Routes
 *--------------------------------------------------------------------------
 *
 * Here is where you can register API routes for your application. These
 * routes are loaded by the RouteServiceProvider within a group which
 * is assigned the "api" middleware group. Enjoy building your API!
 *
*/

Route::middleware([
  'api',
  InitializeTenancyByDomain::class,
  PreventAccessFromCentralDomains::class,
])->group(function () {

  Route::group([
    'middleware' => 'api',
    'as' => 'api.',
  ], function () {
    Route::group(['prefix' => 'V1'], function () {
      Route::prefix('dynamicQr')->name('dynamicQr')->group(function () {
        Route::get('/checkDevice', [DynamicQrDeviceApiController::class, 'checkDeviceExists']);
        Route::post('/register', [DynamicQrDeviceApiController::class, 'register']);
        Route::get('/getCode', [DynamicQrDeviceApiController::class, 'getCode']);
        Route::post('/logout', [DynamicQrDeviceApiController::class, 'logout']);
      });
    });
  });

  Route::middleware('auth:api')->group(function () {
    Route::group(['prefix' => 'V1'], function () {
      Route::group([
        'middleware' => 'api',
        'as' => 'api.',
      ], function () {
        Route::prefix('dynamicQr')->name('dynamicQr')->group(function () {
          Route::post('/verifyCode', [DynamicQrDeviceApiController::class, 'verifyCode']);
        });
      });
    });
  });
});
