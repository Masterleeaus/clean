<?php

return [
    'name' => 'DynamicQrAttendance',
];
