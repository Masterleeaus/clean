@php
  $title = 'Dynamic QR Devices';
@endphp

@extends('layouts/layoutMaster')

@section('title', $title)

<!-- Vendor Styles -->
@section('vendor-style')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-responsive-bs5/responsive.bootstrap5.scss',
    'resources/assets/vendor/libs/datatables-buttons-bs5/buttons.bootstrap5.scss',
    'resources/assets/vendor/libs/select2/select2.scss',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.scss'
  ])
@endsection

<!-- Vendor Scripts -->
@section('vendor-script')
  @vite([
    'resources/assets/vendor/libs/datatables-bs5/datatables-bootstrap5.js',
    'resources/assets/vendor/libs/select2/select2.js',
    'resources/assets/vendor/libs/sweetalert2/sweetalert2.js'
  ])
@endsection

@section('content')
  <div class="row">
    <div class="col">
      <h4>@lang($title)</h4>
    </div>
    <div class="col">
      <div class="float-end">
        <a href="#" class="btn btn-primary" id="addDeviceBtn" data-bs-toggle="offcanvas"
           data-bs-target="#offcanvasAddDevice">@lang('Create')</a>
      </div>
    </div>
  </div>
  <!-- DataTable Section -->
  <div class="card shadow-sm">
    <div class="card-body">
      <div class="table-responsive">
        <table id="deviceTable" class="table table-bordered table-hover">
          <thead>
          <tr>
            <th>Sl. No</th>
            <th>Name</th>
            <th>UID</th>
            <th>Type</th>
            <th>Created At</th>
            <th>Status</th>
            <th>Used By</th>
            <th>Actions</th>
          </tr>
          </thead>
          <tbody></tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Offcanvas for Add/Update Device -->
  <div class="offcanvas offcanvas-end" tabindex="-1" id="offcanvasAddDevice"
       aria-labelledby="offcanvasAddDeviceLabel">
    <div class="offcanvas-header border-bottom">
      <h5 id="offcanvasAddDeviceLabel" class="offcanvas-title">Add Device</h5>
      <button type="button" class="btn-close text-reset" data-bs-dismiss="offcanvas" aria-label="Close"></button>
    </div>
    <div class="offcanvas-body mx-0 flex-grow-0 p-6 h-100">
      <form class="pt-0" id="deviceForm">
        <input type="hidden" name="id" id="id">

        <!-- Device Name (mandatory) -->
        <div class="mb-4">
          <label class="form-label" for="name">Device Name <span class="text-danger">*</span></label>
          <input type="text" class="form-control" id="name" placeholder="Enter Device Name" name="name"
                 required/>
        </div>

        <!-- Device Unique ID (max length 8, mandatory, auto-generate button) -->
        <div class="mb-4">
          <label class="form-label" for="uniqueId">Device Unique ID <span class="text-danger">*</span></label>
          <div class="input-group">
            <input type="text" class="form-control" id="uniqueId" placeholder="Max 8 chars" name="uniqueId"
                   maxlength="8" required/>
            <button class="btn btn-outline-secondary" type="button" id="generateUidBtn">
              <i class="bi bi-magic"></i> Generate
            </button>
          </div>
        </div>

        <!-- Device Pin (6 digit number, mandatory) -->
        <div class="mb-4">
          <label class="form-label" for="pin">Device Pin (6 digits) <span class="text-danger">*</span></label>
          <input type="number" class="form-control" id="pin" placeholder="e.g., 123456" name="pin"
                 minlength="6" maxlength="6" required/>
        </div>

        <!-- QR Update interval -->
        <div class="mb-4">
          <label class="form-label" for="qrUpdateInterval">QR Update Interval (in seconds)<span
              class="text-danger">*</span></label>
          <input type="number" class="form-control" id="qrUpdateInterval" placeholder="e.g., 60"
                 name="qrUpdateInterval"
                 value="60"/>
        </div>

        <!-- Device Type -->
        <div class="mb-4">
          <label class="form-label" for="deviceType">Device Type</label>
          <select class="form-select" id="deviceType" name="deviceType">
            <option value="android">Android</option>
            <option value="ios">iOS</option>
            <option value="windows">Windows</option>
            <option value="mac">Mac</option>
            <option value="linux">Linux</option>
            <option value="web">Web</option>
            <option value="other" selected>Other</option>
          </select>
        </div>

        <button type="submit" class="btn btn-primary me-3 data-submit">Submit</button>
        <button type="reset" class="btn btn-label-danger" data-bs-dismiss="offcanvas">Cancel</button>
      </form>
    </div>
  </div>
  <!-- /Offcanvas -->

@endsection

@section('page-script')
  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script>
    $(function () {
      $.ajaxSetup({
        headers: {
          'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
      });
      let deviceTable = $('#deviceTable').DataTable({
        processing: true,
        serverSide: true,
        ajax: "{{ route('dynamicqrattendance.index') }}",
        columns: [
          {
            data: null,
            orderable: false,
            searchable: false,
            render: function (data, type, row, meta) {
              return meta.row + 1; // Sl. No
            }
          },
          {data: 'name', name: 'name'},
          {data: 'uniqueId', name: 'uniqueId'},
          {data: 'deviceType', name: 'deviceType'},
          {
            data: 'createdAt',
            name: 'createdAt',
            render: function (data) {
              return data ? data : 'N/A';
            }
          },
          {data: 'status', name: 'status'},
          {data: 'usedBy', name: 'usedBy'},
          {
            data: 'actions',
            orderable: false,
            searchable: false
          }
        ]
      });

      // Open offcanvas for ADD
      $('#addDeviceBtn').on('click', function () {
        /*  $('#deviceForm')[0].reset();
          $('#deviceId').val('');
          $('#offcanvasAddDeviceLabel').text('Add Device');
          $('#offcanvasAddDevice').modal ? $('#offcanvasAddDevice').modal('show')
            : new bootstrap.Offcanvas('#offcanvasAddDevice').show();*/
      });

      // Auto-generate UID (max length = 8)
      $('#generateUidBtn').on('click', function () {
        let uid = Math.random().toString(36).substring(2, 10).toUpperCase();
        $('#uniqueId').val(uid);
      });

      // Save Device (Add or Update)
      $('#deviceForm').on('submit', function (e) {
        e.preventDefault();

        $.ajax({
          url: '{{route('dynamicqrattendance.addOrUpdateAjax')}}',
          type: 'POST',
          data: $('#deviceForm').serialize(),
          success: function (response) {
            // Check if Offcanvas instance exists and hide it
            let offcanvasElement = document.getElementById('offcanvasAddDevice');
            let offcanvasInstance = bootstrap.Offcanvas.getInstance(offcanvasElement);

            if (offcanvasInstance) {
              offcanvasInstance.hide();
            } else {
              offcanvasInstance = new bootstrap.Offcanvas(offcanvasElement);
              offcanvasInstance.hide();
            }

            // Reload the DataTable
            deviceTable.ajax.reload();

            // Show success message
            Swal.fire({
              icon: 'success',
              title: `Successfully created!`,
              text: 'Device created successfully',
              customClass: {
                confirmButton: 'btn btn-success'
              }
            });
          },
          error: function (xhr) {
            console.log('Error: ' + xhr.responseJSON.message);

            //Show swal error
            Swal.fire({
              icon: 'error',
              title: `Error!`,
              text: xhr.responseJSON.message,
              customClass: {
                confirmButton: 'btn btn-danger'
              }
            });
          }
        });
      });
    });

    // Edit Device
    window.editDevice = function (id) {


      $.ajax({
        url: baseUrl + `dynamicqrattendance/getByIdAjax/${id}`,
        type: 'GET',
        success: function (response) {
          console.log(response);
          var data = response.data;
          // Populate form
          $('#id').val(data.id);
          $('#name').val(data.name);
          $('#uniqueId').val(data.uniqueId);
          $('#pin').val(data.pin);
          $('#qrUpdateInterval').val(data.qrUpdateInterval);
          $('#deviceType').val(data.deviceType).trigger('change');
          $('#offcanvasAddDeviceLabel').text('Update Device');

        },
        error: function (xhr) {
          console.log('Error: ' + xhr.responseJSON.message);
        }
      });

    };

    // Delete Device
    window.deleteDevice = function (id) {
      Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonText: 'Yes, delete it!',
        customClass: {
          confirmButton: 'btn btn-primary me-3',
          cancelButton: 'btn btn-label-secondary'
        },
        buttonsStyling: false
      }).then(function (result) {
        if (result.value) {
          $.ajax({
            url: `/dynamicqrattendance/${id}`,
            type: 'DELETE',
            data: {_token: '{{ csrf_token() }}'},
            success: function (response) {
              $('#deviceTable').DataTable().ajax.reload();

              // Show success message
              Swal.fire({
                icon: 'success',
                title: `Successfully deleted!`,
                text: 'Device deleted successfully',
                customClass: {
                  confirmButton: 'btn btn-success'
                }
              });
            },
            error: function (xhr) {
              console.log('Error: ' + xhr.responseJSON.message);
              // Show error message
              Swal.fire({
                icon: 'error',
                title: `Error!`,
                text: 'Error deleting device',
                customClass: {
                  confirmButton: 'btn btn-danger'
                }
              });
            }
          });
        }
      });
    };
  </script>
@endsection
