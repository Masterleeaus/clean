<?php

namespace Modules\DynamicQrAttendance\Database\Seeders;

use Illuminate\Database\Seeder;

class DynamicQrAttendanceDatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // $this->call([]);
    }
}
