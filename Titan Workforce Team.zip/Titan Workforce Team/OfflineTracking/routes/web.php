<?php

use Illuminate\Support\Facades\Route;
use Modules\OfflineTracking\App\Http\Controllers\ReportController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['web', 'auth'])->group(function () {
    Route::prefix('offlinetracking')->name('offlinetracking.')->group(function () {

        // Report Routes
        Route::prefix('reports')->name('reports.')->group(function () {
            Route::get('/route-analysis', [ReportController::class, 'routeAnalysis'])->name('route-analysis');
        });
    });
});
