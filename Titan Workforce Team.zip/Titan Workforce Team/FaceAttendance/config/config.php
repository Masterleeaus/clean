<?php

return [
    'name' => 'FaceAttendance',
];
