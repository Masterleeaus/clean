# Payroll Fix PASS45

Fixed migration failure:

`SQLSTATE[HY000]: no such column: allowed_permissions`

## Fix
Updated:
`2021_08_25_092728_alter_allowed_permission_column_in_payroll_permissions_table.php`

The migration now:
- creates `permissions.allowed_permissions` when missing
- uses a nullable/default-safe integer column
- guards all updates with `Schema::hasColumn()`
- remains safe on reruns

Run after extracting:

```bash
php artisan optimize:clear
php artisan migrate --force
```
