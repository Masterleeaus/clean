# Payroll SQLite Compatibility PASS47

Fixed:
- MySQL `CHANGE` syntax failures
- ENUM alteration failures
- SQLite unsupported alter-column migrations

## Strategy
- Wrapped legacy alter migrations with SQLite driver guards
- Removed unsafe raw ALTER CHANGE statements
- Added compatibility migration shim

Safe for:
- SQLite
- MySQL
- repeated reruns (`migrate --force`)
