# Payroll Fix PASS44

Fixed migration failure:

`Undefined constant App\Models\Permission::ALL_4_ADDED_1_OWNED_2_BOTH_3_NONE_5`

## What changed
- Scanned 45 Payroll migrations.
- Replaced legacy undefined Permission constants in Payroll migrations with stable integer fallback values.
- Converted direct seed inserts to `insertOrIgnore()` where detected.
- Preserved existing Payroll module files.

## Patched files
- `TitanPro-main/Modules/Payroll/Database/Migrations/2021_08_25_092728_alter_allowed_permission_column_in_payroll_permissions_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_02_16_124407_fix_payroll_permissions.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_09_02_000000_add_company_id_payroll_module_table.php`

Run after extracting:

```bash
php artisan optimize:clear
php artisan migrate --force
```
