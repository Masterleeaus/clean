<?php

// Payroll macros.
