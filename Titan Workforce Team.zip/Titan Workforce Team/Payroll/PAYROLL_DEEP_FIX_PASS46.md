# Payroll Deep Fix PASS46

You were right: PASS45 only fixed the immediate `allowed_permissions` error. This pass scans and patches the Payroll module more broadly.

## Current observed failure fixed
`Call to undefined method App\Models\User::allAdmins()`

## Deep fixes applied
- Replaced legacy `User::allAdmins()` calls inside Payroll migrations with safe direct queries.
- Replaced undefined legacy `Permission::*` constants with stable numeric fallback values.
- Ensured `permissions.allowed_permissions` is created before updates.
- Added `permissions.guard_name` compatibility when missing.
- Added compatibility migration for legacy Payroll ownership columns:
  - `owned_by`
  - `created_by`
  - `updated_by`
- Added `Schema::hasTable()` guards to create migrations.
- Added `Schema::hasColumn()` guards to add-column migrations.
- Added defaults/nullability for SQLite-safe add-column operations.
- Converted duplicate seed inserts to `insertOrIgnore()`.

## Scanned migrations
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_10_01_184956_create_salary_groups_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_10_07_191322_create_salary_components_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_10_07_192042_create_salary_tds_table_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_10_10_114655_create_salary_group_components_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_10_10_115749_create_employee_salary_groups_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_10_18_095840_create_salary_slips_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_10_18_111743_create_employee_monthly_salary_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_10_22_124159_add_columns_salary_slips_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_10_23_181854_create_payroll_settings_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_10_30_121810_add_tds_column_salary_slips_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_11_13_084620_add_gross_salary_column_salary_slips_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2019_11_21_122601_add_purchase_code_column_payroll_settings_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2021_08_25_092728_alter_allowed_permission_column_in_payroll_permissions_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2021_08_28_123557_add_owned_by_columns_payrolls.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2021_09_12_061155_payroll_custom_field_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2021_09_21_073111_create_payroll_cycle_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2021_09_21_081203_create_employee_payroll_cycle_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_02_16_124407_fix_payroll_permissions.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_08_18_071222_alter_in_salary_components_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_08_24_093601_add_column_in_employee_monthly_salaries_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_08_24_095802_create_employee_variable_commponent_salaries_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_09_01_000000_create_payroll_global_settings.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_09_02_000000_add_company_id_payroll_module_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_09_15_051422_add_column_in_payroll_settings_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_09_21_061658_add_column_weekly_in_salary_components_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_10_18_061658_add_column_fixed_salary_slip_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_11_24_071222_alter_currency_id_payroll_setting_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_12_21_071222_add_currency_id_column_in_salary_slip_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2023_01_01_071222_fix_currency_id_column_in_salary_slip_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2023_01_01_071222_payroll_cycle_insert_users_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2023_01_01_071222_salary_tds_company_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2023_03_31_071222_expenses_id_column_in_salary_slip_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2023_04_04_090201_add_column_fixed_allowance_in_employee_monthly_salaries_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2023_11_02_094141_payroll_notify_update_global_settings.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2023_12_19_091940_purchased_on_payroll_setting_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2024_02_16_110403_add_current_salary_column.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2024_07_05_110403_add_hourly_rate_column.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2024_09_23_110403_company_id_in_monthly_salary.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2024_10_23_110403_add_expenses_id_column.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2024_11_06_110403_add_additional_earning_json.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2026_05_13_000001_create_payroll_runs_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2026_05_13_000002_create_payroll_run_approvals_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2026_05_13_000003_create_payroll_audit_logs_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2026_05_13_000004_create_payroll_payslip_delivery_tables.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2026_05_13_000005_create_payroll_period_locks_table.php`

## Patched files
- `TitanPro-main/Modules/Payroll/Database/Migrations/2021_08_25_092728_alter_allowed_permission_column_in_payroll_permissions_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2021_08_28_123557_add_owned_by_columns_payrolls.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_02_16_124407_fix_payroll_permissions.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_09_02_000000_add_company_id_payroll_module_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2022_12_21_071222_add_currency_id_column_in_salary_slip_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2023_01_01_071222_fix_currency_id_column_in_salary_slip_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2023_01_01_071222_payroll_cycle_insert_users_table.php`
- `TitanPro-main/Modules/Payroll/Database/Migrations/2026_05_19_999999_payroll_legacy_compatibility_patch.php`

## Deploy
Extract over `Modules/Payroll`, then run:

```bash
php artisan optimize:clear
php artisan migrate --force
```
