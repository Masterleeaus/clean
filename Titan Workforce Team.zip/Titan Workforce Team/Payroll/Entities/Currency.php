<?php

namespace Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;

class Currency extends Model
{
    protected $table = 'currencies';
    protected $guarded = [];
}
