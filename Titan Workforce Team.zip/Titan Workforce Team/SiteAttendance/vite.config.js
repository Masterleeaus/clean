import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';

export default defineConfig({
    build: {
        outDir: '../../public/build-siteattendance',
        emptyOutDir: true,
        manifest: true,
    },
    plugins: [
        laravel({
            publicDirectory: '../../public',
            buildDirectory: 'build-siteattendance',
            input: [
                __dirname + '/resources/assets/sass/app.scss',
                __dirname + '/resources/assets/js/app.js',
                __dirname + '/resources/assets/js/index.js',
                __dirname + '/resources/assets/js/create.js',
                __dirname + '/resources/assets/js/show.js',
                __dirname + '/resources/assets/js/edit.js',
            ],
            refresh: true,
        }),
    ],
});
