<?php

return [
    'name' => 'SiteAttendance',
];
