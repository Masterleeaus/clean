<?php

use Illuminate\Support\Facades\Route;
use Modules\SiteAttendance\App\Http\Controllers\SiteAttendanceController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['web', 'auth'])->group(function () {
    Route::prefix('siteattendance')->name('siteattendance.')->group(function () {
        // Main CRUD routes
        Route::get('/', [SiteAttendanceController::class, 'index'])->name('index');
        Route::get('/datatable', [SiteAttendanceController::class, 'datatable'])->name('datatable');
        Route::get('/create', [SiteAttendanceController::class, 'create'])->name('create');
        Route::post('/', [SiteAttendanceController::class, 'store'])->name('store');
        Route::get('/{id}', [SiteAttendanceController::class, 'show'])->name('show');
        Route::get('/{id}/edit', [SiteAttendanceController::class, 'edit'])->name('edit');
        Route::put('/{id}', [SiteAttendanceController::class, 'update'])->name('update');
        Route::delete('/{id}', [SiteAttendanceController::class, 'destroy'])->name('destroy');
        Route::post('/{id}/toggle-status', [SiteAttendanceController::class, 'toggleStatus'])->name('toggleStatus');

        // Attendance configuration routes
        Route::get('/groups/geofence', [SiteAttendanceController::class, 'getGeofenceGroups'])->name('getGeofenceGroups');
        Route::get('/groups/ip-address', [SiteAttendanceController::class, 'getIpAddressGroups'])->name('getIpAddressGroups');
        Route::get('/groups/qr-code', [SiteAttendanceController::class, 'getQrCodeGroups'])->name('getQrCodeGroups');

        Route::post('/attendance/enable', [SiteAttendanceController::class, 'enableAttendance'])->name('enableAttendance');
        Route::post('/attendance/disable/{id}', [SiteAttendanceController::class, 'disableAttendance'])->name('disableAttendance');
    });
});
