<?php

return [
    'name' => 'QRAttendance',
];
