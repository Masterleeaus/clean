<?php

use Illuminate\Support\Facades\Route;
use Modules\QRAttendance\App\Http\Controllers\QRAttendanceController;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::middleware(['web', 'auth'])->group(function () {
    // AJAX endpoints
    Route::get('qrcode/indexAjax', [QRAttendanceController::class, 'indexAjax'])->name('qrcode.indexAjax');
    Route::get('qrcode/getByIdAjax/{id}', [QRAttendanceController::class, 'getByIdAjax'])->name('qrcode.getByIdAjax');
    Route::post('qrcode/addOrUpdateAjax', [QRAttendanceController::class, 'addOrUpdateAjax'])->name('qrcode.addOrUpdateAjax');
    Route::delete('qrcode/deleteAjax/{id}', [QRAttendanceController::class, 'deleteAjax'])->name('qrcode.deleteAjax');
    Route::post('qrcode/changeStatusAjax/{id}', [QRAttendanceController::class, 'changeStatusAjax'])->name('qrcode.changeStatusAjax');

    // Resource routes
    Route::resource('qrcode', QRAttendanceController::class)->names('qrcode');

    // Additional routes
    Route::post('qrcode/addQrCode', [QRAttendanceController::class, 'addQrCode'])->name('qrcode.addQrCode');
    Route::post('qrcode/changeStatus', [QRAttendanceController::class, 'changeStatus'])->name('qrcode.changeStatus');
    Route::post('qrcode/changeStatusItem', [QRAttendanceController::class, 'changeStatusItem'])->name('qrcode.changeStatusItem');
    Route::post('qrcode/update', [QRAttendanceController::class, 'update'])->name('qrcode.updatePost');

    // QR Code management routes
    Route::get('qrcode/qrcode/{id}', [QRAttendanceController::class, 'getQrCode'])->name('qrcode.getQrCode');
    Route::put('qrcode/qrcode/{id}', [QRAttendanceController::class, 'updateQrCode'])->name('qrcode.updateQrCode');
    Route::delete('qrcode/qrcode/{id}', [QRAttendanceController::class, 'destroyQrCode'])->name('qrcode.deleteQrCode');
    Route::get('qrcode/downloadQrCode/{id}', [QRAttendanceController::class, 'downloadQrCode'])->name('qrcode.downloadQrCode');
});
