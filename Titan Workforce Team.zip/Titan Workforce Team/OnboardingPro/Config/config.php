<?php

return [
    'name' => 'OnboardingPro',
];
